"""Replay the observed 3.016 mm drift under full-flow and diagnostic policies."""
import json
from pathlib import Path
import tempfile
import unittest
from s1_control.command_continuity import CommandTrace
from scripts.run_go2_visual_alignment import configure_alignment_downward_trace, load_alignment_config

class Commander:
    last_snapshot=None
    def __init__(self):self.calls=[]
    def __call__(self,arm,target):
        self.calls.append(list(target))
        self.last_snapshot={'measured_q_rad':[0,0,-.0030161063192145026,0,0,0]}
        return 'command_forwarded'

class AlignmentDriftMonitorTests(unittest.TestCase):
    def test_current_full_flow_records_observed_drift_without_aborting(self):
        root=Path(__file__).resolve().parents[1]
        _,cfg=load_alignment_config(root/'config/go2_dual_white_light_full_flow_simplified_v1.json')
        self.assertNotIn('maximum_live_alignment_downward_mm',cfg['runtime'])
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'trace.jsonl';commander=Commander();trace=CommandTrace(commander,path,sample_period_s=0)
            policy=configure_alignment_downward_trace(trace,cfg['runtime'],lambda q:1000*q[2],0)
            self.assertEqual(policy['mode'],'monitor_only')
            for phase in ['support_tangent_center_alignment','support_tangent_residual_alignment','alignment_endpoint_pass_1_trim_1']:
                trace.phase=phase
                self.assertEqual(trace(None,[.01]*6),'command_forwarded')
            trace.close();rows=[json.loads(x) for x in path.read_text().splitlines()]
            self.assertEqual(len(rows),3)
            self.assertEqual(commander.calls,[[.01]*6]*3)
            for row in rows:
                self.assertAlmostEqual(row['support_normal_displacement_mm'],-3.0161063192145026)
                self.assertFalse(row['live_downward_guard_triggered'])
                self.assertFalse(row['live_downward_guard_armed'])
                self.assertTrue(row['live_downward_monitor_only'])

    def test_center_diagnostic_still_aborts_on_the_same_observed_drift(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'trace.jsonl';trace=CommandTrace(Commander(),path)
            policy=configure_alignment_downward_trace(trace,{'maximum_live_alignment_downward_mm':3},lambda q:1000*q[2],0)
            self.assertEqual(policy['mode'],'diagnostic_abort')
            trace.phase='support_tangent_center_alignment'
            with self.assertRaisesRegex(RuntimeError,'downward displacement'):trace(None,[.01]*6)
            trace.close();row=json.loads(path.read_text().splitlines()[-1])
            self.assertTrue(row['live_downward_guard_triggered'])
            self.assertTrue(row['live_downward_guard_armed'])
            self.assertFalse(row['live_downward_monitor_only'])

    def test_full_flow_mode_replaces_a_previously_configured_diagnostic_limit(self):
        with tempfile.TemporaryDirectory() as folder:
            trace=CommandTrace(Commander(),Path(folder)/'trace.jsonl')
            trace.set_downward_guard(lambda q:1000*q[2],0,3)
            configure_alignment_downward_trace(trace,{'simplified_full_flow':True},lambda q:1000*q[2],0)
            trace.phase='support_tangent_center_alignment';trace(None,[0]*6)
            trace.clear_downward_guard();trace.close()

if __name__=='__main__':unittest.main()
