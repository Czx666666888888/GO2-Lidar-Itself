# -*- coding: utf-8 -*-
"""不访问S1硬件的连续尺寸接触判定回归测试。"""
from __future__ import annotations

import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from s1_control.adaptive_grasp import (
    ContactDetector,
    EmptyProbeBaseline,
    ProbeSample,
    load_empty_baseline,
    load_probe_parameters,
    save_empty_baseline,
    settled_window,
)


def free_samples(count, parameters):
    samples = []
    for index in range(count):
        command = parameters.target_gap_mm
        tracking_lag = 0.25 + 0.03 * (index % 3)
        torque = 0.003 + 0.0005 * ((index % 5) - 2)
        samples.append(
            ProbeSample(
                t_s=index / parameters.hz,
                command_gap_mm=command,
                actual_gap_mm=command + tracking_lag,
                gripper_tau_nm=torque,
            )
        )
    return samples


class AdaptiveGraspTests(unittest.TestCase):
    def setUp(self):
        self.parameters = load_probe_parameters()
        self.baseline = EmptyProbeBaseline.from_samples(
            free_samples(150, self.parameters),
            self.parameters,
        )

    def test_config_has_safe_initial_envelope(self):
        self.assertEqual(self.parameters.start_gap_mm, 65.0)
        self.assertEqual(self.parameters.target_gap_mm, 20.0)
        self.assertEqual(self.parameters.probe_force_nm, 0.20)
        self.assertEqual(self.parameters.secure_force_nm, 0.30)
        self.assertEqual(self.parameters.secure_preload_command_mm, 6.0)
        self.assertEqual(self.parameters.timeout_s, 3.0)
        self.assertEqual(self.parameters.debounce_samples, 5)
        self.assertLessEqual(
            self.parameters.probe_force_nm,
            self.parameters.secure_force_nm,
        )

    def test_probe_force_cannot_exceed_secure_force(self):
        invalid = replace(self.parameters, secure_force_nm=0.19)
        with self.assertRaisesRegex(ValueError, "不得高于"):
            invalid.validate()

    def test_free_motion_does_not_report_contact(self):
        detector = ContactDetector(self.parameters, self.baseline)
        decisions = [
            detector.update(sample)
            for sample in free_samples(120, self.parameters)
        ]
        self.assertFalse(any(decision.detected for decision in decisions))

    def test_contact_requires_debounced_tracking_and_torque(self):
        detector = ContactDetector(self.parameters, self.baseline)
        decisions = []
        for index in range(self.parameters.debounce_samples):
            decisions.append(
                detector.update(
                    ProbeSample(
                        t_s=index / self.parameters.hz,
                        command_gap_mm=self.parameters.target_gap_mm,
                        actual_gap_mm=52.8,
                        gripper_tau_nm=self.baseline.tau_center_nm + 0.03,
                    )
                )
            )
        self.assertFalse(any(item.detected for item in decisions[:-1]))
        self.assertTrue(decisions[-1].detected)
        self.assertAlmostEqual(decisions[-1].contact_gap_mm, 52.8)
        self.assertTrue(decisions[-1].tracking_hit)
        self.assertTrue(decisions[-1].torque_hit)

    def test_single_contact_spike_is_rejected(self):
        detector = ContactDetector(self.parameters, self.baseline)
        spike = detector.update(
            ProbeSample(
                t_s=0.0,
                command_gap_mm=self.parameters.target_gap_mm,
                actual_gap_mm=50.0,
                gripper_tau_nm=self.baseline.tau_center_nm + 0.05,
            )
        )
        self.assertFalse(spike.detected)
        recovery = detector.update(
            ProbeSample(
                t_s=1.0 / self.parameters.hz,
                command_gap_mm=self.parameters.target_gap_mm,
                actual_gap_mm=self.parameters.target_gap_mm + 0.2,
                gripper_tau_nm=self.baseline.tau_center_nm,
            )
        )
        self.assertEqual(recovery.consecutive_samples, 0)
        self.assertFalse(recovery.detected)

    def test_stall_can_confirm_contact_when_torque_feedback_is_quiet(self):
        detector = ContactDetector(self.parameters, self.baseline)
        decision = None
        total = self.parameters.debounce_samples + 2
        for index in range(total):
            decision = detector.update(
                ProbeSample(
                    t_s=index / self.parameters.hz,
                    command_gap_mm=self.parameters.target_gap_mm,
                    actual_gap_mm=52.0,
                    gripper_tau_nm=self.baseline.tau_center_nm,
                )
            )
        self.assertTrue(decision.detected)
        self.assertFalse(decision.torque_hit)
        self.assertTrue(decision.stall_hit)

    def test_baseline_round_trip_and_parameter_binding(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "baseline.json"
            save_empty_baseline(path, self.baseline)
            loaded = load_empty_baseline(path)
        self.assertEqual(loaded, self.baseline)
        loaded.assert_compatible(self.parameters)

        changed = replace(self.parameters, timeout_s=4.0)
        with self.assertRaisesRegex(ValueError, "必须重做空载标定"):
            loaded.assert_compatible(changed)

    def test_baseline_rejects_too_few_samples(self):
        with self.assertRaisesRegex(ValueError, "至少需要"):
            EmptyProbeBaseline.from_samples(
                free_samples(10, self.parameters),
                self.parameters,
            )

    def test_settled_window_rejects_motion_and_accepts_stationary_feedback(self):
        stable = free_samples(30, self.parameters)
        self.assertTrue(settled_window(stable, self.parameters))

        moving = [
            ProbeSample(
                t_s=index / self.parameters.hz,
                command_gap_mm=self.parameters.target_gap_mm,
                actual_gap_mm=50.0 - 0.1 * index,
                gripper_tau_nm=0.1,
            )
            for index in range(30)
        ]
        self.assertFalse(settled_window(moving, self.parameters))

    def test_contact_gap_is_continuous_not_a_size_class(self):
        for contact_gap in (29.0, 37.4, 40.0, 46.2, 50.0, 52.8):
            detector = ContactDetector(self.parameters, self.baseline)
            decision = None
            for index in range(self.parameters.debounce_samples):
                decision = detector.update(
                    ProbeSample(
                        t_s=index / self.parameters.hz,
                        command_gap_mm=self.parameters.target_gap_mm,
                        actual_gap_mm=contact_gap,
                        gripper_tau_nm=self.baseline.tau_center_nm + 0.03,
                    )
                )
            self.assertTrue(decision.detected)
            self.assertAlmostEqual(decision.contact_gap_mm, contact_gap)


if __name__ == "__main__":
    unittest.main()
