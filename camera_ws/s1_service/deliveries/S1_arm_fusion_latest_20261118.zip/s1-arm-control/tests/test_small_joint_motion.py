import importlib.util
import math
from pathlib import Path
import sys
import unittest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = PROJECT_ROOT / "scripts"
for path in (PROJECT_ROOT, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

SCRIPT_PATH = SCRIPT_DIR / "diagnose_small_joint_motion.py"
SPEC = importlib.util.spec_from_file_location(
    "diagnose_small_joint_motion_for_test", SCRIPT_PATH
)
module = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(module)


class SmallJointMotionTests(unittest.TestCase):
    def test_defaults_are_bounded_first_motion(self):
        args = module.parser().parse_args([])
        module.validate_args(args)
        self.assertEqual(args.j1_delta_rad, 0.02)
        self.assertEqual(args.v_max_rad_s, 0.05)
        self.assertEqual(args.teach_hz, 50.0)
        self.assertEqual(args.lock_sample_hz, 10.0)
        self.assertEqual(args.target_hold_s, 0.8)
        self.assertEqual(args.return_hold_s, 0.8)
        self.assertEqual(module.MOTION_SETTLE_SECONDS, 1.0)
        self.assertEqual(module.ENDPOINT_SETTLE_SECONDS, 0.5)

    def test_target_changes_only_j1_and_is_reversible(self):
        reference = [0.5, 1.0, 1.1, 0.7, -0.2, 0.1]
        target = module.build_j1_target(reference, 0.02)
        self.assertAlmostEqual(target[0], 0.52)
        self.assertEqual(target[1:], reference[1:])
        returned = list(target)
        returned[0] -= 0.02
        for actual, expected in zip(returned, reference):
            self.assertAlmostEqual(actual, expected)

    def test_target_rejects_excessive_or_negative_delta(self):
        with self.assertRaises(ValueError):
            module.build_j1_target([0.0] * 6, 0.03)
        with self.assertRaises(ValueError):
            module.build_j1_target([0.0] * 6, -0.01)

    def test_tcp_delta_reports_xyz_and_norms(self):
        result = module.tcp_delta_mm(
            [0.1, 0.2, 0.3, 0.0, 0.0, 0.0, 1.0],
            [0.103, 0.196, 0.301, 0.0, 0.0, 0.0, 1.0],
        )
        self.assertEqual([round(value, 6) for value in result["xyz_mm"]], [3.0, -4.0, 1.0])
        self.assertAlmostEqual(result["xy_norm_mm"], 5.0)
        self.assertAlmostEqual(result["norm_mm"], math.sqrt(26.0))

    def test_lock_summary_uses_median_and_span(self):
        rows = [[0.1, 0.2, 0.3, 0.4, 0.5, 0.6] for _ in range(4)]
        rows[-1][2] += 0.002
        summary = module.summarize_lock_rows(rows)
        self.assertEqual(summary["sample_count"], 4)
        self.assertEqual(summary["maximum_span_joint"], 3)
        self.assertAlmostEqual(summary["maximum_span_rad"], 0.002)


if __name__ == "__main__":
    unittest.main()
