import json
import unittest
import numpy as np
from run_go2_visual_alignment import (PROJECT_ROOT,load_alignment_config,load_wrist_servo_config,
    resolve_project_path,compute_alignment_plan,Kinematics,UrdfGravityModel,
    locate_official_gripper_urdf,densify_joint_path)
from plan_go2_multiview_scan import go2_envelope_check
from S1_SDK.hardware.collision import CollisionChecker

class ResidualCorrectionTests(unittest.TestCase):
    def test_rebased_4946mm_residual_generates_real_checked_correction(self):
        d=json.loads((PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261114-145914/run.json").read_text())
        r=d["residual_correction"]
        _,cfg=load_alignment_config("config/go2_left_full_flow_size_adaptive_20261112_v1.json")
        loaded=load_wrist_servo_config(resolve_project_path(cfg["wrist_servo_config"]))
        loaded.record["validated_workspace"]["advisory_bounds"]=True
        cc=CollisionChecker("gripper")
        if cc.model is None:cc._load_model(gripper=True)
        options=dict(planning_start_q_rad=r["post_support_normal_rebase"]["measured_q_rad"],loaded=loaded,
            alignment=cfg["alignment"],tcp_kinematics=Kinematics(verbose=False),collision_checker=cc,
            tilt_model=UrdfGravityModel.from_file(locate_official_gripper_urdf()),
            applied_support_up=r["support_normal_update"]["applied_support_up_normal_base"],
            side_scale=0,torque_limits=[1.2,.37,.32,.2,.2,.1])
        old=compute_alignment_plan(r["planning"],**options)
        corrected=compute_alignment_plan(r["planning"],**options,force_correction=True)
        self.assertEqual(len(old["alignment_joint_path"]),1)
        self.assertGreater(len(corrected["alignment_joint_path"]),1)
        self.assertEqual(corrected["cartesian_path"]["convergence_mm"],5)
        self.assertEqual(cfg["alignment"]["success_tangent_error_mm"],5)
        self.assertGreater(np.linalg.norm(np.array(corrected["cartesian_path"]["tcp_poses_xyz_xyzw"][-1][:3])-np.array(corrected["cartesian_path"]["tcp_poses_xyz_xyzw"][0][:3])),.004)
        self.assertEqual(corrected["collision"]["active_collision_count"],0)
        deployment=json.loads(resolve_project_path(cfg["deployment_plan"]).read_text())
        source=json.loads(resolve_project_path(deployment["source_config"]).read_text())
        body=go2_envelope_check(cc,densify_joint_path(corrected["alignment_joint_path"],.005),source)
        self.assertTrue(body["pass"])

if __name__=="__main__":unittest.main()
