import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from s1_control.box_dump import load_dump_plan,dump_steps,run_dump
from s1_control.integration import ArmIntegrationSession,ZERO_Q
from test_arm_integration import FakeArm

ROOT=Path(__file__).resolve().parents[1]

def taught():
    p=json.loads((ROOT/'config/go2_hinged_box_dump.json').read_text())
    p.update(approach_path_q_rad=[ZERO_Q,[.1]*6,[.2]*6],tip_path_q_rad=[[.2]*6,[.25]*6,[.3]*6],handle_closed_gap_mm=18,restore_release_fraction=1.0)
    return p

class DumpArm(FakeArm):
    def __init__(self, fail=None):
        super().__init__();self.moves=[];self.fail=fail
    def move_waypoints(self,path,label,**kwargs):
        self.moves.append((label,copy.deepcopy(path),kwargs))
        if label==self.fail:return 'simulated tracking fault'
        self.pos=list(path[-1])

class Grip:
    max_gap_mm=102.2
    def __init__(self,arm):self.commands=[]
    def mm_to_fb(self,gap):return gap
    def command_mm(self,gap,force):self.commands.append((gap,force))

class BoxDumpTests(unittest.TestCase):
    def test_uninstalled_plan_not_executable(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'uninstalled.json'
            plan=taught();plan['approach_path_q_rad']=[];plan['tip_path_q_rad']=[]
            path.write_text(json.dumps(plan))
            with self.assertRaisesRegex(ValueError,'not taught'):load_dump_plan(path)

    def test_taught_path_reverse_and_release_order(self):
        steps=dump_steps(taught())
        self.assertEqual(steps[5]['path'],list(reversed(steps[3]['path'])))
        self.assertTrue(all(s['closed'] for s in steps[2:6]))
        self.assertEqual(steps[6]['name'],'dump_handle_release')
        self.assertEqual(steps[7]['path'][-1],ZERO_Q)

    def test_complete_task_returns_zero_and_preserves_grasp_queue(self):
        arm=DumpArm();session=ArmIntegrationSession(arm);session.ready()
        try:
            self.assertTrue(session.request_task('dump',taught())['accepted'])
            self.assertFalse(session.request_grasp()['accepted'])
            self.assertEqual(session.jobs.get()[0],'dump')
            def hold(arm,q,duration,label,**options):
                self.assertEqual(session.snapshot()['state'],'DUMPING')
                arm.pos=list(q)
            with tempfile.TemporaryDirectory() as directory,patch('builtins.input',side_effect=AssertionError('no keyboard')):
                code=session.run_task(lambda active:run_dump(active,taught(),log_root=directory,gripper_factory=Grip,hold_function=hold),task='dump')
                self.assertEqual(code,0)
                result=json.loads(next(Path(directory).glob('*/run.json')).read_text())
                self.assertIsNone(result['unload_confirmed'])
            self.assertEqual(session.snapshot()['state'],'ZERO_HOLD')
            self.assertTrue(session.request_grasp()['accepted'])
            self.assertEqual(arm.moves[1][2]['grip_cmd'],18)
            self.assertEqual(arm.moves[2][2]['grip_cmd'],18)
            self.assertEqual(arm.disabled,0)
        finally:session.stop_hold()

    def test_tip_failure_keeps_handle_and_does_not_release_or_return(self):
        arm=DumpArm(fail='dump_box_restore');session=ArmIntegrationSession(arm);session.ready()
        try:
            with tempfile.TemporaryDirectory() as directory:
                code=session.run_task(lambda active:run_dump(active,taught(),log_root=directory,gripper_factory=Grip,hold_function=lambda *a,**k:None),task='dump')
            self.assertEqual(code,1)
            self.assertEqual(session.snapshot()['state'],'FAULT_HOLD')
            self.assertEqual(session._grip[1],18)
            self.assertEqual([m[0] for m in arm.moves],['dump_handle_approach','dump_tip','dump_box_restore'])
            self.assertFalse(session.request_grasp()['accepted'])
        finally:session.stop_hold()

    def test_taught_join_and_handle_gap_required(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'plan.json';data=taught()
            p.write_text(json.dumps(data));self.assertEqual(load_dump_plan(p)['handle_closed_gap_mm'],18)
            data['tip_path_q_rad'][0]=[.4]*6;p.write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError,'handle grasp pose'):load_dump_plan(p)

    def test_early_release_keeps_path_join_and_opens_before_restore_end(self):
        plan=taught();plan['restore_release_fraction']=.95
        steps=dump_steps(plan)
        restore=steps[5];release=steps[6];remaining=steps[7]
        self.assertEqual(remaining['name'],'dump_restore_released')
        self.assertFalse(remaining['closed'])
        self.assertEqual(restore['path'][-1],release['q'])
        self.assertEqual(release['q'],remaining['path'][0])
        self.assertEqual(remaining['path'][-1],plan['tip_path_q_rad'][0])
        self.assertNotEqual(release['q'],plan['tip_path_q_rad'][0])

    def test_recording_pauses_are_removed_before_sdk_replay(self):
        from s1_control.arm import _validated_joint_path
        plan=taught();plan['restore_release_fraction']=.95
        plan['approach_path_q_rad'].insert(1,list(plan['approach_path_q_rad'][0]))
        plan['tip_path_q_rad'].insert(1,list(plan['tip_path_q_rad'][0]))
        plan['tip_path_q_rad'].append(list(plan['tip_path_q_rad'][-1]))
        original=copy.deepcopy(plan)
        for step in dump_steps(plan):
            if step['kind']=='move':_validated_joint_path(step['path'])
        self.assertEqual(plan,original)

    def test_tip_and_restore_have_independent_speeds(self):
        plan=taught();plan.update(tip_speed_rad_s=1.0,restore_speed_rad_s=1.5,restore_release_fraction=.8)
        steps={s['name']:s for s in dump_steps(plan)}
        self.assertEqual(steps['dump_tip']['speed'],1.0)
        self.assertEqual(steps['dump_box_restore']['speed'],1.5)
        self.assertEqual(steps['dump_restore_released']['speed'],1.5)
