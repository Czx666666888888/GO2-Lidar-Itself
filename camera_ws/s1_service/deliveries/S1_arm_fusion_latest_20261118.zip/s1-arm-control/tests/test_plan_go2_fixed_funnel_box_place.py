import unittest

import numpy as np

from scripts.plan_go2_fixed_funnel_box_place import (
    box_frame,
    payload_design_envelope,
    relative_box_coordinates_mm,
    split_joint_segment,
)


class PlanGo2FixedFunnelBoxPlaceTests(unittest.TestCase):
    def calibration(self):
        return {
            "support_up_normal_base": [0.0, 0.0, 1.0],
            "release": {
                "tcp_xyz_quat_xyzw": [0.3, 0.0, 0.1, 0.0, 0.0, 0.0, 1.0]
            },
        }

    def test_box_frame_uses_go2_rear_and_right_axes(self):
        frame = box_frame(self.calibration())
        self.assertTrue(np.allclose(frame["rear_axis"], [1.0, 0.0, 0.0]))
        self.assertTrue(np.allclose(frame["right_axis"], [0.0, 1.0, 0.0]))
        coordinates = relative_box_coordinates_mm([0.31, -0.02, 0.145], frame)
        self.assertTrue(np.allclose(coordinates, [10.0, -20.0, 45.0]))

    def test_joint_segment_is_bounded_and_reaches_endpoint(self):
        rows = split_joint_segment(
            "transport",
            [0.0] * 6,
            [1.0, 0.2, 0.0, 0.0, 0.0, 0.0],
            0.45,
        )
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[-1]["name"], "transport")
        self.assertTrue(np.allclose(rows[-1]["q"], [1.0, 0.2, 0.0, 0.0, 0.0, 0.0]))
        previous = np.zeros(6)
        for row in rows:
            current = np.asarray(row["q"])
            self.assertLessEqual(float(np.max(np.abs(current - previous))), 0.45)
            previous = current

    def test_payload_design_envelope_applies_dynamic_factor(self):
        design_torque, fraction = payload_design_envelope(
            [0.1, -0.2, 0.0, 0.4, 0.05, 0.0],
            [10.0] * 6,
            2.0,
        )
        self.assertTrue(
            np.allclose(design_torque, [0.2, 0.4, 0.0, 0.8, 0.1, 0.0])
        )
        self.assertTrue(
            np.allclose(fraction, [0.02, 0.04, 0.0, 0.08, 0.01, 0.0])
        )

    def test_payload_design_envelope_rejects_factor_below_one(self):
        with self.assertRaisesRegex(ValueError, ">= 1.0"):
            payload_design_envelope([0.0] * 6, [10.0] * 6, 0.5)


if __name__ == "__main__":
    unittest.main()
