import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from scripts.execute_go2_fixed_funnel_box_empty_route import (
    mount_record_with_lower_route_scale,
    route_names,
    validate_route_shape,
    verify_box_artifacts,
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Go2FixedFunnelBoxEmptyRouteTests(unittest.TestCase):
    def route(self):
        return [
            {"name": name, "q": [0.0] * 6}
            for name in (
                "rear_ready",
                "box_transport_reference_01",
                "box_transport_reference_02",
                "box_transport_reference",
                "box_opening_hover",
                "box_release",
            )
        ]

    def test_route_shape_accepts_commissioned_sequence(self):
        route = self.route()
        validate_route_shape(route)
        self.assertEqual(route_names(route)[-1], "box_release")

    def test_route_shape_rejects_missing_opening_hover(self):
        route = self.route()
        del route[-2]
        with self.assertRaisesRegex(ValueError, "route shape"):
            validate_route_shape(route)

    def test_lower_route_scale_is_scoped_and_does_not_mutate_mount(self):
        mount = {"diagnostic": {"allowed_scale_steps": [0.25, 0.5, 0.75, 1.0]}}
        scoped, override = mount_record_with_lower_route_scale(mount, 0.20)
        self.assertEqual(mount["diagnostic"]["allowed_scale_steps"][0], 0.25)
        self.assertEqual(scoped["diagnostic"]["allowed_scale_steps"][0], 0.20)
        self.assertEqual(override["torque_direction"], "reduced_only")

    def test_unapproved_higher_route_scale_is_rejected(self):
        mount = {"diagnostic": {"allowed_scale_steps": [0.25, 0.5, 0.75, 1.0]}}
        with self.assertRaisesRegex(ValueError, "lower than"):
            mount_record_with_lower_route_scale(mount, 0.30)

    def test_report_must_bind_current_300g_plan(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            box = root / "box.json"
            deployment = root / "deployment.json"
            deployment_report = root / "deployment_report.json"
            mount = root / "mount.json"
            for path, value in (
                (box, {"payload": {"maximum_target_mass_g": 300.0}}),
                (deployment, {}),
                (deployment_report, {}),
                (mount, {}),
            ):
                path.write_text(json.dumps(value), encoding="utf-8")
            plan_path = root / "plan.json"
            report_path = root / "report.json"
            plan = {
                "mode": "go2_fixed_funnel_box_place",
                "status": "candidate_pending_empty_route_physical_validation",
                "bindings": {},
            }
            for name, path in (
                ("box_calibration", box),
                ("deployment_plan", deployment),
                ("deployment_collision_report", deployment_report),
                ("mount_config", mount),
            ):
                plan["bindings"][name] = str(path)
                plan["bindings"][f"{name}_sha256"] = sha(path)
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            report = {
                "status": "OFFLINE_BOX_ROUTE_PASS",
                "source_plan_sha256": sha(plan_path),
                "self_collision_ok": True,
                "floor_contact_ok": True,
                "box_payload_envelope_ok": True,
                "tilt_torque_cap_ok": True,
                "payload_gravity_model": {
                    "mass_kg": 0.3,
                    "dynamic_design_factor": 2.0,
                    "passed": True,
                },
            }
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with mock.patch(
                "scripts.execute_go2_fixed_funnel_box_empty_route.verify_bound_report"
            ):
                loaded_plan, _, _, _ = verify_box_artifacts(plan_path, report_path)
            self.assertEqual(loaded_plan["mode"], "go2_fixed_funnel_box_place")

            report["payload_gravity_model"]["mass_kg"] = 0.04
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "300g"):
                verify_box_artifacts(plan_path, report_path)


if __name__ == "__main__":
    unittest.main()
