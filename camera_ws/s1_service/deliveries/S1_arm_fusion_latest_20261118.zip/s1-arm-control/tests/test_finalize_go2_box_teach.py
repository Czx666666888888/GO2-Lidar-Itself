import math
from pathlib import Path
import tempfile
import unittest

from scripts.finalize_go2_box_teach import (
    build_record,
    projected_square_width_mm,
    support_up_from_mount,
)


class FinalizeGo2BoxTeachTests(unittest.TestCase):
    def mount(self):
        return {
            "mount_measurement": {
                "rear_edge_lower_deg": 5.1,
                "left_right_tilt_deg": 4.0,
                "left_right_tilt_direction": "Go2 right side lower",
            }
        }

    @staticmethod
    def event(q):
        return {
            "q_lock_rad": q,
            "maximum_span_rad": 0.000381,
            "joint_margin_deg": 25.0,
            "correction": {"clipped": False},
        }

    def publisher(self, mount_path):
        return {
            "mode": "tilt-locked-eye-in-hand-pose-publisher",
            "result": "COMPLETED_BY_OPERATOR",
            "mount_config": str(mount_path.resolve()),
            "compensation_scale": 0.25,
            "lock_events": [
                self.event([0.0] * 6),
                self.event([0.1] + [0.0] * 5),
            ],
        }

    def test_square_projection_exposes_sixty_millimetre_throat_risk(self):
        self.assertAlmostEqual(projected_square_width_mm(50.0, 0.0), 50.0)
        self.assertGreater(projected_square_width_mm(50.0, 15.0), 60.0)
        self.assertLess(projected_square_width_mm(50.0, 8.0), 60.0)

    def test_support_normal_contains_pitch_and_roll(self):
        normal = support_up_from_mount(self.mount())
        self.assertLess(normal[0], 0.0)
        self.assertLess(normal[1], 0.0)
        self.assertGreater(normal[2], 0.99)

    def test_two_pose_record_binds_geometry_and_payload(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mount_path = root / "mount.json"
            publisher_path = root / "publisher.json"
            mount_path.write_text("{}", encoding="utf-8")
            publisher_path.write_text("{}", encoding="utf-8")
            support = support_up_from_mount(self.mount())
            release = [0.1, 0.2, 0.3]
            hover = [
                release[index] + 0.1 * support[index]
                for index in range(3)
            ]
            quaternion = [0.0, math.sqrt(0.5), 0.0, math.sqrt(0.5)]

            def fk(q):
                xyz = release if q[0] == 0.0 else hover
                return [*xyz, *quaternion]

            record = build_record(
                self.publisher(mount_path),
                self.mount(),
                publisher_path=publisher_path,
                mount_path=mount_path,
                fk=fk,
                finger_rim_clearance_mm=10.0,
                payload_mass_g=300.0,
            )
        self.assertAlmostEqual(record["teach_geometry"]["normal_raise_mm"], 100.0)
        self.assertAlmostEqual(record["teach_geometry"]["tangent_drift_mm"], 0.0)
        self.assertEqual(record["box"]["top_opening_mm"], [90.0, 90.0])
        self.assertEqual(record["box"]["throat_opening_mm"], [60.0, 60.0])
        self.assertEqual(record["payload"]["maximum_target_mass_g"], 300.0)

    def test_rejects_missing_second_pose(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mount_path = root / "mount.json"
            publisher_path = root / "publisher.json"
            mount_path.write_text("{}", encoding="utf-8")
            publisher_path.write_text("{}", encoding="utf-8")
            publisher = self.publisher(mount_path)
            publisher["lock_events"] = publisher["lock_events"][:1]
            with self.assertRaisesRegex(ValueError, "exactly two locks"):
                build_record(
                    publisher,
                    self.mount(),
                    publisher_path=publisher_path,
                    mount_path=mount_path,
                    fk=lambda q: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
                    finger_rim_clearance_mm=10.0,
                    payload_mass_g=40.0,
                )

    def test_scan_reinterprets_second_pose_as_transport_reference(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mount_path = root / "mount.json"
            publisher_path = root / "publisher.json"
            scan_path = root / "scan.json"
            for path in (mount_path, publisher_path, scan_path):
                path.write_text("{}", encoding="utf-8")
            support = support_up_from_mount(self.mount())
            release = [0.1, 0.2, 0.3]
            transport = [
                release[index] + 0.14 * support[index]
                for index in range(3)
            ]
            opening = [
                release[index] + 0.045 * support[index]
                for index in range(3)
            ]
            quaternion = [0.0, math.sqrt(0.5), 0.0, math.sqrt(0.5)]
            opening_q = [0.05] + [0.0] * 5

            def fk(q):
                if q[0] == 0.0:
                    return [*release, *quaternion]
                if q[0] == 0.1:
                    return [*transport, *quaternion]
                return [*opening, *quaternion]

            scan = {
                "mode": "go2_box_release_support_normal_ik_scan",
                "status": "scan_complete",
                "release_q_rad": [0.0] * 6,
                "transport_reference_q_rad": [0.1] + [0.0] * 5,
                "support_up_normal_base": support.tolist(),
                "levels": [{
                    "raise_mm": 45.0,
                    "reachable_continuously": True,
                    "q_rad": opening_q,
                    "minimum_joint_margin_deg": 15.2,
                    "transport_joint_interpolation": {
                        "normal_raise_monotonic_down": True,
                        "minimum_normal_raise_mm": 45.0,
                        "maximum_tangent_drift_mm": 20.0,
                        "minimum_joint_margin_deg": 15.2,
                    },
                }],
            }
            record = build_record(
                self.publisher(mount_path),
                self.mount(),
                publisher_path=publisher_path,
                mount_path=mount_path,
                fk=fk,
                finger_rim_clearance_mm=10.0,
                payload_mass_g=40.0,
                ik_scan=scan,
                ik_scan_path=scan_path,
                opening_hover_raise_mm=45.0,
            )
        self.assertNotIn("hover", record)
        self.assertEqual(record["transport_reference"]["q_rad"][0], 0.1)
        self.assertEqual(record["opening_hover"]["q_rad"], opening_q)
        self.assertEqual(record["opening_hover"]["raise_mm"], 45.0)


if __name__ == "__main__":
    unittest.main()
