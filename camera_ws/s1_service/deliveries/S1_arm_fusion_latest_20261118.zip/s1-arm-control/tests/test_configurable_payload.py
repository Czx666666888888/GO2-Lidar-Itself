"""Actual payload configuration, without arm or camera access."""
import math
import unittest
from pathlib import Path
from scripts import run_go2_visual_alignment as flow

ROOT = Path(__file__).resolve().parents[1]
RIGHT = "config/go2_dual_white_light_full_flow_size_adaptive_v1.json"
LEFT = "config/go2_left_full_flow_size_adaptive_20261112_v1.json"

class ConfigurablePayloadTests(unittest.TestCase):
    def test_continuous_mass_override_both_sides(self):
        for side in (RIGHT, LEFT):
            for mass in (40.0, 125.5, 500.0, 600.0, 1000.0):
                with self.subTest(side=side, mass=mass):
                    _, config = flow.load_alignment_config(ROOT / side, payload_mass_g=mass)
                    self.assertEqual(config["adaptive_grasp_box_place"]["maximum_test_mass_g"], mass)

    def test_invalid_mass(self):
        for mass in (0, -1, math.nan, math.inf):
            with self.subTest(mass=mass), self.assertRaisesRegex(ValueError, "payload mass"):
                flow.load_alignment_config(ROOT / RIGHT, payload_mass_g=mass)

    def test_default_config_unchanged(self):
        self.assertEqual(flow.load_alignment_config(ROOT / RIGHT)[1]["adaptive_grasp_box_place"]["maximum_test_mass_g"], 40)

    def test_old_box_mass_is_not_a_fixed_rejection(self):
        import json
        _, config = flow.load_alignment_config(ROOT / RIGHT, payload_mass_g=600)
        plan_path = flow.resolve_project_path(config["deployment_plan"])
        plan = json.loads(plan_path.read_text())
        resources = flow.load_bound_box_place_resources(
            config["adaptive_grasp_box_place"], deployment_plan_path=plan_path,
            mount_path=flow.resolve_project_path(plan["mount_config"]),
            allow_identical_deployment_geometry=True)
        report = resources[4]
        estimate = report["configured_payload_estimate"]
        self.assertEqual(estimate["mass_g"],600)
        self.assertEqual(report["payload_gravity_model"]["mass_kg"],0.3)
        for original, scaled in zip(report["payload_gravity_model"]["maximum_design_payload_torque_nm_per_joint"],estimate["maximum_design_payload_torque_nm_per_joint"]):
            self.assertAlmostEqual(scaled,2*original)
        self.assertFalse(estimate["within_original_design_margin"])

    def test_stronger_secure_force_keeps_probe_and_preload(self):
        for side in (RIGHT, LEFT):
            _, config = flow.load_alignment_config(ROOT / side)
            _, _, parameters, baseline = flow.load_bound_adaptive_grasp_resources(config["adaptive_secure_no_lift"])
            self.assertEqual(parameters.secure_force_nm,0.5)
            self.assertEqual(parameters.probe_force_nm,0.2)
            self.assertEqual(parameters.secure_preload_command_mm,12.0)
            baseline.assert_compatible(parameters)

    def test_wider_descent_opening_keeps_calibrated_probe_start(self):
        for side in (RIGHT, LEFT):
            _, config = flow.load_alignment_config(ROOT / side)
            secure = config["adaptive_secure_no_lift"]
            _, _, parameters, baseline = flow.load_bound_adaptive_grasp_resources(secure)
            self.assertIsNone(secure["descent_open_gap_mm"])
            self.assertEqual(parameters.start_gap_mm,65.0)
            baseline.assert_compatible(parameters)
