# -*- coding: utf-8 -*-
"""不访问S1硬件的目标档案与夹爪映射回归测试。"""
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from s1_control.calib import load_grasp_targets
from s1_control.adaptive_grasp import (
    EmptyProbeBaseline,
    ProbeSample,
    load_probe_parameters,
)
from s1_control.gripper import Gripper
from s1_control.kinematics import READY_Q
from scripts.grip_lift_place import (
    ascent_route,
    continuous_route_waypoints,
    descent_route,
    file_sha256,
    guarded_move_continuous_route,
    load_plan_route,
    merge_collinear_approach_route,
    outward_route,
    return_route,
    route_from_plan_record,
    resolve_j6_v_max_rad_s,
    resolve_v_max_rad_s,
    run_adaptive_acquisition,
    run_alignment_only,
    start_pose_is_safe,
    start_pose_window_violations,
    temperature_is_safe,
    validate_execution_mode,
    validate_first_grasp_geometry,
    validate_multi_descent_geometry,
    verify_collision_report,
)


class _FakeSdkArm:
    def __init__(self):
        self.pos = [0.0] * 7
        self.commands = []

    def get_pos(self):
        return list(self.pos)

    def control_gripper(self, fb, force):
        self.commands.append((float(fb), float(force)))


class _FakeArm:
    def __init__(self):
        self._arm = _FakeSdkArm()

    def get_pos(self):
        return self._arm.get_pos()


class _FakeKinematics:
    def fk(self, q):
        return [q[0], q[1], q[2], 0.0, 0.0, 0.0, 1.0]


class _FakeAdaptiveRunner:
    def __init__(self, parameters, stable_samples, secure_actual_gap_mm=None):
        self.parameters = parameters
        self.stable_samples = list(stable_samples)
        self.secure_actual_gap_mm = secure_actual_gap_mm
        self.hold_calls = []

    def hold(self, gap_mm, force_nm, duration_s, phase):
        self.hold_calls.append((gap_mm, force_nm, duration_s, phase))
        if phase == "adaptive_open":
            actual_gap_mm = self.parameters.start_gap_mm
        elif phase == "adaptive_secure_hold":
            if self.secure_actual_gap_mm is None:
                raise AssertionError("测试未提供预压后的实际开口")
            actual_gap_mm = self.secure_actual_gap_mm
        else:
            raise AssertionError(f"未知测试阶段: {phase}")
        return ProbeSample(
            t_s=1.0,
            command_gap_mm=gap_mm,
            actual_gap_mm=actual_gap_mm,
            gripper_tau_nm=0.4,
        )

    def probe_until_settled(self):
        return list(self.stable_samples)


class GraspProfileTests(unittest.TestCase):
    def setUp(self):
        self.arm = _FakeArm()
        self.gripper = Gripper(self.arm)
        root = Path(__file__).resolve().parents[1]
        self.adaptive_parameters = load_probe_parameters(
            root / "config" / "adaptive_grasp.yaml"
        )
        self.adaptive_baseline = EmptyProbeBaseline(
            sample_count=25,
            start_gap_mm=self.adaptive_parameters.start_gap_mm,
            target_gap_mm=self.adaptive_parameters.target_gap_mm,
            probe_force_nm=self.adaptive_parameters.probe_force_nm,
            timeout_s=self.adaptive_parameters.timeout_s,
            evaluation_window_s=(
                self.adaptive_parameters.evaluation_window_s
            ),
            tracking_excess_p99_mm=1.0,
            tau_center_nm=0.03,
            tau_abs_deviation_p99_nm=0.04,
        )

    def _stable_probe_samples(self, gap_mm, tau_nm):
        return [
            ProbeSample(
                t_s=index / self.adaptive_parameters.hz,
                command_gap_mm=self.adaptive_parameters.target_gap_mm,
                actual_gap_mm=gap_mm,
                gripper_tau_nm=tau_nm,
            )
            for index in range(
                self.adaptive_parameters.evaluation_capacity
            )
        ]

    def test_motion_profile_defaults_are_scoped_and_overridable(self):
        self.assertEqual(resolve_v_max_rad_s("linear", None), 0.05)
        self.assertEqual(resolve_v_max_rad_s("s_curve", None), 0.20)
        self.assertEqual(resolve_v_max_rad_s("s_curve", 0.15), 0.15)

        for invalid in (0.0, -0.1, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                resolve_v_max_rad_s("s_curve", invalid)
        with self.assertRaises(ValueError):
            resolve_v_max_rad_s("unknown", None)

        self.assertEqual(resolve_j6_v_max_rad_s(None), 0.10)
        self.assertEqual(resolve_j6_v_max_rad_s(0.12), 0.12)
        for invalid in (0.0, -0.1, float("nan"), float("inf")):
            with self.assertRaises(ValueError):
                resolve_j6_v_max_rad_s(invalid)

    def test_profiles_keep_legacy_and_add_cube(self):
        profiles = load_grasp_targets()
        self.assertIn("cap31", profiles)
        self.assertIn("cube50", profiles)
        self.assertEqual(profiles["cap31"]["status"], "verified")
        self.assertEqual(profiles["cube50"]["status"], "provisional")

    def test_gap_mapping_round_trip(self):
        for gap_mm in (20.0, 47.0, 50.0, 65.0, 81.0):
            fb = self.gripper.mm_to_fb(gap_mm)
            self.assertAlmostEqual(self.gripper.gap_from_fb(fb), gap_mm, places=6)

    def test_force_override_is_explicit(self):
        self.gripper.command_mm(47.0, force=0.20)
        _, force = self.arm._arm.commands[-1]
        self.assertAlmostEqual(force, 0.20)

    def test_cube_contact_mm_separates_blocked_from_empty(self):
        close_mm = 47.0
        self.arm._arm.pos[6] = self.gripper.mm_to_fb(50.0)
        holding, excess, gap = self.gripper.is_holding_mm(close_mm, 2.5)
        self.assertTrue(holding)
        self.assertAlmostEqual(excess, 3.0, places=6)
        self.assertAlmostEqual(gap, 50.0, places=6)

        self.arm._arm.pos[6] = self.gripper.mm_to_fb(close_mm)
        holding, excess, _ = self.gripper.is_holding_mm(close_mm, 2.5)
        self.assertFalse(holding)
        self.assertAlmostEqual(excess, 0.0, places=6)

    def test_optional_approach_waypoint_is_used_both_directions(self):
        approach = [0.1] * 6
        standoff = [0.2] * 6
        start = [0.0] * 6
        outbound = outward_route(approach, standoff)
        inbound = return_route(standoff, approach, start)
        self.assertEqual([segment[2] for segment in outbound], [
            "ready->approach", "approach->standoff"
        ])
        self.assertEqual([segment[2] for segment in inbound], [
            "standoff->approach", "approach->ready", "ready->start"
        ])

    def test_collinear_approach_is_merged_without_changing_path(self):
        start = [0.0] * 6
        approach = [0.1] * 6
        end = [0.2] * 6
        route = [
            (start, approach, "ready->approach"),
            (approach, end, "approach->standoff"),
        ]
        merged = merge_collinear_approach_route(route)
        self.assertEqual(len(merged), 1)
        self.assertEqual(merged[0][0], start)
        self.assertEqual(merged[0][1], end)
        self.assertEqual(merged[0][2], "ready->approach->standoff")
        midpoint = [
            0.5 * (a + b) for a, b in zip(merged[0][0], merged[0][1])
        ]
        self.assertEqual(midpoint, approach)

    def test_non_collinear_approach_keeps_original_stops(self):
        start = [0.0] * 6
        approach = [0.1] * 6
        approach[2] += 0.01
        end = [0.2] * 6
        route = [
            (start, approach, "ready->approach"),
            (approach, end, "approach->standoff"),
        ]
        self.assertEqual(merge_collinear_approach_route(route), route)

    def test_return_merges_only_approach_pair_and_keeps_final_stop(self):
        standoff = [0.2] * 6
        approach = [0.1] * 6
        ready = [0.0] * 6
        start = [-0.01] * 6
        route = [
            (standoff, approach, "standoff->approach"),
            (approach, ready, "approach->ready"),
            (ready, start, "ready->start"),
        ]
        merged = merge_collinear_approach_route(route)
        self.assertEqual([segment[2] for segment in merged], [
            "standoff->approach->ready", "ready->start"
        ])

    def test_hover_plan_maps_midpoint_and_hover(self):
        midpoint = [0.1] * 6
        hover = [0.2] * 6
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "midpoint", "q": midpoint},
            {"name": "hover", "q": hover},
        ]}
        (
            approach_q, standoff_q, descent_waypoints, grasp_q, names
        ) = route_from_plan_record(plan)
        self.assertEqual(approach_q, midpoint)
        self.assertEqual(standoff_q, hover)
        self.assertEqual(descent_waypoints, [])
        self.assertIsNone(grasp_q)
        self.assertEqual(names, ["ready", "midpoint", "hover"])

    def test_grasp_plan_preserves_hover_and_grasp(self):
        midpoint = [0.1] * 6
        hover = [0.2] * 6
        grasp = [0.25] * 6
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "midpoint", "q": midpoint},
            {"name": "hover", "q": hover},
            {"name": "grasp", "q": grasp},
        ]}
        (
            approach_q, standoff_q, descent_waypoints, grasp_q, names
        ) = route_from_plan_record(plan)
        self.assertEqual(approach_q, midpoint)
        self.assertEqual(standoff_q, hover)
        self.assertEqual(descent_waypoints, [])
        self.assertEqual(grasp_q, grasp)
        self.assertEqual(names, ["ready", "midpoint", "hover", "grasp"])

    def test_plan_rejects_multiple_unrepresentable_intermediate_points(self):
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "midpoint", "q": [0.1] * 6},
            {"name": "approach", "q": [0.2] * 6},
            {"name": "hover", "q": [0.3] * 6},
        ]}
        with self.assertRaisesRegex(ValueError, "最多支持一个"):
            route_from_plan_record(plan)

    def test_plan_file_loader_reads_generated_schema(self):
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "midpoint", "q": [0.1] * 6},
            {"name": "hover", "q": [0.2] * 6},
        ]}
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "cube50_hover_plan.json"
            path.write_text(json.dumps(plan), encoding="utf-8")
            (
                resolved,
                approach_q,
                standoff_q,
                descent_waypoints,
                grasp_q,
                names,
            ) = load_plan_route(str(path))
        self.assertEqual(resolved, path.resolve())
        self.assertEqual(approach_q, [0.1] * 6)
        self.assertEqual(standoff_q, [0.2] * 6)
        self.assertEqual(descent_waypoints, [])
        self.assertIsNone(grasp_q)
        self.assertEqual(names, ["ready", "midpoint", "hover"])

    def test_collision_report_must_match_plan_sha256(self):
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "hover", "q": [0.2] * 6},
        ]}
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            report_path = Path(tmpdir) / "report.json"
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            report = {
                "schema_version": 2,
                "status": "OFFLINE_MODEL_PASS",
                "source_plan_sha256": file_sha256(plan_path),
                "sample_step_rad": 0.02,
                "sample_count": 3,
                "hard_limit_ok": True,
                "required_joint_margin_deg": 10.0,
                "required_min_tcp_z_mm": 60.0,
                "height_ok": True,
                "self_collision_ok": True,
                "active_collisions": [],
            }
            report_path.write_text(json.dumps(report), encoding="utf-8")
            resolved, _ = verify_collision_report(plan_path, str(report_path))
            self.assertEqual(resolved, report_path.resolve())

            bench_report = dict(report)
            bench_report["required_min_tcp_z_mm"] = -47.0
            report_path.write_text(json.dumps(bench_report), encoding="utf-8")
            verify_collision_report(plan_path, str(report_path))

            below_bench_report = dict(report)
            below_bench_report["required_min_tcp_z_mm"] = -47.001
            report_path.write_text(
                json.dumps(below_bench_report), encoding="utf-8"
            )
            with self.assertRaisesRegex(ValueError, "tcp_z"):
                verify_collision_report(plan_path, str(report_path))

            weak_report = dict(report)
            weak_report["sample_step_rad"] = 0.05
            report_path.write_text(json.dumps(weak_report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "sample_step_rad"):
                verify_collision_report(plan_path, str(report_path))

            nan_report = dict(report)
            nan_report["required_joint_margin_deg"] = math.nan
            report_path.write_text(json.dumps(nan_report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "joint_margin"):
                verify_collision_report(plan_path, str(report_path))

            report_path.write_text(json.dumps(report), encoding="utf-8")
            plan_path.write_text(
                json.dumps({"joint_path": []}), encoding="utf-8"
            )
            with self.assertRaisesRegex(ValueError, "SHA256|sha256"):
                verify_collision_report(plan_path, str(report_path))

    def test_multi_descent_requires_bound_lateral_collision_report(self):
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "hover", "q": [0.2] * 6},
            {"name": "descent_01", "q": [0.22] * 6},
            {"name": "grasp", "q": [0.24] * 6},
        ]}
        with tempfile.TemporaryDirectory() as tmpdir:
            plan_path = Path(tmpdir) / "plan.json"
            report_path = Path(tmpdir) / "report.json"
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            report = {
                "schema_version": 2,
                "status": "OFFLINE_MODEL_PASS",
                "source_plan_sha256": file_sha256(plan_path),
                "sample_step_rad": 0.02,
                "sample_count": 3,
                "hard_limit_ok": True,
                "required_joint_margin_deg": 10.0,
                "required_min_tcp_z_mm": -47.0,
                "height_ok": True,
                "self_collision_ok": True,
                "active_collisions": [],
            }
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "descent_lateral"):
                verify_collision_report(plan_path, str(report_path))

            report["descent_lateral_ok"] = True
            report["required_max_descent_lateral_mm"] = 3.0
            report_path.write_text(json.dumps(report), encoding="utf-8")
            verify_collision_report(plan_path, str(report_path))

            report["required_max_descent_lateral_mm"] = 3.01
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "descent_lateral"):
                verify_collision_report(plan_path, str(report_path))

    def test_start_pose_window_rejects_unexpected_configuration(self):
        self.assertTrue(start_pose_is_safe([0.0] * 6))
        self.assertFalse(start_pose_is_safe([0.0] * 5))
        self.assertFalse(start_pose_is_safe([0.0] * 6 + [0.0]))
        self.assertFalse(start_pose_is_safe([math.nan] + [0.0] * 5))
        unsafe = [0.0] * 6
        unsafe[1] = 0.2
        self.assertFalse(start_pose_is_safe(unsafe))

    def test_j4_relaxed_start_window_has_explicit_boundary(self):
        at_upper_boundary = [0.0] * 6
        at_upper_boundary[3] = 0.12
        self.assertTrue(start_pose_is_safe(at_upper_boundary))
        self.assertEqual(start_pose_window_violations(at_upper_boundary), [])

        above_upper_boundary = [0.0] * 6
        above_upper_boundary[3] = 0.1201
        self.assertFalse(start_pose_is_safe(above_upper_boundary))
        self.assertEqual(
            start_pose_window_violations(above_upper_boundary),
            ["J4=0.120100rad allowed=[-0.080,0.120]rad"],
        )

    def test_temperature_requires_seven_finite_safe_values(self):
        self.assertTrue(temperature_is_safe([30.0] * 7))
        self.assertFalse(temperature_is_safe([30.0] * 6))
        self.assertFalse(temperature_is_safe([30.0] * 6 + [math.nan]))
        self.assertFalse(temperature_is_safe([30.0] * 6 + [51.0]))

    def test_contact_only_mode_requires_grasp_and_excludes_hover(self):
        validate_execution_mode(False, True, False, True)
        validate_execution_mode(False, False, True, True)
        with self.assertRaisesRegex(ValueError, "不能同时"):
            validate_execution_mode(True, True, False, True)
        with self.assertRaisesRegex(ValueError, "不能同时"):
            validate_execution_mode(False, True, True, True)
        with self.assertRaisesRegex(ValueError, "grasp"):
            validate_execution_mode(False, True, False, False)
        with self.assertRaisesRegex(ValueError, "grasp"):
            validate_execution_mode(False, False, True, False)
        validate_execution_mode(True, False, False, False)

    def test_adaptive_mode_is_opt_in_and_rejects_non_grasp_modes(self):
        validate_execution_mode(False, False, False, True)
        validate_execution_mode(
            False, True, False, True, adaptive_grip=True
        )
        validate_execution_mode(
            False, False, False, True, adaptive_grip=True
        )
        with self.assertRaisesRegex(ValueError, "adaptive-grip"):
            validate_execution_mode(
                True, False, False, False, adaptive_grip=True
            )
        with self.assertRaisesRegex(ValueError, "adaptive-grip"):
            validate_execution_mode(
                False, False, True, True, adaptive_grip=True
            )

    def test_adaptive_acquisition_detects_and_secures_continuous_width(self):
        runner = _FakeAdaptiveRunner(
            self.adaptive_parameters,
            self._stable_probe_samples(37.4, 0.35),
            secure_actual_gap_mm=37.5,
        )
        result = run_adaptive_acquisition(
            runner,
            self.adaptive_parameters,
            self.adaptive_baseline,
            secure=True,
        )

        self.assertTrue(result["detected"])
        self.assertAlmostEqual(result["contact_gap_mm"], 37.4)
        self.assertAlmostEqual(result["secure_gap_mm"], 31.4)
        self.assertAlmostEqual(result["secure_actual_gap_mm"], 37.5)
        self.assertEqual(
            [call[3] for call in runner.hold_calls],
            ["adaptive_open", "adaptive_secure_hold"],
        )

    def test_adaptive_miss_never_issues_secure_hold(self):
        runner = _FakeAdaptiveRunner(
            self.adaptive_parameters,
            self._stable_probe_samples(20.8, 0.03),
        )
        result = run_adaptive_acquisition(
            runner,
            self.adaptive_parameters,
            self.adaptive_baseline,
            secure=True,
        )

        self.assertFalse(result["detected"])
        self.assertIsNone(result["secure_gap_mm"])
        self.assertEqual(
            [call[3] for call in runner.hold_calls],
            ["adaptive_open"],
        )

    def test_adaptive_secure_loss_is_rejected_before_lift(self):
        runner = _FakeAdaptiveRunner(
            self.adaptive_parameters,
            self._stable_probe_samples(29.2, 0.30),
            secure_actual_gap_mm=24.0,
        )
        result = run_adaptive_acquisition(
            runner,
            self.adaptive_parameters,
            self.adaptive_baseline,
            secure=True,
        )

        self.assertTrue(result["detected"])
        self.assertFalse(result["secure_valid"])
        self.assertAlmostEqual(result["secure_gap_mm"], 23.2)

    def test_alignment_only_uses_open_gap_and_safe_return(self):
        grasp_q = [0.3] * 6
        standoff_q = [0.2] * 6
        approach_q = [0.1] * 6
        start_q = [0.0] * 6
        with patch(
            "scripts.grip_lift_place.guarded_hold"
        ) as hold, patch(
            "scripts.grip_lift_place.safe_open_return"
        ) as safe_return:
            run_alignment_only(
                object(), object(), grasp_q, standoff_q,
                approach_q, start_q, 65.0, 0.2, 3.0,
            )

        self.assertEqual(hold.call_args.args[2], 65.0)
        self.assertEqual(hold.call_args.args[4], 3.0)
        self.assertEqual(safe_return.call_args.args[6], 65.0)
        self.assertEqual(
            safe_return.call_args.kwargs["label_prefix"], "alignment"
        )

    def test_first_grasp_geometry_accepts_25mm_vertical_lift(self):
        result = validate_first_grasp_geometry(
            _FakeKinematics(),
            [0.280, 0.000, 0.080, 0.0, 0.0, 0.0],
            [0.283, 0.002, 0.055, 0.0, 0.0, 0.0],
        )
        self.assertAlmostEqual(result["lift_mm"], 25.0, places=6)
        self.assertLess(result["lateral_mm"], 8.0)

    def test_first_grasp_geometry_accepts_submicron_boundary_noise(self):
        result = validate_first_grasp_geometry(
            _FakeKinematics(),
            [0.280, 0.000, 0.0800007, 0.0, 0.0, 0.0],
            [0.280, 0.000, 0.0600012, 0.0, 0.0, 0.0],
        )
        self.assertAlmostEqual(result["lift_mm"], 19.9995, places=6)

        with self.assertRaisesRegex(ValueError, "提升高度"):
            validate_first_grasp_geometry(
                _FakeKinematics(),
                [0.280, 0.000, 0.0800000, 0.0, 0.0, 0.0],
                [0.280, 0.000, 0.0600100, 0.0, 0.0, 0.0],
            )

    def test_first_grasp_geometry_rejects_excessive_lift(self):
        with self.assertRaisesRegex(ValueError, "提升高度"):
            validate_first_grasp_geometry(
                _FakeKinematics(),
                [0.280, 0.000, 0.080, 0.0, 0.0, 0.0],
                [0.280, 0.000, 0.040, 0.0, 0.0, 0.0],
            )

    def test_multi_descent_route_is_parsed_and_reversible(self):
        hover = [0.2] * 6
        descent_01 = [0.22] * 6
        descent_02 = [0.24] * 6
        grasp = [0.26] * 6
        plan = {"joint_path": [
            {"name": "ready", "q": list(READY_Q)},
            {"name": "hover", "q": hover},
            {"name": "descent_01", "q": descent_01},
            {"name": "descent_02", "q": descent_02},
            {"name": "grasp", "q": grasp},
        ]}
        _, standoff_q, descents, grasp_q, names = route_from_plan_record(plan)
        self.assertEqual(
            [name for name, _ in descents], ["descent_01", "descent_02"]
        )
        down = descent_route(standoff_q, descents, grasp_q)
        up = ascent_route(standoff_q, descents, grasp_q)
        self.assertEqual(
            [segment[2] for segment in down],
            ["standoff->descent_01", "descent_01->descent_02", "descent_02->grasp"],
        )
        self.assertEqual(
            [(segment[0], segment[1]) for segment in up],
            [(segment[1], segment[0]) for segment in reversed(down)],
        )
        self.assertEqual(names[-1], "grasp")

    def test_continuous_route_keeps_every_checked_waypoint(self):
        q0 = [0.00] * 6
        q1 = [0.05] * 6
        q2 = [0.10] * 6
        q3 = [0.15] * 6
        route = [
            (q0, q1, "hover->descent_01"),
            (q1, q2, "descent_01->descent_02"),
            (q2, q3, "descent_02->grasp"),
        ]

        waypoints, label = continuous_route_waypoints(route)

        self.assertEqual(waypoints, [q0, q1, q2, q3])
        self.assertEqual(
            label, "hover->descent_01->descent_02->grasp"
        )

    def test_continuous_route_rejects_disconnected_segments(self):
        route = [
            ([0.0] * 6, [0.1] * 6, "hover->descent_01"),
            ([0.2] * 6, [0.3] * 6, "descent_01->grasp"),
        ]
        with self.assertRaises(ValueError):
            continuous_route_waypoints(route)

    def test_continuous_route_is_one_arm_trajectory_call(self):
        class FakeMotionArm:
            def __init__(self):
                self.calls = []

            def move_waypoints(
                self, waypoints, label, grip_cmd=None, grip_force=0.3
            ):
                self.calls.append(
                    (waypoints, label, grip_cmd, grip_force)
                )
                return None

        q0 = [0.0] * 6
        q1 = [0.1] * 6
        q2 = [0.2] * 6
        arm = FakeMotionArm()
        guarded_move_continuous_route(
            arm,
            [
                (q0, q1, "hover->descent_01"),
                (q1, q2, "descent_01->grasp"),
            ],
            grip_fb=1.2,
            force_nm=0.2,
        )

        self.assertEqual(len(arm.calls), 1)
        self.assertEqual(arm.calls[0][0], [q0, q1, q2])
        self.assertEqual(
            arm.calls[0][1], "hover->descent_01->grasp"
        )
        self.assertAlmostEqual(arm.calls[0][2], 1.2)
        self.assertAlmostEqual(arm.calls[0][3], 0.2)

    def test_multi_descent_geometry_accepts_15mm_or_smaller_steps(self):
        result = validate_multi_descent_geometry(
            _FakeKinematics(),
            [0.280, 0.000, 0.070, 0.0, 0.0, 0.0],
            [
                ("descent_01", [0.281, 0.001, 0.056, 0.0, 0.0, 0.0]),
                ("descent_02", [0.282, 0.001, 0.042, 0.0, 0.0, 0.0]),
            ],
            [0.282, 0.001, 0.030, 0.0, 0.0, 0.0],
        )
        self.assertAlmostEqual(result["total_descent_mm"], 40.0)
        self.assertLessEqual(result["maximum_step_mm"], 15.0)
        self.assertLessEqual(result["maximum_lateral_mm"], 3.0)


if __name__ == "__main__":
    unittest.main()
