import copy
import json
import unittest
from run_go2_visual_alignment import (PROJECT_ROOT,load_alignment_config,load_wrist_servo_config,
    resolve_project_path,reuse_tracked_high_view_geometry,compute_final_check,Kinematics)

class GeometryReuseTests(unittest.TestCase):
    def setUp(self):
        self.run=json.loads((PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261114-161315/run.json").read_text())
        _,self.cfg=load_alignment_config(self.run["config"])
        self.loaded=load_wrist_servo_config(resolve_project_path(self.cfg["wrist_servo_config"]))
        self.loaded.record["validated_workspace"]["advisory_bounds"]=True
        self.capture=copy.deepcopy(self.run["residual_correction"]["capture"])
        self.q=self.run["residual_correction"]["measured_q_rad"]
        self.kin=Kinematics(tcp=[0,0,0],verbose=False)
    def recover(self,prior=None,observation=None):
        return reuse_tracked_high_view_geometry(self.capture,self.q,
            self.run["final_capture"] if prior is None else prior,
            self.run["final_observation"] if observation is None else observation,
            loaded=self.loaded,flange_kinematics=self.kin)
    def test_real_failed_frame_reuses_prior_height_but_preserves_bad_depth_diagnostic(self):
        self.assertTrue(self.recover())
        target=self.capture["detection"]["selected"]
        self.assertEqual(target["core_height_mm"],self.run["final_capture"]["detection"]["selected"]["core_height_mm"])
        self.assertLess(target["core_depth_valid_ratio"],.06)
        self.assertTrue(target["geometry_reuse"]["position_and_direction_recomputed"])
        self.assertIn("residual_final",target["geometry_reuse"]["current_capture_path"])
    def test_no_accepted_prior_means_no_reuse(self):
        prior=copy.deepcopy(self.run["final_capture"])
        prior["detection"]["selected"]["accepted"]=False
        self.assertFalse(self.recover(prior=prior))
        self.assertEqual(self.capture["detection"]["status"],"NO_TARGET")
    def test_target_outside_predicted_location_is_not_reassigned(self):
        observation=copy.deepcopy(self.run["final_observation"])
        observation["surface_point_base_m"][0]+=1
        self.assertFalse(self.recover(observation=observation))
    def test_final_center_standard_is_not_bypassed(self):
        safety={**self.loaded.record["safety"],"camera_target_depth_window_enabled":False,
                "maximum_camera_tilt_from_down_deg":18}
        result=compute_final_check(self.capture,self.q,loaded=self.loaded,
            alignment=self.cfg["alignment"],flange_kinematics=self.kin,
            tcp_kinematics=Kinematics(verbose=False),observation_safety=safety,
            prior_capture=self.run["final_capture"],prior_observation=self.run["final_observation"])
        self.assertEqual(result["check"]["convergence_mm"],5)
        self.assertFalse(result["check"]["converged"])
        self.assertAlmostEqual(result["check"]["initial_tangent_error_norm_mm"],5.48003,places=3)

if __name__=="__main__":unittest.main()
