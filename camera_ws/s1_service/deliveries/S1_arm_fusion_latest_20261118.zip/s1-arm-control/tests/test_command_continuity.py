"""Offline checks for command continuity and the streamed SDK trace."""
import json
import math
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import patch

from s1_control.command_continuity import (
    CommandTrace, continuous_command_path, offset_command_path,
)
from s1_control.arm import Arm, SafetyLimits
import scripts.run_go2_visual_alignment as alignment


class CommandContinuityTests(unittest.TestCase):
    def test_mapped_j3_follows_physical_direction_without_initial_reverse(self):
        measured=[0,1.8270778656,1.3483257294,0,0,0]
        held=[0,1.8308912216,1.378636,0,0,0]
        first=[0,1.8422403336,1.370051384,0,0,0]
        commands,offset=offset_command_path(held,[measured,first])
        self.assertEqual(commands[0],held)
        self.assertGreater(commands[1][2],held[2])
        self.assertAlmostEqual(commands[1][2]-held[2],first[2]-measured[2])
        self.assertAlmostEqual(offset[2],.0303102706)

    def test_mapping_keeps_one_constant_offset_on_entire_path(self):
        physical=[[.01*i]*6 for i in range(4)]
        commands,offset=offset_command_path([.025]*6,physical)
        for p,c in zip(physical,commands):
            for a,b,d in zip(p,c,offset):
                self.assertAlmostEqual(b-a,d)

    def test_large_learned_bias_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'offset exceeds'):
            offset_command_path([.051]*6,[[0]*6,[.01]*6])

    def test_clipping_keeps_first_command_and_limits_only_excess_offset(self):
        held = [0.01, -0.052724, 0.0, 0.0, 0.0, 0.02]
        physical = [[0.0] * 6, [0.01] * 6]
        commands, offset = offset_command_path(
            held, physical, clip_learned_offset=True
        )
        self.assertEqual(commands[0], held)
        self.assertEqual(offset, [0.01, -0.05, 0.0, 0.0, 0.0, 0.02])
        self.assertAlmostEqual(commands[1][1], -0.04)

    def test_orientation_handoff_reduces_offset_that_uses_joint_margin(self):
        start = [2.33, 2.0, 1.5, 1.03, 0.03, math.radians(42.0)]
        physical = [start, [*start[:5], math.radians(60.0)],
                    [*start[:5], math.radians(79.38)]]
        previous = [start[0] + .01, *start[1:5], math.radians(43.62)]
        arm = SimpleNamespace(
            _position_commander=SimpleNamespace(
                last_command_q_rad=previous, last_snapshot={"measured_q_rad": start},
            ),
            limits=SimpleNamespace(max_joint_delta_rad=.5),
        )
        options = dict(
            collision_checker=None, tilt_model=None, support_up_normal_base=[0, 0, 1],
            compensation_scale=1, torque_limits=[1] * 6, collision_step_rad=.01,
            minimum_joint_margin_deg=10, workspace={},
            kinematics=SimpleNamespace(fk=lambda q: [0, .32, .1, 0, 0, 0, 1]),
            preserve_physical_offsets=True,
        )
        with patch.object(alignment, "check_collision_path"), patch.object(
            alignment, "validate_torque_envelope"
        ), patch.object(alignment, "validate_workspace_point"):
            with self.assertRaisesRegex(RuntimeError, "violates joint margin"):
                alignment.prepare_continuous_alignment_path(arm, physical, **options)
            commands, _ = alignment.prepare_continuous_alignment_path(
                arm, physical, **options, fit_offset_to_joint_margin=True
            )
        self.assertEqual(commands[0], previous)
        self.assertAlmostEqual(commands[-1][0] - physical[-1][0], .01)
        self.assertAlmostEqual(math.degrees(commands[1][5]), 61.12)
        self.assertAlmostEqual(math.degrees(commands[-1][5]), 80.0)
        self.assertGreaterEqual(alignment.joint_margin_deg(commands[-1]), 10)

    def test_endpoint_checks_physical_target_and_holds_mapped_command(self):
        desired=[0,1,1,0,0,0]
        command=[0,1,1.03,0,0,0]
        class FakeArm:
            dt=.001
            _position_commander=SimpleNamespace(last_snapshot=None)
            def command_position(self,q):
                self.commands.append(list(q))
                measured=list(q);measured[2]-=.03
                self._position_commander.last_snapshot={'measured_q_rad':measured}
            def get_pos(self):return self._position_commander.last_snapshot['measured_q_rad']+[0]
            def get_vel(self):return [0]*7
            def get_temp(self):return [25]*7
            def guard(self,*a,**k):return None
        arm=FakeArm();arm.commands=[]
        config=dict(success_joint_error_rad=.012,maximum_initial_joint_error_rad=.05,
                    bias_step_rad=.004,maximum_bias_rad=.024,maximum_attempts=6,
                    hold_seconds=.005,collision_step_rad=.005,minimum_joint_margin_deg=10,
                    validated_workspace={})
        with patch.object(alignment,'validate_workspace_point'):
            result=alignment.converge_observation_endpoint(
                arm,desired,endpoint_config=config,
                kinematics=SimpleNamespace(fk=lambda q:[0,.32,.1,0,0,0,1]),
                collision_checker=None,tilt_model=None,support_up_normal_base=[0,0,1],
                compensation_scale=1,torque_limits=[1]*6,
                continuous_command_handoff=True,initial_command_q=command)
        self.assertEqual(result['status'],'passed')
        self.assertEqual(result['final_command_q_rad'],command)
        self.assertLess(result['final_tracking']['maximum_abs_joint_error_rad'],1e-10)
        self.assertTrue(all(q==command for q in arm.commands))

    def test_live_guard_logs_and_rejects_downward_feedback(self):
        class Commander:
            last_snapshot=None
            def __call__(self,arm,q):
                self.last_snapshot={'measured_q_rad':[0,0,-.004,0,0,0]}
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'trace.jsonl'
            proxy=CommandTrace(Commander(),path)
            proxy.phase='support_tangent_center_alignment'
            proxy.set_downward_guard(lambda q:1000*q[2],0,3)
            with self.assertRaisesRegex(RuntimeError,'downward displacement'):
                proxy(None,[0]*6)
            proxy.close()
            row=json.loads(path.read_text().splitlines()[-1])
            self.assertTrue(row['live_downward_guard_triggered'])
            self.assertEqual(row['support_normal_displacement_mm'],-4)

    def test_guard_can_be_cleared_for_checked_return(self):
        class Commander:
            last_snapshot=None
            def __call__(self,arm,q):
                self.last_snapshot={'measured_q_rad':[0,0,-.004,0,0,0]}
        with tempfile.TemporaryDirectory() as folder:
            proxy=CommandTrace(Commander(),Path(folder)/'trace.jsonl')
            proxy.phase='support_tangent_center_alignment'
            proxy.set_downward_guard(lambda q:1000*q[2],0,3)
            proxy.clear_downward_guard()
            proxy(None,[0]*6)
            proxy.close()

    def run_real_interpolator(self, previous, physical):
        arm = Arm.__new__(Arm)  # Skip the hardware constructor entirely.
        arm.limits = SafetyLimits(motion_profile='s_curve',v_max_rad_s=.10)
        arm.dt = .02
        commands = []
        def command(q):
            commands.append(list(q))
        arm.command_position = command
        arm._arm = SimpleNamespace(
            get_pos=lambda: commands[-1], get_vel=lambda: [0]*6,
            get_temp=lambda: [25]*7,
        )
        arm.guard = lambda *a,**k: None
        points = continuous_command_path(previous,physical)
        with patch('s1_control.arm.time.sleep'):
            self.assertIsNone(arm.move_waypoints(points,'offline_command_test'))
        return commands

    def test_actual_scurve_first_command_is_exact_previous_hold(self):
        previous=[.0328]*6
        commands=self.run_real_interpolator(previous,[[0]*6,[.01]*6])
        self.assertEqual(commands[0],previous)
        for value in commands[-1]:
            self.assertAlmostEqual(value, .01, places=12)
        self.assertLessEqual(max(abs(b[0]-a[0]) for a,b in zip(commands,commands[1:])), .002)

    def test_actual_trim_scurve_never_reissues_encoder_reset(self):
        commands=self.run_real_interpolator([.024]*6,[[.004]*6,[.028]*6])
        self.assertTrue(all(.024 <= q[0] <= .028 for q in commands))

    def test_initial_command_is_previous_not_measured_seed(self):
        previous = [.03] * 6
        physical = [[0] * 6, [.01] * 6, [.02] * 6]
        result = continuous_command_path(previous, physical)
        self.assertEqual(result[0], previous)
        self.assertEqual(result[1:], physical[1:])
        self.assertEqual(physical[0], [0] * 6)

    def test_accumulated_trim_does_not_restart_at_encoder(self):
        result = continuous_command_path([.024]*6, [[.004]*6, [.028]*6])
        self.assertEqual(result, [[.024]*6, [.028]*6])
        self.assertAlmostEqual(result[1][0]-result[0][0], .004)

    def test_redundant_points_removed_without_changing_endpoint(self):
        self.assertEqual(continuous_command_path([0]*6, [[.01]*6,[0]*6]), [[0]*6])

    def test_invalid_path_is_rejected(self):
        with self.assertRaises(ValueError):
            continuous_command_path([float('nan')]*6, [[0]*6,[1]*6])
        with self.assertRaises(ValueError):
            continuous_command_path([0]*6, [[0]*6])

    def test_trace_proxies_snapshot_and_uses_no_extra_hardware_reads(self):
        class ExistingCommander:
            last_snapshot = None
            def __call__(self, arm, q):
                self.last_snapshot = {'measured_q_rad': [.1]*6,
                                      'command_tau_nm': [.2]*6}
                return 7
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'trace.jsonl'
            proxy = CommandTrace(ExistingCommander(), path, sample_period_s=0)
            self.assertEqual(proxy(None, [0]*6), 7)
            proxy(None, [.001]*6)
            self.assertEqual(proxy.last_command_q_rad, [.001]*6)
            self.assertEqual(proxy.last_snapshot['measured_q_rad'], [.1]*6)
            proxy.close()
            rows = [json.loads(line) for line in path.read_text().splitlines()]
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[1]['command_delta_rad'], [.001]*6)
            self.assertGreaterEqual(rows[1]['command_interval_s'], 0)

    def test_failed_command_is_not_marked_as_successful(self):
        def fail(arm, q):
            raise RuntimeError('test_failure')
        with tempfile.TemporaryDirectory() as folder:
            proxy = CommandTrace(fail, Path(folder)/'trace.jsonl')
            with self.assertRaises(RuntimeError):
                proxy(None, [0]*6)
            self.assertIsNone(proxy.last_command_q_rad)
            proxy.close()

    def prepare(self, collision=None):
        arm = SimpleNamespace(
            _position_commander=SimpleNamespace(
                last_command_q_rad=[.03]*6,
                last_snapshot={'measured_q_rad': [0]*6},
            ),
            limits=SimpleNamespace(max_joint_delta_rad=.9),
        )
        kin = SimpleNamespace(fk=lambda q: [0,0,0,0,0,0,1])
        kwargs = dict(
            collision_checker=None, tilt_model=None,
            support_up_normal_base=[0,0,1], compensation_scale=1,
            torque_limits=[1]*6, collision_step_rad=.005,
            minimum_joint_margin_deg=10,
            workspace={}, kinematics=kin,
        )
        return arm,kwargs

    def test_added_command_bridge_is_in_collision_evidence(self):
        arm,kw = self.prepare()
        with patch.object(alignment,'check_collision_path', return_value={'ok':True}) as cc, \
             patch.object(alignment,'joint_margin_deg', return_value=20), \
             patch.object(alignment,'validate_workspace_point'), \
             patch.object(alignment,'validate_torque_envelope', return_value={'ok':True}):
            path,proof = alignment.prepare_continuous_alignment_path(
                arm, [[0]*6,[.01]*6], **kw)
            self.assertEqual(path[0],[.03]*6)
            checked = cc.call_args.args[1]
            self.assertEqual(checked, [[0]*6,[.03]*6,[.01]*6])
            self.assertIn('torque',proof)

    def test_added_bridge_collision_is_not_bypassed(self):
        arm,kw = self.prepare()
        with patch.object(alignment,'joint_margin_deg',return_value=20), \
             patch.object(alignment,'check_collision_path',side_effect=RuntimeError('bridge_collision')):
            with self.assertRaisesRegex(RuntimeError,'bridge_collision'):
                alignment.prepare_continuous_alignment_path(arm, [[0]*6,[.01]*6], **kw)

    def test_missing_previous_command_fails_before_motion(self):
        arm,kw = self.prepare()
        arm._position_commander.last_command_q_rad = None
        with self.assertRaisesRegex(RuntimeError,'previous position command'):
            alignment.prepare_continuous_alignment_path(arm, [[0]*6,[.01]*6], **kw)

    def test_workspace_guard_still_rejects_measured_tcp(self):
        arm,kw = self.prepare()
        with patch.object(alignment,'check_collision_path',return_value={}), \
             patch.object(alignment,'joint_margin_deg',return_value=20), \
             patch.object(alignment,'validate_torque_envelope',return_value={}), \
             patch.object(alignment,'validate_workspace_point',side_effect=RuntimeError('measured_outside')):
            with self.assertRaisesRegex(RuntimeError,'measured_outside'):
                alignment.prepare_continuous_alignment_path(arm, [[0]*6,[.01]*6], **kw)

    def test_preflight_keeps_main_thread_commanding_same_hold(self):
        commanded = threading.Event()
        main_ident = threading.get_ident()
        command_threads = []
        worker_threads = []
        def command(q):
            command_threads.append(threading.get_ident())
            self.assertEqual(q, [.03]*6)
            commanded.set()
        def slow_check(*args, **kwargs):
            worker_threads.append(threading.get_ident())
            if not commanded.wait(timeout=1):
                raise RuntimeError('preflight_starved_hold')
            return [[.03]*6,[.04]*6], {'ok':True}
        arm = SimpleNamespace(
            _position_commander=SimpleNamespace(last_command_q_rad=[.03]*6),
            command_position=command, get_pos=lambda:[.03]*6,
            get_vel=lambda:[0]*6, get_temp=lambda:[25]*7,
            guard=lambda *a,**k:None,
            limits=SimpleNamespace(settle_seconds=.5), dt=.02,
        )
        with patch.object(alignment,'prepare_continuous_alignment_path',slow_check):
            path,proof=alignment.prepare_continuous_alignment_path_while_holding(
                arm,[[0]*6,[.04]*6],timeout_s=45.0)
        self.assertTrue(command_threads)
        self.assertTrue(all(i==main_ident for i in command_threads))
        self.assertTrue(all(i!=main_ident for i in worker_threads))
        self.assertTrue(proof['ok'])

    def test_background_preflight_rejection_propagates(self):
        arm = SimpleNamespace(
            _position_commander=SimpleNamespace(last_command_q_rad=[.03]*6),
            command_position=lambda q:None, get_pos=lambda:[.03]*6,
            get_vel=lambda:[0]*6, get_temp=lambda:[25]*7,
            guard=lambda *a,**k:None,
            limits=SimpleNamespace(settle_seconds=.5), dt=.02,
        )
        with patch.object(alignment,'prepare_continuous_alignment_path',
                          side_effect=RuntimeError('collision_rejected')):
            with self.assertRaisesRegex(RuntimeError,'collision_rejected'):
                alignment.prepare_continuous_alignment_path_while_holding(
                    arm,[[0]*6,[.04]*6],timeout_s=45.0)


if __name__ == '__main__':
    unittest.main()
