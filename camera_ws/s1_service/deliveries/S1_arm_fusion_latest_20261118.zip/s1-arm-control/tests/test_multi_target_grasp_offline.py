# -*- coding: utf-8 -*-
import unittest


from scripts.run_multi_target_grasp_offline import (
    estimate_outbound_plan_cost,
    target_selection_key,
)


class MultiTargetGraspOfflineTests(unittest.TestCase):
    def test_plan_cost_uses_transit_and_descent_with_independent_j6_cap(self):
        plan = {
            "joint_path": [
                {"name": "ready", "q": [0.0, 0.2, 0.4, 0.2, 0.0, 0.0]},
                {"name": "midpoint", "q": [0.1, 0.7, 0.7, 0.5, 0.0, 0.2]},
                {"name": "hover", "q": [0.2, 1.2, 1.0, 0.8, 0.0, 0.4]},
                {"name": "descent_01", "q": [0.2, 1.25, 0.95, 0.7, 0.0, 0.4]},
                {"name": "grasp", "q": [0.2, 1.30, 0.90, 0.6, 0.0, 0.4]},
            ]
        }
        cost = estimate_outbound_plan_cost(
            plan,
            v_max_rad_s=0.20,
            j6_v_max_rad_s=0.10,
            motion_profile="s_curve",
        )
        self.assertGreater(cost["estimated_transit_duration_s"], 0.0)
        self.assertGreater(cost["estimated_descent_duration_s"], 0.0)
        self.assertAlmostEqual(cost["total_j6_travel_rad"], 0.4)
        self.assertAlmostEqual(
            cost["estimated_outbound_duration_s"],
            cost["estimated_transit_duration_s"]
            + cost["estimated_descent_duration_s"],
        )

    def test_selection_prefers_shorter_feasible_motion_before_confidence(self):
        faster = {
            "target_id": "component_002",
            "estimated_outbound_duration_s": 8.0,
            "total_j6_travel_rad": 0.5,
            "confidence_score": 0.80,
        }
        slower = {
            "target_id": "component_001",
            "estimated_outbound_duration_s": 9.0,
            "total_j6_travel_rad": 0.1,
            "confidence_score": 0.99,
        }
        self.assertIs(
            min((slower, faster), key=target_selection_key), faster
        )

    def test_selection_uses_j6_then_confidence_as_tie_breakers(self):
        candidates = [
            {
                "target_id": "component_001",
                "estimated_outbound_duration_s": 8.0,
                "total_j6_travel_rad": 0.6,
                "confidence_score": 0.99,
            },
            {
                "target_id": "component_002",
                "estimated_outbound_duration_s": 8.0,
                "total_j6_travel_rad": 0.4,
                "confidence_score": 0.80,
            },
        ]
        self.assertEqual(
            min(candidates, key=target_selection_key)["target_id"],
            "component_002",
        )


if __name__ == "__main__":
    unittest.main()
