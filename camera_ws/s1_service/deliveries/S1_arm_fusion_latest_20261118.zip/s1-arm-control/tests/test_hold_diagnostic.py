import importlib.util
import math
from pathlib import Path
import sys
import unittest


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.hold_diagnostic import summarize_hold_samples


HOLD_SCRIPT_PATH = PROJECT_ROOT / "scripts" / "diagnose_wrist_hold_tracking.py"
HOLD_SCRIPT_SPEC = importlib.util.spec_from_file_location(
    "diagnose_wrist_hold_tracking_for_test", HOLD_SCRIPT_PATH
)
hold_script = importlib.util.module_from_spec(HOLD_SCRIPT_SPEC)
HOLD_SCRIPT_SPEC.loader.exec_module(hold_script)


class FakeFeedbackArm:
    def __init__(self, temperatures):
        self.temperatures = [list(row) for row in temperatures]
        self.index = 0

    def _current(self):
        return self.temperatures[min(self.index, len(self.temperatures) - 1)]

    def get_pos(self):
        return [0.1 * joint for joint in range(7)]

    def get_vel(self):
        return [0.0] * 7

    def get_temp(self):
        result = self._current()
        self.index += 1
        return result


def fake_fk(q):
    return [0.1, 0.2, 0.3 + 0.2 * q[2], 0.0, 0.0, 0.0, 1.0]


def samples_for(position_at_time):
    result = []
    for index in range(51):
        elapsed = index * 0.1
        position = list(position_at_time(elapsed))
        result.append(
            {
                "elapsed_s": elapsed,
                "position_rad": position,
                "velocity_rad_s": [0.0] * 6,
                "torque_nm": [float(joint) for joint in range(6)],
                "torque_fresh": index % 5 == 0,
            }
        )
    return result


class HoldDiagnosticTests(unittest.TestCase):
    def test_teaching_rate_defaults_to_serial_safe_50_hz(self):
        args = hold_script.parser().parse_args([])
        self.assertEqual(args.teach_hz, 50.0)

    def test_startup_gate_skips_uninitialized_zero_temperature_frames(self):
        arm = FakeFeedbackArm(
            [[0.0] * 7, [0.0] * 7, [30.0] * 7, [31.0] * 7, [32.0] * 7]
        )
        q, temperature, summary = hold_script.wait_for_valid_feedback(
            arm,
            55.0,
            timeout_s=0.5,
            required_consecutive=3,
            sample_period_s=0.0,
        )
        self.assertEqual(q, [0.1 * joint for joint in range(6)])
        self.assertEqual(temperature, [31.0] * 7)
        self.assertTrue(summary["ready"])
        self.assertEqual(summary["attempt_count"], 5)
        self.assertEqual(summary["invalid_sample_count"], 2)

    def test_startup_gate_rejects_over_temperature_immediately(self):
        arm = FakeFeedbackArm([[60.0] * 7])
        with self.assertRaisesRegex(RuntimeError, "temperature exceeds"):
            hold_script.wait_for_valid_feedback(
                arm,
                55.0,
                timeout_s=0.5,
                required_consecutive=1,
                sample_period_s=0.0,
            )

    def test_small_stationary_error_passes(self):
        summary = summarize_hold_samples(
            [0.0] * 6,
            fake_fk([0.0] * 6),
            samples_for(lambda _: [0.0, 0.0, -0.002, 0.0, 0.0, 0.0]),
            fake_fk,
        )
        self.assertEqual(summary["status"], "HOLD_TRACKING_OK")
        self.assertEqual(summary["maximum_abs_error_joint"], 3)
        self.assertAlmostEqual(summary["tcp_delta_mm"][2], -0.4)

    def test_stable_j3_offset_is_detected_without_claiming_cause(self):
        def position(elapsed):
            j3 = -0.028 * min(1.0, elapsed / 1.0)
            return [0.0, 0.0, j3, 0.0, 0.0, 0.0]

        summary = summarize_hold_samples(
            [0.0] * 6,
            fake_fk([0.0] * 6),
            samples_for(position),
            fake_fk,
        )
        self.assertEqual(summary["status"], "STEADY_OFFSET_DETECTED")
        self.assertTrue(summary["stationary"])
        self.assertEqual(summary["maximum_abs_error_joint"], 3)
        self.assertAlmostEqual(summary["final_error_rad"][2], -0.028)
        self.assertAlmostEqual(summary["tcp_delta_mm"][2], -5.6)
        self.assertEqual(summary["fresh_torque_sample_count"], 11)
        self.assertEqual(summary["feedback_torque_median_nm"], list(map(float, range(6))))

    def test_continuing_drift_is_not_mislabeled_as_steady(self):
        summary = summarize_hold_samples(
            [0.0] * 6,
            fake_fk([0.0] * 6),
            samples_for(
                lambda elapsed: [0.0, 0.0, -0.01 * elapsed, 0.0, 0.0, 0.0]
            ),
            fake_fk,
        )
        self.assertEqual(summary["status"], "NOT_SETTLED")
        self.assertFalse(summary["stationary"])

    def test_non_finite_sample_is_rejected(self):
        records = samples_for(lambda _: [0.0] * 6)
        records[-1]["position_rad"][2] = math.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            summarize_hold_samples(
                [0.0] * 6,
                fake_fk([0.0] * 6),
                records,
                fake_fk,
            )


if __name__ == "__main__":
    unittest.main()
