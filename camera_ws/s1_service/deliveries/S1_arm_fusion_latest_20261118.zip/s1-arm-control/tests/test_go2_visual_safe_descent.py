"""Offline checks for the first no-contact support-normal descent."""
from pathlib import Path
import unittest
from unittest.mock import patch

from scripts.run_go2_visual_alignment import (
    apply_safe_descent_runtime_clearance_scope,
    compute_safe_descent_plan,
    evaluate_safe_descent_endpoint,
    load_alignment_config,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class LinearKinematics:
    def fk(self, q):
        return [float(q[0]), float(q[1]), float(q[2]), 0.0, 0.0, 0.0, 1.0]


class Go2VisualSafeDescentTests(unittest.TestCase):
    def descent_config(self):
        return {
            "target_normal_clearance_mm": 100.0,
            "minimum_initial_normal_clearance_mm": 210.0,
            "maximum_initial_normal_clearance_mm": 250.0,
            "maximum_descent_distance_mm": 150.0,
            "maximum_cartesian_step_mm": 10.0,
            "maximum_joint_step_rad": 0.15,
            "minimum_joint_margin_deg": 10.0,
            "collision_step_rad": 0.01,
            "maximum_endpoint_clearance_error_mm": 15.0,
            "minimum_descent_progress_ratio": 0.70,
            "maximum_descent_progress_ratio": 1.30,
            "v_max_rad_s": 0.05,
            "j6_v_max_rad_s": 0.05,
            "hold_seconds": 1.0,
        }

    def test_derived_config_is_hash_bound_and_no_contact(self):
        _, config = load_alignment_config(
            PROJECT_ROOT
            / "config/go2_crouch_right_visual_safe_descent_nocw_metalbracket_v1.json"
        )
        self.assertEqual(config["operation"], "safe_descent_round_trip")
        self.assertEqual(config["safe_descent"]["target_normal_clearance_mm"], 100.0)
        self.assertEqual(
            [
                config["safe_descent"]["minimum_initial_normal_clearance_mm"],
                config["safe_descent"]["maximum_initial_normal_clearance_mm"],
            ],
            [210.0, 250.0],
        )
        forbidden = set(config["physical_scope"]["forbidden_actions"])
        self.assertIn("descent_below_safe_clearance", forbidden)
        self.assertIn("contact", forbidden)
        self.assertIn("gripper_close", forbidden)

    def test_runtime_clearance_scope_is_local_and_consistent(self):
        wrist_record = {
            "validated_workspace": {
                "tcp_base_x_mm": [-60.0, 55.0],
                "tcp_base_y_mm": [300.0, 345.0],
                "normal_clearance_mm": [224.0, 236.0],
            }
        }
        shared_safety = {
            "minimum_target_clearance_mm": 224.0,
            "maximum_target_clearance_mm": 236.0,
        }
        scoped_safety, clearance_range = apply_safe_descent_runtime_clearance_scope(
            wrist_record,
            shared_safety,
            self.descent_config(),
        )
        self.assertEqual(clearance_range, [210.0, 250.0])
        self.assertEqual(
            wrist_record["validated_workspace"]["normal_clearance_mm"],
            [210.0, 250.0],
        )
        self.assertEqual(scoped_safety["minimum_target_clearance_mm"], 210.0)
        self.assertEqual(scoped_safety["maximum_target_clearance_mm"], 250.0)
        self.assertEqual(shared_safety["minimum_target_clearance_mm"], 224.0)
        self.assertEqual(shared_safety["maximum_target_clearance_mm"], 236.0)

    def test_plan_moves_only_along_support_normal_to_100mm(self):
        descent = self.descent_config()
        observation = {
            "surface_point_base_m": [0.0, 0.0, 0.0],
            "support_up_normal_base": [0.0, 0.0, 1.0],
        }

        def fake_ik(_kin, q_start, tcp_targets, **_kwargs):
            path = [list(q_start)]
            path.extend(
                [[pose[0], pose[1], pose[2], 0.0, 0.0, 0.0] for pose in tcp_targets[1:]]
            )
            return {"joint_path": path, "status": "fake_ok"}

        with patch(
            "scripts.run_go2_visual_alignment.solve_continuous_ik_path",
            side_effect=fake_ik,
        ), patch(
            "scripts.run_go2_visual_alignment.check_collision_path",
            return_value={"sample_count": 14},
        ), patch(
            "scripts.run_go2_visual_alignment.validate_torque_envelope",
            return_value={"maximum_limit_fraction": 0.5},
        ):
            plan = compute_safe_descent_plan(
                [0.0, 0.0, 0.225, 0.0, 0.0, 0.0],
                observation,
                descent_config=descent,
                alignment={
                    "maximum_fk_position_error_mm": 1.0,
                    "maximum_fk_orientation_error_deg": 0.5,
                },
                tcp_kinematics=LinearKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                applied_support_up=[0.0, 0.0, 1.0],
                side_scale=1.0,
                torque_limits=[1.0] * 6,
            )
        self.assertAlmostEqual(plan["initial_normal_clearance_mm"], 225.0)
        self.assertAlmostEqual(plan["descent_distance_mm"], 125.0)
        self.assertEqual(plan["segment_count"], 13)
        self.assertEqual(
            plan["joint_path"][0], [0.0, 0.0, 0.225, 0.0, 0.0, 0.0]
        )
        self.assertAlmostEqual(plan["expected_clearances_mm"][-1], 100.0)
        self.assertTrue(
            all(
                later < earlier
                for earlier, later in zip(
                    plan["expected_clearances_mm"],
                    plan["expected_clearances_mm"][1:],
                )
            )
        )
        endpoint = evaluate_safe_descent_endpoint(
            plan,
            plan["joint_path"][-1],
            descent_config=descent,
            tcp_kinematics=LinearKinematics(),
        )
        self.assertTrue(endpoint["passed"])
        self.assertAlmostEqual(endpoint["measured_normal_clearance_mm"], 100.0)
        self.assertAlmostEqual(endpoint["progress_ratio"], 1.0)


if __name__ == "__main__":
    unittest.main()
