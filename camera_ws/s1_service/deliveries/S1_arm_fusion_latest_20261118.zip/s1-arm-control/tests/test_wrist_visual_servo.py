import ast
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from types import SimpleNamespace
import tempfile
import time
import unittest
from unittest.mock import patch

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in __import__("sys").path:
    __import__("sys").path.insert(0, str(PROJECT_ROOT))

from s1_control.wrist_visual_servo import (
    camera_tilt_from_down_deg,
    dynamic_base_camera,
    evaluate_executed_tangent_correction,
    extract_single_surface_observation,
    joint_margin_details,
    load_wrist_servo_config,
    plan_high_hover_tangent_correction,
    support_plane_geometry,
    validate_local_joint_step,
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class WristVisualServoTests(unittest.TestCase):
    def setUp(self):
        self.safety = {
            "maximum_iterations": 3,
            "convergence_xy_mm": 3.0,
            "maximum_initial_xy_error_mm": 30.0,
            "maximum_xy_step_mm": 10.0,
            "maximum_cumulative_tangent_motion_mm": 30.0,
            "minimum_camera_target_depth_mm": 300.0,
            "maximum_camera_target_depth_mm": 500.0,
            "minimum_target_clearance_mm": 200.0,
            "maximum_target_clearance_mm": 300.0,
            "maximum_joint_step_rad": 0.15,
            "minimum_joint_margin_deg": 10.0,
            "maximum_camera_tilt_from_down_deg": 15.0,
            "maximum_fk_position_error_mm": 1.0,
            "maximum_fk_orientation_error_deg": 0.5,
            "worker_timeout_s": 15.0,
            "final_hold_s": 2.0,
            "collision_step_rad": 0.02,
            "maximum_post_motion_joint_error_rad": 0.02,
            "minimum_post_motion_xy_progress_ratio": 0.5,
            "maximum_post_motion_xy_progress_ratio": 1.5,
            "minimum_post_motion_direction_cosine": 0.5,
            "maximum_post_motion_tcp_z_drift_mm": 3.0,
            "post_motion_settle_s": 0.5,
            "post_motion_sample_count": 10,
        }
        self.workspace = {
            "tcp_base_x_mm": [-60.0, 55.0],
            "tcp_base_y_mm": [300.0, 345.0],
            "normal_clearance_mm": [225.0, 290.0],
            "maximum_camera_tilt_from_support_down_deg": 10.0,
        }

    def test_dynamic_transform_maps_camera_through_flange(self):
        flange_pose = [1.0, 2.0, 3.0, 0.0, 0.0, 0.0, 1.0]
        flange_camera = np.eye(4)
        flange_camera[:3, 3] = [0.1, -0.2, 0.3]
        result = dynamic_base_camera(flange_pose, flange_camera)
        self.assertTrue(np.allclose(result[:3, 3], [1.1, 1.8, 3.3]))

    def test_camera_tilt_is_measured_from_world_vertical_down(self):
        flange_pose = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]
        camera_down = np.eye(4)
        camera_down[:3, :3] = np.diag([1.0, -1.0, -1.0])
        self.assertAlmostEqual(
            camera_tilt_from_down_deg(flange_pose, camera_down), 0.0
        )

        angle = math.radians(12.0)
        camera_tilted = camera_down.copy()
        rotation_y = np.array(
            [
                [math.cos(angle), 0.0, math.sin(angle)],
                [0.0, 1.0, 0.0],
                [-math.sin(angle), 0.0, math.cos(angle)],
            ]
        )
        camera_tilted[:3, :3] = rotation_y @ camera_down[:3, :3]
        self.assertAlmostEqual(
            camera_tilt_from_down_deg(flange_pose, camera_tilted), 12.0
        )

    def test_single_target_transform_and_serial_binding(self):
        metadata = {"quality_pass": True, "serial": "D455"}
        detection = {
            "schema_version": 2,
            "status": "DETECTED_CAMERA_FRAME_ONLY",
            "camera_frame_only": True,
            "accepted_candidate_count": 1,
            "plane": {"quality_pass": True, "normal_cam": [0.0, 0.0, 1.0]},
            "selected": {
                "accepted": True,
                "component_id": 2,
                "target_id": "component_002",
                "confidence_score": 0.9,
                "surface_point_cam_m": [0.1, 0.2, 0.3],
            },
        }
        transform = np.eye(4)
        transform[:3, :3] = np.diag([1.0, -1.0, -1.0])
        transform[:3, 3] = [1.0, 2.0, 3.0]
        result = extract_single_surface_observation(
            detection, metadata, transform, "D455", self.safety
        )
        self.assertTrue(
            np.allclose(result["surface_point_base_m"], [1.1, 1.8, 2.7])
        )
        self.assertTrue(
            np.allclose(result["support_up_normal_base"], [0.0, 0.0, 1.0])
        )
        metadata["serial"] = "OTHER"
        with self.assertRaisesRegex(RuntimeError, "serial"):
            extract_single_surface_observation(
                detection, metadata, transform, "D455", self.safety
            )

    def test_camera_target_depth_gate_rejects_near_and_far_observations(self):
        metadata = {"quality_pass": True, "serial": "D455"}
        detection = {
            "schema_version": 2,
            "status": "DETECTED_CAMERA_FRAME_ONLY",
            "camera_frame_only": True,
            "accepted_candidate_count": 1,
            "plane": {"quality_pass": True, "normal_cam": [0.0, 0.0, 1.0]},
            "selected": {
                "accepted": True,
                "surface_point_cam_m": [0.0, 0.0, 0.299],
            },
        }
        camera_down = np.eye(4)
        camera_down[:3, :3] = np.diag([1.0, -1.0, -1.0])
        with self.assertRaisesRegex(RuntimeError, "camera target depth"):
            extract_single_surface_observation(
                detection, metadata, camera_down, "D455", self.safety
            )

        detection["selected"]["surface_point_cam_m"][2] = 0.501
        with self.assertRaisesRegex(RuntimeError, "camera target depth"):
            extract_single_surface_observation(
                detection, metadata, camera_down, "D455", self.safety
            )

    def test_tangent_correction_is_clipped_and_preserves_normal_clearance(self):
        tcp = [0.0, 0.32, 0.08, 0.0, 0.0, 0.0, 1.0]
        support_up = np.asarray([-0.08, -0.06, 0.995], dtype=float)
        support_up /= np.linalg.norm(support_up)
        raw_tangent = np.asarray([0.018, 0.024, 0.0], dtype=float)
        tangent = raw_tangent - np.dot(raw_tangent, support_up) * support_up
        target = np.asarray(tcp[:3]) - 0.24 * support_up + tangent
        result = plan_high_hover_tangent_correction(
            tcp, target, support_up, self.safety, self.workspace
        )
        self.assertFalse(result["converged"])
        self.assertAlmostEqual(result["tangent_step_norm_mm"], 10.0)
        desired = result["desired_tcp_pose_xyz_xyzw"]
        self.assertAlmostEqual(
            float(np.dot(np.asarray(desired[:3]) - np.asarray(tcp[:3]), support_up)),
            0.0,
            places=9,
        )
        self.assertEqual(desired[3:], tcp[3:])
        self.assertTrue(result["normal_height_and_orientation_unchanged"])

        close = plan_high_hover_tangent_correction(
            tcp,
            np.asarray(tcp[:3]) - 0.24 * support_up + tangent * 0.05,
            support_up,
            self.safety,
            self.workspace,
        )
        self.assertTrue(close["converged"])
        self.assertEqual(close["desired_tcp_pose_xyz_xyzw"], tcp)

    def test_runtime_uses_current_support_normal_result_key(self):
        script = PROJECT_ROOT / "scripts" / "run_wrist_high_hover_servo.py"
        source = script.read_text(encoding="utf-8")
        self.assertNotIn('correction["support_normal_base"]', source)
        self.assertIn('correction["support_up_normal_base"]', source)

    def test_post_motion_verification_accepts_effective_tangent_step(self):
        result = evaluate_executed_tangent_correction(
            [0.0] * 6,
            [0.005, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.32, 0.100, 0.0, 0.0, 0.0, 1.0],
            [0.010, 0.32, 0.100, 0.0, 0.0, 0.0, 1.0],
            [0.008, 0.321, 0.101, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 1.0],
            self.safety,
        )
        self.assertTrue(result["passed"])
        self.assertAlmostEqual(result["tangent_progress_ratio"], 0.8)
        self.assertAlmostEqual(result["support_normal_drift_mm"], 1.0)

    def test_post_motion_verification_rejects_undertravel_and_normal_drift(self):
        result = evaluate_executed_tangent_correction(
            [0.0] * 6,
            [0.0, 0.0, 0.03, 0.0, 0.0, 0.0],
            [0.0, 0.32, 0.100, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.330, 0.100, 0.0, 0.0, 0.0, 1.0],
            [0.0015, 0.3208, 0.093, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 1.0],
            self.safety,
        )
        self.assertFalse(result["passed"])
        self.assertIn("joint_tracking_error_too_large", result["reasons"])
        self.assertIn("tangent_progress_ratio_too_small", result["reasons"])
        self.assertIn("tangent_direction_mismatch", result["reasons"])
        self.assertIn("support_normal_drift_too_large", result["reasons"])

    def test_clearance_and_joint_step_are_hard_gates(self):
        tcp = [0.0, 0.32, 0.18, 0.0, 0.0, 0.0, 1.0]
        with self.assertRaisesRegex(RuntimeError, "clearance"):
            plan_high_hover_tangent_correction(
                tcp,
                [0.0, 0.32, 0.13],
                [0.0, 0.0, 1.0],
                self.safety,
                self.workspace,
            )

    def test_joint_margin_details_identify_limiting_axis(self):
        details = joint_margin_details(
            [0.0, math.radians(20.0), math.radians(30.0),
             math.radians(80.0), 0.0, 0.0]
        )
        self.assertEqual(len(details), 6)
        self.assertEqual(details[3]["joint"], 4)
        self.assertAlmostEqual(details[3]["margin_deg"], 7.0)
        self.assertEqual(
            min(details, key=lambda item: item["margin_deg"])["joint"], 4
        )
        with self.assertRaisesRegex(RuntimeError, "joint step"):
            validate_local_joint_step(
                [0.0, 0.5, 0.5, 0.0, 0.0, 0.0],
                [0.2, 0.5, 0.5, 0.0, 0.0, 0.0],
                self.safety,
            )

    def test_binding_hash_change_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "calibration").mkdir()
            (root / "config").mkdir()
            candidate_path = root / "calibration/candidate.json"
            tcp_path = root / "calibration/tcp.json"
            vision_path = root / "config/vision.yaml"
            candidate_path.write_text(
                json.dumps(
                    {
                        "quantity": "T_flange_camera",
                        "status": "candidate_pending_physical_validation",
                        "runtime_approved": False,
                        "value_T_flange_camera": np.eye(4).tolist(),
                        "provenance": {"camera_serial": "D455"},
                    }
                ),
                encoding="utf-8",
            )
            tcp_path.write_text("tcp", encoding="utf-8")
            vision_path.write_text("vision", encoding="utf-8")
            config = {
                "schema_version": 1,
                "mode": "high_hover_xy_only",
                "candidate_policy": "coarse_closed_loop_only",
                "camera_serial": "D455",
                "bindings": {
                    "eye_in_hand_candidate": {
                        "path": "calibration/candidate.json",
                        "sha256": sha(candidate_path),
                    },
                    "tcp": {
                        "path": "calibration/tcp.json",
                        "sha256": sha(tcp_path),
                    },
                    "vision_config": {
                        "path": "config/vision.yaml",
                        "sha256": sha(vision_path),
                    },
                },
                "safety": self.safety,
            }
            config_path = root / "config/servo.json"
            config_path.write_text(json.dumps(config), encoding="utf-8")
            loaded = load_wrist_servo_config(config_path, root=root)
            self.assertTrue(np.allclose(loaded.transform_flange_camera, np.eye(4)))

            vision_path.write_text("changed", encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "SHA-256 mismatch"):
                load_wrist_servo_config(config_path, root=root)

    def test_runtime_script_never_commands_gripper(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        called_attributes = {
            node.func.attr
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        }
        self.assertNotIn("control_gripper", called_attributes)
        self.assertNotIn("command_mm", called_attributes)

    def test_runtime_routes_all_locked_position_commands_through_arm(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertNotIn("arm._arm.joint_control_mit", source)
        self.assertIn("arm.set_position_commander", source)
        self.assertIn("arm.command_position", source)
        self.assertIn("tilt_commander.set_support_up_normal", source)
        self.assertIn("validated_horizontal_support_plane", source)

    def test_runtime_config_requires_tilt_compensation_and_four_mm_step(self):
        loaded = load_wrist_servo_config(
            PROJECT_ROOT / "config" / "wrist_high_hover_servo.json"
        )
        self.assertTrue(
            loaded.record["tilt_compensation"][
                "required_for_position_control"
            ]
        )
        self.assertEqual(loaded.record["tilt_compensation"]["scale"], 1.0)
        self.assertEqual(
            loaded.record["tilt_compensation"]["gravity_direction_source"],
            "validated_horizontal_support_plane",
        )
        self.assertEqual(
            loaded.record["tilt_compensation"][
                "maximum_support_normal_deviation_from_mount_deg"
            ],
            5.0,
        )
        self.assertEqual(
            loaded.record["tilt_compensation"]["support_normal_blend"],
            0.5,
        )
        self.assertEqual(loaded.record["safety"]["maximum_xy_step_mm"], 4.0)

    def test_live_capture_is_bound_to_saved_path_for_detection(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_path_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        capture = {"rgb": object(), "metadata": {"serial": "D455"}}
        saved_path = Path("data/wrist_high_hover_runs/test/capture.npz")
        detection_capture = module.bind_capture_path(capture, saved_path)

        self.assertEqual(detection_capture["path"], saved_path)
        self.assertNotIn("path", capture)
        self.assertIs(detection_capture["rgb"], capture["rgb"])

    def test_worker_runs_while_hold_commands_continue(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_for_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class Driver:
            def __init__(self):
                self.commands = 0

            def joint_control_mit(self, q):
                self.commands += 1

        class Limits:
            settle_seconds = 0.01

        class FakeArm:
            dt = 0.005
            limits = Limits()

            def __init__(self):
                self._arm = Driver()

            def command_position(self, q):
                return self._arm.joint_control_mit(q)

            def get_pos(self):
                return [0.0] * 7

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *args, **kwargs):
                return None

        fake = FakeArm()

        def worker():
            time.sleep(0.035)
            return "done"

        result, median = module.run_worker_while_holding(
            fake, [0.0] * 6, worker, timeout_s=1.0, label="test"
        )
        self.assertEqual(result, "done")
        self.assertEqual(median, [0.0] * 6)
        self.assertGreaterEqual(fake._arm.commands, 3)

    def test_startup_feedback_gate_skips_all_zero_placeholder_frames(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_startup_feedback_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        valid_q = [0.1, 0.5, 0.7, 0.2, 0.0, 0.1, 0.0]
        rows = [
            {"q": [0.0] * 7, "temp": [0.0] * 7},
            {"q": [0.0] * 7, "temp": [0.0] * 7},
            {"q": valid_q, "temp": [30.0] * 7},
            {"q": valid_q, "temp": [31.0] * 7},
            {"q": valid_q, "temp": [32.0] * 7},
        ]

        class FakeArm:
            def __init__(self):
                self.index = 0

            def get_pos(self):
                return rows[self.index]["q"]

            def get_temp(self):
                return rows[self.index]["temp"]

            def get_vel(self):
                velocity = [0.0] * 7
                self.index = min(self.index + 1, len(rows) - 1)
                return velocity

        q, temperature, summary = module.wait_for_valid_feedback(
            FakeArm(),
            55.0,
            timeout_s=1.0,
            required_consecutive=3,
            sample_period_s=0.0,
        )
        self.assertEqual(q, valid_q[:6])
        self.assertEqual(temperature, [31.0] * 7)
        self.assertTrue(summary["ready"])
        self.assertEqual(summary["attempt_count"], 5)
        self.assertEqual(summary["invalid_sample_count"], 2)

    def test_startup_feedback_gate_times_out_on_all_zero_frames(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_startup_timeout_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class FakeArm:
            def get_pos(self):
                return [0.0] * 7

            def get_temp(self):
                return [0.0] * 7

            def get_vel(self):
                return [0.0] * 7

        with patch.object(
            module.time, "monotonic", side_effect=[0.0, 0.0, 0.2]
        ):
            with self.assertRaisesRegex(RuntimeError, "startup feedback not ready"):
                module.wait_for_valid_feedback(
                    FakeArm(),
                    55.0,
                    timeout_s=0.1,
                    required_consecutive=3,
                    sample_period_s=0.0,
                )

    def test_startup_gate_accepts_small_j2_zero_offset_but_lock_remains_strict(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_zero_offset_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        zero_offset_q = [0.0, -0.025, 0.0, 0.0, 0.0, 0.0, 0.0]

        class FakeArm:
            def get_pos(self):
                return zero_offset_q

            def get_temp(self):
                return [30.0] * 7

            def get_vel(self):
                return [0.0] * 7

        q, temperature, summary = module.wait_for_valid_feedback(
            FakeArm(),
            55.0,
            timeout_s=1.0,
            required_consecutive=3,
            sample_period_s=0.0,
        )
        self.assertEqual(q[1], -0.025)
        self.assertEqual(temperature, [30.0] * 7)
        self.assertTrue(summary["ready"])

        q_teach, _ = module._validated_live_state(
            zero_offset_q, [30.0] * 7, 55.0
        )
        self.assertEqual(q_teach[1], -0.025)
        strict_margin = min(
            item["margin_deg"] for item in module.joint_margin_details(q_teach)
        )
        self.assertLess(strict_margin, 0.0)

        with self.assertRaisesRegex(RuntimeError, "hard joint limit: J2"):
            module._validated_live_state(
                [0.0, -0.04, 0.0, 0.0, 0.0, 0.0, 0.0],
                [30.0] * 7,
                55.0,
            )

    def test_post_motion_hold_collects_settled_joint_median(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_post_motion_sample_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class Driver:
            def __init__(self):
                self.commands = 0

            def joint_control_mit(self, q):
                self.commands += 1

        class FakeArm:
            dt = 0.001

            def __init__(self):
                self._arm = Driver()

            def command_position(self, q):
                return self._arm.joint_control_mit(q)

            def get_pos(self):
                return [0.01] * 6 + [0.0]

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *args, **kwargs):
                return None

        arm = FakeArm()
        trace = []
        measured = module.sample_hold_joint_median(
            arm,
            [0.01] * 6,
            settle_s=0.002,
            sample_count=3,
            label="test_post_motion_hold",
            trace=trace,
        )
        self.assertEqual(measured, [0.01] * 6)
        self.assertGreaterEqual(arm._arm.commands, 3)
        self.assertEqual(len(trace), arm._arm.commands)
        self.assertEqual(trace[-1]["phase"], "sampling")
        self.assertEqual(
            trace[-1]["commanded_arm_q_rad"], [0.01] * 6
        )
        self.assertEqual(
            trace[-1]["measured_motor_position_rad"], [0.01] * 6 + [0.0]
        )
        self.assertEqual(
            trace[-1]["arm_joint_error_command_minus_measured_rad"],
            [0.0] * 6,
        )

    def test_finalize_run_log_persists_terminal_result(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_finalize_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        with tempfile.TemporaryDirectory() as temporary:
            log_path = Path(temporary) / "run.json"
            log = {"status": "live_precheck_passed"}
            module.finalize_run_log(
                log_path,
                log,
                status="cancelled_after_motion_reject",
                result_name="CANCELLED_AFTER_MOTION_REJECT",
            )
            saved = json.loads(log_path.read_text(encoding="utf-8"))

        self.assertEqual(saved["status"], "cancelled_after_motion_reject")
        self.assertEqual(saved["result"], "CANCELLED_AFTER_MOTION_REJECT")
        self.assertIn("finished_at", saved)

    def test_teach_lock_summary_reports_stability_and_limiting_joint(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_teach_summary_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        samples = [
            [0.0, 0.5, 0.7, 0.2, 0.0, 0.1],
            [0.001, 0.501, 0.699, 0.2, 0.0, 0.104],
            [-0.001, 0.499, 0.701, 0.2, 0.0, 0.098],
        ]
        result = module.summarize_teach_lock_samples(samples)
        self.assertEqual(result["sample_count"], 3)
        self.assertEqual(result["maximum_span_joint"], 6)
        self.assertAlmostEqual(result["maximum_span_rad"], 0.006)
        self.assertEqual(result["median_q_rad"], samples[0])

        with self.assertRaisesRegex(ValueError, "6 finite joints"):
            module.summarize_teach_lock_samples([[0.0] * 5])

    def test_hold_worker_supports_operator_wait_without_timeout(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_operator_wait_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class Driver:
            def __init__(self):
                self.commands = 0

            def joint_control_mit(self, q):
                self.commands += 1

        class Limits:
            settle_seconds = 0.01

        class FakeArm:
            dt = 0.005
            limits = Limits()

            def __init__(self):
                self._arm = Driver()

            def command_position(self, q):
                return self._arm.joint_control_mit(q)

            def get_pos(self):
                return [0.0] * 7

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *args, **kwargs):
                return None

        fake = FakeArm()

        def operator_wait():
            time.sleep(0.025)
            return "q"

        result, _ = module.run_worker_while_holding(
            fake,
            [0.0] * 6,
            operator_wait,
            timeout_s=None,
            label="operator_wait_test",
        )
        self.assertEqual(result, "q")
        self.assertGreaterEqual(fake._arm.commands, 2)

    def test_teaching_lock_transitions_directly_from_gravity_to_joint_hold(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_teach_transition_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class Driver:
            def __init__(self):
                self.hold_commands = []

            def joint_control_mit(self, q):
                self.hold_commands.append(list(q))

        class Limits:
            max_temp_c = 55.0

        class FakeArm:
            limits = Limits()

            def __init__(self):
                self._arm = Driver()
                self.gravity_calls = 0
                self.disable_calls = 0

            def command_position(self, q):
                return self._arm.joint_control_mit(q)

            def gravity(self):
                self.gravity_calls += 1

            def get_pos(self):
                return [0.0, 0.5, 0.7, 0.2, 0.0, 0.1, 0.0]

            def get_temp(self):
                return [30.0] * 7

            def disable(self):
                self.disable_calls += 1

        fake = FakeArm()
        with patch("builtins.input", return_value="l"), \
             patch.object(
                 module,
                 "check_collision_segment",
                 return_value={"sample_count": 1},
             ), \
             patch.object(module.time, "sleep"):
            q_lock, record = module.teaching_until_locked(
                fake,
                collision_checker=object(),
                collision_step_rad=0.02,
                minimum_joint_margin_deg=10.0,
            )

        self.assertEqual(q_lock, [0.0, 0.5, 0.7, 0.2, 0.0, 0.1])
        self.assertGreaterEqual(fake.gravity_calls, module.TEACH_LOCK_SAMPLE_COUNT)
        self.assertEqual(fake._arm.hold_commands[-1], q_lock)
        self.assertEqual(fake.disable_calls, 0)
        self.assertEqual(record["collision"], {"sample_count": 1})

    def test_preview_teaching_rejects_tilt_then_locks_and_releases_camera(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_preview_lock_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        events = []

        class Driver:
            def joint_control_mit(self, q):
                events.append("joint_hold")

        class Limits:
            max_temp_c = 55.0

        class FakeArm:
            limits = Limits()

            def __init__(self):
                self._arm = Driver()

            def command_position(self, q):
                return self._arm.joint_control_mit(q)

            def gravity(self):
                events.append("gravity")

            def get_pos(self):
                return [0.0, 0.5, 0.7, 0.2, 0.0, 0.1, 0.0]

            def get_temp(self):
                return [30.0] * 7

        class FakePreview:
            def __init__(self):
                self.ready = True
                self.alive = False
                self.error = None
                self.tilts = []

            def start(self):
                events.append("preview_start")

            def set_tilt(self, value):
                self.tilts.append(value)

            def request_stop(self):
                events.append("preview_stop")

            def join(self, timeout=0.0):
                events.append("preview_join")

        summary = {
            "sample_count": 15,
            "median_q_rad": [0.0, 0.5, 0.7, 0.2, 0.0, 0.1],
            "span_rad": [0.0] * 6,
            "maximum_span_rad": 0.0,
            "maximum_span_joint": 1,
        }
        preview = FakePreview()
        with patch("builtins.input", side_effect=["l", "l"]), \
             patch.object(
                 module,
                 "collect_teach_lock_samples",
                 return_value=(summary, [30.0] * 7),
             ), \
             patch.object(
                 module,
                 "teaching_camera_tilt_deg",
                 side_effect=[20.0, 10.0],
             ), \
             patch.object(
                 module,
                 "check_collision_segment",
                 return_value={"sample_count": 1},
             ), \
             patch.object(module, "TEACH_CAMERA_RELEASE_SETTLE_S", 0.0):
            q_lock, record = module.teaching_until_locked_with_preview(
                FakeArm(),
                collision_checker=object(),
                collision_step_rad=0.02,
                minimum_joint_margin_deg=10.0,
                maximum_camera_tilt_from_down_deg=15.0,
                flange_kinematics=object(),
                transform_flange_camera=np.eye(4),
                preview=preview,
            )

        self.assertEqual(q_lock, summary["median_q_rad"])
        self.assertEqual(record["camera_tilt_from_down_deg"], 10.0)
        self.assertIn("preview_start", events)
        self.assertIn("preview_stop", events)
        self.assertLess(events.index("preview_stop"), events.index("joint_hold"))

    def test_teaching_preview_uses_spawn_process_context(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_spawn_preview_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        preview = module.TeachingCameraPreview(
            {
                "camera_serial": "D455",
                "capture": {
                    "width": 640,
                    "height": 480,
                    "fps": 30,
                    "warmup_frames": 15,
                },
                "safety": {"maximum_camera_tilt_from_down_deg": 15.0},
            },
            {"workspace_roi": {"normalized_xyxy": [0.1, 0.2, 0.8, 0.9]}},
        )
        try:
            self.assertEqual(preview.start_method, "spawn")
            self.assertIsNone(preview._process)
        finally:
            preview._status_queue.close()

    def test_camera_release_settle_keeps_gravity_compensation_active(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_release_settle_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class Limits:
            max_temp_c = 55.0

        class FakeArm:
            limits = Limits()

            def __init__(self):
                self.gravity_calls = 0

            def gravity(self):
                self.gravity_calls += 1

            def get_pos(self):
                return [0.0, 0.5, 0.7, 0.2, 0.0, 0.1, 0.0]

            def get_temp(self):
                return [30.0] * 7

        class FakePreview:
            alive = False
            error = None

            def request_stop(self):
                pass

            def join(self, timeout=0.0):
                pass

        arm = FakeArm()
        with patch.object(module, "TEACH_CAMERA_RELEASE_SETTLE_S", 0.02):
            module.stop_preview_while_teaching(arm, FakePreview())
        self.assertGreater(arm.gravity_calls, 0)

    def test_visual_error_classification_is_deliberately_narrow(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_recovery_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        self.assertTrue(
            module.is_recoverable_visual_error(
                RuntimeError("XY error 95.3 mm exceeds manually bounded range")
            )
        )
        self.assertTrue(
            module.is_recoverable_visual_error(
                ValueError("single-target detection failed: PLANE_REJECTED")
            )
        )
        self.assertTrue(
            module.is_recoverable_visual_error(
                RuntimeError("Frame didn't arrive within 5000")
            )
        )
        self.assertFalse(
            module.is_recoverable_visual_error(
                RuntimeError("speed>0.5 x3")
            )
        )
        self.assertFalse(
            module.is_recoverable_visual_error(KeyError("path"))
        )

    def test_support_normal_ab_evaluation_accepts_small_same_command_drift(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_ab_pass_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        result = module.evaluate_support_normal_ab(
            [0.0] * 6,
            [0.001, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0015, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            [0.001, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 1.0],
        )
        self.assertTrue(result["passed"])
        self.assertAlmostEqual(result["tcp_drift_norm_mm"], 1.0)
        self.assertEqual(result["reasons"], [])

    def test_support_normal_ab_evaluation_rejects_compensation_drift(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_ab_reject_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        result = module.evaluate_support_normal_ab(
            [0.0] * 6,
            [0.0] * 6,
            [0.0, 0.0, 0.008, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            [0.003, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 1.0],
        )
        self.assertFalse(result["passed"])
        self.assertIn("incremental_joint_drift_too_large", result["reasons"])
        self.assertIn("tcp_drift_too_large", result["reasons"])
        self.assertIn("target_error_worsened", result["reasons"])

    def test_support_normal_ab_wrapper_forces_hold_only_mode(self):
        wrapper = PROJECT_ROOT / "scripts/diagnose_support_normal_ab.py"
        source = wrapper.read_text(encoding="utf-8")
        self.assertIn('args.append("--compensation-ab-only")', source)
        servo_source = (
            PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        ).read_text(encoding="utf-8")
        branch = servo_source.index("if args.compensation_ab_only:",
                                    servo_source.index("NORMAL_CLEARANCE_MM"))
        move = servo_source.index("abort = arm.move(", branch)
        self.assertLess(branch, move)
        self.assertIn("run_support_normal_ab(", servo_source[branch:move])

    def test_support_normal_ab_blend_is_bounded_to_25_or_50_percent(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_ab_blend_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        self.assertEqual(
            module.AB_ALLOWED_SUPPORT_NORMAL_BLENDS,
            (0.25, 0.50),
        )
        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--compensation-ab-only",
                    "--compensation-ab-blend",
                    "0.75",
                ]
            )

    def test_support_normal_ab_blend_requires_hold_only_mode(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_ab_scope_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        with self.assertRaises(SystemExit):
            module.main(["--compensation-ab-blend", "0.50"])

    def test_support_normal_motion_ab_requires_teach_lock_and_half_blend(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_motion_ab_args_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--compensation-motion-ab-only",
                    "--compensation-ab-blend",
                    "0.50",
                ]
            )
        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--teach-lock",
                    "--compensation-motion-ab-only",
                    "--compensation-ab-blend",
                    "0.25",
                ]
            )

    def test_support_normal_motion_ab_evaluation_requires_all_four_legs(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_motion_ab_eval_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        passing_leg = {"passed": True, "reasons": []}
        result = module.evaluate_support_normal_motion_ab(
            {
                "mount_only": {
                    "outbound": passing_leg,
                    "return": passing_leg,
                },
                "support_normal": {
                    "outbound": passing_leg,
                    "return": passing_leg,
                },
            }
        )
        self.assertTrue(result["passed"])

        result = module.evaluate_support_normal_motion_ab(
            {
                "mount_only": {
                    "outbound": passing_leg,
                    "return": passing_leg,
                },
                "support_normal": {
                    "outbound": {
                        "passed": False,
                        "reasons": ["tangent_direction_mismatch"],
                    },
                },
            }
        )
        self.assertFalse(result["passed"])
        self.assertIn(
            "support_normal_outbound_tangent_direction_mismatch",
            result["reasons"],
        )
        self.assertIn("support_normal_return_missing", result["reasons"])

    def test_support_normal_motion_ab_target_requires_observable_joint_change(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_motion_ab_target_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        with self.assertRaises(RuntimeError):
            module.validate_support_normal_motion_ab_target(
                [0.0] * 6,
                [0.0, 0.0, 0.011, 0.0, 0.0, 0.0],
            )
        result = module.validate_support_normal_motion_ab_target(
            [0.0] * 6,
            [0.0, 0.0, 0.012, 0.0, 0.0, 0.0],
        )
        self.assertAlmostEqual(result["maximum_joint_delta_rad"], 0.012)

    def test_support_normal_motion_ab_wrapper_is_fixed_to_four_mm_half_blend(self):
        wrapper = PROJECT_ROOT / "scripts/diagnose_support_normal_motion_ab.py"
        source = wrapper.read_text(encoding="utf-8")
        self.assertIn('args.append("--compensation-motion-ab-only")', source)
        self.assertIn('args.extend(["--compensation-ab-blend", "0.50"])', source)

        servo_source = (
            PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        ).read_text(encoding="utf-8")
        self.assertIn("AB_MOTION_TANGENT_STEP_MM = 4.0", servo_source)
        self.assertIn(
            "AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD = 0.012",
            servo_source,
        )
        self.assertIn(
            "same guarded 4 mm round-trip target in two phases",
            servo_source,
        )
        self.assertIn(
            "mount_only_must_return_before_support_normal_phase",
            servo_source,
        )

    def test_support_normal_signed_displacement_and_live_guard(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_live_normal_guard_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        signed = module.support_normal_signed_displacement_mm(
            [0.0, 0.0, 0.10, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 0.095, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 1.0],
        )
        self.assertAlmostEqual(signed, -5.0)
        self.assertIsNone(
            module.live_support_normal_guard_reason(-3.0)
        )
        self.assertEqual(
            module.live_support_normal_guard_reason(-3.001),
            "live_support_normal_downward_drift",
        )

    def test_support_normal_motion_only_requires_teach_lock_and_half_blend(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_motion_only_args_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--support-normal-motion-only",
                    "--compensation-ab-blend",
                    "0.50",
                ]
            )
        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--teach-lock",
                    "--support-normal-motion-only",
                    "--compensation-ab-blend",
                    "0.25",
                ]
            )

    def test_support_normal_motion_only_evaluation_requires_round_trip(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_motion_only_eval_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        passing_leg = {"passed": True, "reasons": []}
        result = module.evaluate_support_normal_only_motion(
            {"outbound": passing_leg, "return": passing_leg}
        )
        self.assertTrue(result["passed"])

        result = module.evaluate_support_normal_only_motion(
            {
                "outbound": {
                    "passed": False,
                    "reasons": ["live_support_normal_downward_drift"],
                }
            }
        )
        self.assertFalse(result["passed"])
        self.assertIn(
            "support_normal_outbound_live_support_normal_downward_drift",
            result["reasons"],
        )
        self.assertIn("support_normal_return_missing", result["reasons"])

    def test_support_normal_motion_only_wrapper_and_scope(self):
        wrapper = PROJECT_ROOT / "scripts/diagnose_support_normal_motion.py"
        source = wrapper.read_text(encoding="utf-8")
        self.assertIn('args.append("--support-normal-motion-only")', source)
        self.assertIn('args.extend(["--compensation-ab-blend", "0.50"])', source)

        servo_source = (
            PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        ).read_text(encoding="utf-8")
        branch_start = servo_source.index(
            "if args.support_normal_motion_only:",
            servo_source.index("NORMAL_CLEARANCE_MM"),
        )
        branch_end = servo_source.index(
            "if args.compensation_motion_ab_only:", branch_start
        )
        branch = servo_source[branch_start:branch_end]
        self.assertIn("run_support_normal_only_motion(", branch)
        self.assertNotIn("run_support_normal_motion_ab(", branch)
        self.assertIn(
            "SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM = 3.0",
            servo_source,
        )

    def test_j3_response_targets_change_only_positive_j3(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_targets_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        reference = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        targets = module.build_j3_positive_targets(reference)
        self.assertEqual(len(targets), 5)
        for target, offset in zip(targets, module.J3_RESPONSE_OFFSETS_RAD):
            self.assertEqual(target[:2], reference[:2])
            self.assertAlmostEqual(target[2], reference[2] + offset)
            self.assertEqual(target[3:], reference[3:])

    def test_j3_live_guard_ignores_j3_but_rejects_other_joint_drift(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_live_guard_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        reason, drift = module.live_other_joint_drift_guard_reason(
            [0.0, 0.0, 0.020, 0.0, 0.0, 0.0],
            [0.0] * 6,
            allowed_joint_index=2,
            maximum_other_joint_drift_rad=0.006,
        )
        self.assertIsNone(reason)
        self.assertAlmostEqual(drift, 0.0)

        reason, drift = module.live_other_joint_drift_guard_reason(
            [0.007, 0.0, 0.020, 0.0, 0.0, 0.0],
            [0.0] * 6,
            allowed_joint_index=2,
            maximum_other_joint_drift_rad=0.006,
        )
        self.assertEqual(reason, "live_other_joint_drift")
        self.assertAlmostEqual(drift, 0.007)

    def test_j3_response_stage_reports_ratio_and_other_joint_drift(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_stage_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        result = module.evaluate_j3_response_stage(
            [0.0] * 6,
            [0.0, 0.0, 0.020, 0.0, 0.0, 0.0],
            [0.001, 0.0, 0.015, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.10, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 0.103, 0.0, 0.0, 0.0, 1.0],
            [0.0, 0.0, 1.0],
        )
        self.assertAlmostEqual(result["response_ratio"], 0.75)
        self.assertAlmostEqual(result["maximum_other_joint_drift_rad"], 0.001)
        self.assertAlmostEqual(
            result["signed_support_normal_displacement_mm"], 3.0
        )

    def test_j3_response_evaluation_requires_full_response_and_return(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_eval_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        stages = [
            {
                "stage_index": index,
                "response_ratio": 0.75,
                "maximum_other_joint_drift_rad": 0.001,
            }
            for index in range(1, 6)
        ]
        result = module.evaluate_j3_positive_response(
            {
                "stages": stages,
                "return_maximum_joint_error_rad": 0.001,
            }
        )
        self.assertTrue(result["passed"])
        self.assertEqual(result["classification"], "responsive")

        stages[-1]["response_ratio"] = 0.05
        result = module.evaluate_j3_positive_response(
            {
                "stages": stages,
                "return_maximum_joint_error_rad": 0.001,
            }
        )
        self.assertFalse(result["passed"])
        self.assertIn("j3_positive_response_ratio_too_small", result["reasons"])

    def test_j3_response_mode_requires_teach_lock_and_half_blend(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_args_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--j3-response-only",
                    "--compensation-ab-blend",
                    "0.50",
                ]
            )
        with self.assertRaises(SystemExit):
            module.main(
                [
                    "--teach-lock",
                    "--j3-response-only",
                    "--compensation-ab-blend",
                    "0.25",
                ]
            )

    def test_j3_response_mode_scope_and_two_mm_live_guard(self):
        servo_source = (
            PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        ).read_text(encoding="utf-8")
        branch_start = servo_source.index(
            "if args.j3_response_only:",
            servo_source.index("NORMAL_CLEARANCE_MM"),
        )
        branch_end = servo_source.index(
            "if args.support_normal_motion_only:", branch_start
        )
        branch = servo_source[branch_start:branch_end]
        self.assertIn("run_j3_positive_response(", branch)
        self.assertIn("J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM = 2.0", servo_source)
        self.assertIn("J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD = 0.006", servo_source)

    def test_j3_closed_loop_bias_builds_and_releases_one_sided_lead(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_bias_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        bias = module.next_j3_closed_loop_bias(0.0, 0.010, 1.0)
        self.assertAlmostEqual(bias, 0.004)
        bias = module.next_j3_closed_loop_bias(bias, 0.010, 1.0)
        self.assertAlmostEqual(bias, 0.008)
        bias = module.next_j3_closed_loop_bias(bias, -0.010, 1.0)
        self.assertAlmostEqual(bias, 0.004)

        bias = 0.0
        for _ in range(20):
            bias = module.next_j3_closed_loop_bias(bias, -0.010, -1.0)
        self.assertAlmostEqual(bias, -module.J3_CLOSED_LOOP_MAX_BIAS_RAD)

    def test_j3_bias_envelope_changes_only_j3_in_motion_direction(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_envelope_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        start = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        goal = [1.1, 2.1, 3.02, 4.1, 5.1, 6.1]
        envelope = module.j3_bias_envelope_target(start, goal)
        self.assertEqual(envelope[:2], goal[:2])
        self.assertAlmostEqual(envelope[2], 3.06)
        self.assertEqual(envelope[3:], goal[3:])

        goal[2] = 2.98
        envelope = module.j3_bias_envelope_target(start, goal)
        self.assertAlmostEqual(envelope[2], 2.94)

    def test_j3_closed_loop_pauses_path_until_j3_responds(self):
        source_path = PROJECT_ROOT / "scripts/run_wrist_high_hover_servo.py"
        spec = importlib.util.spec_from_file_location(
            "run_wrist_high_hover_servo_j3_closed_loop_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        class FakeCommander:
            def __init__(self):
                self.position_bias_rad = [0.0] * 6
                self.last_snapshot = None

            def set_position_bias_rad(self, value):
                self.position_bias_rad = list(value)
                return list(value)

            def clear_position_bias(self):
                return self.set_position_bias_rad([0.0] * 6)

        class FakeKinematics:
            def fk(self, q):
                return [0.0, 0.0, 0.25, 0.0, 0.0, 0.0, 1.0]

        class FakeArm:
            def __init__(self, commander):
                self._position_commander = commander
                self.dt = 0.02
                self.limits = SimpleNamespace(
                    v_max_rad_s=0.12,
                    j6_v_max_rad_s=0.10,
                    motion_profile="linear",
                    settle_seconds=0.5,
                )
                self.position = [0.0, 1.0, 1.0, 0.0, 0.0, 0.0]

            def command_position(self, desired):
                command = [
                    desired[index] + self._position_commander.position_bias_rad[index]
                    for index in range(6)
                ]
                self.position[0] = float(desired[0])
                # Model a J3 actuator that ignores command errors below 8 mrad.
                if abs(command[2] - self.position[2]) >= 0.008 - 1e-12:
                    self.position[2] = float(desired[2])
                self._position_commander.last_snapshot = {
                    "target_q_rad": list(desired),
                    "command_target_q_rad": command,
                    "native_control_pos_return": 0,
                }

            def get_pos(self):
                return list(self.position) + [0.0]

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [30.0] * 7

            def guard(self, *args, **kwargs):
                return None

        clock = [0.0]

        def monotonic():
            return clock[0]

        def sleep(seconds):
            clock[0] += max(float(seconds), 0.02)

        commander = FakeCommander()
        arm = FakeArm(commander)
        with patch.object(module.time, "monotonic", side_effect=monotonic), patch.object(
            module.time, "sleep", side_effect=sleep
        ):
            result = module.run_j3_gated_tangent_move(
                arm,
                [0.0, 1.0, 1.0, 0.0, 0.0, 0.0],
                [0.01, 1.0, 1.02, 0.0, 0.0, 0.0],
                label="test",
                support_up_normal_base=[0.0, 0.0, 1.0],
                tcp_kinematics=FakeKinematics(),
                tilt_commander=commander,
            )

        self.assertEqual(result["mode"], "j3_closed_loop_gated")
        self.assertTrue(
            any(sample["trajectory_paused_for_j3"] for sample in result["samples"])
        )
        self.assertAlmostEqual(arm.position[2], 1.02, delta=0.004)
        self.assertGreaterEqual(result["final_bias_rad"], 0.004)


if __name__ == "__main__":
    unittest.main()
