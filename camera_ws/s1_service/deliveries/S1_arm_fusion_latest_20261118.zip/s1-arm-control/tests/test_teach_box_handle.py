import unittest
from types import SimpleNamespace
from scripts.teach_box_handle import gravity_tick,make_pose
class TeachHandleTests(unittest.TestCase):
    def test_tick_uses_native_gravity_not_position(self):
        calls=[]
        arm=SimpleNamespace(gravity=lambda:calls.append('gravity'),get_pos=lambda:[.1]*7)
        self.assertEqual(gravity_tick(arm),[.1]*7)
        self.assertEqual(calls,['gravity'])
    def test_pose_has_compatible_joint_and_tcp_fields(self):
        kin=SimpleNamespace(fk=lambda q:[*q[:3],0,0,0,1])
        grip=SimpleNamespace(gap_from_fb=lambda q:q*10)
        r=make_pose([[.1]*7,[.2]*7,[.3]*7],kin,grip)
        self.assertEqual(r['joint_rad'],[.2]*6)
        self.assertEqual(r['tcp_xyz_mm'],[200]*3)
        self.assertEqual(r['gripper_gap_mm'],2)
