"""Exercise descent planning through the real continuous IK helper, offline."""
import unittest
from unittest.mock import patch
import numpy as np
import scripts.run_go2_visual_alignment as flow

class AnalyticKinematics:
    def fk(self,q):
        return [q[0],.3,.1*q[2],0,0,0,1]
    def ik(self,xyz,orientation,seed):
        return [xyz[0],1.,xyz[2]*10,0.,0.,0.]

class DescentFirstWaypointTests(unittest.TestCase):
    def test_every_requested_descent_sample_reaches_the_actual_ik_path(self):
        for distance,step in [(30.,10.),(6.,10.),(30.,5.)]:
            with self.subTest(distance=distance,step=step):
                kin=AnalyticKinematics()
                cfg=dict(minimum_initial_normal_clearance_mm=90.,
                         maximum_initial_normal_clearance_mm=110.,
                         target_normal_clearance_mm=100.-distance,
                         maximum_descent_distance_mm=40.,maximum_cartesian_step_mm=step,
                         maximum_joint_step_rad=.15,minimum_joint_margin_deg=10.,
                         collision_step_rad=.01)
                with patch.object(flow,'check_collision_path',return_value={}), \
                     patch.object(flow,'differential_tilt_compensation_from_support_up',return_value=np.zeros(6)):
                    plan=flow.compute_safe_descent_plan(
                        [.25,1.,1.,0.,0.,0.],
                        dict(surface_point_base_m=[.25,.3,0.],support_up_normal_base=[0.,0.,1.]),
                        descent_config=cfg,
                        alignment=dict(maximum_fk_position_error_mm=1.,maximum_fk_orientation_error_deg=.5),
                        tcp_kinematics=kin,collision_checker=None,tilt_model=None,
                        applied_support_up=[0.,0.,1.],side_scale=1.,torque_limits=[1.]*6)
                self.assertEqual(len(plan['joint_path']),plan['segment_count']+1)
                heights=[1000*kin.fk(q)[2] for q in plan['joint_path']]
                self.assertAlmostEqual(heights[-1],100.-distance)
                self.assertTrue(all(0 < a-b <= step+1e-7 for a,b in zip(heights,heights[1:])))
                for q,target in zip(plan['joint_path'][1:],plan['tcp_targets_xyz_xyzw']):
                    np.testing.assert_allclose(kin.fk(q),target,atol=1e-12)

if __name__=='__main__':unittest.main()
