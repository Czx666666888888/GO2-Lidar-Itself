"""Hardware-free tests for shared-clock retiming and unchanged guards."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from s1_control.feedback_path import (
    SharedClockGovernor, forward_tracking_lag, move_feedback_synchronized,
)


class FeedbackPathTests(unittest.TestCase):
    def test_directional_lag_and_not_command_bias(self):
        self.assertAlmostEqual(forward_tracking_lag(
            [1,1,0,0,0,0], [.99,1.02,0,0,0,0], [1,-1,0,0,0,0]), .02)
        self.assertEqual(forward_tracking_lag([0]*6,[0]*6,[1]*6),0)

    def test_clock_inhibits_and_resumes_with_limited_slew(self):
        g=SharedClockGovernor()
        self.assertEqual(g.update(.004,.02),0)
        self.assertAlmostEqual(g.update(0,.02),.04)
        self.assertAlmostEqual(g.update(0,.02),.08)

    def test_invalid_limits_and_feedback_rejected(self):
        with self.assertRaises(ValueError): SharedClockGovernor(.004,.002)
        with self.assertRaises(ValueError): forward_tracking_lag([float('nan')]*6,[0]*6,[1]*6)

    def run_fake(self, follows=True, fault=None):
        class Clock:
            now=0.0
            def monotonic(self): return self.now
            def sleep(self,seconds): self.now+=max(seconds,.000001)
        class FakeArm:
            dt=.02
            limits=SimpleNamespace(v_max_rad_s=.05,j6_v_max_rad_s=.05,
                                   motion_profile='s_curve',settle_seconds=.1)
            def __init__(self):
                self.q=[0]*6;self.commands=[];self.guard_calls=0;self._arm=self
            def get_pos(self): return list(self.q)
            def get_vel(self): return [0]*6
            def get_temp(self): return [25]*7
            def command_position(self,q):
                self.commands.append(list(q))
                if follows: self.q=[x-.03 for x in q]
            def guard(self,*args,**kwargs):
                self.guard_calls+=1
                return fault
        arm=FakeArm();report={};clock=Clock()
        physical=[[0]*6,[.02]*6];command=[[.03]*6,[.05]*6]
        with patch('s1_control.feedback_path.time',clock):
            result=move_feedback_synchronized(arm,command,physical,'test',report)
        return arm,report,result

    def test_exact_offset_path_and_original_guard_preserved(self):
        arm,report,result=self.run_fake()
        self.assertIsNone(result)
        self.assertEqual(arm.commands[0],[.03]*6)
        self.assertTrue(all(abs(x-.05)<1e-12 for x in arm.commands[-1]))
        self.assertEqual(arm.guard_calls,len(arm.commands))
        self.assertTrue(report['status'].startswith('path_issued_pending'))
        self.assertTrue(all(.03-1e-12<=x<=.05+1e-12 for q in arm.commands for x in q))

    def test_frozen_feedback_cannot_finish(self):
        arm,report,result=self.run_fake(follows=False)
        self.assertIn('stalled',result)
        self.assertEqual(report['status'],'tracking_stalled')
        self.assertLess(arm.commands[-1][0],.04)

    def test_existing_guard_failure_propagates(self):
        arm,report,result=self.run_fake(fault='speed guard')
        self.assertIn('speed guard',result)
        self.assertEqual(report['status'],'guard_rejected')

    def test_nonconstant_bias_rejected(self):
        with self.assertRaisesRegex(ValueError,'constant learned offset'):
            move_feedback_synchronized(None,[[.03]*6,[.06]*6],[[0]*6,[.02]*6],'x',{})


if __name__=='__main__': unittest.main()
