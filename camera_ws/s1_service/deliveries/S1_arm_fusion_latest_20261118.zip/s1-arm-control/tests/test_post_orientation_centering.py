"""Exercise post-yaw centering flow without constructing real devices."""
import copy
from types import SimpleNamespace
import unittest
from unittest.mock import patch,Mock
import scripts.run_go2_visual_alignment as m
from s1_control.command_continuity import offset_command_path

class PostOrientationCenterTests(unittest.TestCase):
    def exercise(self,converged=False,final_error=1.,motion_fault=None):
        start=[.25,.3,2.2,0.,0.,.58];offset=[.01,0.,0.,0.,0.,.02]
        hold=[a+b for a,b in zip(start,offset)];target=list(start);target[0]+=.00656
        class Arm:
            def __init__(self):self.physical=list(start);self.moves=[];self.commands=[];self._position_commander=SimpleNamespace(last_snapshot=None)
            def get_pos(self):return self.physical+[0.]
            def command_position(self,q):
                self.commands.append(list(q));self.physical=[a-b for a,b in zip(q,offset)]
            def move_waypoints(self,path,label):
                self.moves.append(copy.deepcopy(path))
                for q in path:self.command_position(q)
                return motion_fault
        arm=Arm();history=[list(hold)];record={};captures=[]
        def capture(label,q):
            self.assertEqual(list(q),hold if len(captures)==0 or converged else arm.moves[-1][-1])
            captures.append(label)
            return {'capture_label':label},arm.get_pos()[:6]
        initial_observation={'surface_point_base_m':[.25656,.3,0.],'support_up_normal_base':[0.,0.,1.]}
        final_observation={**initial_observation,'fresh_final_marker':True}
        initial_check={'converged':converged,'initial_tangent_error_norm_mm':2. if converged else 6.56,'normal_clearance_mm':220.}
        final_check={'converged':final_error<=5.,'initial_tangent_error_norm_mm':final_error,'normal_clearance_mm':220.}
        checks=[dict(observation=initial_observation,check=initial_check,q_observed_rad=start),dict(observation=final_observation,check=final_check)]
        plan={'cartesian_path':initial_check,'alignment_joint_path':[start,target],'planning_start_q_rad':start}
        def worker(arm,q,fn,**kw):
            arm.command_position(q)
            return fn(),arm.get_pos()[:6]
        def handoff(arm,path,**kw):
            self.assertTrue(kw['preserve_physical_offsets'])
            return offset_command_path(arm.commands[-1],path)[0],{'command_path':'checked'}
        commander=SimpleNamespace(nominal_support_up_normal_base=[0.,0.,1.],compensation_scale=1.,set_support_up_normal=Mock())
        kwargs=dict(capture=capture,loaded=SimpleNamespace(record={'validated_workspace':{}}),
            alignment={'collision_step_rad':.005,'minimum_joint_margin_deg':10.,'hold_after_alignment_s':.5,'maximum_final_normal_drift_mm':6.},
            tcp_kinematics=None,flange_kinematics=None,collision_checker=None,tilt_model=None,
            commander=commander,tilt_config={'normal_transition_s':.5,'support_normal_blend':.5},
            torque_limits=[1.]*6,runtime={'worker_timeout_s':45.,'maximum_learned_position_bias_rad':.05},
            observation_safety={},executed_alignment_path=history,record=record,save_progress=lambda:None)
        with patch.object(m,'run_worker_while_holding',side_effect=worker), \
             patch.object(m,'compute_final_check',side_effect=checks) as check_mock, \
             patch.object(m,'compute_alignment_plan',return_value=plan) as planner, \
             patch.object(m,'prepare_continuous_alignment_path_while_holding',side_effect=handoff) as preflight, \
             patch.object(m,'guarded_hold',side_effect=lambda a,q,*args:a.command_position(q)), \
             patch.object(m,'sample_endpoint_hold',side_effect=lambda a,q,*args:a.get_pos()[:6]):
            try:result=m.run_post_orientation_centering(arm,hold,**kwargs)
            except RuntimeError as error:result=error
        return result,arm,history,record,captures,planner,preflight,check_mock

    def test_new_observation_corrects_center_and_preserves_rotated_direction_and_commands(self):
        result,arm,history,record,captures,planner,preflight,checks=self.exercise()
        self.assertEqual(captures,['post_orientation','post_orientation_final'])
        self.assertIs(planner.call_args.args[0]['observation'],record['initial_observation'])
        self.assertEqual(arm.moves[0][0],[.26,.3,2.2,0.,0.,.6])
        self.assertAlmostEqual(arm.moves[0][-1][5],.6)
        self.assertAlmostEqual(result[1][5],.58)
        self.assertEqual(history[-1],result[0])
        self.assertTrue(result[3]['fresh_final_marker'])
        self.assertEqual(record['status'],'passed')
        self.assertEqual(checks.call_args.args[0]['capture_label'],'post_orientation_final')

    def test_already_centered_keeps_hold_and_only_refreshes_observation(self):
        result,arm,history,record,captures,planner,preflight,checks=self.exercise(converged=True)
        self.assertEqual(arm.moves,[]);preflight.assert_not_called()
        self.assertEqual(len(history),1);self.assertEqual(record['status'],'passed')
        self.assertEqual(captures,['post_orientation'])
        self.assertEqual(checks.call_count,1)
        self.assertEqual(result[2]['capture_label'],'post_orientation')
        self.assertIs(result[3],record['initial_observation'])
        self.assertTrue(record['observation_reused'])
        self.assertEqual(result[1],record['planning']['planning_start_q_rad'])

    def test_remaining_error_uses_existing_final_geometry_decision(self):
        result,arm,history,record,*_=self.exercise(final_error=6.)
        self.assertIsInstance(result,RuntimeError);self.assertEqual(record['status'],'rejected')
        self.assertEqual(history[-1],arm.moves[-1][-1])

    def test_motion_fault_retains_checked_path_for_recovery(self):
        result,arm,history,record,captures,*_=self.exercise(motion_fault='tracking rejected')
        self.assertIsInstance(result,RuntimeError)
        self.assertEqual(history[-1],arm.moves[-1][-1]);self.assertEqual(captures,['post_orientation'])

if __name__=='__main__':unittest.main()
