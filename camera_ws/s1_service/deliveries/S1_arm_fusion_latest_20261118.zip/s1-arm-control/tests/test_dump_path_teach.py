import unittest
from scripts.teach_box_dump_path import PathRecorder
class DumpPathTeachTests(unittest.TestCase):
    def test_continuous_approach_and_tip_samples_preserved(self):
        r=PathRecorder();r.command('a',[0]*6)
        for i in range(10):r.sample([i*.01]*6,i*.05)
        r.command('h',[.1]*6);r.command('t',[.1]*6)
        for i in range(20):r.sample([.1+i*.01]*6,1+i*.05)
        r.command('s',[.3]*6)
        plan=r.plan({},.5)
        self.assertEqual(len(r.samples),30)
        self.assertEqual(len(plan['tip_path_q_rad']),23)
        self.assertEqual(plan['tip_path_q_rad'][0],plan['approach_path_q_rad'][-1])
        self.assertEqual(plan['tip_path_q_rad'][-1],[.3]*6)
    def test_incomplete_trajectory_is_not_exported(self):
        r=PathRecorder();r.command('a',[0]*6)
        with self.assertRaises(ValueError):r.plan({},.5)
