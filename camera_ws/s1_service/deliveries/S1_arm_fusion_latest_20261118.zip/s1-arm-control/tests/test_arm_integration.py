import builtins
from collections import deque
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from s1_control.arm import SafetyLimits
from s1_control.integration import ArmIntegrationSession, ZERO_Q
from s1_control.project_paths import project_path

class FakeArm:
    def __init__(self):
        self.limits = SafetyLimits()
        self.dt = 0.02
        self._speed_strikes = 0
        self._speed_strike_samples = []
        self._guard_position_samples = deque()
        self.commander = None
        self.commands = []
        self.disabled = 0
        self.pos = list(ZERO_Q)
    def set_position_commander(self, value): self.commander = value
    def command_position(self, target): self.commands.append((threading.current_thread().name, list(target)))
    def get_temp(self): return [20.0]*7
    def get_pos(self): return self.pos + [0.0]
    def disable(self): self.disabled += 1
    def close(self): pass

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.arm = FakeArm()
        self.session = ArmIntegrationSession(self.arm, hold_hz=200)
    def tearDown(self): self.session.stop_hold()
    def test_repeated_zero_hold_and_grasp_handoff_without_disable(self):
        self.session.start_hold(); self.session.ready()
        time.sleep(0.025)
        self.assertGreater(len(self.arm.commands), 1)
        self.assertTrue(all(q==ZERO_Q for _,q in self.arm.commands))
        self.assertTrue(self.session.request_grasp()["accepted"])
        self.assertFalse(self.session.request_grasp()["accepted"])
        def task(active):
            arm = active.acquire(SafetyLimits(v_max_rad_s=1.5))
            count = len(arm.commands)
            time.sleep(0.02)
            self.assertEqual(len(arm.commands), count)  # idle writer joined
            arm.command_position([0.1]*6)
            active.finish_task(at_zero=True, result="done", log_path="run.json")
            return 0
        self.session.run_task(task)
        time.sleep(0.02)
        self.assertEqual(self.session.snapshot()["state"], "ZERO_HOLD")
        self.assertTrue(self.session.snapshot()["navigation_allowed"])
        self.assertEqual(self.arm.commands[-1][1], ZERO_Q)
        self.assertEqual(self.arm.disabled, 0)
        self.assertTrue(self.session.request_grasp()["accepted"])
    def test_collecting_does_not_implicitly_trigger_dump(self):
        def grasp(active):
            active.acquire(SafetyLimits())
            active.finish_task(at_zero=True,result="grasp done",log_path="grasp.json")
            return 0
        self.session.run_task(grasp)
        self.assertTrue(self.session.jobs.empty())
        self.assertEqual(self.session.snapshot()["last_task"],"grasp")
        self.assertEqual(self.session.snapshot()["state"],"ZERO_HOLD")
        # Only an explicit mission-end request queues unloading.
        self.assertTrue(self.session.request_task("dump",{"mission_end_plan":True})["accepted"])
        self.assertEqual(self.session.jobs.get()[0],"dump")

    def test_fault_keeps_pose_and_payload_without_input_or_disable(self):
        self.arm.pos = [0.2]*6
        grip_commands = []
        class Grip:
            def command_mm(self, gap, force): grip_commands.append((gap,force))
        def task(active):
            active.acquire(SafetyLimits())
            active.mark_fault("speed fault")
            active.finish_task(at_zero=False,result="fault",log_path="run.json",
                               gripper=Grip(),grip_gap_mm=30,grip_force=0.3)
            return 1
        with patch.object(builtins,"input",side_effect=AssertionError("no keyboard")):
            self.session.run_task(task)
            time.sleep(0.02)
        self.assertEqual(self.session.snapshot()["state"],"FAULT_HOLD")
        self.assertFalse(self.session.snapshot()["navigation_allowed"])
        self.assertFalse(self.session.request_grasp()["accepted"])
        self.assertEqual(self.arm.commands[-1][1],[0.2]*6)
        self.assertTrue(grip_commands)
        self.assertEqual(self.arm.disabled,0)
    def test_preflight_failure_stops_idle_writer_before_fault_hold(self):
        self.session.start_hold();self.session.ready()
        self.session.run_task(lambda active: (_ for _ in ()).throw(ValueError("preflight")))
        self.assertEqual(self.session.snapshot()["state"],"FAULT_HOLD")
    def test_relocates_legacy_path_even_when_original_exists(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(project_path("/home/ljw/桌面/s1-arm-control/config/a.json",folder),
                             Path(folder)/"config/a.json")
            self.assertEqual(project_path("config/a.json",folder),Path(folder)/"config/a.json")

if __name__ == "__main__": unittest.main()
