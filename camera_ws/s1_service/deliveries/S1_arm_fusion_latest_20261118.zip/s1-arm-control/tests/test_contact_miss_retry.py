import ast
import copy
import json
import tempfile
import unittest
from pathlib import Path
from run_go2_visual_alignment import should_retry_grasp
import run_go2_visual_alignment as flow

class ContactMissRetryTests(unittest.TestCase):
    def test_only_acquisition_failure_retries_once(self):
        for failure in ("contact_miss", "secure_lost"):
            self.assertTrue(should_retry_grasp(failure, 0, 2))
            self.assertFalse(should_retry_grasp(failure, 1, 2))
        for result in (None, "holding_verified", "ABORTED"):
            self.assertFalse(should_retry_grasp(result, 0, 2))

    def execute_retry_control(self, outcomes):
        tree=ast.parse(Path(flow.__file__).read_text())
        loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For)
                  and isinstance(n.target,ast.Name) and n.target.id=="grasp_attempt")
        loop=copy.deepcopy(loop)
        first=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.FunctionDef))
        last=next(i for i,n in enumerate(loop.body) if isinstance(n,ast.Assign)
                  and any(isinstance(t,ast.Name) and t.id=="attempt_record" for t in n.targets))
        # Replace the hardware sequence only. Execute the production retry control and logging.
        fake=ast.parse("adaptive_secure_outcome=outcomes.pop(0)\nlog['final_check']={'fresh':grasp_attempt}\n").body
        loop.body=loop.body[:first]+fake+loop.body[last:]
        with tempfile.TemporaryDirectory() as folder:
            scope=dict(maximum_grasp_attempts=2,attempt_root=Path(folder),run_dir=Path(folder),
                log_path=Path(folder)/"run.json",log={"grasp_attempts":[]},
                attempt_stage_keys=("final_check",),outcomes=list(outcomes),json=json,
                payload_held=False,adaptive_gripper_may_be_closed=False,
                write_json=lambda *args:None,should_retry_grasp=should_retry_grasp)
            exec(compile(ast.fix_missing_locations(ast.Module(body=[loop],type_ignores=[])),
                         "actual_retry_control", "exec"),scope)
            return scope['log']['grasp_attempts']

    def test_miss_then_success_retains_both_attempts(self):
        attempts=self.execute_retry_control(["contact_miss","holding_verified"])
        self.assertEqual(len(attempts),2)
        self.assertEqual(attempts[0]['acquisition_outcome'],"contact_miss")
        self.assertEqual(attempts[1]['acquisition_outcome'],"holding_verified")
        self.assertNotEqual(attempts[0]['capture_directory'],attempts[1]['capture_directory'])
        self.assertEqual(attempts[0]['stages']['final_check']['fresh'],0)

    def test_second_miss_stops(self):
        self.assertEqual(len(self.execute_retry_control(["contact_miss","contact_miss"])),2)

    def test_success_never_repeats(self):
        self.assertEqual(len(self.execute_retry_control(["holding_verified"])),1)
