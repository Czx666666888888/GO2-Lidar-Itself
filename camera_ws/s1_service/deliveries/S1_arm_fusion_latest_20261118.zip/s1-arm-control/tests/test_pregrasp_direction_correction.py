import json
import unittest
import numpy as np
from run_go2_visual_alignment import (
    PROJECT_ROOT, load_alignment_config, resolve_project_path,
    plan_pregrasp_direction_correction, evaluate_safe_descent_endpoint,
    densify_joint_path, append_executed_path, quaternion_error_deg,
    UrdfGravityModel, locate_official_gripper_urdf)
from plan_go2_multiview_scan import go2_envelope_check
from s1_control.kinematics import Kinematics
from S1_SDK.hardware.collision import CollisionChecker

class DirectionCorrectionReplayTests(unittest.TestCase):
    def test_logged_orientation_failure_can_be_trimmed_at_fixed_tcp(self):
        d = json.loads((PROJECT_ROOT / "data/go2_visual_alignment_runs/alignment_20261118-181210/run.json").read_text())
        plan = d["adaptive_pregrasp"]["planning"]
        measured = d["adaptive_pregrasp"]["endpoint"]["measured_q_rad"]
        held = plan["joint_path"][-1]
        rotation = plan["merged_grasp_orientation"]["target_quaternion_xyzw"]
        _, cfg = load_alignment_config(d["config"])
        deployment = json.loads(resolve_project_path(cfg["deployment_plan"]).read_text())
        source = json.loads(resolve_project_path(deployment["source_config"]).read_text())
        mount = json.loads(resolve_project_path(deployment["mount_config"]).read_text())
        cc = CollisionChecker("gripper")
        if cc.model is None:
            cc._load_model(gripper=True)
        def body(path):
            result = go2_envelope_check(cc, densify_joint_path(path, .005), source)
            self.assertTrue(result["pass"])
            return result
        kin = Kinematics(verbose=False)
        path, record = plan_pregrasp_direction_correction(measured, held, rotation,
            orientation_config=cfg["adaptive_grasp_orientation"],
            descent_config=cfg["adaptive_pregrasp"], tcp_kinematics=kin,
            collision_checker=cc,
            tilt_model=UrdfGravityModel.from_file(locate_official_gripper_urdf()),
            applied_support_up=plan["support_up_normal_base"], compensation_scale=0,
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"], check_body=body)
        predicted = np.array(measured) + np.array(path[-1]) - np.array(path[0])
        before = kin.fk(measured)
        after = kin.fk(predicted.tolist())
        self.assertLess(np.linalg.norm(np.array(before[:3])-after[:3])*1000, .1)
        self.assertLess(quaternion_error_deg(after[3:], rotation), 4.)
        endpoint = evaluate_safe_descent_endpoint(plan, predicted.tolist(),
            descent_config=cfg["adaptive_pregrasp"], tcp_kinematics=kin)
        self.assertTrue(endpoint["passed"])
        route = [list(q) for q in plan["joint_path"]]
        append_executed_path(route, path)
        self.assertEqual(route[-1], path[-1])
        print("DIRECTION_REPLAY", quaternion_error_deg(before[3:], rotation),
              quaternion_error_deg(after[3:], rotation), endpoint["clearance_error_mm"])
