import json
import unittest
import numpy as np
from run_go2_visual_alignment import (PROJECT_ROOT,load_alignment_config,resolve_project_path,
    plan_pregrasp_endpoint_correction,evaluate_safe_descent_endpoint,densify_joint_path,
    append_executed_path,UrdfGravityModel,locate_official_gripper_urdf)
from plan_go2_multiview_scan import go2_envelope_check
from s1_control.kinematics import Kinematics
from S1_SDK.hardware.collision import CollisionChecker

class CorrectionReplayTests(unittest.TestCase):
    def test_failed_endpoint_can_be_corrected_without_changing_goal_or_return_handoff(self):
        d=json.loads((PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261113-233055/run.json").read_text())
        old=d["adaptive_pregrasp"];plan=old["planning"]
        _,cfg=load_alignment_config("config/go2_left_full_flow_size_adaptive_20261112_v1.json")
        deployment=json.loads(resolve_project_path(cfg["deployment_plan"]).read_text())
        source=json.loads(resolve_project_path(deployment["source_config"]).read_text())
        mount=json.loads(resolve_project_path(deployment["mount_config"]).read_text())
        cc=CollisionChecker("gripper")
        if cc.model is None:cc._load_model(gripper=True)
        desired=plan["joint_path"][-1];measured=old["endpoint"]["measured_q_rad"]
        def body(path):
            result=go2_envelope_check(cc,densify_joint_path(path,.005),source)
            self.assertTrue(result["pass"])
            return result
        path,record=plan_pregrasp_endpoint_correction(desired,measured,desired,
            descent_config=cfg["adaptive_pregrasp"],collision_checker=cc,
            tilt_model=UrdfGravityModel.from_file(locate_official_gripper_urdf()),
            applied_support_up=plan["support_up_normal_base"],compensation_scale=0,
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"],check_body=body)
        self.assertGreater(old["endpoint"]["clearance_error_mm"],10)
        self.assertEqual(path[0],desired)
        predicted=np.array(measured)+np.array(path[-1])-np.array(path[0])
        corrected=evaluate_safe_descent_endpoint(plan,predicted.tolist(),
            descent_config=cfg["adaptive_pregrasp"],tcp_kinematics=Kinematics(verbose=False))
        self.assertTrue(corrected["passed"])
        self.assertLess(corrected["clearance_error_mm"],.01)
        route=[list(q) for q in plan["joint_path"]]
        append_executed_path(route,path)
        self.assertEqual(route[-1],path[-1])
        self.assertEqual(list(reversed(route))[0],path[-1])

if __name__=="__main__":unittest.main()
