"""Shared endpoints are stored once without changing the checked route."""
import copy
import unittest
from scripts.run_go2_visual_alignment import append_executed_path
from s1_control.arm import joint_path_motion_duration_s

class ExecutedPathJoinTests(unittest.TestCase):
    def test_shared_endpoint_does_not_break_reverse_motion(self):
        start=[0.,1.,1.,.2,0.,0.]
        boundary=[.1,1.1,1.1,.2,0.,0.]
        end=[.1,1.1,1.1,.2,0.,.6]
        first=[start,boundary];second=[boundary,end];unchanged=copy.deepcopy(second)
        with self.assertRaisesRegex(ValueError,'duplicate adjacent'):
            joint_path_motion_duration_s(list(reversed(first+second)),.08,.05,'s_curve')
        append_executed_path(first,second)
        self.assertEqual(first,[start,boundary,end]);self.assertEqual(second,unchanged)
        self.assertGreater(joint_path_motion_duration_s(list(reversed(first)),.08,.05,'s_curve'),0)

    def test_distinct_boundary_retains_the_bridge_and_all_points(self):
        first=[[0.]*6,[.1]*6];second=[[.11]*6,[.2]*6];expected=copy.deepcopy(first+second)
        append_executed_path(first,second)
        self.assertEqual(first,expected)

    def test_only_the_shared_boundary_is_removed(self):
        # Interior validation still belongs to the motion layer, not the join.
        first=[[0.]*6,[.1]*6];second=[[.1]*6,[.2]*6,[.2]*6]
        append_executed_path(first,second)
        with self.assertRaisesRegex(ValueError,'duplicate adjacent'):
            joint_path_motion_duration_s(first,.08,.05,'s_curve')

if __name__=='__main__':unittest.main()
