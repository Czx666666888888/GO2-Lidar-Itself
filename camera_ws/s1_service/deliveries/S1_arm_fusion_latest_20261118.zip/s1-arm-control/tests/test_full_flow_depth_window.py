import json
import unittest
from run_go2_visual_alignment import (PROJECT_ROOT,load_alignment_config,load_wrist_servo_config,
    resolve_project_path,compute_observation,Kinematics)

class DepthWindowReplayTests(unittest.TestCase):
    def test_294mm_target_passes_without_legacy_depth_window(self):
        folder=PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261114-003920"
        run=json.loads((folder/"run.json").read_text())
        capture=json.loads((folder/"final_process_result.json").read_text())["result"]
        _,cfg=load_alignment_config("config/go2_left_full_flow_size_adaptive_20261112_v1.json")
        loaded=load_wrist_servo_config(resolve_project_path(cfg["wrist_servo_config"]))
        safety={**loaded.record["safety"],"maximum_camera_tilt_from_down_deg":18}
        options=dict(loaded=loaded,flange_kinematics=Kinematics(tcp=[0,0,0],verbose=False),observation_safety=safety)
        with self.assertRaisesRegex(RuntimeError,"camera target depth"):
            compute_observation(capture,run["final_q_rad"],**options)
        safety["camera_target_depth_window_enabled"]=False
        result=compute_observation(capture,run["final_q_rad"],**options)
        self.assertAlmostEqual(result["observation"]["camera_target_depth_mm"],294.6485,places=3)

if __name__=="__main__":unittest.main()
