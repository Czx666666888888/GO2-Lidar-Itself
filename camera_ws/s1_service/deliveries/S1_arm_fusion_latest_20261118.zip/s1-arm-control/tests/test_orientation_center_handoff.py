"""Position-only yaw drift is resolved by target centering in complete flow."""
import copy
import json
import math
from pathlib import Path
import unittest
from scripts.run_go2_visual_alignment import evaluate_grasp_orientation_endpoint, orientation_endpoint_can_recenter

class LinearPoseKinematics:
    def fk(self,q):return [q[0],q[1],q[2],0.,0.,math.sin(q[5]/2),math.cos(q[5]/2)]

class OrientationCenterHandoffTests(unittest.TestCase):
    def endpoint(self,yaw_deg=1.71,window=.000381,other_joint_error=0.):
        root=Path(__file__).resolve().parents[1]
        cfg=json.loads((root/'config/go2_dual_white_light_full_flow_simplified_v1.json').read_text())['adaptive_grasp_orientation']
        return evaluate_grasp_orientation_endpoint(
            [0.]*6,[.00642,other_joint_error,0.,0.,0.,math.radians(yaw_deg)],
            start_tcp_pose=[0.,0.,0.,0.,0.,0.,1.],target_quaternion=[0.,0.,0.,1.],
            config=cfg,tcp_kinematics=LinearPoseKinematics(),endpoint_window_range_rad=[window]*6,
            j6_checked_by_tool_orientation=True)

    def test_recorded_scale_drift_can_proceed_only_to_target_center_verification(self):
        endpoint=self.endpoint();before=copy.deepcopy(endpoint)
        self.assertEqual(endpoint['reasons'],['tcp_position_drift_too_large'])
        self.assertAlmostEqual(endpoint['tcp_position_drift_mm'],6.42)
        self.assertTrue(orientation_endpoint_can_recenter(endpoint,simplified_full_flow=True,orientation_only_requested=False))
        self.assertEqual(endpoint,before)
        self.assertFalse(endpoint['passed'])

    def test_stable_tracking_in_fallback_range_can_recenter_before_descent(self):
        endpoint = self.endpoint(yaw_deg=2.03, other_joint_error=.03125)
        self.assertEqual(
            endpoint["reasons"],
            ["joint_tracking_error_too_large", "tcp_position_drift_too_large"],
        )
        self.assertFalse(endpoint["passed"])
        self.assertTrue(orientation_endpoint_can_recenter(
            endpoint, simplified_full_flow=True, orientation_only_requested=False,
        ))
        for rejected_endpoint in (
            self.endpoint(yaw_deg=5.0, other_joint_error=.03125),
            self.endpoint(window=.01, other_joint_error=.03125),
            self.endpoint(other_joint_error=.03201),
        ):
            self.assertFalse(orientation_endpoint_can_recenter(
                rejected_endpoint, simplified_full_flow=True, orientation_only_requested=False,
            ))

    def test_orientation_only_and_older_profiles_keep_original_verdict(self):
        endpoint=self.endpoint()
        for full,only in [(False,False),(True,True),(False,True)]:
            self.assertFalse(orientation_endpoint_can_recenter(endpoint,simplified_full_flow=full,orientation_only_requested=only))

    def test_direction_tracking_and_unstable_window_are_not_position_only_failures(self):
        for endpoint in [self.endpoint(yaw_deg=5.),self.endpoint(other_joint_error=.04),self.endpoint(window=.01)]:
            self.assertFalse(orientation_endpoint_can_recenter(endpoint,simplified_full_flow=True,orientation_only_requested=False))

if __name__=='__main__':unittest.main()
