import json
import unittest
import numpy as np
from run_go2_visual_alignment import (
    PROJECT_ROOT, load_alignment_config, resolve_project_path,
    compute_safe_descent_plan, compute_oriented_pregrasp_plan,
    resolve_adaptive_secure_no_lift_config, densify_joint_path,
    UrdfGravityModel, locate_official_gripper_urdf)
from plan_go2_multiview_scan import go2_envelope_check
from s1_control.kinematics import Kinematics
from S1_SDK.hardware.collision import CollisionChecker

class DescentCenteringReplayTests(unittest.TestCase):
    def test_both_existing_descent_segments_remove_inherited_lateral_offset(self):
        run=PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261118-184105"
        d=json.loads((run/"run.json").read_text())
        _,cfg=load_alignment_config(d["config"])
        deployment=json.loads(resolve_project_path(cfg["deployment_plan"]).read_text())
        source=json.loads(resolve_project_path(deployment["source_config"]).read_text())
        mount=json.loads(resolve_project_path(deployment["mount_config"]).read_text())
        cc=CollisionChecker("gripper")
        if cc.model is None:cc._load_model(gripper=True)
        kin=Kinematics(verbose=False)
        def body(path):
            r=go2_envelope_check(cc,densify_joint_path(path,.005),source)
            self.assertTrue(r["pass"])
            return r
        observation=d["final_observation"]
        old=d["adaptive_pregrasp"]["planning"]
        desc=dict(cfg["adaptive_pregrasp"],target_normal_clearance_mm=old["target_normal_clearance_mm"])
        common=dict(alignment=cfg["alignment"],tcp_kinematics=kin,collision_checker=cc,
            tilt_model=UrdfGravityModel.from_file(locate_official_gripper_urdf()),
            applied_support_up=old["support_up_normal_base"],side_scale=0,
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"])
        high=compute_oriented_pregrasp_plan(old["start_q_rad"],observation,
            orientation_config=cfg["adaptive_grasp_orientation"],check_body=body,
            descent_config=desc,**common)
        detection=json.loads((run/"residual_final_detection.json").read_text())
        low_cfg,_=resolve_adaptive_secure_no_lift_config({"detection":detection},cfg["adaptive_secure_no_lift"])
        low_cfg["minimum_initial_normal_clearance_mm"]=10
        low_cfg["maximum_initial_normal_clearance_mm"]=30
        low_old=d["adaptive_secure_no_lift"]["low_descent_planning"]
        low=compute_safe_descent_plan(low_old["start_q_rad"],observation,
            descent_config=low_cfg,center_target_during_descent=True,**common)
        body(low["joint_path"])
        n=np.array(observation["support_up_normal_base"]);n/=np.linalg.norm(n)
        surface=np.array(observation["surface_point_base_m"])
        for name,plan,baseline in [("pregrasp",high,old),("low",low,low_old)]:
            p=np.array(kin.fk(plan["joint_path"][-1])[:3]);v=p-surface
            error=np.linalg.norm(v-n*np.dot(v,n))*1000
            self.assertLess(error,.01)
            self.assertEqual(plan["segment_count"],baseline["segment_count"])
            self.assertEqual(plan["target_normal_clearance_mm"],baseline["target_normal_clearance_mm"])
            print("CENTERING_REPLAY",name,"planned_center_error_mm",error,
                  "blended_correction_mm",plan["descent_centering_correction_xyz_mm"])
