# -*- coding: utf-8 -*-
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.run_visual_adaptive_grasp import (
    build_descent_z_waypoints,
    build_execution_command,
    build_planning_commands,
    main,
    validated_run_id,
)
from scripts.grip_lift_place import write_execution_diagnostic


class VisualGraspPipelineTests(unittest.TestCase):
    def setUp(self):
        self.target = {
            "visual_target": {
                "hover_tcp_mm": [260.0, 10.0, -18.0],
                "grasp_tcp_mm": [260.0, 10.0, -43.0],
            }
        }
        self.calibration = {
            "geometry": {
                "minimum_tcp_z_mm": -47.0,
                "maximum_cartesian_descent_step_mm": 15.0,
                "maximum_descent_lateral_deviation_mm": 3.0,
            },
            "execution": {
                "target_profile": "cube50",
                "adaptive_grip": True,
                "motion_profile": "s_curve",
            },
        }

    def test_planning_commands_bind_dynamic_target_and_collision_report(self):
        commands = build_planning_commands(
            "/env/python",
            Path("target.json"),
            Path("hover.json"),
            Path("grasp.json"),
            Path("collision.json"),
            self.target,
            self.calibration,
        )
        self.assertEqual([stage for stage, _ in commands], [
            "plan_hover", "plan_descent_01", "plan_grasp", "check_collision"
        ])
        hover = commands[0][1]
        descent = commands[1][1]
        grasp = commands[2][1]
        collision = commands[3][1]
        self.assertEqual(hover[hover.index("--target-z-mm") + 1], "-18.000000000")
        self.assertEqual(
            descent[descent.index("--target-z-mm") + 1], "-30.500000000"
        )
        self.assertEqual(grasp[grasp.index("--target-z-mm") + 1], "-43.000000000")
        self.assertIn("descent_01_plan.json", grasp)
        self.assertIn("grasp.json", collision)
        for command in (hover, descent, grasp):
            self.assertEqual(
                command[command.index("--motion-profile") + 1],
                "s_curve",
            )
            self.assertEqual(
                command[command.index("--v-max-rad-s") + 1],
                "0.2",
            )
            self.assertEqual(
                command[command.index("--j6-v-max-rad-s") + 1],
                "0.1",
            )
        self.assertEqual(
            collision[collision.index("--min-tcp-z-mm") + 1],
            "-47.000000000",
        )
        self.assertEqual(
            collision[collision.index("--max-descent-lateral-mm") + 1],
            "3.000000000",
        )

    def test_descent_waypoints_are_uniform_and_never_exceed_limit(self):
        points = build_descent_z_waypoints(70.0, 9.4, 15.0)
        self.assertEqual(
            [name for name, _ in points],
            ["descent_01", "descent_02", "descent_03", "descent_04", "grasp"],
        )
        z_values = [70.0] + [z for _, z in points]
        self.assertTrue(all(
            0.0 < before - after <= 15.0
            for before, after in zip(z_values, z_values[1:])
        ))
        self.assertAlmostEqual(points[-1][1], 9.4)

    def test_execution_uses_adaptive_s_curve_and_default_j6_limit(self):
        command = build_execution_command(
            "/env/python",
            "/dev/ttyUSB0",
            Path("grasp.json"),
            Path("collision.json"),
            self.calibration,
            diagnostic_log_path=Path("execution_diagnostic.json"),
        )
        self.assertIn("--adaptive-grip", command)
        self.assertIn("--motion-profile", command)
        self.assertEqual(
            command[command.index("--motion-profile") + 1], "s_curve"
        )
        self.assertEqual(
            command[command.index("--v-max-rad-s") + 1], "0.2"
        )
        self.assertEqual(
            command[command.index("--j6-v-max-rad-s") + 1], "0.1"
        )
        self.assertEqual(
            command[command.index("--diagnostic-log") + 1],
            "execution_diagnostic.json",
        )
        self.assertEqual(command[-1], "--execute")

    def test_execution_diagnostic_is_bounded_small_json(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "diagnostic.json"
            saved = write_execution_diagnostic(path, {
                "schema_version": 1,
                "result": "ABORTED: speed>0.5 x3",
                "exception_message": "sdk_frames=[J6=+0.7]",
            })
            self.assertEqual(saved, path.resolve())
            self.assertLess(saved.stat().st_size, 64 * 1024)
            record = json.loads(saved.read_text(encoding="utf-8"))
            self.assertIn("speed>0.5", record["result"])
            saved = write_execution_diagnostic(path, {
                "schema_version": 1,
                "result": "ABORTED",
                "exception_message": "x" * 100000,
            })
            self.assertLess(saved.stat().st_size, 64 * 1024)
            record = json.loads(saved.read_text(encoding="utf-8"))
            self.assertTrue(record["diagnostic_truncated"])

    def test_execution_forwards_explicit_j6_limit(self):
        command = build_execution_command(
            "/env/python",
            "/dev/ttyUSB0",
            Path("grasp.json"),
            Path("collision.json"),
            self.calibration,
            alignment_only=True,
            v_max_rad_s=0.15,
            j6_v_max_rad_s=0.12,
        )
        self.assertEqual(
            command[command.index("--v-max-rad-s") + 1], "0.15"
        )
        self.assertEqual(
            command[command.index("--j6-v-max-rad-s") + 1], "0.12"
        )
        self.assertIn("--hover-only", command)

    def test_alignment_only_is_one_shot_and_never_enables_adaptive_grip(self):
        command = build_execution_command(
            "/env/python",
            "/dev/ttyUSB0",
            Path("grasp.json"),
            Path("collision.json"),
            self.calibration,
            alignment_only=True,
        )
        self.assertIn("--hover-only", command)
        self.assertNotIn("--alignment-only", command)
        self.assertNotIn("--adaptive-grip", command)
        self.assertEqual(command[-1], "--execute")

    def test_alignment_only_requires_execute(self):
        with self.assertRaisesRegex(ValueError, "--execute"):
            main(["--live-capture", "--alignment-only"])

    def test_j6_limit_must_be_positive_and_finite(self):
        for invalid in ("0", "-0.1", "nan", "inf"):
            with self.assertRaisesRegex(ValueError, "j6-v-max-rad-s"):
                main([
                    "--live-capture",
                    "--j6-v-max-rad-s",
                    invalid,
                ])

    def test_global_limit_must_be_positive_and_finite(self):
        for invalid in ("0", "-0.1", "nan", "inf"):
            with self.assertRaisesRegex(ValueError, "v-max-rad-s"):
                main([
                    "--live-capture",
                    "--v-max-rad-s",
                    invalid,
                ])

    def test_replay_can_never_request_hardware_execution(self):
        with self.assertRaisesRegex(ValueError, "live-capture"):
            main(["--replay-npz", "old.npz", "--execute"])

    def test_run_id_is_restricted(self):
        self.assertEqual(validated_run_id("trial_29-left"), "trial_29-left")
        for invalid in ("", "../escape", "space name", "x" * 81):
            with self.assertRaises(ValueError):
                validated_run_id(invalid)


if __name__ == "__main__":
    unittest.main()
