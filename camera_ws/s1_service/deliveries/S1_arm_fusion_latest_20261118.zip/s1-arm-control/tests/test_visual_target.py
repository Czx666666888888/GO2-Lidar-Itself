# -*- coding: utf-8 -*-
import hashlib
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from s1_control.visual_target import (
    LoadedVisualGraspCalibration,
    derive_visual_grasp_target,
    derive_visual_grasp_targets,
    load_visual_grasp_calibration,
)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class VisualTargetTests(unittest.TestCase):
    def setUp(self):
        self.record = {
            "schema_version": 1,
            "name": "test_bench",
            "status": "provisional_test",
            "camera_serial": "D455-TEST",
            "workspace_center_bounds_base_mm": {
                "x": [200.0, 340.0],
                "y": [-280.0, 280.0],
            },
            "empirical_target_center_bias_base_mm": [0.0, 4.0, 0.0],
            "geometry": {
                "tcp_table_clearance_mm": 9.4,
                "hover_lift_mm": 25.0,
                "prealign_clearance_above_detected_top_mm": 20.0,
                "maximum_cartesian_descent_step_mm": 15.0,
                "maximum_descent_lateral_deviation_mm": 3.0,
                "minimum_tcp_z_mm": -47.0,
                "minimum_target_height_mm": 15.0,
                "maximum_target_height_mm": 65.0,
                "minimum_table_normal_z": 0.995,
                "reference_table_z_mm": 0.0,
                "maximum_reference_table_z_deviation_mm": 6.0,
                "grasp_orientation_mode": "dynamic_topdown_square_edge_mod90",
                "minimum_orientation_confidence_score": 0.75,
                "maximum_orientation_p90_deviation_deg": 8.0,
                "small_sample_orientation": {
                    "max_points": 300,
                    "minimum_confidence_score": 0.70,
                    "maximum_p90_deviation_deg": 10.0,
                },
                "maximum_orientation_axis_normal_abs_dot": 0.02,
                "empirical_grasp_yaw_bias_deg": 0.0,
            },
            "planner_seed_joint_rad": [0.0, 1.0, 0.8, 0.3, 0.0, 0.0],
        }
        self.calibration = LoadedVisualGraspCalibration(
            path=Path("/tmp/test_calibration.json"),
            record=self.record,
            transform_base_camera=np.eye(4),
            binding_paths={},
        )
        self.metadata = {"quality_pass": True, "serial": "D455-TEST"}
        self.detection = {
            "schema_version": 2,
            "status": "DETECTED_CAMERA_FRAME_ONLY",
            "camera_frame_only": True,
            "accepted_candidate_count": 1,
            "plane": {
                "quality_pass": True,
                "normal_cam": [0.0, 0.0, 1.0],
                "offset_m": 0.0,
            },
            "selected": {
                "accepted": True,
                "surface_point_cam_m": [0.25, 0.10, 0.04],
                "core_height_mm": {"median": 38.0},
                "confidence_score": 0.90,
                "orientation": {
                    "symmetry_period_deg": 90.0,
                    "axis_cam": [1.0, 0.0, 0.0],
                    "confidence_score": 0.95,
                    "p90_deviation_deg": 1.5,
                },
            },
        }

    def derive(self):
        return derive_visual_grasp_target(
            self.detection,
            self.calibration,
            self.metadata,
            source_detection="detection.json",
            source_capture="capture.npz",
        )

    def test_derives_table_relative_hover_and_grasp(self):
        result = self.derive()
        target = result["visual_target"]
        self.assertEqual(target["raw_target_base_xy_mm"], [250.0, 100.0])
        self.assertEqual(
            target["empirical_target_center_bias_base_mm"],
            [0.0, 4.0, 0.0],
        )
        self.assertEqual(
            target["corrected_target_base_xy_mm"], [250.0, 104.0]
        )
        self.assertEqual(target["grasp_tcp_mm"], [250.0, 104.0, 9.4])
        self.assertEqual(target["hover_tcp_mm"], [250.0, 104.0, 60.0])
        self.assertAlmostEqual(target["hover_to_grasp_descent_mm"], 50.6)
        self.assertAlmostEqual(
            target["prealign_clearance_above_detected_top_mm"], 20.0
        )
        self.assertAlmostEqual(target["height_along_table_normal_mm"], 40.0)
        self.assertEqual(result["joint_rad"], self.record["planner_seed_joint_rad"])
        self.assertTrue(result["control_ready_after_external_transform"])
        self.assertEqual(result["schema_version"], 2)
        self.assertEqual(target["target_edge_axis_base"], [1.0, 0.0, 0.0])
        self.assertEqual(
            target["grasp_orientation_mode"],
            "dynamic_topdown_square_edge_mod90",
        )

    def test_rejects_low_confidence_or_non_tangent_orientation(self):
        self.detection["selected"]["orientation"]["confidence_score"] = 0.5
        with self.assertRaisesRegex(ValueError, "方向置信度"):
            self.derive()

        self.detection["selected"]["orientation"]["confidence_score"] = 0.95
        self.detection["selected"]["orientation"]["axis_cam"] = [1.0, 0.0, 0.1]
        with self.assertRaisesRegex(ValueError, "相机台面"):
            self.derive()

    def test_small_sample_orientation_uses_bound_relaxed_limits(self):
        orientation = self.detection["selected"]["orientation"]
        orientation.update({
            "confidence_score": 0.722,
            "p90_deviation_deg": 8.57,
            "quality_profile": "small_sample",
            "sample_point_count": 237,
            "applied_min_confidence_score": 0.70,
            "applied_max_p90_deviation_deg": 10.0,
        })
        result = self.derive()["visual_target"]
        self.assertEqual(result["orientation_quality_profile"], "small_sample")
        self.assertEqual(result["orientation_sample_point_count"], 237)
        self.assertEqual(
            result["orientation_applied_min_confidence_score"], 0.70
        )
        self.assertEqual(
            result["orientation_applied_max_p90_deviation_deg"], 10.0
        )

    def test_rejects_unbound_or_oversized_small_sample_profile(self):
        orientation = self.detection["selected"]["orientation"]
        orientation.update({
            "confidence_score": 0.722,
            "p90_deviation_deg": 8.57,
            "quality_profile": "small_sample",
            "sample_point_count": 301,
            "applied_min_confidence_score": 0.70,
            "applied_max_p90_deviation_deg": 10.0,
        })
        with self.assertRaisesRegex(ValueError, "采样点数"):
            self.derive()

        orientation["sample_point_count"] = 237
        orientation["applied_min_confidence_score"] = 0.69
        with self.assertRaisesRegex(ValueError, "最低置信度"):
            self.derive()

    def test_rejects_target_outside_expanded_workspace(self):
        self.detection["selected"]["surface_point_cam_m"][0] = 0.341
        with self.assertRaisesRegex(ValueError, "目标X"):
            self.derive()

    def test_rejects_corrected_target_outside_workspace(self):
        self.detection["selected"]["surface_point_cam_m"][1] = 0.279
        with self.assertRaisesRegex(ValueError, "补偿后目标Y"):
            self.derive()

    def test_rejects_stale_camera_or_bad_source_quality(self):
        self.metadata["serial"] = "OTHER"
        with self.assertRaisesRegex(ValueError, "序列号"):
            self.derive()
        self.metadata["serial"] = "D455-TEST"
        self.metadata["quality_pass"] = False
        with self.assertRaisesRegex(ValueError, "质量门控"):
            self.derive()

    def test_rejects_ambiguous_target_and_moved_table(self):
        self.detection["accepted_candidate_count"] = 2
        with self.assertRaisesRegex(ValueError, "唯一候选"):
            self.derive()
        self.detection["accepted_candidate_count"] = 1
        self.detection["plane"]["offset_m"] = 0.020
        with self.assertRaisesRegex(ValueError, "台面高度"):
            self.derive()

    def test_multi_target_derivation_keeps_component_attributes_bound(self):
        first = copy.deepcopy(self.detection["selected"])
        first["component_id"] = 1
        first["target_id"] = "component_001"
        second = copy.deepcopy(first)
        second["component_id"] = 2
        second["target_id"] = "component_002"
        second["surface_point_cam_m"] = [0.30, -0.10, 0.03]
        second["core_height_mm"]["median"] = 29.0
        second["orientation"]["axis_cam"] = [0.0, 1.0, 0.0]

        detection_record = copy.deepcopy(self.detection)
        detection_record["status"] = "MULTIPLE_TARGETS_CAMERA_FRAME_ONLY"
        detection_record["accepted_candidate_count"] = 2
        detection_record["accepted_targets"] = [first, second]
        detection_record["selected"] = None
        result = derive_visual_grasp_targets(
            detection_record,
            self.calibration,
            self.metadata,
            source_detection="multi_detection.json",
            source_capture="capture.npz",
        )
        self.assertEqual(result["status"], "MULTI_TARGETS_BASE_FRAME_READY")
        self.assertEqual(result["base_frame_target_count"], 2)
        targets = result["targets"]
        self.assertEqual(
            [target["source_component_id"] for target in targets], [1, 2]
        )
        self.assertEqual(
            targets[0]["visual_target"]["corrected_target_base_xy_mm"],
            [250.0, 104.0],
        )
        self.assertEqual(
            targets[1]["visual_target"]["corrected_target_base_xy_mm"],
            [300.0, -96.0],
        )
        self.assertEqual(
            targets[1]["visual_target"]["target_edge_axis_base"],
            [0.0, 1.0, 0.0],
        )
    def test_calibration_hash_binding_detects_change(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "calibration").mkdir()
            (root / "config").mkdir()
            extrinsic = root / "calibration/extrinsic_camera.json"
            tcp = root / "calibration/tcp.json"
            vision = root / "config/cube_vision.yaml"
            extrinsic.write_text(
                json.dumps({"value_T_base_cam": np.eye(4).tolist()}),
                encoding="utf-8",
            )
            tcp.write_text("tcp", encoding="utf-8")
            vision.write_text("vision", encoding="utf-8")
            record = dict(self.record)
            record["bindings"] = {
                "extrinsic": {
                    "path": "calibration/extrinsic_camera.json",
                    "sha256": _sha(extrinsic),
                },
                "tcp": {
                    "path": "calibration/tcp.json",
                    "sha256": _sha(tcp),
                },
                "vision_config": {
                    "path": "config/cube_vision.yaml",
                    "sha256": _sha(vision),
                },
            }
            record["valid_only_if"] = "unchanged"
            record["recalibrate_when"] = "changed"
            calibration_path = root / "calibration/visual.json"
            calibration_path.write_text(json.dumps(record), encoding="utf-8")

            loaded = load_visual_grasp_calibration(
                calibration_path,
                root=root,
                verbose=False,
            )
            self.assertTrue(np.allclose(loaded.transform_base_camera, np.eye(4)))

            tcp.write_text("changed", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "SHA-256失配"):
                load_visual_grasp_calibration(
                    calibration_path,
                    root=root,
                    verbose=False,
                )


if __name__ == "__main__":
    unittest.main()
