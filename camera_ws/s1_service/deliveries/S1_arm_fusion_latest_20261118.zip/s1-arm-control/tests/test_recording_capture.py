import json
import os
from pathlib import Path
import socket
import struct
import tempfile
import threading
import unittest
from unittest.mock import patch
import numpy as np
from scripts.record_wrist_video import make_capture,encode_capture
from demo_grasp.capture_rgbd import capture_aligned_rgbd
from demo_grasp.recording_capture import request_snapshot

class RecordingCaptureTests(unittest.TestCase):
    def capture(self):
        info=dict(depth_scale=.001,K=np.eye(3),distortion_coeffs=np.zeros(5),metadata=dict(usb_type='3.2',serial='test',width=2,height=2,fps=30))
        options=dict(min_depth_samples=None,depth_frames=3,warmup_frames=0,min_valid_depth_ratio=.6,max_frame_interval_ms=300)
        samples=[dict(depth=np.full((2,2),v,dtype=np.uint16),rgb=np.full((2,2,3),i,dtype=np.uint8),time=i/30) for i,v in enumerate([100,102,101])]
        return make_capture(samples,options,info)

    def test_same_depth_fusion_and_quality(self):
        result=self.capture()
        np.testing.assert_allclose(result['depth_m'],.101)
        self.assertTrue(result['metadata']['quality_pass'])
        self.assertEqual(result['rgb'][0,0,0],2)

    def test_socket_snapshot_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            path=str(Path(d)/'camera.sock')
            with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as server:
                server.bind(path);server.listen(1)
                def serve():
                    connection,_=server.accept()
                    with connection:
                        with connection.makefile('rb') as reader:json.loads(reader.readline())
                        body=encode_capture(self.capture())
                        connection.sendall(struct.pack('!BQ',1,len(body))+body)
                thread=threading.Thread(target=serve);thread.start()
                result=request_snapshot(path,dict(fps=30,warmup_frames=0,depth_frames=3))
                thread.join()
                np.testing.assert_allclose(result['depth_m'],.101)
                self.assertEqual(result['metadata']['serial'],'test')

    def test_environment_routes_capture_without_opening_camera(self):
        with patch.dict(os.environ,{'S1_RGBD_RECORD_SOCKET':'/tmp/test-camera'}),patch('demo_grasp.recording_capture.request_snapshot',return_value={'shared':True}) as client:
            self.assertEqual(capture_aligned_rgbd(serial='test'),{'shared':True})
            self.assertEqual(client.call_args.args[1]['serial'],'test')
