"""Offline replay of the 2026-09-26 real 29mm wrist-camera observation."""
import json
import math
from pathlib import Path
import threading
import time
import unittest
from unittest.mock import patch

import scripts.run_go2_visual_alignment as alignment_script
from demo_grasp.capture_rgbd import evaluate_capture_quality
from scripts.run_go2_visual_alignment import (
    apply_local_capture_quality_policy,
    bounded_endpoint_bias,
    build_segmented_recovery_path,
    capture_and_detect_with_retry,
    check_collision_path,
    compute_alignment_plan,
    converge_observation_endpoint,
    endpoint_tracking_record,
    evaluate_grasp_orientation_endpoint,
    execute_segmented_recovery,
    is_retriable_camera_timeout,
    load_alignment_config,
    load_bound_deployment_source,
    load_detector_config,
    load_spawn_worker_result,
    measured_position_from_commander,
    residual_correction_decision,
    run_capture_process_while_holding,
    run_worker_while_holding,
    summarize_endpoint_tail,
)
from s1_control.go2_visual_alignment import (
    blended_support_up_normal,
    build_tangent_tcp_path,
    densify_joint_path,
    solve_continuous_ik_path,
    validate_torque_envelope,
)
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    differential_tilt_compensation_from_support_up,
    gravity_vector_base_rear_down,
    locate_official_gripper_urdf,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class Go2VisualAlignmentRealReplay(unittest.TestCase):
    def test_endpoint_tail_summary_ignores_early_catchup_samples(self):
        samples = []
        for j6 in (0.40, 0.50, 0.60, 0.68, 0.700, 0.701, 0.700):
            samples.append([0.0, 0.0, 0.0, 0.0, 0.0, j6])
        summary = summarize_endpoint_tail(samples, 3)
        self.assertEqual(summary["sample_count"], 7)
        self.assertEqual(summary["evaluation_sample_count"], 3)
        self.assertAlmostEqual(summary["measured_q_rad"][5], 0.700, places=6)
        self.assertAlmostEqual(
            summary["evaluation_window_range_rad"][5], 0.001, places=6
        )

    def test_orientation_endpoint_rejects_unstable_tail_window(self):
        class IdentityKinematics:
            def fk(self, q):
                return [q[0], q[1], q[2], 0.0, 0.0, 0.0, 1.0]

        result = evaluate_grasp_orientation_endpoint(
            [0.0] * 6,
            [0.0] * 6,
            start_tcp_pose=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            target_quaternion=[0.0, 0.0, 0.0, 1.0],
            config={
                "maximum_endpoint_joint_error_rad": 0.03,
                "maximum_endpoint_tcp_position_drift_mm": 5.0,
                "maximum_endpoint_orientation_error_deg": 3.0,
                "maximum_endpoint_window_range_rad": 0.005,
            },
            tcp_kinematics=IdentityKinematics(),
            endpoint_window_range_rad=[0.0, 0.0, 0.0, 0.0, 0.0, 0.006],
        )
        self.assertFalse(result["passed"])
        self.assertIn("endpoint_window_not_stable", result["reasons"])

    def test_orientation_endpoint_accepts_stable_task_space_fallback(self):
        class FixedPoseKinematics:
            def fk(self, q):
                return [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]

        result = evaluate_grasp_orientation_endpoint(
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0306077],
            [0.0] * 6,
            start_tcp_pose=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            target_quaternion=[0.0, 0.0, 0.0, 1.0],
            config={
                "maximum_endpoint_joint_error_rad": 0.03,
                "fallback_maximum_endpoint_joint_error_rad": 0.032,
                "maximum_endpoint_tcp_position_drift_mm": 5.0,
                "maximum_endpoint_orientation_error_deg": 3.0,
                "maximum_endpoint_window_range_rad": 0.005,
            },
            tcp_kinematics=FixedPoseKinematics(),
            endpoint_window_range_rad=[
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.000381,
            ],
        )
        self.assertTrue(result["passed"])
        self.assertEqual(
            result["joint_error_gate"], "stable_task_space_fallback"
        )
        self.assertEqual(result["applied_joint_error_limit_rad"], 0.032)

    def test_orientation_endpoint_fallback_rejects_unstable_or_large_error(self):
        class FixedPoseKinematics:
            def fk(self, q):
                return [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0]

        config = {
            "maximum_endpoint_joint_error_rad": 0.03,
            "fallback_maximum_endpoint_joint_error_rad": 0.032,
            "maximum_endpoint_tcp_position_drift_mm": 5.0,
            "maximum_endpoint_orientation_error_deg": 3.0,
            "maximum_endpoint_window_range_rad": 0.005,
        }
        unstable = evaluate_grasp_orientation_endpoint(
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0306077],
            [0.0] * 6,
            start_tcp_pose=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            target_quaternion=[0.0, 0.0, 0.0, 1.0],
            config=config,
            tcp_kinematics=FixedPoseKinematics(),
            endpoint_window_range_rad=[0.0, 0.0, 0.0, 0.0, 0.0, 0.006],
        )
        too_large = evaluate_grasp_orientation_endpoint(
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0321],
            [0.0] * 6,
            start_tcp_pose=[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
            target_quaternion=[0.0, 0.0, 0.0, 1.0],
            config=config,
            tcp_kinematics=FixedPoseKinematics(),
            endpoint_window_range_rad=[
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
                0.000381,
            ],
        )
        self.assertFalse(unstable["passed"])
        self.assertIn("joint_tracking_error_too_large", unstable["reasons"])
        self.assertIn("endpoint_window_not_stable", unstable["reasons"])
        self.assertFalse(too_large["passed"])
        self.assertIn("joint_tracking_error_too_large", too_large["reasons"])

    def test_alignment_plan_rebases_start_after_support_normal_update(self):
        class LinearKinematics:
            def fk(self, q):
                return [q[0], q[1], q[2], 0.0, 0.0, 0.0, 1.0]

        class Loaded:
            record = {
                "safety": {
                    "minimum_target_clearance_mm": 200.0,
                    "maximum_target_clearance_mm": 300.0,
                },
                "validated_workspace": {
                    "tcp_base_x_mm": [-60.0, 55.0],
                    "tcp_base_y_mm": [300.0, 345.0],
                    "normal_clearance_mm": [225.0, 290.0],
                },
            }

        capture_q = [0.0, 0.31, 0.25, 0.0, 0.0, 0.0]
        rebased_q = [0.01, 0.32, 0.25, 0.0, 0.0, 0.0]
        observation_record = {
            "q_observed_rad": capture_q,
            "observation": {
                "surface_point_base_m": [0.01, 0.32, 0.0],
                "support_up_normal_base": [0.0, 0.0, 1.0],
            },
        }
        result = compute_alignment_plan(
            observation_record,
            planning_start_q_rad=rebased_q,
            loaded=Loaded(),
            alignment={
                "maximum_initial_tangent_error_mm": 40.0,
                "success_tangent_error_mm": 5.0,
                "maximum_cartesian_step_mm": 5.0,
                "maximum_joint_step_rad": 0.15,
                "minimum_joint_margin_deg": 10.0,
                "maximum_fk_position_error_mm": 1.0,
                "maximum_fk_orientation_error_deg": 0.5,
                "collision_step_rad": 0.01,
            },
            tcp_kinematics=LinearKinematics(),
            collision_checker=None,
            tilt_model=None,
            applied_support_up=[0.0, 0.0, 1.0],
            side_scale=1.0,
            torque_limits=[1.0] * 6,
        )
        self.assertEqual(result["observation_capture_q_rad"], capture_q)
        self.assertEqual(result["planning_start_q_rad"], rebased_q)
        self.assertTrue(result["planning_start_rebased_after_support_normal"])
        self.assertEqual(result["alignment_joint_path"], [rebased_q])
        self.assertTrue(result["cartesian_path"]["converged"])

    def test_live_camera_stages_use_spawn_process_isolation(self):
        source = (
            PROJECT_ROOT / "scripts" / "run_go2_visual_alignment.py"
        ).read_text(encoding="utf-8")
        import ast
        import inspect
        self.assertIn('multiprocessing.get_context("spawn")', source)
        main_tree = ast.parse(inspect.getsource(alignment_script.main))
        calls = {node.func.id for node in ast.walk(main_tree)
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)}
        self.assertIn("run_capture_process_while_holding", calls)
        self.assertTrue(calls.isdisjoint({"capture_and_detect", "capture_and_detect_with_retry",
                                         "capture_aligned_rgbd"}))

    def test_spawn_worker_result_contract(self):
        import tempfile

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "result.json"
            path.write_text(
                json.dumps({"ok": True, "result": {"status": "done"}}),
                encoding="utf-8",
            )
            self.assertEqual(
                load_spawn_worker_result(path, "test_worker"),
                {"status": "done"},
            )
            path.write_text(
                json.dumps(
                    {"ok": False, "error_type": "ValueError", "error": "bad"}
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(RuntimeError, "ValueError: bad"):
                load_spawn_worker_result(path, "test_worker")

    def test_detector_loader_unpacks_config_and_path(self):
        config, config_path = load_detector_config(
            PROJECT_ROOT / "config" / "wrist_cube_vision.yaml"
        )
        self.assertIsInstance(config, dict)
        self.assertIn("plane", config)
        self.assertEqual(
            config_path,
            (PROJECT_ROOT / "config" / "wrist_cube_vision.yaml").resolve(),
        )

    def test_alignment_config_has_dedicated_worker_budget(self):
        _, config = load_alignment_config(
            PROJECT_ROOT / "config" / "go2_crouch_right_visual_alignment.json"
        )
        self.assertEqual(
            config["alignment"]["maximum_initial_tangent_error_mm"], 40.0
        )
        runtime = config["runtime"]
        self.assertEqual(runtime["worker_timeout_s"], 30.0)
        self.assertEqual(runtime["capture_hold_hz"], 10.0)
        self.assertEqual(runtime["capture_velocity_guard_hz"], 2.0)
        self.assertEqual(runtime["capture_temperature_period_s"], 2.0)
        self.assertEqual(runtime["camera_attempts"], 2)
        self.assertEqual(runtime["camera_retry_delay_s"], 1.0)
        quality_override = config["capture_quality_override"]
        self.assertEqual(
            quality_override["scope"],
            "go2_visual_alignment_vm_usb_only",
        )
        self.assertEqual(
            quality_override["status"], "provisional_working_threshold"
        )
        self.assertEqual(
            quality_override["maximum_frame_interval_ms"], 350.0
        )
        endpoint = config["observation_endpoint_convergence"]
        self.assertEqual(endpoint["success_joint_error_rad"], 0.020)
        self.assertEqual(endpoint["maximum_bias_rad"], 0.024)
        self.assertEqual(endpoint["maximum_attempts"], 6)
        alignment_endpoint = config["alignment_endpoint_convergence"]
        self.assertEqual(
            alignment_endpoint["success_joint_error_rad"], 0.012
        )
        self.assertEqual(
            alignment_endpoint["fallback_success_joint_error_rad"], 0.020
        )
        self.assertEqual(alignment_endpoint["maximum_bias_rad"], 0.024)
        self.assertEqual(alignment_endpoint["maximum_attempts"], 6)
        residual = config["residual_correction"]
        self.assertEqual(residual["maximum_passes"], 1)
        self.assertEqual(residual["maximum_residual_error_mm"], 12.0)
        recovery = config["fault_recovery"]
        self.assertEqual(
            recovery["status"], "provisional_low_speed_segmented_return"
        )
        self.assertEqual(recovery["v_max_rad_s"], 0.04)
        self.assertEqual(recovery["maximum_joint_step_rad"], 0.04)
        self.assertEqual(recovery["operator_support_timeout_s"], 15.0)
        geometry_override = config["geometry_quality_override"]
        self.assertEqual(
            geometry_override["scope"],
            "go2_visual_alignment_go2_crouch_right_only",
        )
        self.assertEqual(
            geometry_override["maximum_camera_tilt_from_down_deg"], 12.0
        )
        payload = config["d455_payload"]
        self.assertEqual(payload["mass_kg"], 0.077)
        self.assertEqual(payload["ab_scale"], 0.5)
        self.assertIs(payload["enabled_for_full_alignment"], False)

    def test_alignment_config_rejects_more_than_40mm(self):
        import tempfile

        source = PROJECT_ROOT / "config" / "go2_crouch_right_visual_alignment.json"
        record = json.loads(source.read_text(encoding="utf-8"))
        record["alignment"]["maximum_initial_tangent_error_mm"] = 40.001
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "alignment.json"
            path.write_text(json.dumps(record), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "cannot exceed 40mm"):
                load_alignment_config(path)

    def test_alignment_config_rejects_local_camera_tilt_above_15deg(self):
        import tempfile

        source = PROJECT_ROOT / "config" / "go2_crouch_right_visual_alignment.json"
        record = json.loads(source.read_text(encoding="utf-8"))
        record["geometry_quality_override"][
            "maximum_camera_tilt_from_down_deg"
        ] = 15.001
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "alignment.json"
            path.write_text(json.dumps(record), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "within \\[10, 15\\]"):
                load_alignment_config(path)

    def test_alignment_config_accepts_adaptive_approach_tilt_at_15deg(self):
        source = (
            PROJECT_ROOT
            / "config"
            / "go2_crouch_right_visual_orientation_only_nocw_metalbracket_"
            "dual_white_light_highturn050_v2.json"
        )
        _, config = load_alignment_config(source)
        self.assertEqual(
            config["runtime"]["support_normal_deviation_reference"],
            "mount_record_pitch_roll",
        )
        self.assertEqual(
            config["geometry_quality_override"]["maximum_camera_tilt_from_down_deg"],
            15.0,
        )
        self.assertEqual(
            config["adaptive_grasp_orientation"][
                "maximum_approach_tilt_from_support_down_deg"
            ],
            15.0,
        )

    def test_alignment_config_rejects_adaptive_approach_tilt_above_15deg(self):
        import tempfile

        source = (
            PROJECT_ROOT
            / "config"
            / "go2_crouch_right_visual_orientation_only_nocw_metalbracket_"
            "dual_white_light_highturn050_v2.json"
        )
        record = json.loads(source.read_text(encoding="utf-8"))
        record["adaptive_grasp_orientation"][
            "maximum_approach_tilt_from_support_down_deg"
        ] = 15.001
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "alignment.json"
            path.write_text(json.dumps(record), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "cannot exceed 15deg"):
                load_alignment_config(path)

    def test_local_capture_policy_accepts_v4_isolated_interval_spike(self):
        metadata = {
            "quality_pass": False,
            "quality_reasons": ["frame_interval_ms_max=400.484 > 350.000"],
            "frame_interval_ms_max": 400.483524,
            "frame_interval_ms_p95": 294.653128,
            "valid_depth_ratio_fused": 0.780885,
        }
        policy = {
            "isolated_frame_interval_spike": {
                "enabled": True,
                "maximum_single_frame_interval_ms": 450.0,
                "maximum_frame_interval_p95_ms": 350.0,
                "minimum_valid_depth_ratio_fused": 0.70,
            }
        }
        decision = apply_local_capture_quality_policy(metadata, policy)
        self.assertEqual(
            decision["status"], "accepted_isolated_frame_interval_spike"
        )
        self.assertIs(metadata["quality_pass"], True)
        self.assertEqual(metadata["quality_reasons"], [])
        self.assertEqual(
            metadata["local_quality_review"]["original_quality_reasons"],
            ["frame_interval_ms_max=400.484 > 350.000"],
        )

    def test_local_capture_policy_rejects_sustained_interval_jitter(self):
        metadata = {
            "quality_pass": False,
            "quality_reasons": ["frame_interval_ms_max=400.484 > 350.000"],
            "frame_interval_ms_max": 400.483524,
            "frame_interval_ms_p95": 351.0,
            "valid_depth_ratio_fused": 0.780885,
        }
        policy = {
            "isolated_frame_interval_spike": {
                "enabled": True,
                "maximum_single_frame_interval_ms": 450.0,
                "maximum_frame_interval_p95_ms": 350.0,
                "minimum_valid_depth_ratio_fused": 0.70,
            }
        }
        decision = apply_local_capture_quality_policy(metadata, policy)
        self.assertEqual(decision["status"], "rejected")
        self.assertEqual(
            decision["reason"], "isolated_spike_secondary_limits_failed"
        )
        self.assertIs(metadata["quality_pass"], False)

    def test_local_capture_policy_never_hides_other_quality_failure(self):
        metadata = {
            "quality_pass": False,
            "quality_reasons": ["valid_depth_ratio_fused=0.500 < 0.600"],
            "frame_interval_ms_max": 100.0,
            "frame_interval_ms_p95": 90.0,
            "valid_depth_ratio_fused": 0.50,
        }
        policy = {
            "isolated_frame_interval_spike": {
                "enabled": True,
                "maximum_single_frame_interval_ms": 450.0,
                "maximum_frame_interval_p95_ms": 350.0,
                "minimum_valid_depth_ratio_fused": 0.70,
            }
        }
        decision = apply_local_capture_quality_policy(metadata, policy)
        self.assertEqual(decision["status"], "rejected")
        self.assertEqual(
            decision["reason"],
            "quality_failure_is_not_one_isolated_interval_spike",
        )
        self.assertIs(metadata["quality_pass"], False)

    def test_final_capture_is_persisted_before_geometry_check(self):
        source = (
            PROJECT_ROOT / "scripts" / "run_go2_visual_alignment.py"
        ).read_text(encoding="utf-8")
        capture_log = source.index('"final_geometry_check_status": "pending"')
        geometry_check = source.index(
            "final_record, _ = run_worker_while_holding(", capture_log
        )
        self.assertLess(capture_log, geometry_check)

    def test_endpoint_bias_opposes_error_with_step_and_total_caps(self):
        first = bounded_endpoint_bias(
            [0.0] * 6,
            [-0.020, 0.003, 0.0, 0.010, -0.001, 0.040],
            maximum_step_rad=0.004,
            maximum_bias_rad=0.024,
        )
        self.assertEqual(
            first,
            [0.004, -0.003, 0.0, -0.004, 0.001, -0.004],
        )
        saturated = bounded_endpoint_bias(
            [0.023, -0.023, 0.0, 0.0, 0.0, 0.0],
            [-0.020, 0.020, 0.0, 0.0, 0.0, 0.0],
            maximum_step_rad=0.004,
            maximum_bias_rad=0.024,
        )
        self.assertEqual(saturated[:2], [0.024, -0.024])

    def test_fault_recovery_path_starts_at_feedback_and_is_bounded(self):
        current = [0.09, 0.0, 0.0, 0.0, 0.0, 0.0]
        waypoints = [
            [0.09, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.03, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        ]
        path = build_segmented_recovery_path(current, waypoints, 0.04)
        self.assertEqual(path[0], current)
        self.assertEqual(path[-1], waypoints[-1])
        self.assertTrue(
            all(
                max(abs(a - b) for a, b in zip(first, second))
                <= 0.04 + 1e-12
                for first, second in zip(path, path[1:])
            )
        )

    def test_segmented_fault_recovery_rebases_and_restores_speed_limits(self):
        class Limits:
            v_max_rad_s = 0.08
            j6_v_max_rad_s = 0.08

        class FakeArm:
            limits = Limits()

            def __init__(self):
                self.measured = [0.09, 0.0, 0.0, 0.0, 0.0, 0.0]
                self.moves = []

            def get_pos(self):
                return list(self.measured) + [0.0]

            def move(self, q_from, q_to, label):
                self.moves.append(
                    {
                        "from": list(q_from),
                        "to": list(q_to),
                        "label": label,
                        "v_max": self.limits.v_max_rad_s,
                        "j6_v_max": self.limits.j6_v_max_rad_s,
                    }
                )
                self.measured = list(q_to)
                return None

        arm = FakeArm()
        with patch.object(
            alignment_script,
            "check_collision_path",
            return_value={"sample_count": 2, "active_collision_count": 0},
        ):
            record = execute_segmented_recovery(
                arm,
                [[0.0] * 6],
                label="test_recovery",
                collision_checker=object(),
                collision_step_rad=0.01,
                maximum_joint_step_rad=0.04,
                v_max_rad_s=0.04,
                j6_v_max_rad_s=0.04,
            )
        self.assertEqual(record["status"], "completed")
        self.assertEqual(record["final_measured_q_rad"], [0.0] * 6)
        self.assertEqual(arm.limits.v_max_rad_s, 0.08)
        self.assertEqual(arm.limits.j6_v_max_rad_s, 0.08)
        self.assertGreaterEqual(len(arm.moves), 3)
        self.assertTrue(
            all(
                max(
                    abs(a - b)
                    for a, b in zip(move["from"], move["to"])
                )
                <= 0.04 + 1e-12
                for move in arm.moves
            )
        )
        self.assertTrue(all(move["v_max"] == 0.04 for move in arm.moves))

    def test_endpoint_tracking_record_reports_joint_and_tcp_error(self):
        class LinearKinematics:
            def fk(self, q):
                return [q[0], q[1], q[2], 0.0, 0.0, 0.0, 1.0]

        record = endpoint_tracking_record(
            [0.0] * 6,
            [0.001, -0.002, 0.003, 0.0, 0.0, 0.0],
            LinearKinematics(),
        )
        self.assertAlmostEqual(record["maximum_abs_joint_error_rad"], 0.003)
        self.assertEqual(record["tcp_error_xyz_mm"], [1.0, -2.0, 3.0])
        self.assertAlmostEqual(
            record["tcp_error_norm_mm"], math.sqrt(14.0), places=9
        )

    def test_residual_retry_is_single_and_bounded_without_relaxing_success(self):
        alignment = {
            "success_tangent_error_mm": 5.0,
            "maximum_final_normal_drift_mm": 5.0,
        }
        residual = {
            "maximum_passes": 1,
            "maximum_residual_error_mm": 12.0,
        }
        allowed = residual_correction_decision(
            {
                "converged": False,
                "initial_tangent_error_norm_mm": 9.3688,
            },
            4.4689,
            alignment=alignment,
            residual_config=residual,
        )
        self.assertTrue(allowed["allowed"])
        self.assertEqual(allowed["reason"], "single_bounded_retry_allowed")
        too_far = residual_correction_decision(
            {
                "converged": False,
                "initial_tangent_error_norm_mm": 12.001,
            },
            1.0,
            alignment=alignment,
            residual_config=residual,
        )
        self.assertFalse(too_far["allowed"])
        self.assertEqual(too_far["reason"], "residual_above_bounded_retry_range")

        planned_range = {**residual, "maximum_residual_error_mm": None}
        needs_planning = residual_correction_decision(
            {"converged": False, "initial_tangent_error_norm_mm": 12.197},
            8.649,
            alignment={**alignment, "normal_drift_monitor_only": True},
            residual_config=planned_range,
        )
        self.assertTrue(needs_planning["allowed"])
        self.assertEqual(needs_planning["reason"], "single_retry_pending_path_planning")
        self.assertEqual(needs_planning["success_error_mm"], 5.0)
        self.assertEqual(needs_planning["maximum_passes"], 1)

        drifted = residual_correction_decision(
            {
                "converged": False,
                "initial_tangent_error_norm_mm": 9.0,
            },
            5.001,
            alignment=alignment,
            residual_config=residual,
        )
        self.assertFalse(drifted["allowed"])
        self.assertEqual(drifted["reason"], "normal_drift_limit_reached")

    def test_endpoint_convergence_corrects_bounded_static_offset(self):
        class FakeKinematics:
            def fk(self, _q):
                return [0.0, 0.32, 0.10, 0.0, 0.0, 0.0, 1.0]

        class FakeCommander:
            last_snapshot = None

        class FakeArm:
            dt = 0.001

            def __init__(self):
                self._position_commander = FakeCommander()

            def command_position(self, q):
                measured = list(q)
                measured[0] -= 0.010
                self._position_commander.last_snapshot = {
                    "measured_q_rad": measured
                }

            def get_pos(self):
                return self._position_commander.last_snapshot["measured_q_rad"] + [0.0]

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

            def move_waypoints(self, points, _label):
                self.command_position(points[-1])
                return None

        endpoint_config = {
            "success_joint_error_rad": 0.008,
            "maximum_initial_joint_error_rad": 0.05,
            "bias_step_rad": 0.004,
            "maximum_bias_rad": 0.024,
            "maximum_attempts": 6,
            "hold_seconds": 0.01,
            "collision_step_rad": 0.005,
            "minimum_joint_margin_deg": 10.0,
            "validated_workspace": {
                "tcp_base_x_mm": [-60.0, 55.0],
                "tcp_base_y_mm": [300.0, 345.0],
                "normal_clearance_mm": [225.0, 290.0],
            },
        }
        arm = FakeArm()
        arm.command_position([0.0, 1.0, 1.0, 0.0, 0.0, 0.0])
        with patch.object(
            alignment_script,
            "check_collision_path",
            return_value={"sample_count": 2, "active_collision_count": 0},
        ), patch.object(
            alignment_script,
            "validate_torque_envelope",
            return_value={"maximum_limit_fraction": 0.1},
        ):
            record = converge_observation_endpoint(
                arm,
                [0.0, 1.0, 1.0, 0.0, 0.0, 0.0],
                endpoint_config=endpoint_config,
                kinematics=FakeKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                support_up_normal_base=[0.0, 0.0, 1.0],
                compensation_scale=1.0,
                torque_limits=[1.0] * 6,
            )
        self.assertEqual(record["status"], "passed")
        self.assertEqual(len(record["attempts"]), 2)
        self.assertAlmostEqual(record["final_command_q_rad"][0], 0.004)
        self.assertLessEqual(
            record["final_tracking"]["maximum_abs_joint_error_rad"], 0.008
        )

    def test_alignment_endpoint_trim_covers_observed_j3_j6_offsets(self):
        class FakeKinematics:
            def fk(self, _q):
                return [0.0, 0.32, 0.10, 0.0, 0.0, 0.0, 1.0]

        class FakeCommander:
            last_snapshot = None

        class FakeArm:
            dt = 0.001

            def __init__(self):
                self._position_commander = FakeCommander()

            def command_position(self, q):
                measured = list(q)
                measured[2] -= 0.030
                measured[5] += 0.025
                self._position_commander.last_snapshot = {
                    "measured_q_rad": measured
                }

            def get_pos(self):
                return self._position_commander.last_snapshot["measured_q_rad"] + [0.0]

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

            def move_waypoints(self, points, _label):
                self.command_position(points[-1])
                return None

        endpoint_config = {
            "success_joint_error_rad": 0.012,
            "maximum_initial_joint_error_rad": 0.05,
            "bias_step_rad": 0.004,
            "maximum_bias_rad": 0.024,
            "maximum_attempts": 6,
            "hold_seconds": 0.01,
            "collision_step_rad": 0.005,
            "minimum_joint_margin_deg": 10.0,
            "validated_workspace": {
                "tcp_base_x_mm": [-60.0, 55.0],
                "tcp_base_y_mm": [300.0, 345.0],
                "normal_clearance_mm": [225.0, 290.0],
            },
        }
        arm = FakeArm()
        arm.command_position([0.0, 1.0, 1.0, 0.0, 0.0, 0.0])
        with patch.object(
            alignment_script,
            "check_collision_path",
            return_value={"sample_count": 2, "active_collision_count": 0},
        ), patch.object(
            alignment_script,
            "validate_torque_envelope",
            return_value={"maximum_limit_fraction": 0.1},
        ):
            record = converge_observation_endpoint(
                arm,
                [0.0, 1.0, 1.0, 0.0, 0.0, 0.0],
                endpoint_config=endpoint_config,
                kinematics=FakeKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                support_up_normal_base=[0.0, 0.0, 1.0],
                compensation_scale=1.0,
                torque_limits=[1.0] * 6,
                label_prefix="alignment_endpoint_test",
            )
        self.assertEqual(record["status"], "passed")
        self.assertEqual(record["label"], "alignment_endpoint_test")
        self.assertLessEqual(
            record["final_tracking"]["maximum_abs_joint_error_rad"], 0.012
        )
        self.assertAlmostEqual(record["final_command_q_rad"][2], 1.020)
        self.assertAlmostEqual(record["final_command_q_rad"][5], -0.020)

    def test_alignment_endpoint_uses_fallback_only_after_all_attempts(self):
        class FakeKinematics:
            def fk(self, _q):
                return [0.0, 0.32, 0.10, 0.0, 0.0, 0.0, 1.0]

        class FakeCommander:
            last_snapshot = None

        class FixedResidualArm:
            dt = 0.001

            def __init__(self):
                self._position_commander = FakeCommander()

            def command_position(self, q):
                measured = list(q)
                measured[2] = 0.985
                self._position_commander.last_snapshot = {
                    "measured_q_rad": measured
                }

            def get_pos(self):
                return self._position_commander.last_snapshot["measured_q_rad"] + [0.0]

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

            def move_waypoints(self, points, _label):
                self.command_position(points[-1])
                return None

        endpoint_config = {
            "success_joint_error_rad": 0.012,
            "fallback_success_joint_error_rad": 0.020,
            "maximum_initial_joint_error_rad": 0.05,
            "bias_step_rad": 0.004,
            "maximum_bias_rad": 0.024,
            "maximum_attempts": 2,
            "hold_seconds": 0.01,
            "collision_step_rad": 0.005,
            "minimum_joint_margin_deg": 10.0,
            "validated_workspace": {
                "tcp_base_x_mm": [-60.0, 55.0],
                "tcp_base_y_mm": [300.0, 345.0],
                "normal_clearance_mm": [225.0, 290.0],
            },
        }
        arm = FixedResidualArm()
        arm.command_position([0.0, 1.0, 1.0, 0.0, 0.0, 0.0])
        with patch.object(
            alignment_script,
            "check_collision_path",
            return_value={"sample_count": 2, "active_collision_count": 0},
        ), patch.object(
            alignment_script,
            "validate_torque_envelope",
            return_value={"maximum_limit_fraction": 0.1},
        ):
            record = converge_observation_endpoint(
                arm,
                [0.0, 1.0, 1.0, 0.0, 0.0, 0.0],
                endpoint_config=endpoint_config,
                kinematics=FakeKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                support_up_normal_base=[0.0, 0.0, 1.0],
                compensation_scale=1.0,
                torque_limits=[1.0] * 6,
                label_prefix="alignment_endpoint_fallback_test",
            )
        self.assertEqual(record["status"], "passed_fallback_working_threshold")
        self.assertEqual(len(record["attempts"]), 3)
        self.assertGreater(
            record["final_tracking"]["maximum_abs_joint_error_rad"], 0.012
        )
        self.assertLessEqual(
            record["final_tracking"]["maximum_abs_joint_error_rad"], 0.020
        )

    def test_local_frame_interval_override_passes_jitter_not_stall(self):
        common = {
            "usb_type": "3.2",
            "valid_depth_ratio_fused": 0.783408203125,
        }
        current = dict(common, frame_interval_ms_max=302.355433)
        historical_stall = dict(common, frame_interval_ms_max=1290.9)
        self.assertTrue(
            evaluate_capture_quality(
                current,
                max_frame_interval_ms=350.0,
            )[0]
        )
        passed, reasons = evaluate_capture_quality(
            historical_stall,
            max_frame_interval_ms=350.0,
        )
        self.assertFalse(passed)
        self.assertIn("1290.900 > 350.000", reasons[0])

    def test_capture_reuses_tilt_commander_feedback(self):
        class Commander:
            last_snapshot = {"measured_q_rad": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]}

        class FakeArm:
            _position_commander = Commander()

            def get_pos(self):
                raise AssertionError("duplicate serial position read")

        self.assertEqual(
            measured_position_from_commander(FakeArm()),
            [0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
        )

    def test_capture_retries_only_frame_arrival_timeout(self):
        self.assertTrue(
            is_retriable_camera_timeout(
                RuntimeError("Frame didn't arrive within 5000")
            )
        )
        self.assertFalse(is_retriable_camera_timeout(ValueError("NO_TARGET")))
        expected = {"capture_metadata": {"quality_pass": True}}
        with patch.object(
            alignment_script,
            "capture_and_detect",
            side_effect=[
                RuntimeError("Frame didn't arrive within 5000"),
                dict(expected),
            ],
        ) as capture_mock, patch.object(alignment_script.time, "sleep"):
            result = capture_and_detect_with_retry(
                object(),
                {},
                PROJECT_ROOT,
                "retry_test",
                camera_attempts=2,
                retry_delay_s=1.0,
            )
        self.assertEqual(capture_mock.call_count, 2)
        self.assertEqual(result["camera_attempt"], 2)
        self.assertEqual(result["capture_metadata"], expected["capture_metadata"])

    def test_capture_hold_avoids_high_rate_feedback_reads(self):
        import tempfile

        class FakeLimits:
            settle_seconds = 0.0

        class Commander:
            last_snapshot = None

        class FakeArm:
            limits = FakeLimits()

            def __init__(self):
                self._position_commander = Commander()
                self.command_count = 0
                self.position_read_count = 0
                self.velocity_read_count = 0
                self.temperature_read_count = 0

            def command_position(self, q):
                self.command_count += 1
                self._position_commander.last_snapshot = {
                    "measured_q_rad": list(q)
                }

            def get_pos(self):
                self.position_read_count += 1
                return [0.0] * 7

            def get_vel(self):
                self.velocity_read_count += 1
                return [0.0] * 7

            def get_temp(self):
                self.temperature_read_count += 1
                return [25.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

        class FakeProcess:
            exitcode = 0
            pid = 12345

            def __init__(self):
                self._alive_checks = 0

            def start(self):
                return None

            def is_alive(self):
                self._alive_checks += 1
                return self._alive_checks <= 3

            def join(self, timeout=None):
                return None

        class FakeContext:
            def Process(self, **_kwargs):
                return FakeProcess()

        with tempfile.TemporaryDirectory() as temp_dir:
            result_path = Path(temp_dir) / "sample_process_result.json"
            result_path.write_text(
                json.dumps({"ok": True, "result": {"status": "done"}}),
                encoding="utf-8",
            )
            arm = FakeArm()
            with patch.object(
                alignment_script.multiprocessing,
                "get_context",
                return_value=FakeContext(),
            ):
                result, measured = run_capture_process_while_holding(
                    arm,
                    [0.0] * 6,
                    wrist_config_path="unused.json",
                    vision_config_path="unused.yaml",
                    run_dir=temp_dir,
                    capture_label="sample",
                    timeout_s=2.0,
                    label="low_load_test",
                    hold_hz=100.0,
                    velocity_guard_hz=1.0,
                    temperature_period_s=1.0,
                    camera_attempts=2,
                    camera_retry_delay_s=0.0,
                    write_raw_capture_previews=False,
                    capture_quality_override={
                        "scope": "go2_visual_alignment_vm_usb_only",
                        "status": "provisional_working_threshold",
                        "maximum_frame_interval_ms": 350.0,
                    },
                )
        self.assertEqual(result, {"status": "done"})
        self.assertEqual(len(measured), 6)
        self.assertEqual(arm.command_count, 3)
        self.assertEqual(arm.position_read_count, 0)
        self.assertEqual(arm.velocity_read_count, 2)
        self.assertEqual(arm.temperature_read_count, 2)

    def test_worker_timeout_waits_for_resource_cleanup_before_raising(self):
        class FakeLimits:
            settle_seconds = 0.0

        class FakeArm:
            dt = 0.001
            limits = FakeLimits()

            def command_position(self, _q):
                return None

            def get_pos(self):
                return [0.0] * 7

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

        released = threading.Event()

        def slow_worker():
            time.sleep(0.03)
            released.set()
            return "done"

        started = time.monotonic()
        with self.assertRaisesRegex(TimeoutError, "resources were released"):
            run_worker_while_holding(
                FakeArm(),
                [0.0] * 6,
                slow_worker,
                timeout_s=0.01,
                label="cleanup_regression",
            )
        self.assertTrue(released.is_set())
        self.assertGreaterEqual(time.monotonic() - started, 0.03)

    def test_generated_plan_loads_segment_limit_from_bound_source(self):
        plan = json.loads(
            (
                PROJECT_ROOT
                / "data"
                / "plans"
                / "go2_crouch_right_observe_deployment_v1.json"
            ).read_text(encoding="utf-8")
        )
        source_path, source = load_bound_deployment_source(plan)
        self.assertEqual(
            source_path,
            (PROJECT_ROOT / "config" / "go2_crouch_right_observe_deployment.json").resolve(),
        )
        self.assertEqual(source["safety"]["maximum_segment_delta_rad"], 0.9)

    def test_20260927_50mm_observation_has_safe_extended_path(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))

        q = [
            1.6611356735229492,
            1.8274593353271484,
            1.3502330780029297,
            1.0355157852172852,
            0.00782012939453125,
            0.03147125244140625,
        ]
        tcp = [
            -0.026761794462800026,
            0.3036373555660248,
            0.030451418831944466,
            -0.5006864666938782,
            0.46924808621406555,
            0.527758777141571,
            0.5005896091461182,
        ]
        target = [
            -0.002115924233753539,
            0.35384019901836893,
            -0.20288543627336847,
        ]
        support_up = [
            -0.08222464556584798,
            -0.062207390737870114,
            0.9946704721661123,
        ]
        workspace = {
            "tcp_base_x_mm": [-60.0, 55.0],
            "tcp_base_y_mm": [300.0, 345.0],
            "normal_clearance_mm": [225.0, 290.0],
        }
        cartesian = build_tangent_tcp_path(
            tcp,
            target,
            support_up,
            maximum_initial_error_mm=40.0,
            convergence_mm=5.0,
            maximum_cartesian_step_mm=5.0,
            minimum_clearance_mm=200.0,
            maximum_clearance_mm=300.0,
            workspace=workspace,
        )
        self.assertAlmostEqual(
            cartesian["initial_tangent_error_norm_mm"], 35.9124, places=3
        )
        self.assertEqual(cartesian["segment_count"], 8)
        endpoint = cartesian["tcp_poses_xyz_xyzw"][-1]
        self.assertAlmostEqual(endpoint[0] * 1000.0, -21.6231, places=3)
        self.assertAlmostEqual(endpoint[1] * 1000.0, 339.0819, places=3)

        kinematics = Kinematics(verbose=False)
        solved = solve_continuous_ik_path(
            kinematics,
            q,
            cartesian["tcp_poses_xyz_xyzw"],
            maximum_joint_step_rad=0.15,
            minimum_joint_margin_deg=10.0,
            maximum_fk_position_error_mm=1.0,
            maximum_fk_orientation_error_deg=0.5,
        )
        self.assertEqual(len(solved["joint_path"]), 9)
        self.assertLessEqual(
            max(sample["maximum_joint_delta_rad"] for sample in solved["samples"]),
            0.023,
        )
        self.assertGreaterEqual(
            min(sample["minimum_joint_margin_deg"] for sample in solved["samples"]),
            24.0,
        )

        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        collision = check_collision_path(checker, solved["joint_path"], 0.01)
        self.assertEqual(collision["active_collision_count"], 0)
        self.assertEqual(collision["floor_contact_count"], 0)

        mount = json.loads(
            (PROJECT_ROOT / "config" / "go2_crouch_mount.json").read_text(
                encoding="utf-8"
            )
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(6.0) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up, support_up, 0.5
        )
        dense = densify_joint_path(solved["joint_path"], 0.01)
        torque = validate_torque_envelope(
            dense,
            lambda sample: differential_tilt_compensation_from_support_up(
                model, sample, applied_support_up
            ),
            mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertLess(torque["maximum_limit_fraction"], 0.61)

    def test_20260927_residual_has_safe_two_segment_path(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))

        q = [
            1.6454954147338867,
            1.9384679794311523,
            1.4940481185913086,
            1.0957880020141602,
            0.00743865966796875,
            0.04902076721191406,
        ]
        tcp = [
            -0.024155952036380768,
            0.32961660623550415,
            0.027433233335614204,
            -0.4999234676361084,
            0.48437681794166565,
            0.5126513242721558,
            0.5026373267173767,
        ]
        target = [
            -0.0021491519345581394,
            0.3539984118421761,
            -0.20339159750220315,
        ]
        support_up = [
            -0.08276374483016466,
            -0.06634649305744629,
            0.9943582379608799,
        ]
        workspace = {
            "tcp_base_x_mm": [-60.0, 55.0],
            "tcp_base_y_mm": [300.0, 345.0],
            "normal_clearance_mm": [225.0, 290.0],
        }
        cartesian = build_tangent_tcp_path(
            tcp,
            target,
            support_up,
            maximum_initial_error_mm=40.0,
            convergence_mm=5.0,
            maximum_cartesian_step_mm=5.0,
            minimum_clearance_mm=200.0,
            maximum_clearance_mm=300.0,
            workspace=workspace,
        )
        self.assertAlmostEqual(
            cartesian["initial_tangent_error_norm_mm"], 9.3688, places=3
        )
        self.assertEqual(cartesian["segment_count"], 2)

        kinematics = Kinematics(verbose=False)
        solved = solve_continuous_ik_path(
            kinematics,
            q,
            cartesian["tcp_poses_xyz_xyzw"],
            maximum_joint_step_rad=0.15,
            minimum_joint_margin_deg=10.0,
            maximum_fk_position_error_mm=1.0,
            maximum_fk_orientation_error_deg=0.5,
        )
        self.assertEqual(len(solved["joint_path"]), 3)
        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        collision = check_collision_path(checker, solved["joint_path"], 0.01)
        self.assertEqual(collision["active_collision_count"], 0)
        self.assertEqual(collision["floor_contact_count"], 0)

        mount = json.loads(
            (PROJECT_ROOT / "config" / "go2_crouch_mount.json").read_text(
                encoding="utf-8"
            )
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(6.0) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up, support_up, 0.5
        )
        dense = densify_joint_path(solved["joint_path"], 0.01)
        torque = validate_torque_envelope(
            dense,
            lambda sample: differential_tilt_compensation_from_support_up(
                model, sample, applied_support_up
            ),
            mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertLess(torque["maximum_limit_fraction"], 1.0)

    def test_real_29mm_observation_has_safe_continuous_path(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))

        q = [
            1.6607542037963867,
            1.8274593353271484,
            1.3666362762451172,
            1.0347528457641602,
            0.00705718994140625,
            0.04940223693847656,
        ]
        tcp = [
            -0.02744826301932335,
            0.3091202974319458,
            0.03425409272313118,
            -0.4911786913871765,
            0.47014978528022766,
            0.5280344486236572,
            0.5088047385215759,
        ]
        target = [
            -0.0015326892715769001,
            0.352537516755931,
            -0.20165541949130483,
        ]
        support_up = [
            -0.08117456696334992,
            -0.0636057589335518,
            0.9946682849617754,
        ]
        workspace = {
            "tcp_base_x_mm": [-60.0, 55.0],
            "tcp_base_y_mm": [300.0, 345.0],
            "normal_clearance_mm": [225.0, 290.0],
        }
        cartesian = build_tangent_tcp_path(
            tcp,
            target,
            support_up,
            maximum_initial_error_mm=30.0,
            convergence_mm=5.0,
            maximum_cartesian_step_mm=5.0,
            minimum_clearance_mm=200.0,
            maximum_clearance_mm=300.0,
            workspace=workspace,
        )
        self.assertAlmostEqual(
            cartesian["initial_tangent_error_norm_mm"], 29.0101, places=3
        )
        self.assertEqual(cartesian["segment_count"], 6)

        kinematics = Kinematics(verbose=False)
        solved = solve_continuous_ik_path(
            kinematics,
            q,
            cartesian["tcp_poses_xyz_xyzw"],
            maximum_joint_step_rad=0.15,
            minimum_joint_margin_deg=10.0,
            maximum_fk_position_error_mm=1.0,
            maximum_fk_orientation_error_deg=0.5,
        )
        self.assertEqual(len(solved["joint_path"]), 7)

        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        collision = check_collision_path(checker, solved["joint_path"], 0.01)
        self.assertGreater(collision["sample_count"], 6)

        mount = json.loads(
            (PROJECT_ROOT / "config" / "go2_crouch_mount.json").read_text(
                encoding="utf-8"
            )
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(6.0) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up, support_up, 0.5
        )
        dense = densify_joint_path(solved["joint_path"], 0.01)
        torque = validate_torque_envelope(
            dense,
            lambda sample: differential_tilt_compensation_from_support_up(
                model, sample, applied_support_up
            ),
            mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertLess(torque["maximum_limit_fraction"], 1.0)


if __name__ == "__main__":
    unittest.main()
