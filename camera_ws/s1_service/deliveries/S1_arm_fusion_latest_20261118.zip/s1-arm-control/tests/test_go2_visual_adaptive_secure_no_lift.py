"""Offline gates for the first adaptive secure-contact, no-lift Go2 run."""
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from scripts.run_go2_visual_alignment import (
    compute_safe_descent_plan,
    converge_observation_endpoint,
    endpoint_vision_handoff_decision,
    load_alignment_config,
    load_bound_adaptive_grasp_resources,
    resolve_adaptive_pregrasp_config,
    resolve_adaptive_secure_no_lift_config,
)
from scripts.gripper_contact_probe import BenchRunner
from s1_control.go2_visual_alignment import blended_support_up_normal
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    gravity_vector_base_rear_down,
    locate_official_gripper_urdf,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = (
    PROJECT_ROOT
    / "config/go2_crouch_right_visual_adaptive_secure_no_lift_nocw_metalbracket_v1.json"
)


class LinearKinematics:
    def fk(self, q):
        return [float(q[0]), float(q[1]), float(q[2]), 0.0, 0.0, 0.0, 1.0]


class Go2VisualAdaptiveSecureNoLiftTests(unittest.TestCase):
    def config(self):
        return load_alignment_config(CONFIG_PATH)[1]

    @staticmethod
    def final_capture(height_p90=51.85727233886719):
        return {
            "detection": {
                "selected": {
                    "accepted": True,
                    "target_id": "component_001",
                    "core_height_mm": {"p90": height_p90},
                }
            }
        }

    def test_config_allows_contact_but_forbids_lift(self):
        config = self.config()
        self.assertEqual(
            config["operation"], "adaptive_secure_no_lift_round_trip"
        )
        forbidden = set(config["physical_scope"]["forbidden_actions"])
        self.assertIn("lift", forbidden)
        self.assertIn("box_place", forbidden)
        self.assertIn("descent_below_grasp_height", forbidden)
        self.assertNotIn("contact", forbidden)
        self.assertNotIn("gripper_close", forbidden)
        self.assertAlmostEqual(
            config["adaptive_secure_no_lift"][
                "pregrasp_descent_compensation_scale"
            ],
            0.85,
        )
        self.assertAlmostEqual(
            config["adaptive_secure_no_lift"]["low_stage_compensation_scale"],
            0.80,
        )
        self.assertGreater(
            config["adaptive_secure_no_lift"][
                "pregrasp_descent_compensation_scale"
            ],
            config["adaptive_secure_no_lift"]["low_stage_compensation_scale"],
        )
        handoff = config["adaptive_secure_no_lift"][
            "alignment_endpoint_vision_handoff"
        ]
        self.assertTrue(handoff["handoff_only_to_final_vision_gate"])
        self.assertAlmostEqual(handoff["maximum_joint_error_rad"], 0.027)
        self.assertAlmostEqual(handoff["maximum_tcp_error_mm"], 7.0)
        self.assertAlmostEqual(
            handoff["maximum_support_normal_error_mm"], 5.0
        )

    def test_endpoint_residual_can_handoff_only_to_final_vision_gate(self):
        handoff_config = self.config()["adaptive_secure_no_lift"][
            "alignment_endpoint_vision_handoff"
        ]
        decision = endpoint_vision_handoff_decision(
            {
                "maximum_abs_joint_error_rad": 0.02513,
                "tcp_error_xyz_mm": [0.347, -5.096, -3.970],
                "tcp_error_norm_mm": 6.469,
            },
            [-0.087526, -0.059009, 0.994413],
            handoff_config,
        )
        self.assertTrue(decision["allowed"])
        self.assertTrue(decision["handoff_only_to_final_vision_gate"])
        self.assertFalse(decision["authorizes_descent"])
        self.assertLessEqual(
            abs(decision["signed_support_normal_error_mm"]), 5.0
        )

    def test_endpoint_handoff_rejects_joint_or_support_normal_overrun(self):
        handoff_config = self.config()["adaptive_secure_no_lift"][
            "alignment_endpoint_vision_handoff"
        ]
        joint_reject = endpoint_vision_handoff_decision(
            {
                "maximum_abs_joint_error_rad": 0.0271,
                "tcp_error_xyz_mm": [1.0, 1.0, 1.0],
                "tcp_error_norm_mm": 3.0,
            },
            [0.0, 0.0, 1.0],
            handoff_config,
        )
        normal_reject = endpoint_vision_handoff_decision(
            {
                "maximum_abs_joint_error_rad": 0.025,
                "tcp_error_xyz_mm": [0.0, 0.0, -5.1],
                "tcp_error_norm_mm": 5.1,
            },
            [0.0, 0.0, 1.0],
            handoff_config,
        )
        self.assertFalse(joint_reject["allowed"])
        self.assertIn("joint_error_too_large", joint_reject["reasons"])
        self.assertFalse(normal_reject["allowed"])
        self.assertIn(
            "support_normal_error_too_large", normal_reject["reasons"]
        )

    def test_endpoint_convergence_handoff_still_requires_final_vision(self):
        handoff_config = self.config()["adaptive_secure_no_lift"][
            "alignment_endpoint_vision_handoff"
        ]
        endpoint_config = {
            "success_joint_error_rad": 0.012,
            "fallback_success_joint_error_rad": 0.020,
            "maximum_initial_joint_error_rad": 0.05,
            "bias_step_rad": 0.004,
            "maximum_bias_rad": 0.024,
            "maximum_attempts": 0,
            "hold_seconds": 0.5,
            "collision_step_rad": 0.01,
            "minimum_joint_margin_deg": 10.0,
            "validated_workspace": {
                "tcp_base_x_mm": [-100.0, 100.0],
                "tcp_base_y_mm": [-100.0, 100.0],
                "normal_clearance_mm": [-100.0, 100.0],
            },
        }
        measured_q = [0.000347, -0.005096, -0.003970, 0.0, 0.0, 0.02513]
        with patch(
            "scripts.run_go2_visual_alignment.sample_endpoint_hold",
            return_value=measured_q,
        ), patch(
            "scripts.run_go2_visual_alignment.validate_workspace_point"
        ):
            result = converge_observation_endpoint(
                object(),
                [0.0] * 6,
                endpoint_config=endpoint_config,
                kinematics=LinearKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                support_up_normal_base=[0.0, 0.0, 1.0],
                compensation_scale=1.0,
                torque_limits=[1.0] * 6,
                vision_handoff_config=handoff_config,
                vision_handoff_support_up_normal_base=[0.0, 0.0, 1.0],
                label_prefix="test_endpoint",
            )
        self.assertEqual(result["status"], "passed_to_final_vision_gate_only")
        self.assertFalse(result["authorizes_descent"])
        self.assertTrue(result["vision_handoff"]["allowed"])

    def test_bound_adaptive_resources_are_compatible(self):
        config = self.config()["adaptive_secure_no_lift"]
        config_path, baseline_path, parameters, baseline = (
            load_bound_adaptive_grasp_resources(config)
        )
        self.assertEqual(config_path, PROJECT_ROOT / "config/adaptive_grasp.yaml")
        self.assertEqual(
            baseline_path,
            PROJECT_ROOT / "data/adaptive_grasp/empty_baseline.json",
        )
        baseline.assert_compatible(parameters)

    def test_contact_runner_uses_active_tilt_position_commander(self):
        hold_q = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]

        class FakeArm:
            def __init__(self):
                self.commanded = []

            def command_position(self, q):
                self.commanded.append(list(q))

            def get_pos(self):
                return hold_q + [1.2647]

            def get_vel(self):
                return [0.0] * 7

            def get_tau(self):
                return [0.0] * 7

            def get_temp(self):
                return [25.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

        class FakeGripper:
            def command_mm(self, *_args, **_kwargs):
                return None

            def gap_from_fb(self, _feedback):
                return 65.0

        arm = FakeArm()
        parameters = SimpleNamespace(
            max_joint_hold_error_rad=0.08,
            max_temperature_c=50.0,
        )
        runner = BenchRunner(arm, FakeGripper(), hold_q, parameters)
        runner.tick(65.0, 0.3, "test")
        self.assertEqual(arm.commanded, [hold_q])

    def test_height_handoff_converts_support_clearance_to_top_reference(self):
        secure = self.config()["adaptive_secure_no_lift"]
        effective, handoff = resolve_adaptive_secure_no_lift_config(
            self.final_capture(), secure
        )
        self.assertAlmostEqual(
            handoff["target_support_plane_tcp_clearance_mm"], 9.4
        )
        self.assertAlmostEqual(
            handoff["target_top_clearance_mm"],
            9.4 - 51.85727233886719,
        )
        self.assertAlmostEqual(
            effective["target_normal_clearance_mm"],
            handoff["target_top_clearance_mm"],
        )
        self.assertFalse(handoff["lift_allowed"])

    def test_low_plan_stops_at_bound_support_plane_clearance(self):
        secure, handoff = resolve_adaptive_secure_no_lift_config(
            self.final_capture(50.0),
            self.config()["adaptive_secure_no_lift"],
        )
        observation = {
            "surface_point_base_m": [0.0, 0.0, 0.0],
            "support_up_normal_base": [0.0, 0.0, 1.0],
        }

        def fake_ik(_kin, q_start, tcp_targets, **_kwargs):
            return {
                "joint_path": [list(q_start)]
                + [
                    [pose[0], pose[1], pose[2], 0.0, 0.0, 0.0]
                    for pose in tcp_targets
                ],
                "status": "fake_ok",
            }

        with patch(
            "scripts.run_go2_visual_alignment.solve_continuous_ik_path",
            side_effect=fake_ik,
        ), patch(
            "scripts.run_go2_visual_alignment.check_collision_path",
            return_value={"sample_count": 30},
        ), patch(
            "scripts.run_go2_visual_alignment.validate_torque_envelope",
            return_value={"maximum_limit_fraction": 0.96},
        ):
            plan = compute_safe_descent_plan(
                [0.0, 0.0, 0.020, 0.0, 0.0, 0.0],
                observation,
                descent_config=secure,
                alignment={
                    "maximum_fk_position_error_mm": 1.0,
                    "maximum_fk_orientation_error_deg": 0.5,
                },
                tcp_kinematics=LinearKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                applied_support_up=[0.0, 0.0, 1.0],
                side_scale=0.95,
                torque_limits=[1.0] * 6,
            )
        self.assertAlmostEqual(plan["initial_normal_clearance_mm"], 20.0)
        self.assertAlmostEqual(plan["target_normal_clearance_mm"], -40.6)
        self.assertAlmostEqual(plan["descent_distance_mm"], 60.6)
        self.assertEqual(plan["segment_count"], 13)
        self.assertAlmostEqual(
            plan["target_normal_clearance_mm"] + handoff["target_height_mm"],
            9.4,
        )

    def test_real_pregrasp_v1_low_path_collision_and_torque_replay_when_present(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))
        run_path = (
            PROJECT_ROOT
            / "data/go2_visual_alignment_runs"
            / "new_s1_go2_nocw_metalbracket_adaptive_pregrasp_v1"
            / "run.json"
        )
        if not run_path.is_file():
            self.skipTest("successful adaptive pregrasp replay is not present")
        run = json.loads(run_path.read_text(encoding="utf-8"))
        self.assertEqual(
            run["status"], "VISUAL_ALIGN_ADAPTIVE_PREGRASP_ROUND_TRIP_DONE"
        )
        config = self.config()
        secure, handoff = resolve_adaptive_secure_no_lift_config(
            run["final_capture"], config["adaptive_secure_no_lift"]
        )
        mount = json.loads(
            (
                PROJECT_ROOT
                / "config/go2_crouch_mount_nocw_metalbracket_measured_v1.json"
            ).read_text(encoding="utf-8")
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(
            float(mount["mount_measurement"]["rear_edge_lower_deg"])
        ) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up,
            run["final_observation"]["support_up_normal_base"],
            0.5,
        )
        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        plan = compute_safe_descent_plan(
            run["adaptive_pregrasp"]["endpoint"]["measured_q_rad"],
            run["final_observation"],
            descent_config=secure,
            alignment=config["alignment"],
            tcp_kinematics=Kinematics(verbose=False),
            collision_checker=checker,
            tilt_model=model,
            applied_support_up=applied_support_up,
            side_scale=float(secure["low_stage_compensation_scale"]),
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertEqual(plan["collision"]["active_collision_count"], 0)
        self.assertEqual(plan["collision"]["floor_contact_count"], 0)
        self.assertLess(plan["torque"]["maximum_limit_fraction"], 1.0)
        self.assertAlmostEqual(
            plan["target_normal_clearance_mm"] + handoff["target_height_mm"],
            9.4,
        )

    def test_v5_high_to_pregrasp_path_uses_local_scale_when_present(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))
        run_path = (
            PROJECT_ROOT
            / "data/go2_visual_alignment_runs"
            / "new_s1_go2_adaptive_secure_no_lift_v5"
            / "run.json"
        )
        if not run_path.is_file():
            self.skipTest("v5 torque-cap replay is not present")
        run = json.loads(run_path.read_text(encoding="utf-8"))
        config = self.config()
        pregrasp, _ = resolve_adaptive_pregrasp_config(
            run["final_capture"], config["adaptive_pregrasp"]
        )
        secure = config["adaptive_secure_no_lift"]
        mount = json.loads(
            (
                PROJECT_ROOT
                / "config/go2_crouch_mount_nocw_metalbracket_measured_v1.json"
            ).read_text(encoding="utf-8")
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(
            float(mount["mount_measurement"]["rear_edge_lower_deg"])
        ) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up,
            run["final_observation"]["support_up_normal_base"],
            0.5,
        )
        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        plan = compute_safe_descent_plan(
            run["final_q_rad"],
            run["final_observation"],
            descent_config=pregrasp,
            alignment=config["alignment"],
            tcp_kinematics=Kinematics(verbose=False),
            collision_checker=checker,
            tilt_model=model,
            applied_support_up=applied_support_up,
            side_scale=float(secure["pregrasp_descent_compensation_scale"]),
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertEqual(plan["collision"]["active_collision_count"], 0)
        self.assertEqual(plan["collision"]["floor_contact_count"], 0)
        self.assertLess(plan["torque"]["maximum_limit_fraction"], 0.95)
        self.assertGreater(plan["torque"]["maximum_limit_fraction"], 0.90)

    def test_v8_low_contact_path_uses_reduced_scale_when_present(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))
        run_path = (
            PROJECT_ROOT
            / "data/go2_visual_alignment_runs"
            / "new_s1_go2_adaptive_secure_no_lift_v8"
            / "run.json"
        )
        if not run_path.is_file():
            self.skipTest("v8 measured pregrasp endpoint replay is not present")
        run = json.loads(run_path.read_text(encoding="utf-8"))
        config = self.config()
        secure, handoff = resolve_adaptive_secure_no_lift_config(
            run["final_capture"], config["adaptive_secure_no_lift"]
        )
        mount = json.loads(
            (
                PROJECT_ROOT
                / "config/go2_crouch_mount_nocw_metalbracket_measured_v1.json"
            ).read_text(encoding="utf-8")
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(
            float(mount["mount_measurement"]["rear_edge_lower_deg"])
        ) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up,
            run["final_observation"]["support_up_normal_base"],
            0.5,
        )
        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        plan = compute_safe_descent_plan(
            run["adaptive_pregrasp"]["endpoint"]["measured_q_rad"],
            run["final_observation"],
            descent_config=secure,
            alignment=config["alignment"],
            tcp_kinematics=Kinematics(verbose=False),
            collision_checker=checker,
            tilt_model=model,
            applied_support_up=applied_support_up,
            side_scale=float(secure["low_stage_compensation_scale"]),
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertEqual(plan["collision"]["active_collision_count"], 0)
        self.assertEqual(plan["collision"]["floor_contact_count"], 0)
        self.assertGreater(plan["torque"]["maximum_limit_fraction"], 0.94)
        self.assertLess(plan["torque"]["maximum_limit_fraction"], 0.95)
        self.assertAlmostEqual(
            plan["target_normal_clearance_mm"] + handoff["target_height_mm"],
            9.4,
        )


if __name__ == "__main__":
    unittest.main()
