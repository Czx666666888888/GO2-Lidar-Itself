"""Effective J2/J3 allowances in the current complete-flow configuration."""
import copy
import unittest
from pathlib import Path
from scripts.run_go2_visual_alignment import apply_local_j2_tilt_limit,apply_local_j3_tilt_limit,load_alignment_config

class LocalJ2LimitTests(unittest.TestCase):
    def test_current_configuration_applies_both_joint_allowances_without_mutating_bound_mount(self):
        root=Path(__file__).resolve().parents[1]
        _,cfg=load_alignment_config(root/'config/go2_dual_white_light_full_flow_simplified_v1.json')
        original={'diagnostic':{'correction_absolute_limits_nm':[1.2,.2,.2,.2,.2,.1]}}
        before=copy.deepcopy(original)
        mount,j3=apply_local_j3_tilt_limit(original,cfg['runtime'])
        mount,j2=apply_local_j2_tilt_limit(mount,cfg['runtime'])
        self.assertEqual(mount['diagnostic']['correction_absolute_limits_nm'],[1.2,.3,.25,.2,.2,.1])
        self.assertEqual(original,before)
        self.assertEqual(j2['original_limit_nm'],.2)
        self.assertEqual(j2['applied_limit_nm'],.3)
        self.assertFalse(j2['global_mount_file_modified'])
        self.assertEqual(j3['applied_limit_nm'],.25)

    def test_profiles_without_j2_override_keep_their_mount_record(self):
        mount={'diagnostic':{'correction_absolute_limits_nm':[1.2,.2,.25,.2,.2,.1]}}
        unchanged,report=apply_local_j2_tilt_limit(mount,{})
        self.assertIs(unchanged,mount);self.assertIsNone(report)

if __name__=='__main__':unittest.main()
