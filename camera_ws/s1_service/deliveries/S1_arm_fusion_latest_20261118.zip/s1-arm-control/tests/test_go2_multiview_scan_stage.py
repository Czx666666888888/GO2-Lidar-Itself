#!/usr/bin/env python3
"""Offline regression checks for the Go2 multi-view scan executor."""
from importlib.machinery import SourceFileLoader
import os
from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parents[1]
module_file = os.environ.get(
    "GO2_MULTIVIEW_SCAN_MODULE", "run_go2_multiview_scan.py"
)
module = SourceFileLoader(
    "go2_multiview_scan",
    str(root / "scripts" / module_file),
).load_module()

plan_path = (
    root
    / "data"
    / "plans"
    / "go2_right_multiview_observation_scan_candidate_v1.json"
)
report_path = (
    root
    / "data"
    / "plans"
    / "go2_right_multiview_observation_scan_collision_report_v1.json"
)
plan, report = module.verify_scan_artifacts(plan_path, report_path)

assert report["source_plan_sha256"] == module.file_sha256(plan_path)
assert len(plan["selected_views"]) == 4
assert len(plan["covered_point_ids"]) == 36
assert plan["uncovered_point_ids"] == []
assert plan["selected_views"][0]["name"] == "view_up000_vp000_np000"

scan = module.load_json(module.resolve_project_path(plan["workspace_scan"]))
baseline_mm = scan["baseline"]["target_top_base_xyz_mm"]
coordinates = module.target_coordinates(
    {"surface_point_base_m": [value / 1000.0 for value in baseline_mm]},
    scan,
)
assert abs(coordinates["u_mm"]) < 1e-9
assert abs(coordinates["v_mm"]) < 1e-9
assert coordinates["classification"] == "inside_nearest_40mm_candidate_cell"

assert module.detection_accepted(
    {"detection": {"status": "DETECTED", "selected": {"accepted": True}}}
)
assert not module.detection_accepted(
    {"detection": {"status": "NO_TARGET", "selected": None}}
)
assert not module.detection_accepted(
    {"detection": {"status": "DETECTED", "selected": {"accepted": False}}}
)

loaded = module.load_wrist_servo_config(
    module.resolve_project_path(plan["wrist_config"])
)
flange_kinematics = module.Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
hub_q = plan["hub"]["q_rad"]
transform_base_camera = module.dynamic_base_camera(
    flange_kinematics.fk(hub_q),
    loaded.transform_flange_camera,
)
planned_support_up = np.asarray(
    scan["support_plane_frame"]["support_up_normal_base"], dtype=float
)
normal_camera = transform_base_camera[:3, :3].T @ planned_support_up
plane_capture = {
    "capture_metadata": {"quality_pass": True},
    "detection": {
        "status": "NO_TARGET",
        "plane": {
            "normal_cam": normal_camera.tolist(),
            "quality_pass": True,
            "rmse_mm": 0.4,
            "inlier_ratio": 1.0,
            "sample_count": 8000,
        },
    },
}
support_plane = module.validated_support_plane_from_capture(
    plane_capture,
    hub_q,
    loaded=loaded,
    flange_kinematics=flange_kinematics,
    planned_support_up=planned_support_up,
)
assert support_plane["deviation_from_planning_deg"] < 1e-6

bad_capture = {
    "capture_metadata": {"quality_pass": True},
    "detection": {"status": "NO_TARGET", "plane": {"quality_pass": False}},
}
try:
    module.validated_support_plane_from_capture(
        bad_capture,
        hub_q,
        loaded=loaded,
        flange_kinematics=flange_kinematics,
        planned_support_up=planned_support_up,
    )
except ValueError as exc:
    assert "support-plane quality gate failed" in str(exc)
else:
    raise AssertionError("invalid support plane was accepted")

mount = module.load_json(module.resolve_project_path(plan["mount_config"]))
tilt_model = module.UrdfGravityModel.from_file(
    module.locate_official_gripper_urdf()
)
actual_first_run_support_up = [
    -0.09894977680154217,
    -0.030418251999178976,
    0.994627403411066,
]
adaptive_scale = module.select_path_compensation_scale(
    tilt_model,
    plan["selected_views"][1]["path_from_hub_q_rad"],
    actual_first_run_support_up,
    mount["diagnostic"]["correction_absolute_limits_nm"],
    mount["diagnostic"]["allowed_scale_steps"],
)
assert adaptive_scale["selected_scale"] == 0.75
assert adaptive_scale["evaluations"][0]["scale"] == 1.0
assert adaptive_scale["evaluations"][0]["pass"] is False
assert adaptive_scale["selected_evaluation"]["maximum_torque_fraction"] < 0.90

for view in plan["selected_views"]:
    path = view["path_from_hub_q_rad"]
    assert len(path) >= 2
    assert len(path[0]) == 6
    assert len(path[-1]) == 6
    assert view["collision_sample_count"] > 0
    assert view["go2_envelope_sample_count"] > 0
    assert view["maximum_torque_fraction"] < 1.0

print("GO2_MULTIVIEW_SCAN_STAGE_TEST_OK")
print("SELECTED_VIEWS =", [view["name"] for view in plan["selected_views"]])
print("COVERAGE =", len(plan["covered_point_ids"]), "/", len(plan["universe_point_ids"]))
