import ast
import importlib.util
import math
from pathlib import Path
import sys
import tempfile
import time
import unittest

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.hand_eye import (
    fixed_reference_residuals,
    fixed_target_residuals,
    invert_transform,
    pose_xyz_quat_to_transform,
    refine_hand_eye,
    rotation_angle_deg,
    sample_motion_diversity,
    solve_hand_eye,
    validate_transform,
)


def rotation_xyz_deg(rx, ry, rz):
    x, y, z = [math.radians(value) for value in (rx, ry, rz)]
    Rx = np.array(
        [[1, 0, 0], [0, math.cos(x), -math.sin(x)], [0, math.sin(x), math.cos(x)]],
        dtype=float,
    )
    Ry = np.array(
        [[math.cos(y), 0, math.sin(y)], [0, 1, 0], [-math.sin(y), 0, math.cos(y)]],
        dtype=float,
    )
    Rz = np.array(
        [[math.cos(z), -math.sin(z), 0], [math.sin(z), math.cos(z), 0], [0, 0, 1]],
        dtype=float,
    )
    return Rz @ Ry @ Rx


def make_transform(xyz, rpy_deg):
    result = np.eye(4)
    result[:3, :3] = rotation_xyz_deg(*rpy_deg)
    result[:3, 3] = xyz
    return result


def synthetic_samples():
    flange_camera = make_transform([0.035, -0.018, 0.092], [8.0, -12.0, 4.0])
    base_target = make_transform([0.42, -0.06, 0.11], [5.0, 2.0, -7.0])
    specifications = [
        ([0.12, -0.20, 0.28], [-25, -18, -20]),
        ([0.16, -0.14, 0.33], [-18, 12, -8]),
        ([0.20, -0.08, 0.30], [15, -20, 10]),
        ([0.24, -0.02, 0.35], [22, 15, 18]),
        ([0.28, 0.04, 0.31], [-12, 24, 25]),
        ([0.30, 0.10, 0.37], [28, -8, -25]),
        ([0.22, 0.16, 0.34], [-30, 10, 20]),
        ([0.14, 0.12, 0.29], [10, 28, -15]),
        ([0.10, 0.04, 0.36], [26, 20, 5]),
        ([0.18, -0.18, 0.39], [-20, -25, 22]),
        ([0.26, -0.12, 0.27], [8, 30, -22]),
        ([0.32, 0.02, 0.33], [-28, 5, 28]),
        ([0.27, 0.14, 0.28], [18, -28, -4]),
        ([0.19, 0.18, 0.38], [-8, 18, 30]),
        ([0.11, -0.02, 0.32], [30, 2, -28]),
        ([0.23, 0.08, 0.40], [-22, 26, 12]),
    ]
    base_flange = [make_transform(xyz, angles) for xyz, angles in specifications]
    camera_target = [
        invert_transform(base @ flange_camera) @ base_target for base in base_flange
    ]
    return flange_camera, base_target, base_flange, camera_target


class HandEyeGeometryTests(unittest.TestCase):
    @staticmethod
    def load_capture_module():
        source_path = PROJECT_ROOT / "scripts" / "capture_eye_in_hand.py"
        spec = importlib.util.spec_from_file_location(
            "capture_eye_in_hand_for_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_capture_parser_uses_csv_and_rejects_arm_serial_options(self):
        module = self.load_capture_module()
        args = module.build_parser().parse_args(
            [
                "collect",
                "--session",
                "test_session",
                "--live-preview",
            ]
        )
        self.assertTrue(args.live_preview)
        self.assertEqual(args.pose_source_type, "official-teaching-csv")
        pose_csv = Path(args.pose_csv)
        self.assertEqual(pose_csv.name, "data.csv")
        self.assertEqual(pose_csv.parent.name, "python")
        tilt_args = module.build_parser().parse_args(
            [
                "collect",
                "--session",
                "tilt_session",
                "--pose-source-type",
                "tilt-locked-csv",
                "--pose-csv",
                "/tmp/tilt_session.csv",
            ]
        )
        self.assertEqual(tilt_args.pose_source_type, "tilt-locked-csv")
        with self.assertRaises(SystemExit):
            module.build_parser().parse_args(
                [
                    "collect",
                    "--session",
                    "test_session",
                    "--allow-active-teach",
                ]
            )
        with self.assertRaises(SystemExit):
            module.build_parser().parse_args(
                ["collect", "--session", "test_session", "--dev", "/dev/ttyUSB0"]
            )

    def test_capture_script_contains_no_robot_interface_access(self):
        source_path = PROJECT_ROOT / "scripts" / "capture_eye_in_hand.py"
        source = source_path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        forbidden = {
            "enable",
            "disable",
            "get_pos",
            "move",
            "move_waypoints",
            "joint_control",
            "joint_control_mit",
            "control_pos",
            "control_pos_vel",
            "control_foc",
        }
        calls = {
            node.func.attr
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
        }
        self.assertEqual(calls & forbidden, set())
        self.assertNotIn("s1_control.arm", source)

    def test_official_teaching_csv_tail_and_freshness(self):
        module = self.load_capture_module()
        now = time.time()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "data.csv"
            rows = ["time,1,2,3,4,5,6,7,1,2,3,4,5,6"]
            for index in range(8):
                timestamp = now - 0.07 + index * 0.01
                values = [timestamp, *[0.1 * index + joint for joint in range(7)], *([0.0] * 6)]
                rows.append(",".join(str(value) for value in values))
            path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            records = module.read_teaching_csv_tail(path, 4)
            self.assertEqual(len(records), 4)
            self.assertAlmostEqual(records[-1]["state"][0], 0.7)
            self.assertIsNone(records[-1]["source_state"])
            freshness = module.validate_teaching_csv_freshness(
                records, now_s=now + 0.01, maximum_age_s=0.25
            )
            self.assertLess(freshness["newest_age_s"], 0.02)

    def test_tilt_locked_csv_state_gate(self):
        module = self.load_capture_module()
        now = time.time()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tilt.csv"
            rows = ["time,q1,q2,q3,q4,q5,q6,gripper,source_state"]
            for index, state in enumerate(("locked", "locked", "locked", "locking")):
                values = [now + 0.01 * index, *([0.1 * index] * 7), state]
                rows.append(",".join(str(value) for value in values))
            path.write_text("\n".join(rows) + "\n", encoding="utf-8")

            records = module.read_teaching_csv_tail(path, 4)
            self.assertEqual(records[0]["source_state"], "locked")
            self.assertEqual(records[-1]["source_state"], "locking")
            self.assertEqual(
                module.pose_source_state_reasons(
                    records[:3], "tilt-locked-csv"
                ),
                [],
            )
            reasons = module.pose_source_state_reasons(
                records, "tilt-locked-csv"
            )
            self.assertEqual(len(reasons), 1)
            self.assertIn("locking", reasons[0])
            self.assertEqual(
                module.pose_source_state_reasons(
                    records, "official-teaching-csv"
                ),
                [],
            )

    def test_stale_teaching_csv_is_rejected(self):
        module = self.load_capture_module()
        records = [
            {"timestamp_s": 1.0, "state": [0.0] * 7},
            {"timestamp_s": 1.1, "state": [0.0] * 7},
        ]
        with self.assertRaisesRegex(RuntimeError, "已停止或过旧"):
            module.validate_teaching_csv_freshness(
                records, now_s=2.0, maximum_age_s=0.25
            )

    def test_pose_and_inverse_round_trip(self):
        transform = pose_xyz_quat_to_transform(
            [0.1, -0.2, 0.3, 0.0, 0.0, math.sin(math.pi / 8), math.cos(math.pi / 8)]
        )
        self.assertTrue(np.allclose(transform @ invert_transform(transform), np.eye(4)))
        self.assertAlmostEqual(rotation_angle_deg(transform[:3, :3]), 45.0, places=7)

    def test_invalid_reflection_is_rejected(self):
        reflection = np.eye(4)
        reflection[0, 0] = -1.0
        with self.assertRaisesRegex(ValueError, "determinant"):
            validate_transform(reflection)

    def test_fixed_target_residual_is_zero_for_true_transform(self):
        flange_camera, base_target, base_flange, camera_target = synthetic_samples()
        estimated, details, summary = fixed_target_residuals(
            base_flange, camera_target, flange_camera
        )
        self.assertTrue(np.allclose(estimated, base_target, atol=1e-10))
        self.assertLess(summary.translation_max_mm, 1e-8)
        self.assertLess(summary.rotation_max_deg, 1e-6)
        self.assertEqual(len(details), len(base_flange))

    def test_holdout_residual_uses_given_reference_without_refitting(self):
        flange_camera, base_target, base_flange, camera_target = synthetic_samples()
        details, summary = fixed_reference_residuals(
            base_flange,
            camera_target,
            flange_camera,
            base_target,
        )
        self.assertLess(summary.translation_max_mm, 1e-8)
        self.assertLess(summary.rotation_max_deg, 1e-6)
        self.assertEqual(len(details), len(base_flange))

        shifted_reference = base_target.copy()
        shifted_reference[0, 3] += 0.010
        _, shifted_summary = fixed_reference_residuals(
            base_flange,
            camera_target,
            flange_camera,
            shifted_reference,
        )
        self.assertAlmostEqual(shifted_summary.translation_rms_mm, 10.0, places=7)

    def test_motion_diversity_reports_large_spans(self):
        _, _, base_flange, _ = synthetic_samples()
        diversity = sample_motion_diversity(base_flange)
        self.assertGreater(diversity["maximum_pairwise_rotation_deg"], 25.0)
        self.assertGreater(diversity["maximum_pairwise_translation_mm"], 80.0)
        self.assertGreater(diversity["informative_rotation_pair_count"], 8)

    def test_opencv_solver_recovers_transform_and_convention(self):
        try:
            import cv2
        except ImportError:
            self.skipTest("OpenCV unavailable")
        if not hasattr(cv2, "calibrateHandEye"):
            self.skipTest("OpenCV build has no calibrateHandEye; use S1-calib")
        truth, _, base_flange, camera_target = synthetic_samples()
        solved = solve_hand_eye(base_flange, camera_target, method_name="PARK")
        delta = invert_transform(truth) @ solved
        self.assertLess(1000.0 * np.linalg.norm(delta[:3, 3]), 1e-4)
        self.assertLess(rotation_angle_deg(delta[:3, :3]), 1e-5)

    def test_joint_refinement_recovers_truth_from_perturbed_initial_guess(self):
        truth, _, base_flange, camera_target = synthetic_samples()
        perturbation = make_transform([0.012, -0.007, 0.009], [1.2, -0.8, 0.6])
        initial = truth @ perturbation
        refined, base_target, diagnostics = refine_hand_eye(
            base_flange,
            camera_target,
            initial,
            rotation_weight_m_per_rad=0.5,
            maximum_iterations=60,
        )
        delta = invert_transform(truth) @ refined
        self.assertLess(1000.0 * np.linalg.norm(delta[:3, 3]), 1e-4)
        self.assertLess(rotation_angle_deg(delta[:3, :3]), 1e-5)
        self.assertTrue(diagnostics["converged"])
        self.assertGreater(diagnostics["objective_improvement_m2"], 0.0)
        expected_base_target = make_transform([0.42, -0.06, 0.11], [5.0, 2.0, -7.0])
        target_delta = invert_transform(expected_base_target) @ base_target
        self.assertLess(1000.0 * np.linalg.norm(target_delta[:3, 3]), 1e-4)
        self.assertLess(rotation_angle_deg(target_delta[:3, :3]), 1e-4)

    def test_joint_refinement_rejects_invalid_arguments(self):
        truth, _, base_flange, camera_target = synthetic_samples()
        with self.assertRaisesRegex(ValueError, "positive and finite"):
            refine_hand_eye(
                base_flange,
                camera_target,
                truth,
                rotation_weight_m_per_rad=0.0,
            )
        with self.assertRaisesRegex(ValueError, "at least 3"):
            refine_hand_eye(
                base_flange[:2],
                camera_target[:2],
                truth,
            )


if __name__ == "__main__":
    unittest.main()
