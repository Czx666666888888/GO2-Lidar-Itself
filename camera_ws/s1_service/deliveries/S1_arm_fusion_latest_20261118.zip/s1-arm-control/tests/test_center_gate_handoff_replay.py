import json
import unittest
import numpy as np
from run_go2_visual_alignment import (
    PROJECT_ROOT, load_alignment_config, resolve_project_path,
    compute_safe_descent_plan, compute_oriented_pregrasp_plan,
    resolve_adaptive_secure_no_lift_config, densify_joint_path,
    UrdfGravityModel, locate_official_gripper_urdf)
from plan_go2_multiview_scan import go2_envelope_check
from s1_control.kinematics import Kinematics
from S1_SDK.hardware.collision import CollisionChecker

class CenterGateHandoffReplayTests(unittest.TestCase):
    def test_latest_failed_high_view_residual_has_checked_centering_descent(self):
        run=PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261118-190456"
        d=json.loads((run/"run.json").read_text())
        _,cfg=load_alignment_config(d["config"])
        deployment=json.loads(resolve_project_path(cfg["deployment_plan"]).read_text())
        source=json.loads(resolve_project_path(deployment["source_config"]).read_text())
        mount=json.loads(resolve_project_path(deployment["mount_config"]).read_text())
        cc=CollisionChecker("gripper")
        if cc.model is None:cc._load_model(gripper=True)
        kin=Kinematics(verbose=False)
        def body(path):
            r=go2_envelope_check(cc,densify_joint_path(path,.005),source)
            self.assertTrue(r["pass"])
            return r
        observation=d["final_observation"]
        old={"start_q_rad":d["final_q_rad"],"target_normal_clearance_mm":20.0, "support_up_normal_base":observation["support_up_normal_base"]}
        desc=dict(cfg["adaptive_pregrasp"],target_normal_clearance_mm=old["target_normal_clearance_mm"])
        common=dict(alignment=cfg["alignment"],tcp_kinematics=kin,collision_checker=cc,
            tilt_model=UrdfGravityModel.from_file(locate_official_gripper_urdf()),
            applied_support_up=old["support_up_normal_base"],side_scale=0,
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"])
        high=compute_oriented_pregrasp_plan(old["start_q_rad"],observation,
            orientation_config=cfg["adaptive_grasp_orientation"],check_body=body,
            descent_config=desc,**common)
        n=np.array(observation["support_up_normal_base"]);n/=np.linalg.norm(n)
        delta=np.array(kin.fk(high["joint_path"][-1])[:3])-np.array(observation["surface_point_base_m"])
        lateral=float(np.linalg.norm(delta-n*np.dot(delta,n))*1000)
        self.assertGreater(d["final_check"]["initial_tangent_error_norm_mm"],5)
        self.assertLess(lateral,.01)
        print("LATEST_HIGH_VIEW_HANDOFF",d["final_check"]["initial_tangent_error_norm_mm"],lateral)
