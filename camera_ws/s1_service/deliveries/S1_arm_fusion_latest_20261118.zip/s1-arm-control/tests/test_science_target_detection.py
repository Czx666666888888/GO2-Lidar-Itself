# -*- coding: utf-8 -*-
"""离线science_target RGB-D检测回归测试；不访问相机、串口或机械臂。"""
import importlib.util
import json
import math
import unittest
from pathlib import Path

import numpy as np


MODULE_PATH = (
    Path(__file__).resolve().parents[1]
    / "demo_grasp"
    / "detect_science_target_rgbd.py"
)
SPEC = importlib.util.spec_from_file_location("science_target_detection", MODULE_PATH)
detection = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(detection)


def test_config():
    return {
        "input": {"require_capture_quality_pass": True},
        "workspace_roi": {"normalized_xyxy": [0.10, 0.10, 0.90, 0.90]},
        "plane": {
            "min_depth_m": 0.2,
            "max_depth_m": 2.0,
            "min_valid_points": 500,
            "sample_cap": 5000,
            "random_seed": 7,
            "ransac_iterations": 120,
            "ransac_inlier_threshold_mm": 2.0,
            "min_inlier_ratio": 0.80,
            "good_rmse_mm": 0.2,
            "max_rmse_mm": 2.0,
            "max_tilt_deg": 20.0,
        },
        "foreground": {
            "min_height_mm": 10.0,
            "max_height_mm": 80.0,
            "open_iterations": 0,
        },
        "component": {
            "min_area_px": 50,
            "max_area_px": 2000,
            "min_bbox_side_px": 6,
            "max_bbox_side_px": 60,
            "max_aspect_ratio": 1.8,
            "min_fill_ratio": 0.40,
            "good_fill_ratio": 0.70,
            "reject_roi_border_px": 1,
            "core_erode_fraction": 0.15,
            "core_erode_min_px": 2,
            "core_erode_max_px": 3,
            "min_core_pixels": 20,
            "min_core_depth_valid_ratio": 0.90,
        },
        "orientation": {
            "min_points": 40,
            "bootstrap_samples": 16,
            "bootstrap_fraction": 0.80,
            "random_seed": 13,
            "max_rectangle_aspect_ratio": 1.35,
            "min_rectangularity": 0.65,
            "min_angular_concentration": 0.80,
            "max_p90_deviation_deg": 8.0,
            "min_confidence_score": 0.75,
            "small_sample": {
                "max_points": 300,
                "max_p90_deviation_deg": 10.0,
                "min_confidence_score": 0.70,
            },
        },
        "target": {
            "min_core_height_mm": 15.0,
            "good_core_height_mm": 20.0,
            "max_core_height_mm": 65.0,
            "min_confidence_score": 0.72,
        },
    }


def scene(rectangles=()):
    height, width = 120, 160
    rgb = np.zeros((height, width, 3), dtype=np.uint8)
    rgb[:, :] = [20, 150, 150]
    depth = np.ones((height, width), dtype=np.float32)
    for x0, y0, x1, y1, depth_m in rectangles:
        depth[y0:y1, x0:x1] = depth_m
        rgb[y0:y1, x0:x1] = [40, 190, 190]
    K = np.array(
        [[120.0, 0.0, 80.0], [0.0, 120.0, 60.0], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    return rgb, depth, K


def rotated_square_scene(angle_deg, side_px=28):
    import cv2

    rgb, depth, K = scene()
    rectangle = ((80.0, 60.0), (float(side_px), float(side_px)), angle_deg)
    box = np.rint(cv2.boxPoints(rectangle)).astype(np.int32)
    cv2.fillConvexPoly(depth, box, 0.96)
    cv2.fillConvexPoly(rgb, box, (40, 190, 190))
    return rgb, depth, K


def rotated_square_with_invalid_fringe_scene(
    angle_deg,
    side_px=28,
    central_hole_px=0,
):
    """Synthetic rotated top with invalid depth around/optionally inside it."""
    import cv2

    rgb, depth, K = scene()
    rectangle = ((80.0, 60.0), (float(side_px), float(side_px)), angle_deg)
    box = np.rint(cv2.boxPoints(rectangle)).astype(np.int32)
    target_mask = np.zeros_like(depth, dtype=np.uint8)
    cv2.fillConvexPoly(target_mask, box, 1)
    x, y, width, height = cv2.boundingRect(box)
    fringe = np.zeros_like(target_mask)
    fringe[y : y + height, x : x + width] = 1
    fringe[target_mask.astype(bool)] = 0
    depth[fringe.astype(bool)] = 0.0
    depth[target_mask.astype(bool)] = 0.96
    rgb[target_mask.astype(bool)] = [40, 190, 190]
    if central_hole_px > 0:
        half = central_hole_px // 2
        depth[60 - half : 60 + half, 80 - half : 80 + half] = 0.0
    return rgb, depth, K


def undirected_angle_mod90_deg(axis_cam):
    angle = math.degrees(math.atan2(axis_cam[1], axis_cam[0])) % 90.0
    return angle


def angle_error_mod90_deg(actual, expected):
    difference = abs(actual - expected) % 90.0
    return min(difference, 90.0 - difference)


class ScienceTargetDetectionTests(unittest.TestCase):
    def detect(self, rectangles=(), quality=True):
        rgb, depth, K = scene(rectangles)
        return detection.detect_from_arrays(
            rgb,
            depth,
            K,
            {"quality_pass": quality},
            test_config(),
            source="synthetic",
        )

    def test_one_square_target_is_detected_in_camera_frame_only(self):
        result = self.detect([(65, 45, 85, 65, 0.96)])
        self.assertEqual(result["schema_version"], 2)
        self.assertEqual(result["status"], "DETECTED_CAMERA_FRAME_ONLY")
        self.assertFalse(result["control_ready"])
        self.assertTrue(result["camera_frame_only"])
        self.assertEqual(result["accepted_candidate_count"], 1)
        selected = result["selected"]
        self.assertEqual(selected["label"], "science_target")
        self.assertAlmostEqual(selected["core_height_mm"]["median"], 40.0, places=2)
        self.assertGreaterEqual(selected["confidence_score"], 0.72)
        self.assertGreaterEqual(
            selected["orientation"]["confidence_score"], 0.75
        )

    def test_rotated_square_orientation_is_recovered_modulo_90(self):
        for expected_deg in (0.0, 15.0, 30.0, 44.0):
            with self.subTest(expected_deg=expected_deg):
                rgb, depth, K = rotated_square_scene(expected_deg)
                result = detection.detect_from_arrays(
                    rgb,
                    depth,
                    K,
                    {"quality_pass": True},
                    test_config(),
                    source="synthetic-rotated",
                )
                self.assertEqual(
                    result["status"], "DETECTED_CAMERA_FRAME_ONLY"
                )
                orientation = result["selected"]["orientation"]
                actual_deg = undirected_angle_mod90_deg(
                    orientation["axis_cam"]
                )
                self.assertLessEqual(
                    angle_error_mod90_deg(actual_deg, expected_deg),
                    3.0,
                )
                self.assertEqual(orientation["symmetry_period_deg"], 90.0)

    def test_rotated_depth_region_excludes_axis_aligned_invalid_fringe(self):
        rgb, depth, K = rotated_square_with_invalid_fringe_scene(44.0)
        result = detection.detect_from_arrays(
            rgb,
            depth,
            K,
            {"quality_pass": True},
            test_config(),
            source="synthetic-rotated-invalid-fringe",
        )
        self.assertEqual(result["status"], "DETECTED_CAMERA_FRAME_ONLY")
        selected = result["selected"]
        self.assertEqual(
            selected["core_depth_region_method"],
            "oriented_rectangle_inset",
        )
        self.assertGreaterEqual(selected["core_depth_valid_ratio"], 0.90)
        self.assertEqual(len(selected["core_depth_region_corners_px"]), 4)

    def test_rotated_internal_hole_uses_rgb_outline_and_real_core_depth(self):
        rgb, depth, K = rotated_square_with_invalid_fringe_scene(
            44.0,
            central_hole_px=12,
        )
        result = detection.detect_from_arrays(
            rgb,
            depth,
            K,
            {"quality_pass": True},
            test_config(),
            source="synthetic-rotated-internal-hole",
        )
        self.assertEqual(result["status"], "DETECTED_CAMERA_FRAME_ONLY")
        selected=result["selected"]
        self.assertGreaterEqual(selected["core_pixels"],test_config()["orientation"]["min_points"])
        self.assertTrue(selected["contour_completion"]["depth_measurements_unchanged"])
        self.assertTrue(np.any(depth==0))

    def test_adaptive_core_erosion_scales_and_clamps(self):
        component = test_config()["component"]
        self.assertEqual(detection.adaptive_core_erode_px(16, 14, component), 2)
        self.assertEqual(detection.adaptive_core_erode_px(20, 19, component), 3)
        self.assertEqual(detection.adaptive_core_erode_px(34, 29, component), 3)

    def test_orientation_quality_profile_relaxes_only_small_samples(self):
        orientation = test_config()["orientation"]
        small = detection.orientation_quality_profile(237, orientation)
        self.assertEqual(small["name"], "small_sample")
        self.assertEqual(small["min_confidence_score"], 0.70)
        self.assertEqual(small["max_p90_deviation_deg"], 10.0)

        standard = detection.orientation_quality_profile(301, orientation)
        self.assertEqual(standard["name"], "standard")
        self.assertEqual(standard["min_confidence_score"], 0.75)
        self.assertEqual(standard["max_p90_deviation_deg"], 8.0)

    def test_empty_plane_returns_no_target(self):
        result = self.detect([])
        self.assertEqual(result["status"], "NO_TARGET")
        self.assertIsNone(result["selected"])

    def test_two_valid_targets_are_returned_as_independent_records(self):
        result = self.detect(
            [(45, 45, 60, 60, 0.96), (90, 45, 105, 60, 0.96)]
        )
        self.assertEqual(
            result["status"], "MULTIPLE_TARGETS_CAMERA_FRAME_ONLY"
        )
        self.assertEqual(result["accepted_candidate_count"], 2)
        self.assertIsNone(result["selected"])
        targets = result["accepted_targets"]
        self.assertEqual(
            [target["target_id"] for target in targets],
            ["component_001", "component_002"],
        )
        self.assertNotEqual(
            targets[0]["surface_point_cam_m"],
            targets[1]["surface_point_cam_m"],
        )

    def test_component_touching_workspace_border_is_rejected(self):
        # ROI left border is x=16.
        result = self.detect([(16, 45, 32, 61, 0.96)])
        self.assertEqual(result["status"], "NO_TARGET")
        reasons = [
            reason
            for candidate in result["candidates"]
            for reason in candidate["reject_reasons"]
        ]
        self.assertIn("touches_workspace_roi_border", reasons)

    def test_rejected_empty_core_uses_standard_json_nulls(self):
        result = self.detect(
            [
                (20, 20, 23, 23, 0.96),
                (65, 45, 85, 65, 0.96),
            ]
        )
        rejected = next(
            candidate
            for candidate in result["candidates"]
            if "core_has_no_finite_height" in candidate["reject_reasons"]
        )
        self.assertEqual(
            rejected["core_height_mm"],
            {"p10": None, "median": None, "p90": None},
        )
        self.assertEqual(rejected["surface_point_cam_m"], [None, None, None])
        json.dumps(result, allow_nan=False)

    def test_failed_source_capture_quality_stops_before_plane_fit(self):
        result = self.detect([(65, 45, 85, 65, 0.96)], quality=False)
        self.assertEqual(result["status"], "INPUT_REJECTED")
        self.assertNotIn("plane", result)
        self.assertIn("source_capture_quality_not_passed", result["reasons"])

    def test_invalid_normalized_roi_is_rejected(self):
        with self.assertRaises(ValueError):
            detection.normalized_roi((120, 160), [0.5, 0.2, 0.4, 0.9])


if __name__ == "__main__":
    unittest.main()
