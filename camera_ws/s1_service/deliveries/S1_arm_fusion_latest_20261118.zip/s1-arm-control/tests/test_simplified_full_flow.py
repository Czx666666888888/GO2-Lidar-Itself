"""Local full-flow commissioning policy; no devices accessed."""
import copy
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import numpy as np

import scripts.run_go2_visual_alignment as main
from s1_control.go2_visual_alignment import validate_workspace_point, build_tangent_tcp_path
from s1_control.wrist_visual_servo import _validate_tcp_workspace


class SimplifiedFlowTests(unittest.TestCase):
    def workspace(self,advisory):
        return dict(tcp_base_x_mm=[-10,10],tcp_base_y_mm=[300,330],
                    normal_clearance_mm=[224,236],advisory_bounds=advisory)

    def test_historical_xy_advisory_only_when_selected(self):
        for fn in (validate_workspace_point,_validate_tcp_workspace):
            with self.assertRaises(RuntimeError): fn([.02,.34,.1],self.workspace(False),'test')
            fn([.02,.34,.1],self.workspace(True),'test')
            with self.assertRaises(ValueError): fn([float('nan'),.3,.1],self.workspace(True),'test')

    def test_absolute_clearance_still_rejects(self):
        args=dict(maximum_initial_error_mm=40,convergence_mm=5,
                  maximum_cartesian_step_mm=5,minimum_clearance_mm=200,
                  maximum_clearance_mm=300,workspace=self.workspace(True))
        build_tangent_tcp_path([.02,.34,.25,0,0,0,1],[.02,.34,0],[0,0,1],**args)
        with self.assertRaisesRegex(RuntimeError,'normal clearance'):
            build_tangent_tcp_path([.02,.34,.15,0,0,0,1],[.02,.34,0],[0,0,1],**args)

    def test_pending_visual_handoff_is_not_descent_authorization(self):
        desired=[0,1,1,0,0,0]; measured=[0,1,.97,0,0,0]
        arm=SimpleNamespace(_position_commander=SimpleNamespace())
        cfg=dict(success_joint_error_rad=.012,maximum_initial_joint_error_rad=.05,
                 bias_step_rad=.004,maximum_bias_rad=.024,maximum_attempts=0,
                 hold_seconds=.5,collision_step_rad=.005,minimum_joint_margin_deg=10,
                 validated_workspace=self.workspace(True),handoff_after_one_trim=True)
        with patch.object(main,'sample_endpoint_hold',return_value=measured):
            result=main.converge_observation_endpoint(
                arm,desired,endpoint_config=cfg,
                kinematics=SimpleNamespace(fk=lambda q:[0,.32,.1,0,0,0,1]),
                collision_checker=None,tilt_model=None,support_up_normal_base=[0,0,1],
                compensation_scale=1,torque_limits=[1]*6)
        self.assertEqual(result['status'],'pending_visual_verification')
        self.assertIs(result['authorizes_descent'],False)

    def test_large_tracking_error_not_excused_by_visual_handoff(self):
        desired=[0,1,1,0,0,0]
        cfg=dict(success_joint_error_rad=.012,maximum_initial_joint_error_rad=.05,
                 bias_step_rad=.004,maximum_bias_rad=.024,maximum_attempts=0,
                 hold_seconds=.5,collision_step_rad=.005,minimum_joint_margin_deg=10,
                 validated_workspace=self.workspace(True),handoff_after_one_trim=True)
        with patch.object(main,'sample_endpoint_hold',return_value=[0,1,.9,0,0,0]):
            with self.assertRaises(main.ObservationEndpointConvergenceError):
                main.converge_observation_endpoint(
                    SimpleNamespace(),desired,endpoint_config=cfg,
                    kinematics=SimpleNamespace(fk=lambda q:[0,.32,.1,0,0,0,1]),
                    collision_checker=None,tilt_model=None,support_up_normal_base=[0,0,1],
                    compensation_scale=1,torque_limits=[1]*6)


if __name__=='__main__': unittest.main()
