import math
import unittest

import numpy as np

from scripts.diagnose_tilt_compensation import (
    build_tilt_j1_target,
    evaluate_observed_j1_motion,
    guard_endpoint_trim,
    guard_tilt_motion,
    next_endpoint_trim_bias,
)
from s1_control.tilt_gravity import (
    GRAVITY_M_S2,
    UrdfGravityModel,
    differential_tilt_compensation,
    differential_tilt_compensation_from_support_up,
    gravity_vector_base_from_support_up,
    gravity_vector_base_rear_down,
    limited_correction,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import (
    TiltCompensatedPositionCommander,
    commander_from_mount_record,
)


REFERENCE_Q = [
    1.499007,
    2.152857,
    1.481460,
    0.900091,
    0.078775,
    -0.002480,
]


class GuardProbe:
    def __init__(self, result=None):
        self.result = result
        self.calls = []

    def guard(self, meas, vel, temp, target6, settling):
        self.calls.append(
            {
                "meas": list(meas),
                "target": list(target6),
                "settling": settling,
            }
        )
        return self.result


class TiltGravityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = UrdfGravityModel.from_file(locate_official_gripper_urdf())

    def test_rear_down_gravity_vector_has_positive_base_x(self):
        vector = gravity_vector_base_rear_down(6.0)
        self.assertAlmostEqual(vector[0], GRAVITY_M_S2 * math.sin(math.radians(6.0)))
        self.assertAlmostEqual(vector[1], 0.0)
        self.assertAlmostEqual(vector[2], -GRAVITY_M_S2 * math.cos(math.radians(6.0)))

    def test_official_gripper_urdf_mass_and_joint_count(self):
        self.assertEqual(self.model.actuated_joint_count, 6)
        self.assertAlmostEqual(self.model.total_mass_kg, 4.2358441, places=5)

    def test_zero_mount_tilt_has_zero_differential(self):
        delta = differential_tilt_compensation(self.model, REFERENCE_Q, 0.0)
        np.testing.assert_allclose(delta, np.zeros(6), atol=1e-10)

    def test_six_degree_reference_pose_matches_independent_calculation(self):
        delta = differential_tilt_compensation(self.model, REFERENCE_Q, 6.0)
        expected = np.array(
            [0.917801, 0.021065, -0.048049, 0.012926, -0.048306, -0.000065]
        )
        np.testing.assert_allclose(delta, expected, atol=2e-5)

    def test_full_support_normal_matches_pitch_only_for_same_mount(self):
        gravity = gravity_vector_base_rear_down(6.0)
        support_up = -gravity / GRAVITY_M_S2
        pitch_only = differential_tilt_compensation(
            self.model, REFERENCE_Q, 6.0
        )
        full_normal = differential_tilt_compensation_from_support_up(
            self.model, REFERENCE_Q, support_up
        )
        np.testing.assert_allclose(full_normal, pitch_only, atol=1e-10)
        np.testing.assert_allclose(
            gravity_vector_base_from_support_up(support_up), gravity, atol=1e-10
        )

    def test_support_up_gravity_rejects_wall_or_non_unit_normal(self):
        with self.assertRaises(ValueError):
            gravity_vector_base_from_support_up([1.0, 0.0, 0.0])
        with self.assertRaises(ValueError):
            gravity_vector_base_from_support_up([0.0, 0.0, 2.0])

    def test_j1_correction_changes_sign_between_robot_sides(self):
        right_side_q = list(REFERENCE_Q)
        left_side_q = list(REFERENCE_Q)
        left_side_q[0] = -right_side_q[0]
        right_delta = differential_tilt_compensation(
            self.model, right_side_q, 6.0
        )
        left_delta = differential_tilt_compensation(
            self.model, left_side_q, 6.0
        )
        self.assertGreater(right_delta[0], 0.8)
        self.assertLess(left_delta[0], -0.8)

    def test_initial_scale_is_quarter_of_model_result_without_clipping(self):
        delta = differential_tilt_compensation(self.model, REFERENCE_Q, 6.0)
        requested, applied = limited_correction(
            delta,
            0.25,
            [1.2, 0.2, 0.2, 0.2, 0.2, 0.1],
        )
        np.testing.assert_allclose(requested, delta * 0.25, atol=1e-12)
        np.testing.assert_allclose(applied, requested, atol=1e-12)

    def test_external_point_mass_generates_full_gravity_compensation(self):
        center = [0.0894257, -0.0099632, 0.0601781]
        torque = self.model.point_mass_gravity_compensation(
            REFERENCE_Q,
            [0.0, 0.0, -GRAVITY_M_S2],
            link_name="gripper",
            mass_kg=0.077,
            center_of_mass_link_m=center,
        )
        self.assertEqual(torque.shape, (6,))
        self.assertGreater(float(np.max(np.abs(torque))), 0.20)
        self.assertLess(abs(float(torque[5])), 0.01)

    def test_point_mass_rejects_unknown_link_or_invalid_mass(self):
        with self.assertRaisesRegex(ValueError, "unknown payload"):
            self.model.point_mass_gravity_compensation(
                REFERENCE_Q, [0.0, 0.0, -GRAVITY_M_S2],
                link_name="missing", mass_kg=0.077,
                center_of_mass_link_m=[0.0, 0.0, 0.0],
            )
        with self.assertRaisesRegex(ValueError, "mass_kg"):
            self.model.point_mass_gravity_compensation(
                REFERENCE_Q, [0.0, 0.0, -GRAVITY_M_S2],
                link_name="gripper", mass_kg=0.0,
                center_of_mass_link_m=[0.0, 0.0, 0.0],
            )

    def test_hard_limits_clip_each_joint_independently(self):
        requested, applied = limited_correction(
            [2.0, -0.5, 0.1, -0.1, 0.4, -0.2],
            1.0,
            [1.2, 0.2, 0.2, 0.2, 0.2, 0.1],
        )
        np.testing.assert_allclose(requested, [2.0, -0.5, 0.1, -0.1, 0.4, -0.2])
        np.testing.assert_allclose(applied, [1.2, -0.2, 0.1, -0.1, 0.2, -0.1])

    def test_tilt_position_commander_adds_bounded_differential_torque(self):
        class FakeMotor:
            def __init__(self):
                self.commands = []

            def gravity(self, measured):
                return [0.1] * 6

            def control_pos(self, target, torque):
                self.commands.append((list(target), list(torque)))
                return "commanded"

        class FakeSdkArm:
            def __init__(self):
                self.motor = FakeMotor()

        class FakeArm:
            def __init__(self):
                self._arm = FakeSdkArm()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        arm = FakeArm()
        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=6.0,
            scale=1.0,
            correction_absolute_limits_nm=[1.2, 0.2, 0.2, 0.2, 0.2, 0.1],
        )
        target = [value + 0.001 for value in REFERENCE_Q]
        self.assertEqual(commander(arm, target), "commanded")
        commanded_target, commanded_tau = arm._arm.motor.commands[-1]
        np.testing.assert_allclose(commanded_target, target)
        expected = differential_tilt_compensation(
            self.model, REFERENCE_Q, 6.0
        ) + 0.1
        np.testing.assert_allclose(commanded_tau, expected, atol=1e-9)
        self.assertFalse(commander.last_snapshot["clipped"])
        self.assertEqual(
            commander.last_snapshot["native_control_pos_return"],
            "commanded",
        )
        self.assertEqual(commander.command_count, 1)

    def test_tilt_position_commander_applies_explicit_position_bias(self):
        class FakeMotor:
            def __init__(self):
                self.target = None

            def gravity(self, measured):
                return [0.0] * 6

            def control_pos(self, target, torque):
                self.target = list(target)
                return 7

        class FakeArm:
            def __init__(self):
                self._arm = type("Sdk", (), {"motor": FakeMotor()})()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=6.0,
            scale=1.0,
            correction_absolute_limits_nm=[5.0] * 6,
        )
        bias = [0.0, 0.0, 0.012, 0.0, 0.0, 0.0]
        commander.set_position_bias_rad(bias)
        arm = FakeArm()
        commander(arm, REFERENCE_Q)

        expected = list(REFERENCE_Q)
        expected[2] += 0.012
        np.testing.assert_allclose(arm._arm.motor.target, expected)
        np.testing.assert_allclose(
            commander.last_snapshot["target_q_rad"], REFERENCE_Q
        )
        np.testing.assert_allclose(
            commander.last_snapshot["command_target_q_rad"], expected
        )
        self.assertEqual(
            commander.last_snapshot["native_control_pos_return"], 7
        )
        np.testing.assert_allclose(commander.clear_position_bias(), [0.0] * 6)

    def test_disabling_extra_tilt_preserves_vendor_gravity_and_can_restore(self):
        from types import SimpleNamespace
        commands = []
        arm = SimpleNamespace(
            get_pos=lambda: list(REFERENCE_Q) + [0.],
            _arm=SimpleNamespace(motor=SimpleNamespace(
                gravity=lambda measured: [.1] * 6,
                control_pos=lambda target, torque: commands.append((target, torque)),
            )),
        )
        commander = TiltCompensatedPositionCommander(
            self.model, rear_edge_lower_deg=6., scale=.25,
            correction_absolute_limits_nm=[1.2, .37, .32, .2, .2, .1],
        )
        commander.tilt_compensation_enabled = False
        commander(arm, REFERENCE_Q)
        np.testing.assert_allclose(commands[-1][0], REFERENCE_Q)
        np.testing.assert_allclose(commands[-1][1], [.1] * 6)
        np.testing.assert_allclose(commander.last_snapshot["applied_nm"], np.zeros(6))
        self.assertEqual(commander.compensation_scale, 0.)
        commander.tilt_compensation_enabled = True
        commander(arm, REFERENCE_Q)
        expected = .1 + .25 * differential_tilt_compensation(self.model, REFERENCE_Q, 6.)
        np.testing.assert_allclose(commands[-1][1], expected, atol=1e-10)

    def test_tilt_position_commander_supports_bounded_runtime_scale_ramp(self):
        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=6.0,
            scale=0.25,
            correction_absolute_limits_nm=[5.0] * 6,
        )
        self.assertAlmostEqual(commander.compensation_scale, 0.25)
        self.assertAlmostEqual(commander.set_compensation_scale(0.625), 0.625)
        self.assertAlmostEqual(commander.compensation_scale, 0.625)
        for invalid in (0.0, -0.1, 1.01, float("nan")):
            with self.assertRaises(ValueError):
                commander.set_compensation_scale(invalid)

    def test_payload_commander_is_explicit_and_defaults_disabled(self):
        class FakeMotor:
            def __init__(self):
                self.commands = []

            def gravity(self, measured):
                return [0.0] * 6

            def control_pos(self, target, torque):
                self.commands.append((list(target), list(torque)))

        class FakeArm:
            def __init__(self):
                self._arm = type("Sdk", (), {"motor": FakeMotor()})()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        center = [0.0894257, -0.0099632, 0.0601781]
        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=0.0,
            scale=1.0,
            correction_absolute_limits_nm=[1.0] * 6,
            payload_mass_kg=0.077,
            payload_center_of_mass_link_m=center,
            payload_scale=0.0,
            payload_correction_absolute_limits_nm=[1.0] * 6,
        )
        arm = FakeArm()
        commander(arm, REFERENCE_Q)
        np.testing.assert_allclose(arm._arm.motor.commands[-1][1], [0.0] * 6)
        self.assertEqual(commander.payload_scale, 0.0)

        commander.set_payload_scale(0.5)
        commander(arm, REFERENCE_Q)
        expected = 0.5 * self.model.point_mass_gravity_compensation(
            REFERENCE_Q,
            [0.0, 0.0, -GRAVITY_M_S2],
            link_name="gripper",
            mass_kg=0.077,
            center_of_mass_link_m=center,
        )
        np.testing.assert_allclose(
            arm._arm.motor.commands[-1][1], expected, atol=1e-9
        )
        self.assertFalse(commander.last_snapshot["payload_clipped"])

    def test_payload_commander_rejects_payload_hard_cap(self):
        class FakeMotor:
            def gravity(self, measured):
                return [0.0] * 6

            def control_pos(self, target, torque):
                raise AssertionError("clipped payload torque must not be commanded")

        class FakeArm:
            def __init__(self):
                self._arm = type("Sdk", (), {"motor": FakeMotor()})()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=0.0,
            scale=1.0,
            correction_absolute_limits_nm=[1.0] * 6,
            payload_mass_kg=0.077,
            payload_center_of_mass_link_m=[0.089, -0.01, 0.06],
            payload_scale=0.5,
            payload_correction_absolute_limits_nm=[0.001] * 6,
        )
        with self.assertRaisesRegex(RuntimeError, "payload compensation"):
            commander(FakeArm(), REFERENCE_Q)

    def test_tilt_position_commander_rejects_hard_cap_clipping(self):
        mount_record = {
            "mount_measurement": {"rear_edge_lower_deg": 6.0},
            "diagnostic": {
                "allowed_scale_steps": [1.0],
                "correction_absolute_limits_nm": [0.1] * 6,
            },
        }
        commander = commander_from_mount_record(
            self.model, mount_record, 1.0
        )

        class FakeMotor:
            def gravity(self, measured):
                return [0.0] * 6

            def control_pos(self, target, torque):
                raise AssertionError("clipped torque must not be commanded")

        class FakeArm:
            def __init__(self):
                self._arm = type("Sdk", (), {"motor": FakeMotor()})()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        with self.assertRaisesRegex(RuntimeError, "hard torque cap"):
            commander(FakeArm(), REFERENCE_Q)

    def test_tilt_position_commander_uses_quality_gated_full_normal(self):
        support_up = np.array([-0.079047, -0.063592, 0.994840])

        class FakeMotor:
            def __init__(self):
                self.commands = []

            def gravity(self, measured):
                return [0.0] * 6

            def control_pos(self, target, torque):
                self.commands.append((list(target), list(torque)))

        class FakeArm:
            def __init__(self):
                self._arm = type("Sdk", (), {"motor": FakeMotor()})()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=6.0,
            scale=1.0,
            correction_absolute_limits_nm=[5.0] * 6,
            maximum_support_tilt_deg=10.0,
            maximum_support_normal_deviation_deg=5.0,
            normal_transition_s=0.0,
        )
        state = commander.set_support_up_normal(
            support_up,
            source="validated_horizontal_support_plane:test",
        )
        arm = FakeArm()
        commander(arm, REFERENCE_Q)
        expected = differential_tilt_compensation_from_support_up(
            self.model, REFERENCE_Q, support_up
        )
        np.testing.assert_allclose(
            arm._arm.motor.commands[-1][1], expected, atol=1e-9
        )
        self.assertLess(state["support_tilt_from_base_up_deg"], 10.0)
        self.assertEqual(
            commander.last_snapshot["support_normal_source"],
            "validated_horizontal_support_plane:test",
        )

    def test_tilt_position_commander_rejects_unbounded_visual_normal(self):
        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=6.0,
            scale=1.0,
            correction_absolute_limits_nm=[1.2, 0.5, 0.2, 0.2, 0.2, 0.1],
            maximum_support_tilt_deg=10.0,
            maximum_support_normal_deviation_deg=5.0,
        )
        with self.assertRaisesRegex(RuntimeError, "support tilt"):
            commander.set_support_up_normal(
                [math.sin(math.radians(12.0)), 0.0, math.cos(math.radians(12.0))],
                source="bad",
            )
        observed = commander.set_support_up_normal(
            [0.0, -math.sin(math.radians(6.0)), math.cos(math.radians(6.0))],
            source="changed_ground_plane",
        )
        self.assertGreater(observed["deviation_from_mount_nominal_deg"], 5)
        self.assertFalse(observed["nominal_deviation_check_enabled"])

    def test_first_physical_half_blend_stays_inside_existing_torque_caps(self):
        support_up = np.array([-0.079047, -0.063592, 0.994840])

        class FakeMotor:
            def __init__(self):
                self.commands = []

            def gravity(self, measured):
                return [0.0] * 6

            def control_pos(self, target, torque):
                self.commands.append((list(target), list(torque)))

        class FakeArm:
            def __init__(self):
                self._arm = type("Sdk", (), {"motor": FakeMotor()})()

            def get_pos(self):
                return list(REFERENCE_Q) + [0.0]

        limits = np.array([1.2, 0.2, 0.2, 0.2, 0.2, 0.1])
        commander = TiltCompensatedPositionCommander(
            self.model,
            rear_edge_lower_deg=6.0,
            scale=1.0,
            correction_absolute_limits_nm=limits,
            maximum_support_tilt_deg=10.0,
            maximum_support_normal_deviation_deg=5.0,
            support_normal_blend=0.5,
            normal_transition_s=0.0,
        )
        state = commander.set_support_up_normal(
            support_up,
            source="validated_horizontal_support_plane:test",
        )
        arm = FakeArm()
        commander(arm, REFERENCE_Q)
        requested = np.asarray(commander.last_snapshot["requested_nm"])
        self.assertTrue(np.all(np.abs(requested) <= limits))
        self.assertFalse(commander.last_snapshot["clipped"])
        self.assertEqual(state["support_normal_blend"], 0.5)
        self.assertNotEqual(
            state["observed_support_up_normal_base"],
            state["applied_support_up_normal_base"],
        )

    def test_invalid_joint_vector_is_rejected(self):
        with self.assertRaises(ValueError):
            self.model.gravity_compensation([0.0] * 5, [0.0, 0.0, -9.81])

    def test_observed_j1_motion_accepts_eighty_percent_travel(self):
        result = evaluate_observed_j1_motion(0.05, 1.04, 1.0, 0.8)
        self.assertTrue(result["direction_ok"])
        self.assertTrue(result["passed"])
        self.assertAlmostEqual(result["observed_ratio"], 0.8)

    def test_observed_j1_motion_rejects_old_false_positive(self):
        result = evaluate_observed_j1_motion(
            0.02,
            1.011444,
            1.006485,
            0.8,
        )
        self.assertTrue(result["direction_ok"])
        self.assertFalse(result["passed"])
        self.assertAlmostEqual(result["observed_ratio"], 0.24795, places=5)

    def test_observed_j1_motion_rejects_wrong_direction(self):
        result = evaluate_observed_j1_motion(0.05, 0.99, 1.0, 0.8)
        self.assertFalse(result["direction_ok"])
        self.assertFalse(result["passed"])

    def test_tilt_diagnostic_accepts_five_hundredths_j1_target(self):
        target = build_tilt_j1_target([1.0, 2.0, 3.0, 4.0, 5.0, 6.0], 0.05)
        np.testing.assert_allclose(target, [1.05, 2.0, 3.0, 4.0, 5.0, 6.0])

    def test_tilt_diagnostic_rejects_larger_j1_target(self):
        with self.assertRaises(ValueError):
            build_tilt_j1_target([0.0] * 6, 0.050001)

    def test_motion_guard_accepts_known_transient_and_preserves_other_guards(self):
        arm = GuardProbe()
        position = [0.0] * 6
        target = [0.02, 0.0, 0.0, 0.0, 0.0, 0.0]
        result = guard_tilt_motion(
            arm,
            position,
            [0.0] * 6,
            [30.0] * 7,
            target,
            0.025,
        )
        self.assertIsNone(result)
        self.assertEqual(len(arm.calls), 1)
        self.assertEqual(arm.calls[0]["target"], position)
        self.assertFalse(arm.calls[0]["settling"])

    def test_motion_guard_rejects_excessive_transient_before_delegating(self):
        arm = GuardProbe()
        result = guard_tilt_motion(
            arm,
            [0.0] * 6,
            [0.0] * 6,
            [30.0] * 7,
            [0.026, 0.0, 0.0, 0.0, 0.0, 0.0],
            0.025,
        )
        self.assertIn("track_err>0.025", result)
        self.assertEqual(arm.calls, [])

    def test_motion_guard_propagates_speed_or_temperature_failure(self):
        arm = GuardProbe("speed>0.5 x3")
        result = guard_tilt_motion(
            arm,
            [0.0] * 6,
            [0.6] + [0.0] * 5,
            [30.0] * 7,
            [0.01, 0.0, 0.0, 0.0, 0.0, 0.0],
            0.025,
        )
        self.assertEqual(result, "speed>0.5 x3")

    def test_endpoint_trim_guard_accepts_v5_bias_residual(self):
        arm = GuardProbe()
        desired = [1.567701, 2.0, 1.2, 0.7, 0.05, 0.04]
        command = list(desired)
        command[0] += 0.004
        position = list(desired)
        position[0] -= 0.009564
        result = guard_endpoint_trim(
            arm,
            position,
            [0.0] * 6,
            [30.0] * 7,
            command,
            desired,
            0.025,
            0.012,
            0.012,
            settling=False,
        )
        self.assertIsNone(result)
        self.assertEqual(arm.calls[0]["target"], position)

    def test_endpoint_trim_guard_rejects_true_j1_error(self):
        arm = GuardProbe()
        result = guard_endpoint_trim(
            arm,
            [0.0] * 6,
            [0.0] * 6,
            [30.0] * 7,
            [0.014] + [0.0] * 5,
            [0.013] + [0.0] * 5,
            0.025,
            0.012,
            0.012,
            settling=False,
        )
        self.assertIn("J1_desired_err>0.012", result)
        self.assertEqual(arm.calls, [])

    def test_endpoint_trim_guard_rejects_command_or_non_j1_error(self):
        arm = GuardProbe()
        command_result = guard_endpoint_trim(
            arm,
            [0.0] * 6,
            [0.0] * 6,
            [30.0] * 7,
            [0.026] + [0.0] * 5,
            [0.0] * 6,
            0.025,
            0.012,
            0.012,
            settling=False,
        )
        self.assertIn("J1_command_err>0.025", command_result)
        non_j1_result = guard_endpoint_trim(
            arm,
            [0.0, 0.013, 0.0, 0.0, 0.0, 0.0],
            [0.0] * 6,
            [30.0] * 7,
            [0.0] * 6,
            [0.0] * 6,
            0.025,
            0.012,
            0.012,
            settling=False,
        )
        self.assertIn("non_J1_desired_err>0.012", non_j1_result)

    def test_endpoint_trim_guard_preserves_speed_or_temperature_failure(self):
        arm = GuardProbe("speed>0.5 x3")
        result = guard_endpoint_trim(
            arm,
            [0.0] * 6,
            [0.6] + [0.0] * 5,
            [30.0] * 7,
            [0.0] * 6,
            [0.0] * 6,
            0.025,
            0.012,
            0.012,
            settling=False,
        )
        self.assertEqual(result, "speed>0.5 x3")

    def test_endpoint_trim_bias_opposes_error_and_limits_each_step(self):
        self.assertAlmostEqual(next_endpoint_trim_bias(0.0, -0.009), 0.004)
        self.assertAlmostEqual(next_endpoint_trim_bias(0.004, -0.009), 0.008)
        self.assertAlmostEqual(next_endpoint_trim_bias(0.0, 0.009), -0.004)

    def test_endpoint_trim_bias_respects_total_limit(self):
        self.assertAlmostEqual(next_endpoint_trim_bias(0.011, -0.009), 0.012)
        self.assertAlmostEqual(next_endpoint_trim_bias(-0.011, 0.009), -0.012)

    def test_endpoint_trim_rejects_invalid_bounds(self):
        with self.assertRaises(ValueError):
            next_endpoint_trim_bias(0.0, 0.01, 0.02, 0.01)


if __name__ == "__main__":
    unittest.main()
