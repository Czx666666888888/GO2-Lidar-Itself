import math
import unittest

import numpy as np

from s1_control.go2_visual_alignment import (
    blended_support_up_normal,
    build_tangent_tcp_path,
    densify_joint_path,
    solve_continuous_ik_path,
    tangent_projection,
    validate_torque_envelope,
)


WORKSPACE = {
    "tcp_base_x_mm": [-60.0, 55.0],
    "tcp_base_y_mm": [300.0, 345.0],
    "normal_clearance_mm": [225.0, 290.0],
}


class LinearFakeKinematics:
    def __init__(self, reference_pose, reference_q):
        self.reference_pose = np.asarray(reference_pose, dtype=float)
        self.reference_q = np.asarray(reference_q, dtype=float)

    def ik(self, xyz, orientation, seed):
        xyz = np.asarray(xyz, dtype=float)
        q = self.reference_q.copy()
        q[:3] += 10.0 * (xyz - self.reference_pose[:3])
        return q.tolist()

    def fk(self, q):
        q = np.asarray(q, dtype=float)
        pose = self.reference_pose.copy()
        pose[:3] += (q[:3] - self.reference_q[:3]) / 10.0
        return pose.tolist()


class Go2VisualAlignmentTests(unittest.TestCase):
    def setUp(self):
        self.normal = np.asarray([-0.08, -0.06, 0.995], dtype=float)
        self.normal /= np.linalg.norm(self.normal)
        self.current = np.asarray(
            [0.0, 0.32, 0.10, 0.0, 0.0, 0.0, 1.0], dtype=float
        )

    def make_target(self, tangent_raw=(0.018, 0.009, 0.0), clearance_m=0.25):
        tangent = tangent_projection(tangent_raw, self.normal)
        return self.current[:3] + tangent - clearance_m * self.normal

    def test_tangent_path_uses_pitch_and_roll_and_preserves_clearance(self):
        target = self.make_target()
        result = build_tangent_tcp_path(
            self.current,
            target,
            self.normal,
            maximum_initial_error_mm=30.0,
            convergence_mm=5.0,
            maximum_cartesian_step_mm=5.0,
            minimum_clearance_mm=200.0,
            maximum_clearance_mm=300.0,
            workspace=WORKSPACE,
        )
        self.assertGreater(result["segment_count"], 1)
        self.assertAlmostEqual(result["normal_clearance_mm"], 250.0, places=6)
        path = np.asarray(result["tcp_poses_xyz_xyzw"], dtype=float)
        displacement = path[-1, :3] - path[0, :3]
        self.assertAlmostEqual(float(displacement @ self.normal), 0.0, places=9)
        self.assertGreater(abs(float(displacement[2])), 1e-5)
        self.assertTrue(np.allclose(path[:, 3:], self.current[3:]))

    def test_blended_normal_contains_observed_roll(self):
        nominal = [-math.sin(math.radians(6.0)), 0.0, math.cos(math.radians(6.0))]
        observed = self.normal
        applied = blended_support_up_normal(nominal, observed, 0.5)
        self.assertLess(applied[1], 0.0)
        self.assertAlmostEqual(float(np.linalg.norm(applied)), 1.0, places=9)

    def test_continuous_ik_path_tracks_each_cartesian_sample(self):
        target = self.make_target(tangent_raw=(0.012, 0.004, 0.0))
        cartesian = build_tangent_tcp_path(
            self.current,
            target,
            self.normal,
            maximum_initial_error_mm=30.0,
            convergence_mm=2.0,
            maximum_cartesian_step_mm=5.0,
            minimum_clearance_mm=200.0,
            maximum_clearance_mm=300.0,
            workspace=WORKSPACE,
        )
        start_q = [0.0, 1.0, 1.0, 0.0, 0.0, 0.0]
        solved = solve_continuous_ik_path(
            LinearFakeKinematics(self.current, start_q),
            start_q,
            cartesian["tcp_poses_xyz_xyzw"],
            maximum_joint_step_rad=0.15,
            minimum_joint_margin_deg=10.0,
            maximum_fk_position_error_mm=0.01,
            maximum_fk_orientation_error_deg=0.01,
        )
        self.assertEqual(len(solved["joint_path"]), cartesian["segment_count"] + 1)
        self.assertTrue(all(item["maximum_joint_delta_rad"] <= 0.15 for item in solved["samples"]))

    def test_dense_path_covers_segment_interior(self):
        dense = densify_joint_path(
            [[0, 1, 1, 0, 0, 0], [0.025, 1, 1, 0, 0, 0]], 0.01
        )
        self.assertEqual(len(dense), 4)
        self.assertAlmostEqual(dense[-1][0], 0.025)

    def test_torque_envelope_rejects_cap(self):
        with self.assertRaisesRegex(RuntimeError, "torque cap"):
            validate_torque_envelope(
                [[0, 1, 1, 0, 0, 0]],
                lambda _q: [1.0, 0, 0, 0, 0, 0],
                [1.0, 1, 1, 1, 1, 1],
            )


if __name__ == "__main__":
    unittest.main()
