"""Replay the mapped endpoint subtraction at the configured bias boundary."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from scripts import run_go2_visual_alignment as flow

class MappedEndpointBoundaryTests(unittest.TestCase):
    def invoke(self, offset):
        desired = [2.1504065990448,1.8831450939178467,1.357070803642273,1.0187125205993652,0.015196508727967739,0.5001490712165833]
        command = list(desired)
        command[5] += offset
        config = dict(success_joint_error_rad=0.012,maximum_initial_joint_error_rad=0.05,bias_step_rad=0.004,maximum_bias_rad=0.024,maximum_attempts=1,hold_seconds=0.5,collision_step_rad=0.005,minimum_joint_margin_deg=10,validated_workspace={})
        arm = SimpleNamespace(_position_commander=SimpleNamespace(phase=None))
        with patch.object(flow,'validate_workspace_point'), patch.object(flow,'sample_endpoint_hold',side_effect=RuntimeError('reached endpoint hold')) as hold:
            try:
                flow.converge_observation_endpoint(arm,desired,endpoint_config=config,kinematics=SimpleNamespace(fk=lambda q:[0]*7),collision_checker=None,tilt_model=None,support_up_normal_base=[0,0,1],compensation_scale=0,torque_limits=None,continuous_command_handoff=True,initial_command_q=command)
            finally:
                self.hold_called=hold.called

    def test_recorded_positive_boundary_is_accepted(self):
        with self.assertRaisesRegex(RuntimeError,'reached endpoint hold'):
            self.invoke(0.05)
        self.assertTrue(self.hold_called)

    def test_negative_boundary_is_accepted(self):
        with self.assertRaisesRegex(RuntimeError,'reached endpoint hold'):
            self.invoke(-0.05)
        self.assertTrue(self.hold_called)

    def test_actual_excess_still_rejected(self):
        with self.assertRaisesRegex(ValueError,'mapped endpoint baseline'):
            self.invoke(0.050001)
        self.assertFalse(self.hold_called)
