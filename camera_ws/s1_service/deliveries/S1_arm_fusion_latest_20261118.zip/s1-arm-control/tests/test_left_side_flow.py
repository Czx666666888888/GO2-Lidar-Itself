import contextlib
import io
import json
from pathlib import Path
import unittest
from execute_go2_observe_deployment import planned_phases
from run_go2_visual_alignment import load_alignment_config, load_bound_deployment_source, resolve_project_path, load_bound_box_place_resources
from s1_control.go2_deployment import verify_bound_report
from run_go2_multiview_scan import verify_scan_artifacts
from s1_control.kinematics import Kinematics

class LeftSideTests(unittest.TestCase):
    def setUp(self):
        self.path,self.config=load_alignment_config("config/go2_left_full_flow_size_adaptive_20261112_v1.json")
        self.plan_path=resolve_project_path(self.config["deployment_plan"])
        self.plan=json.loads(self.plan_path.read_text())
    def test_left_deployment_uses_negative_y_and_three_phases(self):
        source_path,source=load_bound_deployment_source(self.plan)
        self.assertEqual(source["route"]["side"],"left")
        phases=planned_phases([0]*6,self.plan["joint_path"],"left_observe")
        self.assertEqual([p[0] for p in phases],["vertical_escape","high_turn","side_deploy"])
        self.assertLess(Kinematics(verbose=False).fk(phases[-1][1][-1])[1],-0.29)
        report=verify_bound_report(self.plan_path,resolve_project_path(self.config["deployment_collision_report"]),resolve_project_path(self.plan["mount_config"]))
        self.assertTrue(report["self_collision_ok"])
    def test_left_search_paths_bound_to_left_hub(self):
        p=resolve_project_path("data/plans/go2_left_grasp_search_20261112_v1.json")
        plan,report=verify_scan_artifacts(p,resolve_project_path("data/plans/go2_left_grasp_search_20261112_v1_report.json"))
        self.assertEqual(plan["side"],"left")
        self.assertEqual(len(plan["selected_views"]),4)
        self.assertEqual(plan["hub"]["q_rad"],self.plan["joint_path"][-1]["q"])
        for view in plan["selected_views"]:
            self.assertEqual(view["path_from_hub_q_rad"][0],plan["hub"]["q_rad"])
            self.assertLess(view["tcp_pose_xyz_xyzw"][1],0)
    def test_shared_box_requires_explicit_left_option(self):
        options=dict(deployment_plan_path=self.plan_path,mount_path=resolve_project_path(self.plan["mount_config"]),allow_identical_deployment_geometry=True)
        with self.assertRaisesRegex(RuntimeError,"different plans"):
            load_bound_box_place_resources(self.config["adaptive_grasp_box_place"],**options)
        with contextlib.redirect_stdout(io.StringIO()):
            values=load_bound_box_place_resources(self.config["adaptive_grasp_box_place"],**options,allow_shared_box_from_left=True)
        self.assertEqual(values[3]["route"][0]["q"],self.plan["joint_path"][1]["q"])

if __name__=="__main__":unittest.main()
