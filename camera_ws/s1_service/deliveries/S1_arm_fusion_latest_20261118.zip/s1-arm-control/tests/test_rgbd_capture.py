# -*- coding: utf-8 -*-
"""不访问相机和S1硬件的RGB-D采集辅助函数回归测试。"""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np


MODULE_PATH = Path(__file__).resolve().parents[1] / "demo_grasp" / "capture_rgbd.py"
SPEC = importlib.util.spec_from_file_location("capture_rgbd", MODULE_PATH)
capture_rgbd = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(capture_rgbd)


class RgbdCaptureTests(unittest.TestCase):
    def test_temporal_median_ignores_zero_depth(self):
        frames = np.array(
            [
                [[1000, 0], [500, 0]],
                [[1100, 2000], [0, 0]],
                [[900, 2100], [700, 0]],
            ],
            dtype=np.uint16,
        )
        fused = capture_rgbd.fuse_depth_frames(
            frames, 0.001, min_valid_samples=2
        )
        np.testing.assert_allclose(
            fused,
            np.array([[1.0, 2.05], [0.6, 0.0]], dtype=np.float32),
            atol=1e-6,
        )

    def test_temporal_median_requires_enough_samples(self):
        frames = np.array([[[1000]], [[0]], [[0]]], dtype=np.uint16)
        fused = capture_rgbd.fuse_depth_frames(
            frames, 0.001, min_valid_samples=2
        )
        self.assertEqual(float(fused[0, 0]), 0.0)

    def test_invalid_fusion_arguments_are_rejected(self):
        with self.assertRaises(ValueError):
            capture_rgbd.fuse_depth_frames([], 0.001)
        with self.assertRaises(ValueError):
            capture_rgbd.fuse_depth_frames(np.ones((1, 2, 2)), 0.0)
        with self.assertRaises(ValueError):
            capture_rgbd.fuse_depth_frames(
                np.ones((2, 2, 2)), 0.001, min_valid_samples=3
            )

    def test_quality_gate_passes_good_usb3_capture(self):
        metadata = {
            "usb_type": "3.2",
            "valid_depth_ratio_fused": 0.84,
            "frame_interval_ms_max": 126.0,
        }
        passed, reasons = capture_rgbd.evaluate_capture_quality(metadata)
        self.assertTrue(passed)
        self.assertEqual(reasons, [])

    def test_quality_gate_reports_each_failure(self):
        metadata = {
            "usb_type": "2.1",
            "valid_depth_ratio_fused": 0.40,
            "frame_interval_ms_max": 300.0,
        }
        passed, reasons = capture_rgbd.evaluate_capture_quality(metadata)
        self.assertFalse(passed)
        self.assertEqual(len(reasons), 3)

    def test_save_capture_has_replayable_schema(self):
        capture = {
            "rgb": np.zeros((2, 3, 3), dtype=np.uint8),
            "depth_m": np.ones((2, 3), dtype=np.float32),
            "K": np.eye(3, dtype=np.float64),
            "distortion_coeffs": np.zeros(5, dtype=np.float64),
            "metadata": {"serial": "test", "quality_pass": True},
        }
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "frame.npz"
            saved, previews = capture_rgbd.save_capture(
                capture, output, write_preview=False
            )
            self.assertEqual(saved, output.resolve())
            self.assertEqual(previews, [])
            with np.load(saved, allow_pickle=False) as replay:
                self.assertEqual(
                    set(replay.files),
                    {"rgb", "depth_m", "K", "distortion_coeffs", "metadata_json"},
                )
                metadata = json.loads(str(replay["metadata_json"].item()))
                self.assertEqual(metadata["serial"], "test")

    def test_output_extension_is_explicit(self):
        capture = {
            "rgb": np.zeros((1, 1, 3), dtype=np.uint8),
            "depth_m": np.zeros((1, 1), dtype=np.float32),
            "K": np.eye(3),
            "distortion_coeffs": np.zeros(5),
            "metadata": {},
        }
        with self.assertRaises(ValueError):
            capture_rgbd.save_capture(capture, "frame.bin", write_preview=False)


if __name__ == "__main__":
    unittest.main()
