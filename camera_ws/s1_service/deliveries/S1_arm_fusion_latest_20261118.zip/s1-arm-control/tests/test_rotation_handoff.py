"""Offline replay checks for the center -> rotation command boundary."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from s1_control.command_continuity import offset_command_path
import scripts.run_go2_visual_alignment as main


class RotationHandoffTests(unittest.TestCase):
    def test_failed_run_boundary_is_not_reset(self):
        physical_start=[1.6805906296,1.8442440033,1.3498516083,1.0358972549,.0047683716,.0833530426]
        held=[1.7028811839,1.8415661304,1.3826289314,1.0377848849,.0126892751,.0914863505]
        physical_target=[1.7018500566,1.8394132853,1.3428325653,1.0338184834,.0056281830,-.6592545509]
        physical=[physical_start,physical_target]
        snapshot=copy.deepcopy(physical)
        command,offset=offset_command_path(held,physical)
        self.assertEqual(command[0],held)
        self.assertEqual(physical,snapshot)
        np.testing.assert_allclose(np.array(command[1])-command[0],np.array(physical_target)-physical_start)
        np.testing.assert_allclose(np.array(command[1])-offset,physical_target)
        # A single J6 correction preserves the other held motor targets.
        trim_physical=np.array(physical_target);trim_physical[5]-=.02
        trim_motor=trim_physical+offset
        np.testing.assert_allclose(trim_motor[:5],command[1][:5])
        self.assertAlmostEqual(trim_motor[5]-command[1][5],-.02)

    def test_only_simplified_profile_accepts_four_degree_limit(self):
        source=Path(main.PROJECT_ROOT)/'config/go2_dual_white_light_full_flow_simplified_v1.json'
        cfg=json.loads(source.read_text())
        cfg['adaptive_grasp_orientation']['maximum_endpoint_orientation_error_deg']=4
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'config.json';path.write_text(json.dumps(cfg))
            _,loaded=main.load_alignment_config(path)
            self.assertEqual(loaded['adaptive_grasp_orientation']['maximum_endpoint_orientation_error_deg'],4)
            self.assertEqual(loaded['adaptive_grasp_orientation']['maximum_endpoint_tcp_position_drift_mm'],5)
            self.assertEqual(loaded['adaptive_grasp_orientation']['maximum_endpoint_joint_error_rad'],.03)
            cfg['adaptive_grasp_orientation']['maximum_endpoint_orientation_error_deg']=4.1
            path.write_text(json.dumps(cfg))
            with self.assertRaises(ValueError):main.load_alignment_config(path)


if __name__=='__main__':unittest.main()
