"""No-device checks for the approved local J3 correction limit."""
import copy
import unittest
from scripts.run_go2_visual_alignment import apply_local_j3_tilt_limit


class LocalJ3LimitTests(unittest.TestCase):
    def setUp(self):
        self.mount={'diagnostic':{'correction_absolute_limits_nm':[1.2,.2,.2,.2,.2,.1]}}

    def test_only_j3_changes_and_original_not_mutated(self):
        original=copy.deepcopy(self.mount)
        updated,report=apply_local_j3_tilt_limit(self.mount,dict(
            simplified_full_flow=True,j3_tilt_correction_limit_nm=.25))
        self.assertEqual(self.mount,original)
        self.assertEqual(updated['diagnostic']['correction_absolute_limits_nm'],[1.2,.2,.25,.2,.2,.1])
        self.assertFalse(report['global_mount_file_modified'])

    def test_old_profiles_unchanged(self):
        result,report=apply_local_j3_tilt_limit(self.mount,{})
        self.assertIs(result,self.mount)
        self.assertIsNone(report)

    def test_wrong_scope_or_value_rejected(self):
        for runtime in [dict(j3_tilt_correction_limit_nm=.25),
                        dict(simplified_full_flow=True,j3_tilt_correction_limit_nm=.3)]:
            with self.assertRaises(ValueError): apply_local_j3_tilt_limit(self.mount,runtime)

    def test_unexpected_original_limit_rejected(self):
        self.mount['diagnostic']['correction_absolute_limits_nm'][2]=.3
        with self.assertRaises(ValueError):
            apply_local_j3_tilt_limit(self.mount,dict(simplified_full_flow=True,j3_tilt_correction_limit_nm=.25))


if __name__=='__main__':unittest.main()
