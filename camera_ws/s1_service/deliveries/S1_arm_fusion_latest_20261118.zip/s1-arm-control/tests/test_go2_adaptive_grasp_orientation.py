import math
import unittest
from pathlib import Path
import json
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

import scripts.run_go2_visual_alignment as alignment

from s1_control.go2_visual_alignment import (
    build_fixed_position_orientation_path,
    quaternion_error_deg,
    quaternion_to_rotation_matrix,
    rotation_matrix_to_quaternion,
    square_grasp_orientation_candidates,
)
from s1_control.wrist_visual_servo import extract_single_surface_observation


class Go2AdaptiveGraspOrientationTests(unittest.TestCase):
    def test_full_flow_is_enabled_after_orientation_only_physical_pass(self):
        root = Path(__file__).resolve().parents[1]
        config = json.loads(
            (
                root
                / "config/go2_crouch_right_visual_adaptive_grasp_box_place_nocw_metalbracket_v1.json"
            ).read_text(encoding="utf-8")
        )
        orientation = config["adaptive_grasp_orientation"]
        self.assertTrue(orientation["enabled"])
        self.assertTrue(orientation["full_flow_enabled"])
        self.assertEqual(
            orientation["maximum_endpoint_joint_error_rad"], 0.03
        )
        self.assertEqual(
            orientation["fallback_maximum_endpoint_joint_error_rad"],
            0.032,
        )
        self.assertEqual(orientation["unstable_retry_hold_seconds"], 0.5)

    @staticmethod
    def downward_tcp_pose():
        approach = np.array([0.0, 0.0, -1.0])
        closing = np.array([1.0, 0.0, 0.0])
        tool_z = np.cross(approach, closing)
        rotation = np.column_stack((approach, closing, tool_z))
        quaternion = rotation_matrix_to_quaternion(rotation)
        return [0.1, 0.3, 0.2, *quaternion.tolist()]

    def test_square_candidates_preserve_approach_and_bound_shortest_rotation(self):
        pose = self.downward_tcp_pose()
        angle = math.radians(29.0)
        edge = [math.cos(angle), math.sin(angle), 0.0]
        candidates = square_grasp_orientation_candidates(
            pose,
            edge,
            [0.0, 0.0, 1.0],
            maximum_approach_tilt_from_support_down_deg=14.0,
        )
        self.assertEqual(
            [candidate["name"] for candidate in candidates],
            ["edge", "edge_roll180", "edge90", "edge90_roll180"],
        )
        self.assertLessEqual(
            min(candidate["rotation_from_current_deg"] for candidate in candidates),
            45.0 + 1e-9,
        )
        current_approach = quaternion_to_rotation_matrix(pose[3:])[:, 0]
        for candidate in candidates:
            rotation = quaternion_to_rotation_matrix(
                candidate["target_quaternion_xyzw"]
            )
            self.assertTrue(np.allclose(rotation[:, 0], current_approach, atol=1e-9))
            self.assertAlmostEqual(float(np.linalg.det(rotation)), 1.0, places=9)

    def test_fixed_position_path_uses_bounded_shortest_arc_steps(self):
        pose = self.downward_tcp_pose()
        candidates = square_grasp_orientation_candidates(
            pose,
            [math.cos(math.radians(37.0)), math.sin(math.radians(37.0)), 0.0],
            [0.0, 0.0, 1.0],
            maximum_approach_tilt_from_support_down_deg=14.0,
        )
        selected = min(candidates, key=lambda item: item["rotation_from_current_deg"])
        path = build_fixed_position_orientation_path(
            pose,
            selected["target_quaternion_xyzw"],
            maximum_orientation_step_deg=5.0,
        )
        self.assertTrue(all(np.allclose(sample[:3], pose[:3]) for sample in path))
        self.assertAlmostEqual(
            quaternion_error_deg(path[-1][3:], selected["target_quaternion_xyzw"]),
            0.0,
            places=7,
        )
        for first, second in zip(path, path[1:]):
            self.assertLessEqual(
                quaternion_error_deg(first[3:], second[3:]), 5.0 + 1e-9
            )

    def test_nearest_alternate_is_tried_only_after_preferred_rotation_fails(self):
        root = Path(__file__).resolve().parents[1]
        config = json.loads(
            (root / "config/go2_dual_white_light_full_flow_size_adaptive_v1.json").read_text()
        )["adaptive_grasp_orientation"]
        pose = self.downward_tcp_pose()
        angle = math.radians(44.9)
        observation = {
            "target_edge_axis_base": [math.cos(angle), math.sin(angle), 0.0],
            "support_up_normal_base": [0.0, 0.0, 1.0],
            "orientation_symmetry_period_deg": 90.0,
            "orientation_confidence_score": 0.9,
            "orientation_p90_deviation_deg": 2.0,
        }
        start_q = [0.0, 1.0, 1.0, 0.0, 0.0, 0.0]
        options = dict(
            config=config, tcp_kinematics=SimpleNamespace(fk=lambda q: pose),
            collision_checker=None, tilt_model=None, applied_support_up=[0, 0, 1],
            compensation_scale=1, torque_limits=[1] * 6,
        )
        solution = {"joint_path": [start_q, start_q]}
        with patch.object(alignment, "solve_continuous_ik_path") as solve, patch.object(
            alignment, "check_collision_path"
        ), patch.object(alignment, "validate_torque_envelope"):
            solve.return_value = solution
            preferred = alignment.compute_grasp_orientation_plan(
                start_q, observation, **options, allow_alternate_closing_direction=True,
            )["selected"]
            self.assertAlmostEqual(preferred["rotation_from_current_deg"], 44.9)
            self.assertFalse(preferred["alternate_closing_direction"])
            self.assertEqual(solve.call_count, 1)

            solve.reset_mock()
            solve.side_effect = [RuntimeError("no safe continuous IK solution"), solution]
            alternate = alignment.compute_grasp_orientation_plan(
                start_q, observation, **options, allow_alternate_closing_direction=True,
            )["selected"]
            self.assertAlmostEqual(alternate["rotation_from_current_deg"], 45.1)
            self.assertTrue(alternate["alternate_closing_direction"])
            self.assertEqual(solve.call_count, 2)

            solve.reset_mock()
            solve.side_effect = RuntimeError("no safe continuous IK solution")
            with self.assertRaisesRegex(RuntimeError, "no safe square-grasp orientation candidate"):
                alignment.compute_grasp_orientation_plan(start_q, observation, **options)
            self.assertEqual(solve.call_count, 1)

    def test_detector_orientation_is_transformed_into_support_plane(self):
        detection = {
            "schema_version": 2,
            "status": "DETECTED_CAMERA_FRAME_ONLY",
            "camera_frame_only": True,
            "accepted_candidate_count": 1,
            "plane": {"quality_pass": True, "normal_cam": [0.0, 0.0, 1.0]},
            "selected": {
                "accepted": True,
                "target_id": "component_001",
                "surface_point_cam_m": [0.0, 0.0, 0.35],
                "orientation": {
                    "axis_cam": [1.0, 0.0, 0.0],
                    "angle_in_table_basis_mod90_deg": 20.0,
                    "symmetry_period_deg": 90.0,
                    "confidence_score": 0.90,
                    "p90_deviation_deg": 2.0,
                    "applied_min_confidence_score": 0.75,
                    "applied_max_p90_deviation_deg": 8.0,
                    "quality_profile": "cube_square_mod90",
                },
            },
        }
        transform = np.eye(4)
        transform[:3, :3] = np.diag([1.0, -1.0, -1.0])
        safety = {
            "maximum_camera_tilt_from_down_deg": 14.0,
            "minimum_camera_target_depth_mm": 300.0,
            "maximum_camera_target_depth_mm": 500.0,
        }
        observation = extract_single_surface_observation(
            detection,
            {"quality_pass": True, "serial": "D455"},
            transform,
            "D455",
            safety,
        )
        self.assertTrue(
            np.allclose(observation["target_edge_axis_base"], [1.0, 0.0, 0.0])
        )
        self.assertEqual(observation["orientation_symmetry_period_deg"], 90.0)
        self.assertEqual(observation["orientation_confidence_score"], 0.90)


if __name__ == "__main__":
    unittest.main()
