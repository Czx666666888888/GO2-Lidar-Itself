import ast
import importlib.util
import math
from pathlib import Path
import sys
import tempfile
import unittest
import json
import hashlib

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


class EyeInHandValidationTests(unittest.TestCase):
    @staticmethod
    def load_validation_module():
        source_path = PROJECT_ROOT / "scripts" / "validate_eye_in_hand.py"
        spec = importlib.util.spec_from_file_location(
            "validate_eye_in_hand_for_test", source_path
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_validation_script_has_no_hardware_access(self):
        source_path = PROJECT_ROOT / "scripts" / "validate_eye_in_hand.py"
        source = source_path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        imported_roots = {
            alias.name.split(".")[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imported_from_roots = {
            (node.module or "").split(".")[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
        }
        self.assertNotIn("pyrealsense2", imported_roots | imported_from_roots)
        self.assertNotIn("S1_SDK", imported_roots | imported_from_roots)
        self.assertNotIn("/dev/tty", source)

    def test_validation_parser_accepts_one_or_multiple_sessions(self):
        module = self.load_validation_module()
        parser = module.build_parser()

        one = parser.parse_args(["--session", "validation_a"])
        self.assertEqual(one.session, ["validation_a"])

        multiple = parser.parse_args(
            [
                "--session",
                "validation_a",
                "--session",
                "validation_b",
            ]
        )
        self.assertEqual(
            multiple.session,
            ["validation_a", "validation_b"],
        )
        self.assertFalse(multiple.allow_base_target_relocation)

        relocated = parser.parse_args(
            ["--session", "validation_a", "--allow-base-target-relocation"]
        )
        self.assertTrue(relocated.allow_base_target_relocation)

    def test_validation_sessions_must_be_distinct(self):
        module = self.load_validation_module()
        sessions = module.resolve_validation_sessions(
            ["validation_a", "validation_b"]
        )
        self.assertEqual(len(sessions), 2)
        with self.assertRaisesRegex(ValueError, "must be distinct"):
            module.resolve_validation_sessions(
                ["validation_a", "validation_a"]
            )

    def test_pose_novelty_requires_translation_or_rotation_separation(self):
        module = self.load_validation_module()
        training = [np.eye(4)]

        duplicate = np.eye(4)
        duplicate[0, 3] = 0.009
        duplicate_result = module.nearest_training_pose(
            duplicate,
            training,
            minimum_translation_mm=10.0,
            minimum_rotation_deg=3.0,
        )
        self.assertFalse(duplicate_result["novel"])

        translated = np.eye(4)
        translated[0, 3] = 0.011
        translated_result = module.nearest_training_pose(
            translated,
            training,
            minimum_translation_mm=10.0,
            minimum_rotation_deg=3.0,
        )
        self.assertTrue(translated_result["novel"])

        rotation_only = np.eye(4)
        angle = math.radians(3.1)
        rotation_only[:3, :3] = [
            [math.cos(angle), -math.sin(angle), 0.0],
            [math.sin(angle), math.cos(angle), 0.0],
            [0.0, 0.0, 1.0],
        ]
        close_in_both = np.eye(4)
        close_in_both[0, 3] = -0.009
        mixed_result = module.nearest_training_pose(
            np.eye(4),
            [rotation_only, close_in_both],
            minimum_translation_mm=10.0,
            minimum_rotation_deg=3.0,
        )
        self.assertFalse(mixed_result["novel"])
        self.assertEqual(mixed_result["training_sample_index"], 1)

    def test_validation_failures_enforce_residual_and_novelty_gates(self):
        module = self.load_validation_module()
        quality = {
            "minimum_samples": 1,
            "minimum_max_pairwise_rotation_deg": 0.0,
            "minimum_max_pairwise_translation_mm": 0.0,
            "minimum_informative_rotation_pairs": 0,
            "maximum_translation_rms_mm": 8.0,
            "maximum_translation_max_mm": 20.0,
            "maximum_rotation_rms_deg": 2.0,
            "maximum_rotation_max_deg": 5.0,
        }
        samples = [
            {
                "path": Path("sample_001.json"),
                "record": {"observation": {"accepted": True}},
                "reprojection_rms_px": 0.1,
            }
        ]
        diversity = {
            "maximum_pairwise_rotation_deg": 0.0,
            "maximum_pairwise_translation_mm": 0.0,
            "informative_rotation_pair_count": 0,
        }
        summary = {
            "translation_rms_mm": 9.0,
            "translation_max_mm": 12.0,
            "rotation_rms_deg": 1.0,
            "rotation_max_deg": 2.0,
        }
        failures = module.validation_failures(
            quality,
            samples,
            diversity,
            [{"novel": False, "training_sample_index": 0}],
            summary,
            maximum_reprojection_rms_px=0.8,
        )
        self.assertTrue(any("too close" in reason for reason in failures))
        self.assertTrue(any("translation_rms_mm" in reason for reason in failures))

    def test_candidate_supports_multiple_training_sessions(self):
        module = self.load_validation_module()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config_path = root / "config.json"
            candidate_path = root / "candidate.json"
            sessions = [root / "session_a", root / "session_b"]
            config = {
                "camera_serial": "D455-test",
                "checkerboard": {"inner_corners_columns": 11},
            }
            config_path.write_text(json.dumps(config), encoding="utf-8")
            config_hash = hashlib.sha256(config_path.read_bytes()).hexdigest()
            candidate = {
                "quantity": "T_flange_camera",
                "status": "candidate_pending_physical_validation",
                "value_T_flange_camera": np.eye(4).tolist(),
                "provenance": {
                    "config_sha256": config_hash,
                    "camera_serial": "D455-test",
                    "checkerboard": config["checkerboard"],
                    "sessions": [str(path) for path in sessions],
                    "T_base_target_estimate": np.eye(4).tolist(),
                },
            }
            candidate_path.write_text(json.dumps(candidate), encoding="utf-8")

            loaded = module.load_bound_candidate(
                candidate_path, config_path, config
            )
            self.assertEqual(loaded["training_sessions"], sessions)

    def test_relocation_mode_refits_one_validation_reference(self):
        module = self.load_validation_module()
        flange_camera = np.eye(4)
        training_base_target = np.eye(4)
        validation_base_target = np.eye(4)
        validation_base_target[0, 3] = 0.050

        pose_a = np.eye(4)
        pose_b = np.eye(4)
        angle = math.radians(20.0)
        pose_b[:3, :3] = [
            [math.cos(angle), -math.sin(angle), 0.0],
            [math.sin(angle), math.cos(angle), 0.0],
            [0.0, 0.0, 1.0],
        ]
        pose_b[:3, 3] = [0.03, -0.02, 0.01]
        poses = [pose_a, pose_b]
        camera_targets = [
            np.linalg.inv(pose) @ validation_base_target for pose in poses
        ]

        strict = module.evaluate_candidate_residuals(
            poses,
            camera_targets,
            flange_camera,
            training_base_target,
            allow_base_target_relocation=False,
        )
        self.assertEqual(strict["reference_mode"], "training_reference_fixed")
        self.assertAlmostEqual(strict["summary"].translation_rms_mm, 50.0)

        relocated = module.evaluate_candidate_residuals(
            poses,
            camera_targets,
            flange_camera,
            training_base_target,
            allow_base_target_relocation=True,
        )
        self.assertEqual(relocated["reference_mode"], "validation_session_refit")
        self.assertLess(relocated["summary"].translation_max_mm, 1.0e-8)
        self.assertLess(relocated["summary"].rotation_max_deg, 1.0e-6)
        self.assertTrue(
            all(
                "translation_error_base_xyz_mm" in detail
                and "predicted_T_base_target" in detail
                for detail in relocated["details"]
            )
        )
        self.assertAlmostEqual(
            relocated["shift_from_training_translation_mm"], 50.0
        )


if __name__ == "__main__":
    unittest.main()
