import ast
import copy
import unittest
from pathlib import Path
import run_go2_visual_alignment as flow

class DescentBranchControlTests(unittest.TestCase):
    def test_normal_and_residual_handoff_both_create_descent_execution(self):
        tree=ast.parse(Path(flow.__file__).read_text())
        branch=next(n for n in ast.walk(tree) if isinstance(n,ast.If)
                    and ast.unparse(n.test)=="descent_round_trip_enabled and (not orientation_only_requested)")
        nodes=[]
        for n in branch.body:
            if isinstance(n,ast.If) and ast.unparse(n.test)=='\"center_alignment_handoff\" in log':
                nodes.append(copy.deepcopy(n))
            elif isinstance(n,ast.If) and ast.unparse(n.test)=="'center_alignment_handoff' in log":
                nodes.append(copy.deepcopy(n))
            elif isinstance(n,ast.Assign) and any(ast.unparse(t)=="log[descent_log_key]" for t in n.targets):
                nodes.append(copy.deepcopy(n))
        self.assertEqual(len(nodes),2)
        for with_handoff in (False,True):
            log={"center_alignment_handoff":{}} if with_handoff else {}
            scope=dict(log=log,descent_log_key="adaptive_pregrasp",
                pregrasp_descent_scale=0.,descent_planning={"collision":{},"body_check":{},
                    "descent_centering_correction_xyz_mm":[0.,0.,0.]})
            exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),
                         "actual_descent_branch","exec"),scope)
            self.assertEqual(log['adaptive_pregrasp']['status'],'planned')
            self.assertEqual('center_alignment_handoff' in log,with_handoff)
        calls=[n for n in ast.walk(branch) if isinstance(n,ast.Call)
               and isinstance(n.func,ast.Attribute) and n.func.attr=='move_waypoints'
               and n.args and isinstance(n.args[0],ast.Name) and n.args[0].id=='executed_descent_path']
        self.assertTrue(calls)
