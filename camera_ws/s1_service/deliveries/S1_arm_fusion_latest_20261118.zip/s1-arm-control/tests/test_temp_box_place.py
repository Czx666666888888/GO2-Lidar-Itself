import math
import unittest

from s1_control.kinematics import READY_Q
from scripts.plan_temp_box_place import (
    build_transit_waypoints,
    derive_geometry,
    evenly_spaced_levels,
    orientation_report,
)


CAPTURED_QUATERNION = [
    -0.48438939452171326,
    0.505793571472168,
    0.5039711594581604,
    0.5055223107337952,
]


def sample_config(raise_mm=23.0):
    return {
        "box": {"outer_height_mm": 115.0},
        "geometry": {
            "reference_table_z_mm": -52.882568480913164,
            "raise_from_taught_mm": raise_mm,
            "hover_above_release_mm": 80.0,
            "minimum_release_rim_clearance_mm": 35.0,
        },
    }


def sample_pose():
    return {
        "tcp_xyz_quat_xyzw": [
            -0.004319247789680958,
            0.23742015659809113,
            0.07740228623151779,
            *CAPTURED_QUATERNION,
        ]
    }


class TempBoxPlaceTests(unittest.TestCase):
    def test_derived_release_has_required_rim_clearance(self):
        derived = derive_geometry(sample_config(), sample_pose())
        self.assertAlmostEqual(derived["box_rim_z_mm"], 62.1174315191, places=6)
        self.assertAlmostEqual(derived["release_xyz_mm"][2], 100.4022862315, places=6)
        self.assertAlmostEqual(derived["release_rim_clearance_mm"], 38.2848547124, places=6)
        self.assertAlmostEqual(derived["hover_xyz_mm"][2], 180.4022862315, places=6)

    def test_low_taught_pose_is_not_accepted_without_raise(self):
        with self.assertRaisesRegex(ValueError, "上沿净空"):
            derive_geometry(sample_config(raise_mm=1.0), sample_pose())

    def test_captured_orientation_is_topdown_and_horizontal(self):
        report = orientation_report(CAPTURED_QUATERNION)
        self.assertLess(report["topdown_approach_error_deg"], 3.0)
        self.assertLess(report["closing_axis_vertical_abs"], 0.05)

    def test_vertical_levels_respect_maximum_step(self):
        levels = evenly_spaced_levels(102.4, 182.4, 15.0)
        self.assertEqual(levels[0], 102.4)
        self.assertEqual(levels[-1], 182.4)
        self.assertTrue(all(
            after - before <= 15.0 + 1e-9
            for before, after in zip(levels, levels[1:])
        ))

    def test_transit_interpolation_respects_joint_delta(self):
        target = [1.57, 1.61, 1.30, 1.20, 0.0, 0.0]
        intermediates = build_transit_waypoints(READY_Q, target, 0.8)
        route = [list(READY_Q)] + [item["q"] for item in intermediates] + [target]
        self.assertGreaterEqual(len(intermediates), 1)
        for before, after in zip(route, route[1:]):
            self.assertLessEqual(
                max(abs(a - b) for a, b in zip(before, after)),
                0.8 + 1e-12,
            )

    def test_orientation_quaternion_is_normalized_in_output(self):
        scaled = [2.0 * value for value in CAPTURED_QUATERNION]
        report = orientation_report(scaled)
        rotation = report["rotation_matrix"]
        for column in range(3):
            norm = math.sqrt(sum(rotation[row][column] ** 2 for row in range(3)))
            self.assertAlmostEqual(norm, 1.0, places=9)


if __name__ == "__main__":
    unittest.main()
