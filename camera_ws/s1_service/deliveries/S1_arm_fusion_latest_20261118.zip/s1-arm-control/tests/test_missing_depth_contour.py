import copy
import json
from pathlib import Path
import unittest
import numpy as np
from demo_grasp.detect_science_target_rgbd import load_capture,load_config,detect_capture,complete_missing_depth_contour
ROOT=Path(__file__).resolve().parents[1]

class ContourTests(unittest.TestCase):
    def test_failed_capture_recovers_square_without_changing_raw_depth_or_thresholds(self):
        folder=ROOT/"data/go2_visual_alignment_runs/alignment_20261114-001328"
        frame=load_capture(folder/"final_capture.npz")
        cfg,_=load_config(ROOT/"config/wrist_cube_vision_go2_nocw_metalbracket_v1.yaml")
        depth=frame["depth_m"].copy();before=copy.deepcopy(cfg)
        result=detect_capture(frame,cfg)
        self.assertEqual(result["status"],"DETECTED_CAMERA_FRAME_ONLY")
        obj=result["selected"]
        self.assertTrue(obj["contour_completion"]["depth_measurements_unchanged"])
        self.assertGreater(obj["contour_completion"]["completed_contour_pixels"],3000)
        self.assertLess(obj["orientation"]["rectangle_aspect_ratio"],1.1)
        self.assertGreater(obj["orientation"]["confidence_score"],.9)
        self.assertAlmostEqual(obj["core_height_mm"]["median"],50.994186,places=4)
        np.testing.assert_array_equal(frame["depth_m"],depth)
        self.assertEqual(cfg,before)
    def test_valid_ground_and_disconnected_holes_are_not_added(self):
        rgb=np.zeros((30,30,3),np.uint8);rgb[:]=[20,160,200]
        depth=np.ones((30,30),float)
        seed=np.zeros((30,30),np.uint8);seed[15:20,10:20]=1
        depth[10:15,10:20]=0;depth[1:4,1:4]=0
        K=np.array([[100,0,15],[0,100,15],[0,0,1]],float)
        plane={"roi_mask":np.ones((30,30),bool),"normal":np.array([0,0,-1]),"offset_m":1.0}
        result=complete_missing_depth_contour(rgb,depth,seed,seed.astype(bool),plane,K,50)
        self.assertEqual(result["completed_contour_pixels"],100)
        self.assertFalse(result["mask"][2,2])
        self.assertFalse(result["mask"][20,15])

if __name__=="__main__":unittest.main()
