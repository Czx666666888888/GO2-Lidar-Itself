"""Replay elapsed preflight time without waiting or connecting devices."""
from pathlib import Path
from types import SimpleNamespace
import json
import unittest
from unittest.mock import patch
import scripts.run_go2_visual_alignment as flow

class HandoffTimeoutConfigTests(unittest.TestCase):
    def execute(self,duration,error=None):
        root=Path(__file__).resolve().parents[1]
        runtime=json.loads((root/'config/go2_dual_white_light_full_flow_simplified_v1.json').read_text())['runtime']
        clock=[0.];commands=[]
        class WorkerThread:
            def __init__(self,target,**kwargs):self.target=target;self.done=False
            def start(self):pass
            def is_alive(self):
                if clock[0]>=duration and not self.done:
                    self.target();self.done=True
                return not self.done
            def join(self,**kwargs):pass
        def preflight(*args,**kwargs):
            self.assertNotIn('timeout_s',kwargs)
            if error:raise error
            return [[.03]*6,[.04]*6],{'checked':True}
        arm=SimpleNamespace(_position_commander=SimpleNamespace(last_command_q_rad=[.03]*6),
            command_position=lambda q:commands.append(list(q)),get_pos=lambda:[.03]*6,
            get_vel=lambda:[0]*6,get_temp=lambda:[25]*7,guard=lambda *args,**kwargs:None,
            limits=SimpleNamespace(settle_seconds=.5),dt=.02)
        with patch.object(flow.threading,'Thread',WorkerThread), \
             patch.object(flow.time,'monotonic',side_effect=lambda:clock[0]), \
             patch.object(flow.time,'sleep',side_effect=lambda seconds:clock.__setitem__(0,clock[0]+max(seconds,.02))), \
             patch.object(flow,'prepare_continuous_alignment_path',side_effect=preflight):
            result=flow.prepare_continuous_alignment_path_while_holding(
                arm,[[0]*6,[.04]*6],timeout_s=runtime['worker_timeout_s'])
        self.assertTrue(commands)
        self.assertTrue(all(q==[.03]*6 for q in commands))
        return result,clock[0]

    def test_recorded_13_613_second_preflight_uses_existing_runtime_budget(self):
        result,elapsed=self.execute(13.613)
        self.assertTrue(result[1]['checked'])
        self.assertGreaterEqual(elapsed,13.613)

    def test_actual_preflight_rejection_is_not_excused_by_the_runtime_budget(self):
        with self.assertRaisesRegex(RuntimeError,'collision rejected'):
            self.execute(13.613,RuntimeError('collision rejected'))

    def test_existing_configured_budget_still_applies(self):
        with self.assertRaisesRegex(TimeoutError,'exceeding 45.000s'):
            self.execute(46.)

if __name__=='__main__':unittest.main()
