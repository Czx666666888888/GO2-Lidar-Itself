"""Offline checks for visual handoff and no-contact adaptive pregrasp descent."""
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from scripts.run_go2_visual_alignment import (
    check_collision_path,
    compute_safe_descent_plan,
    evaluate_safe_descent_endpoint,
    load_alignment_config,
    resolve_adaptive_pregrasp_config,
)
from s1_control.go2_visual_alignment import blended_support_up_normal
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    gravity_vector_base_rear_down,
    locate_official_gripper_urdf,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class LinearKinematics:
    def fk(self, q):
        return [float(q[0]), float(q[1]), float(q[2]), 0.0, 0.0, 0.0, 1.0]


class Go2VisualAdaptivePregraspTests(unittest.TestCase):
    def config(self):
        _, config = load_alignment_config(
            PROJECT_ROOT
            / "config/go2_crouch_right_visual_adaptive_pregrasp_nocw_metalbracket_v1.json"
        )
        return config

    @staticmethod
    def final_capture(height_p90=51.88599319458008):
        return {
            "detection": {
                "selected": {
                    "accepted": True,
                    "target_id": "component_001",
                    "core_height_mm": {
                        "p10": height_p90 - 1.0,
                        "median": height_p90 - 0.5,
                        "p90": height_p90,
                    },
                }
            }
        }

    def test_config_is_bound_and_forbids_low_view_recheck_and_contact(self):
        config = self.config()
        self.assertEqual(config["operation"], "adaptive_pregrasp_round_trip")
        self.assertEqual(config["adaptive_pregrasp"]["height_statistic"], "p90")
        self.assertEqual(
            config["adaptive_pregrasp"]["clearance_above_detected_top_mm"],
            20.0,
        )
        forbidden = set(config["physical_scope"]["forbidden_actions"])
        self.assertIn("low_view_camera_recheck", forbidden)
        self.assertIn("descent_below_adaptive_pregrasp_clearance", forbidden)
        self.assertIn("contact", forbidden)
        self.assertIn("gripper_close", forbidden)

    def test_real_v2_height_handoff_targets_20mm_above_top(self):
        config = self.config()["adaptive_pregrasp"]
        effective, handoff = resolve_adaptive_pregrasp_config(
            self.final_capture(), config
        )
        self.assertAlmostEqual(handoff["target_height_mm"], 51.88599319458008)
        self.assertAlmostEqual(effective["target_normal_clearance_mm"], 20.0)
        self.assertEqual(
            handoff["target_clearance_reference"],
            "selected_target_top_surface",
        )
        self.assertAlmostEqual(
            handoff["predicted_support_plane_clearance_mm"],
            71.88599319458008,
        )
        self.assertFalse(handoff["low_view_camera_recheck_required"])
        self.assertTrue(handoff["low_view_camera_recheck_forbidden"])

    def test_rejects_missing_rejected_or_out_of_range_height(self):
        config = self.config()["adaptive_pregrasp"]
        with self.assertRaises(ValueError):
            resolve_adaptive_pregrasp_config({}, config)
        rejected = self.final_capture()
        rejected["detection"]["selected"]["accepted"] = False
        with self.assertRaises(ValueError):
            resolve_adaptive_pregrasp_config(rejected, config)
        with self.assertRaises(ValueError):
            resolve_adaptive_pregrasp_config(self.final_capture(80.0), config)

    def test_effective_plan_stops_20mm_above_detected_top(self):
        config = self.config()
        descent, handoff = resolve_adaptive_pregrasp_config(
            self.final_capture(50.0), config["adaptive_pregrasp"]
        )
        observation = {
            "surface_point_base_m": [0.0, 0.0, 0.0],
            "support_up_normal_base": [0.0, 0.0, 1.0],
        }

        def fake_ik(_kin, q_start, tcp_targets, **_kwargs):
            path = [list(q_start)]
            path.extend(
                [[pose[0], pose[1], pose[2], 0.0, 0.0, 0.0] for pose in tcp_targets]
            )
            return {"joint_path": path, "status": "fake_ok"}

        with patch(
            "scripts.run_go2_visual_alignment.solve_continuous_ik_path",
            side_effect=fake_ik,
        ), patch(
            "scripts.run_go2_visual_alignment.check_collision_path",
            return_value={"sample_count": 18},
        ), patch(
            "scripts.run_go2_visual_alignment.validate_torque_envelope",
            return_value={"maximum_limit_fraction": 0.6},
        ):
            plan = compute_safe_descent_plan(
                [0.0, 0.0, 0.225, 0.0, 0.0, 0.0],
                observation,
                descent_config=descent,
                alignment={
                    "maximum_fk_position_error_mm": 1.0,
                    "maximum_fk_orientation_error_deg": 0.5,
                },
                tcp_kinematics=LinearKinematics(),
                collision_checker=object(),
                tilt_model=object(),
                applied_support_up=[0.0, 0.0, 1.0],
                side_scale=1.0,
                torque_limits=[1.0] * 6,
            )
        self.assertAlmostEqual(plan["target_normal_clearance_mm"], 20.0)
        self.assertAlmostEqual(plan["descent_distance_mm"], 205.0)
        self.assertEqual(plan["segment_count"], 21)
        endpoint = evaluate_safe_descent_endpoint(
            plan,
            plan["joint_path"][-1],
            descent_config=descent,
            tcp_kinematics=LinearKinematics(),
        )
        self.assertTrue(endpoint["passed"])
        self.assertAlmostEqual(endpoint["measured_normal_clearance_mm"], 20.0)
        self.assertAlmostEqual(
            handoff["predicted_support_plane_clearance_mm"], 70.0
        )

    def test_real_safe_descent_v2_detection_replay_when_present(self):
        replay = (
            PROJECT_ROOT
            / "data/go2_visual_alignment_runs"
            / "new_s1_go2_nocw_metalbracket_safe_descent_v2"
            / "final_detection.json"
        )
        if not replay.is_file():
            self.skipTest("local v2 replay fixture is not present")
        detection = json.loads(replay.read_text(encoding="utf-8"))
        descent, handoff = resolve_adaptive_pregrasp_config(
            {"detection": detection}, self.config()["adaptive_pregrasp"]
        )
        self.assertEqual(handoff["target_id"], "component_001")
        self.assertAlmostEqual(descent["target_normal_clearance_mm"], 20.0)
        self.assertAlmostEqual(
            handoff["predicted_support_plane_clearance_mm"],
            71.88599319458008,
        )

    def test_real_v2_joint_path_collision_and_torque_replay_when_present(self):
        try:
            from S1_SDK.hardware.collision import CollisionChecker
        except ModuleNotFoundError as exc:
            self.skipTest(str(exc))
        run_path = (
            PROJECT_ROOT
            / "data/go2_visual_alignment_runs"
            / "new_s1_go2_nocw_metalbracket_safe_descent_v2"
            / "run.json"
        )
        if not run_path.is_file():
            self.skipTest("real safe-descent v2 run is not present")
        run = json.loads(run_path.read_text(encoding="utf-8"))
        config = self.config()
        descent, _ = resolve_adaptive_pregrasp_config(
            run["final_capture"], config["adaptive_pregrasp"]
        )
        mount = json.loads(
            (
                PROJECT_ROOT
                / "config/go2_crouch_mount_nocw_metalbracket_measured_v1.json"
            ).read_text(encoding="utf-8")
        )
        model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        nominal_support_up = -gravity_vector_base_rear_down(
            float(mount["mount_measurement"]["rear_edge_lower_deg"])
        ) / 9.80665
        applied_support_up = blended_support_up_normal(
            nominal_support_up,
            run["final_observation"]["support_up_normal_base"],
            0.5,
        )
        checker = CollisionChecker("gripper")
        if checker.model is None:
            checker._load_model(gripper=True)
        plan = compute_safe_descent_plan(
            run["final_q_rad"],
            run["final_observation"],
            descent_config=descent,
            alignment=config["alignment"],
            tcp_kinematics=Kinematics(verbose=False),
            collision_checker=checker,
            tilt_model=model,
            applied_support_up=applied_support_up,
            side_scale=1.0,
            torque_limits=mount["diagnostic"]["correction_absolute_limits_nm"],
        )
        self.assertAlmostEqual(plan["initial_normal_clearance_mm"], 224.1528, places=3)
        self.assertAlmostEqual(plan["target_normal_clearance_mm"], 20.0, places=3)
        self.assertAlmostEqual(plan["descent_distance_mm"], 204.1528, places=3)
        self.assertEqual(plan["segment_count"], 21)
        self.assertEqual(plan["collision"]["active_collision_count"], 0)
        self.assertEqual(plan["collision"]["floor_contact_count"], 0)
        self.assertLess(plan["torque"]["maximum_limit_fraction"], 1.0)


if __name__ == "__main__":
    unittest.main()
