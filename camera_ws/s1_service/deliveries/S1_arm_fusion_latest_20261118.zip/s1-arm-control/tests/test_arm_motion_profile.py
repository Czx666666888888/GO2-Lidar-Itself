# -*- coding: utf-8 -*-
"""Pure offline regression tests for joint interpolation profiles."""
import math
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from s1_control.arm import (
    Arm,
    S_CURVE_BLEND_FRACTION,
    SafetyLimits,
    joint_path_motion_duration_s,
    joint_path_target,
    joint_path_total_delta,
    motion_duration_s,
    motion_profile_peak_factor,
    motion_profile_progress,
)


class ArmMotionProfileTests(unittest.TestCase):
    @staticmethod
    def diagnostic_guard_arm():
        arm = Arm.__new__(Arm)
        arm.limits = SafetyLimits()
        arm._speed_strikes = 0
        return arm

    def test_elapsed_clock_accounts_for_serial_cost_and_caps_stalls(self):
        from types import SimpleNamespace

        def replay(method, elapsed, serial_cost):
            clock = [0.0]
            commands = []
            arm = Arm.__new__(Arm)
            arm.dt = .02
            arm.limits = SafetyLimits(
                v_max_rad_s=.2, j6_v_max_rad_s=.1,
                elapsed_cycle_progress=elapsed,
            )
            def command(q):
                commands.append((clock[0], list(q)))
                clock[0] += serial_cost
            arm.command_position = command
            arm._arm = SimpleNamespace(
                get_pos=lambda: commands[-1][1], get_vel=lambda: [0.] * 6,
                get_temp=lambda: [25.] * 7,
            )
            arm.guard = lambda *args, **kwargs: None
            start = [0.] * 6
            end = [.1, 0., 0., 0., 0., .04]
            simulated_time = SimpleNamespace(
                monotonic=lambda: clock[0],
                sleep=lambda delay: clock.__setitem__(0, clock[0] + delay),
            )
            with patch("s1_control.arm.time", simulated_time):
                fault = (arm.move(start, end, "test") if method == "move"
                         else arm.move_waypoints([start, end], "test"))
            self.assertIsNone(fault)
            self.assertEqual(commands[0][1], start)
            np_end = commands[-1][1]
            for actual, expected in zip(np_end, end):
                self.assertAlmostEqual(actual, expected)
            for (_, left), (_, right) in zip(commands, commands[1:]):
                self.assertLessEqual(abs(right[0] - left[0]), .2 * 2 * arm.dt + 1e-12)
                self.assertLessEqual(abs(right[5] - left[5]), .1 * 2 * arm.dt + 1e-12)
            return clock[0]

        for method in ("move", "move_waypoints"):
            self.assertLess(replay(method, True, .03), replay(method, False, .03))
            replay(method, True, .2)

    def test_tracking_lag_repeats_target_then_resumes_and_keeps_other_guards(self):
        from types import SimpleNamespace

        def replay(method, fault_kind=None):
            clock = [0.0]
            commands = []
            lag = {"started": False, "remaining": 0}
            arm = Arm.__new__(Arm)
            arm.dt = .02
            arm._speed_strikes = 0
            arm.limits = SafetyLimits(
                v_max_rad_s=.3, pause_on_tracking_lag=True,
                elapsed_cycle_progress=True, settle_seconds=0,
            )
            arm.command_position = lambda q: commands.append(list(q))
            def measured():
                q = commands[-1].copy()
                if not lag["started"] and q[0] > .1:
                    lag.update(started=True, remaining=4)
                if lag["remaining"]:
                    q[0] -= .09
                    lag["remaining"] -= 1
                return q
            arm._arm = SimpleNamespace(
                get_pos=measured,
                get_vel=lambda: [.6 if fault_kind == "speed" and lag["remaining"] else 0.] * 6,
                get_temp=lambda: [56. if fault_kind == "temperature" and lag["remaining"] else 25.] * 7,
            )
            simulated_time = SimpleNamespace(
                monotonic=lambda: clock[0],
                sleep=lambda delay: clock.__setitem__(0, clock[0] + delay),
            )
            start = [0.] * 6
            end = [.3, 0., 0., 0., 0., 0.]
            with patch("s1_control.arm.time", simulated_time):
                result = (arm.move(start, end, "test") if method == "move"
                          else arm.move_waypoints([start, end], "test"))
            return result, commands, end

        for method in ("move", "move_waypoints"):
            result, commands, end = replay(method)
            self.assertIsNone(result)
            self.assertTrue(any(a == b for a, b in zip(commands, commands[1:])))
            for actual, expected in zip(commands[-1], end):
                self.assertAlmostEqual(actual, expected)
            result, _, _ = replay(method, "temperature")
            self.assertIn("temp>", result)
            result, _, _ = replay(method, "speed")
            self.assertIn("speed>", result)

    def test_linear_profile_is_unchanged(self):
        for u in (0.0, 0.1, 0.5, 0.9, 1.0):
            self.assertEqual(motion_profile_progress(u, "linear"), u)
        self.assertEqual(motion_profile_peak_factor("linear"), 1.0)

    def test_gravity_cycle_is_forwarded_to_official_sdk(self):
        class FakeSdkArm:
            def __init__(self):
                self.calls = 0

            def gravity(self):
                self.calls += 1
                return "gravity-result"

        arm = Arm.__new__(Arm)
        arm._arm = FakeSdkArm()
        self.assertEqual(arm.gravity(), "gravity-result")
        self.assertEqual(arm._arm.calls, 1)

    def test_explicit_position_commander_routes_position_commands(self):
        class FakeSdkArm:
            def __init__(self):
                self.default_calls = []

            def joint_control_mit(self, target):
                self.default_calls.append(list(target))

        calls = []
        arm = Arm.__new__(Arm)
        arm._arm = FakeSdkArm()
        arm._position_commander = None
        arm.command_position([0.0] * 6)
        self.assertEqual(arm._arm.default_calls, [[0.0] * 6])

        arm.set_position_commander(
            lambda active_arm, target: calls.append(
                (active_arm, list(target))
            )
        )
        arm.command_position([0.1] * 6)
        self.assertEqual(calls, [(arm, [0.1] * 6)])
        self.assertEqual(arm._arm.default_calls, [[0.0] * 6])

        with self.assertRaises(ValueError):
            arm.command_position([0.0] * 5)

    def test_s_curve_is_monotonic_bounded_and_exact_at_endpoints(self):
        values = [
            motion_profile_progress(index / 1000.0, "s_curve")
            for index in range(1001)
        ]
        self.assertEqual(values[0], 0.0)
        self.assertAlmostEqual(values[-1], 1.0, places=12)
        self.assertTrue(all(0.0 <= value <= 1.0 for value in values))
        self.assertTrue(all(a <= b for a, b in zip(values, values[1:])))

    def test_s_curve_starts_and_ends_with_near_zero_speed(self):
        epsilon = 1e-4
        start_slope = motion_profile_progress(epsilon, "s_curve") / epsilon
        end_slope = (
            1.0 - motion_profile_progress(1.0 - epsilon, "s_curve")
        ) / epsilon
        self.assertLess(start_slope, 1e-4)
        self.assertLess(end_slope, 1e-4)

    def test_s_curve_peak_speed_factor_matches_sampled_profile(self):
        expected = 1.0 / (1.0 - S_CURVE_BLEND_FRACTION)
        self.assertAlmostEqual(
            motion_profile_peak_factor("s_curve"),
            expected,
            places=12,
        )
        count = 10000
        values = [
            motion_profile_progress(index / count, "s_curve")
            for index in range(count + 1)
        ]
        sampled_peak = max(
            (b - a) * count for a, b in zip(values, values[1:])
        )
        self.assertLessEqual(sampled_peak, expected * 1.000001)
        self.assertGreater(sampled_peak, expected * 0.999)

    def test_trial_s_curve_is_smoother_and_faster_than_validated_linear(self):
        delta_rad = 0.81
        linear_008 = motion_duration_s(delta_rad, 0.08, "linear")
        s_curve_012 = motion_duration_s(delta_rad, 0.12, "s_curve")
        self.assertTrue(math.isclose(linear_008, 10.125))
        self.assertTrue(math.isclose(s_curve_012, 8.4375))
        self.assertLess(s_curve_012, linear_008)

    def test_invalid_profile_and_speed_are_rejected(self):
        with self.assertRaises(ValueError):
            motion_profile_progress(0.5, "unknown")
        with self.assertRaises(ValueError):
            motion_duration_s(0.5, 0.0, "s_curve")

    def test_piecewise_joint_path_preserves_checked_waypoints(self):
        path = [
            [0.0] * 6,
            [0.1] * 6,
            [0.3] * 6,
        ]
        self.assertAlmostEqual(joint_path_total_delta(path), 0.3)
        self.assertEqual(joint_path_target(path, 0.0), path[0])
        self.assertEqual(joint_path_target(path, 1.0), path[-1])
        for actual, expected in zip(
            joint_path_target(path, 1.0 / 3.0), path[1]
        ):
            self.assertAlmostEqual(actual, expected)

    def test_global_s_curve_does_not_stop_at_internal_waypoint(self):
        path = [
            [0.0] * 6,
            [0.1] * 6,
            [0.2] * 6,
        ]
        epsilon = 1e-4
        before = joint_path_target(
            path, motion_profile_progress(0.5 - epsilon, "s_curve")
        )[0]
        middle = joint_path_target(
            path, motion_profile_progress(0.5, "s_curve")
        )[0]
        after = joint_path_target(
            path, motion_profile_progress(0.5 + epsilon, "s_curve")
        )[0]
        self.assertGreater(middle - before, 0.0)
        self.assertGreater(after - middle, 0.0)
        self.assertAlmostEqual(middle, 0.1)

    def test_global_path_timing_respects_joint_speed_limit(self):
        path = [
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.05, 0.10, -0.08, 0.02, 0.0, 0.0],
            [0.10, 0.20, -0.12, 0.08, 0.0, 0.0],
        ]
        speed_limit = 0.2
        duration = motion_duration_s(
            joint_path_total_delta(path), speed_limit, "s_curve"
        )
        count = 10000
        targets = [
            joint_path_target(
                path, motion_profile_progress(index / count, "s_curve")
            )
            for index in range(count + 1)
        ]
        dt = duration / count
        sampled_peak = max(
            max(abs(b - a) for a, b in zip(q_a, q_b)) / dt
            for q_a, q_b in zip(targets, targets[1:])
        )
        self.assertLessEqual(sampled_peak, speed_limit * 1.00001)

    def test_synchronized_path_respects_independent_j6_speed_limit(self):
        path = [
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.8, 0.2, 0.0, 0.0, 0.35],
            [0.0, 1.6, 0.4, 0.0, 0.0, 0.76],
        ]
        global_limit = 0.20
        j6_limit = 0.08
        duration = joint_path_motion_duration_s(
            path,
            global_limit,
            j6_limit,
            "s_curve",
        )
        global_only_duration = motion_duration_s(
            joint_path_total_delta(path),
            global_limit,
            "s_curve",
        )
        self.assertGreater(duration, global_only_duration)

        count = 10000
        targets = [
            joint_path_target(
                path, motion_profile_progress(index / count, "s_curve")
            )
            for index in range(count + 1)
        ]
        dt = duration / count
        sampled_j6_peak = max(
            abs(q_b[5] - q_a[5]) / dt
            for q_a, q_b in zip(targets, targets[1:])
        )
        sampled_other_peak = max(
            max(
                abs(q_b[index] - q_a[index]) / dt
                for index in range(5)
            )
            for q_a, q_b in zip(targets, targets[1:])
        )
        self.assertLessEqual(sampled_j6_peak, j6_limit * 1.00001)
        self.assertLessEqual(sampled_other_peak, global_limit * 1.00001)

    def test_blocked_control_cycles_do_not_advance_wall_clock_targets(self):
        class FakeSdkArm:
            def __init__(self):
                self.commands = []

            def joint_control_mit(self, target):
                self.commands.append(list(target))

            def get_pos(self):
                return list(self.commands[-1]) + [0.0]

            def get_vel(self):
                return [0.0] * 7

            def get_temp(self):
                return [30.0] * 7

        arm = Arm.__new__(Arm)
        arm.limits = SafetyLimits(
            hz=10.0,
            v_max_rad_s=1.0,
            j6_v_max_rad_s=1.0,
            motion_profile="linear",
            settle_seconds=0.0,
        )
        arm.dt = 0.1
        arm._arm = FakeSdkArm()
        arm.guard = lambda *args, **kwargs: None

        wall_time = [0.0]

        def stalled_monotonic():
            wall_time[0] += 1.0
            return wall_time[0]

        path = [[0.0] * 6, [0.8, 0.0, 0.0, 0.0, 0.0, 0.0]]
        with patch(
            "s1_control.arm.time.monotonic",
            side_effect=stalled_monotonic,
        ), patch("s1_control.arm.time.sleep"):
            result = arm.move_waypoints(path, "stalled-test")

        self.assertIsNone(result)
        self.assertGreater(len(arm._arm.commands), 5)
        self.assertAlmostEqual(arm._arm.commands[0][0], 0.0)
        self.assertAlmostEqual(arm._arm.commands[1][0], 0.1)
        self.assertAlmostEqual(arm._arm.commands[-1][0], 0.8)
        self.assertTrue(
            all(
                later[0] >= earlier[0]
                for earlier, later in zip(
                    arm._arm.commands, arm._arm.commands[1:]
                )
            )
        )

    def test_speed_guard_keeps_three_strike_behavior_and_reports_evidence(self):
        arm = self.diagnostic_guard_arm()
        results = []
        with patch(
            "s1_control.arm.time.monotonic",
            side_effect=[0.00, 0.02, 0.04],
        ):
            for sample_index in range(3):
                measured = [0.0, 0.0, 0.004 * sample_index, 0.0, 0.0, 0.0]
                results.append(
                    arm.guard(
                        measured,
                        [0.0, 0.0, 0.7, 0.0, 0.0, 0.0],
                        [30.0] * 7,
                        measured,
                        settling=False,
                    )
                )

        self.assertIsNone(results[0])
        self.assertIsNone(results[1])
        self.assertIn("speed>0.5 x3", results[2])
        self.assertIn("J3=+0.700", results[2])
        self.assertIn("sdk_frames=[", results[2])
        self.assertIn("pos_window_ms=40.0", results[2])
        self.assertIn("pos_vel=[+0.000,+0.000,+0.200", results[2])
        self.assertIn("track_err_max=0.0000", results[2])

    def test_speed_guard_low_sample_resets_strikes_and_evidence(self):
        arm = self.diagnostic_guard_arm()
        high = [0.6, 0.0, 0.0, 0.0, 0.0, 0.0]
        low = [0.2, 0.0, 0.0, 0.0, 0.0, 0.0]
        results = []
        with patch(
            "s1_control.arm.time.monotonic",
            side_effect=[0.00, 0.02, 0.04, 0.06, 0.08, 0.10],
        ):
            for velocity in (high, high, low, high, high, high):
                results.append(
                    arm.guard(
                        [0.0] * 6,
                        velocity,
                        [30.0] * 7,
                        [0.0] * 6,
                        settling=False,
                    )
                )

        self.assertTrue(all(result is None for result in results[:5]))
        self.assertIn("speed>0.5 x3", results[5])
        self.assertEqual(results[5].count("J1=+0.600"), 3)


if __name__ == "__main__":
    unittest.main()
