import copy
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import run_go2_visual_alignment as flow
from s1_control.kinematics import Kinematics

class J6HandoffTests(unittest.TestCase):
    def setUp(self):
        self.run=json.loads((flow.PROJECT_ROOT/"data/go2_visual_alignment_runs/alignment_20261113-235000/run.json").read_text())
        self.record=self.run["alignment_endpoint_convergence_pass_1"]
        self.tracking=self.record["attempts"][0]["tracking"]
        self.vision={**self.record["limits"]["vision_handoff"],"j6_tracking_diagnostic_only":True}
    def test_logged_j6_error_proceeds_only_to_final_visual_verification(self):
        config={**self.record["limits"],"validated_workspace":{"advisory_bounds":True},"j6_tracking_diagnostic_only":True}
        # Workspace validation has its own replay tests. This case exercises the
        # actual convergence function with the failed run's joint measurements.
        arm=SimpleNamespace(_position_commander=SimpleNamespace(phase=""))
        with patch.object(flow,"sample_endpoint_hold",return_value=self.tracking["measured_q_rad"]),patch.object(flow,"validate_workspace_point"),patch.object(flow,"run_worker_while_holding",side_effect=AssertionError("must not chase J6")):
            result=flow.converge_observation_endpoint(arm,self.record["desired_q_rad"],
                endpoint_config=config,kinematics=Kinematics(verbose=False),collision_checker=None,
                tilt_model=None,support_up_normal_base=[0,0,1],compensation_scale=0,
                torque_limits=[1]*6,vision_handoff_config=self.vision,
                vision_handoff_support_up_normal_base=[0,0,1],continuous_command_handoff=True,
                initial_command_q=self.record["attempts"][0]["command_q_rad"])
        self.assertEqual(result["status"],"passed_to_final_vision_gate_only")
        self.assertFalse(result["authorizes_descent"])
        self.assertGreater(result["final_tracking"]["maximum_abs_joint_error_rad"],.05)
        self.assertLess(result["vision_handoff"]["measured_joint_error_rad"],.027)
    def test_position_and_other_joints_still_decide_visual_handoff(self):
        for kind in ["j2","tcp"]:
            t=copy.deepcopy(self.tracking)
            if kind=="j2":t["joint_error_rad"][1]=.06
            else:t["tcp_error_norm_mm"]=8
            result=flow.endpoint_vision_handoff_decision(t,[0,0,1],self.vision)
            self.assertFalse(result["allowed"])

if __name__=="__main__":unittest.main()
