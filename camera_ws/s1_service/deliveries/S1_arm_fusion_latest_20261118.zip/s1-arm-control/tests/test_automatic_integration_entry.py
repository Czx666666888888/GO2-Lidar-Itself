from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import run_go2_visual_alignment as flow
from test_arm_integration import FakeArm

class AutomaticEntryTests(unittest.TestCase):
    def test_default_execute_does_not_read_e_or_d(self):
        arm=FakeArm()
        arm.preflight=lambda *a,**k:None
        def enabled():
            arm.enable_reached=True
            raise RuntimeError("offline test stops before enable")
        arm.enable=enabled
        with tempfile.TemporaryDirectory() as tmp,patch.object(flow,"DEFAULT_OUTPUT_ROOT",Path(tmp)),patch.object(flow,"Arm",return_value=arm),patch.object(flow,"wait_for_valid_feedback",return_value=([0]*6,[20]*7,{"ready":True})),patch("builtins.input",side_effect=AssertionError("no keyboard confirmations")):
            code=flow.main(["--config","config/go2_dual_white_light_full_flow_size_adaptive_v1.json","--all-joint-speed-rad-s","1.5","--descent-speed-rad-s","0.75","--execute"])
        self.assertTrue(arm.enable_reached)
        self.assertEqual(code,1)
        self.assertEqual(arm.disabled,1)

if __name__=="__main__":unittest.main()
