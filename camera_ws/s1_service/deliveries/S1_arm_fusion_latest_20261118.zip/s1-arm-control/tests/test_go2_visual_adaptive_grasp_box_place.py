"""Offline gates for the first supervised 50mm/40g grasp-to-box run."""
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import yaml

from scripts import run_go2_visual_alignment as alignment
from scripts.run_go2_visual_alignment import (
    endpoint_vision_handoff_decision,
    final_contact_is_explicitly_allowed,
    compute_observation,
    load_alignment_config,
    load_bound_box_place_resources,
    loaded_fault_requires_operator_recovery,
    plan_grasp_orientation_j6_endpoint_trim,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = (
    PROJECT_ROOT
    / "config/go2_crouch_right_visual_adaptive_grasp_box_place_nocw_metalbracket_v1.json"
)


class Go2VisualAdaptiveGraspBoxPlaceTests(unittest.TestCase):
    def config(self):
        return load_alignment_config(CONFIG_PATH)[1]

    def test_scope_is_exactly_50mm_and_at_most_40g(self):
        config = self.config()
        self.assertEqual(
            config["operation"], "adaptive_grasp_box_place_round_trip"
        )
        box = config["adaptive_grasp_box_place"]
        self.assertEqual(box["target_edge_mm"], 50.0)
        self.assertEqual(box["maximum_test_mass_g"], 40.0)
        forbidden = set(config["physical_scope"]["forbidden_actions"])
        self.assertIn("payload_above_40g", forbidden)
        self.assertIn("unverified_box_route", forbidden)
        self.assertIn("automatic_loaded_fault_recovery", forbidden)
        self.assertNotIn("lift", forbidden)
        self.assertNotIn("box_place", forbidden)

    def test_final_normal_drift_override_is_local_and_bounded(self):
        config = self.config()
        box = config["adaptive_grasp_box_place"]
        override = box["alignment_working_threshold_override"]
        self.assertEqual(
            override["scope"],
            "go2_adaptive_grasp_box_place_round_trip_only",
        )
        self.assertEqual(override["maximum_final_normal_drift_mm"], 6.0)
        base_path = PROJECT_ROOT / config["base_alignment_config"]["path"]
        base = json.loads(base_path.read_text(encoding="utf-8"))
        self.assertEqual(
            base["alignment"]["maximum_final_normal_drift_mm"], 5.0
        )

    def test_low_endpoint_clearance_working_threshold_is_local_and_safe(self):
        secure = self.config()["adaptive_secure_no_lift"]
        self.assertEqual(secure["maximum_endpoint_clearance_error_mm"], 3.0)
        self.assertEqual(secure["minimum_support_plane_tcp_clearance_mm"], 6.5)
        self.assertIn("local to this 50mm/40g full-flow operation", secure["reason"])

    def test_stable_j6_undershoot_gets_one_bounded_j6_only_trim(self):
        config = self.config()["adaptive_grasp_orientation"]
        planned = [1.6765, 1.8190, 1.3113, 1.0170, 0.0062, 0.7102]
        measured = [1.6802, 1.8271, 1.3178, 1.0199, 0.0036, 0.6781]
        endpoint = {
            "passed": False,
            "reasons": ["joint_tracking_error_too_large"],
            "endpoint_window_stable": True,
            "tcp_position_drift_mm": 1.90,
            "orientation_error_deg": 2.08,
        }
        trim = plan_grasp_orientation_j6_endpoint_trim(
            planned, measured, endpoint, config
        )
        self.assertTrue(trim["eligible"])
        self.assertEqual(trim["reason"], "stable_j6_dominant_undershoot")
        self.assertAlmostEqual(trim["applied_j6_bias_rad"], 0.03)
        self.assertEqual(trim["command_q_rad"][:5], measured[:5])
        self.assertAlmostEqual(trim["command_q_rad"][5], planned[5] + 0.03)

    def test_j6_trim_can_recover_v7_tool_error_without_weakening_final_gate(self):
        config = self.config()["adaptive_grasp_orientation"]
        endpoint = {
            "passed": False,
            "reasons": [
                "joint_tracking_error_too_large",
                "tool_orientation_error_too_large",
            ],
            "endpoint_window_stable": True,
            "tcp_position_drift_mm": 2.37,
            "orientation_error_deg": 3.40,
        }
        planned = [1.6788, 1.8166, 1.3061, 1.0169, 0.0097, 0.7393]
        measured = [1.6848, 1.8252, 1.3113, 1.0199, 0.0074, 0.6865]
        trim = plan_grasp_orientation_j6_endpoint_trim(
            planned, measured, endpoint, config
        )
        self.assertTrue(trim["eligible"])
        self.assertLessEqual(abs(trim["j6_error_rad"]), 0.06)
        self.assertEqual(config["maximum_endpoint_orientation_error_deg"], 3.0)
        self.assertEqual(config["fallback_maximum_endpoint_joint_error_rad"], 0.032)

    def test_tool_direction_only_failure_trims_from_held_setpoint(self):
        import math

        class WristKinematics:
            def fk(self, q):
                return [0.0, 0.0, 0.0, 0.0, 0.0, math.sin(q[5] / 2), math.cos(q[5] / 2)]

        config = dict(self.config()["adaptive_grasp_orientation"],
                      maximum_endpoint_orientation_error_deg=4.0)
        hold = [0.01, 0.02, 0.0, 0.0, 0.0, -0.01]
        endpoint = {
            "passed": False,
            "reasons": ["tool_orientation_error_too_large"],
            "joint_error_scope": "J1-J5",
            "endpoint_window_stable": True,
        }
        trim = plan_grasp_orientation_j6_endpoint_trim(
            [0.0] * 6, [0.0] * 5 + [0.089], endpoint, config,
            tcp_kinematics=WristKinematics(), target_quaternion=[0.0, 0.0, 0.0, 1.0],
            hold_command_q=hold,
        )
        self.assertTrue(trim["eligible"])
        self.assertEqual(trim["command_q_rad"][:5], hold[:5])
        self.assertAlmostEqual(trim["command_q_rad"][5], hold[5] - 0.03)
        self.assertLess(trim["predicted_tool_orientation_error_deg"], 4.0)

    def test_j6_trim_rejects_non_j6_or_out_of_range_errors(self):
        config = self.config()["adaptive_grasp_orientation"]
        endpoint = {
            "passed": False,
            "reasons": ["joint_tracking_error_too_large"],
            "endpoint_window_stable": True,
            "tcp_position_drift_mm": 2.0,
            "orientation_error_deg": 2.0,
        }
        non_j6 = plan_grasp_orientation_j6_endpoint_trim(
            [0.0] * 6,
            [0.0, 0.0, 0.02, 0.0, 0.0, 0.01],
            endpoint,
            config,
        )
        self.assertFalse(non_j6["eligible"])
        self.assertEqual(non_j6["reason"], "j6_is_not_dominant_error")
        too_large = plan_grasp_orientation_j6_endpoint_trim(
            [0.0] * 6,
            [0.0, 0.0, 0.0, 0.0, 0.0, -0.061],
            endpoint,
            config,
        )
        self.assertFalse(too_large["eligible"])
        self.assertEqual(
            too_large["reason"], "j6_error_outside_bounded_trim_range"
        )

    def test_visual_timeout_override_is_local_and_inherits_other_runtime_fields(self):
        config = self.config()
        self.assertEqual(config["runtime"]["worker_timeout_s"], 45.0)
        self.assertFalse(
            config["runtime"]["write_raw_capture_previews_before_detection"]
        )
        self.assertEqual(config["runtime"]["capture_hold_hz"], 10.0)
        base_path = PROJECT_ROOT / config["base_alignment_config"]["path"]
        base = json.loads(base_path.read_text(encoding="utf-8"))
        self.assertEqual(base["runtime"]["worker_timeout_s"], 30.0)
        self.assertNotIn(
            "write_raw_capture_previews_before_detection", base["runtime"]
        )

    def test_current_go2_vision_depth_ratio_override_is_local(self):
        config = self.config()
        base_path = PROJECT_ROOT / config["base_alignment_config"]["path"]
        base = json.loads(base_path.read_text(encoding="utf-8"))
        wrist_path = PROJECT_ROOT / base["wrist_servo_config"]
        wrist = json.loads(wrist_path.read_text(encoding="utf-8"))
        local_path = PROJECT_ROOT / wrist["bindings"]["vision_config"]["path"]
        local = yaml.safe_load(local_path.read_text(encoding="utf-8"))
        global_config = yaml.safe_load(
            (PROJECT_ROOT / "config/wrist_cube_vision.yaml").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(
            local["component"]["min_core_depth_valid_ratio"], 0.87
        )
        self.assertEqual(
            global_config["component"]["min_core_depth_valid_ratio"], 0.90
        )

    def test_task_space_good_endpoint_hands_off_before_joint_bias_chasing(self):
        tracking = {
            "maximum_abs_joint_error_rad": 0.0195,
            "tcp_error_norm_mm": 2.3,
            "tcp_error_xyz_mm": [1.0, -1.8, -1.0],
        }
        decision = endpoint_vision_handoff_decision(
            tracking,
            [-0.09, -0.05, 0.995],
            {
                "maximum_joint_error_rad": 0.027,
                "maximum_tcp_error_mm": 7.0,
                "maximum_support_normal_error_mm": 5.0,
            },
        )
        self.assertTrue(decision["allowed"])
        self.assertFalse(decision["authorizes_descent"])

    def test_only_bound_contact_is_allowed_at_exact_return_endpoint(self):
        active = {
            (
                "geom1 (link=1_Link)",
                "geom5 (link=5_Link)",
            )
        }
        allowed = [["geom1", "geom5"]]
        self.assertTrue(
            final_contact_is_explicitly_allowed(
                active,
                set(),
                allowed,
                is_final_endpoint=True,
            )
        )
        self.assertFalse(
            final_contact_is_explicitly_allowed(
                active,
                set(),
                allowed,
                is_final_endpoint=False,
            )
        )
        self.assertFalse(
            final_contact_is_explicitly_allowed(
                active,
                {("floor", "geom5")},
                allowed,
                is_final_endpoint=True,
            )
        )

    def test_no_target_with_candidate_reports_the_actual_rejection(self):
        capture = {
            "detection": {
                "status": "NO_TARGET",
                "candidates": [
                    {
                        "component_id": 1,
                        "area_px": 3700,
                        "core_depth_valid_ratio": 0.885,
                        "reject_reasons": [
                            "core_depth_valid_ratio_too_low"
                        ],
                    }
                ],
            }
        }
        with self.assertRaisesRegex(
            ValueError, "candidate was found but rejected"
        ):
            compute_observation(
                capture,
                [0.0] * 6,
                loaded=None,
                flange_kinematics=None,
            )

    def test_full_flow_skips_raw_previews_before_detection(self):
        loaded = SimpleNamespace(
            record={
                "camera_serial": "test-camera",
                "capture": {
                    "width": 640,
                    "height": 480,
                    "fps": 30,
                    "warmup_frames": 15,
                    "depth_frames": 9,
                    "timeout_ms": 5000,
                    "minimum_valid_depth_ratio": 0.7,
                    "maximum_frame_interval_ms": 300.0,
                },
            }
        )
        capture = {
            "metadata": {"quality_pass": True, "quality_reasons": []},
            "rgb": object(),
        }
        detection = {"status": "DETECTED_CAMERA_FRAME_ONLY"}
        with (
            patch.object(alignment, "capture_aligned_rgbd", return_value=capture),
            patch.object(alignment, "save_capture") as save_capture,
            patch.object(alignment, "detect_capture", return_value=detection),
            patch.object(alignment, "save_result"),
            patch.object(alignment, "save_preview"),
        ):
            result = alignment.capture_and_detect(
                loaded,
                {},
                PROJECT_ROOT / "data" / "test_full_flow_preview_policy",
                "initial",
                write_raw_capture_previews=False,
            )
        self.assertFalse(result["raw_capture_previews_written"])
        self.assertFalse(save_capture.call_args.kwargs["write_preview"])

    def test_box_resources_bind_empty_physical_evidence(self):
        config = self.config()
        plan_path = PROJECT_ROOT / config["deployment_plan"]
        mount_path = alignment.resolve_project_path(
            __import__("json").loads(plan_path.read_text(encoding="utf-8"))[
                "mount_config"
            ]
        )
        (
            _box_plan_path,
            _box_report_path,
            _evidence_path,
            box_plan,
            report,
            evidence,
            scoped_mount,
            override,
        ) = load_bound_box_place_resources(
            config["adaptive_grasp_box_place"],
            deployment_plan_path=plan_path,
            mount_path=mount_path,
        )
        self.assertEqual(evidence["status"], "EMPTY_BOX_ROUTE_ROUND_TRIP_DONE")
        self.assertTrue(report["payload_gravity_model"]["passed"])
        self.assertEqual(box_plan["payload"]["maximum_mass_g"], 300.0)
        self.assertEqual(scoped_mount["diagnostic"]["allowed_scale_steps"][0], 0.20)
        self.assertEqual(override["torque_direction"], "reduced_only")

    def test_loaded_faults_never_enter_automatic_recovery(self):
        self.assertTrue(loaded_fault_requires_operator_recovery(True, True, False))
        self.assertTrue(loaded_fault_requires_operator_recovery(True, False, True))
        self.assertFalse(loaded_fault_requires_operator_recovery(True, False, False))
        self.assertFalse(loaded_fault_requires_operator_recovery(False, True, True))


if __name__ == "__main__":
    unittest.main()
