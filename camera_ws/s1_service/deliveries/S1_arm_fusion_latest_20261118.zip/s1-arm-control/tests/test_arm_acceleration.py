import math
import unittest
import numpy as np
from s1_control.arm import (_validated_joint_path,_joint_path_motion_duration_prepared,
    acceleration_limited_path_duration,motion_profile_progress)

class AccelerationTests(unittest.TestCase):
    def check_path(self,path,limit):
        points,lengths,total=_validated_joint_path(path)
        old=_joint_path_motion_duration_prepared(points,lengths,total,1.5,1.5,"s_curve")
        duration=acceleration_limited_path_duration(points,lengths,old,"s_curve",limit,.02)
        self.assertGreaterEqual(duration,old)
        times=np.linspace(0,duration,int(math.ceil(duration/.02))+1)
        progress=np.array([motion_profile_progress(t/duration,"s_curve") for t in times])
        cumulative=np.r_[0,np.cumsum(lengths)]
        q=np.column_stack([np.interp(progress*total,cumulative,np.array(points)[:,axis]) for axis in range(6)])
        velocity=np.diff(q,axis=0)/np.diff(times)[:,None]
        vt=np.r_[0,(times[:-1]+times[1:])/2,duration]
        a=np.diff(np.vstack([np.zeros(6),velocity,np.zeros(6)]),axis=0)/np.diff(vt)[:,None]
        self.assertLessEqual(np.max(np.abs(a)),limit+1e-8)
        self.assertLessEqual(np.max(np.abs(velocity)),1.5+1e-8)
        np.testing.assert_allclose(q[0],path[0]);np.testing.assert_allclose(q[-1],path[-1])
    def test_straight_start_stop(self):self.check_path([[0]*6,[1,0,0,0,0,0]],1)
    def test_corner_axis_change(self):self.check_path([[0]*6,[.4,0,0,0,0,0],[.4,.4,0,0,0,0]],1)
    def test_reversal(self):self.check_path([[0]*6,[.3,0,0,0,0,0],[-.2,0,0,0,0,0]],1)
    def test_gentler_descent_limit(self):
        self.check_path([[0]*6,[.2,.3,.1,0,0,0],[.25,.4,.08,0,0,0]],.25)
    def test_unconfigured_duration_preserved(self):
        self.assertEqual(acceleration_limited_path_duration(None,None,2,"s_curve",None,.02),2)

if __name__=="__main__":unittest.main()
