"""Offline sampling and evidence-semantics regressions for trace review."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from scripts.analyze_position_trace import analyze_trace, main


def row(t,index,measured=0.,phase='low_descent',delta=.0006):
    return dict(elapsed_s=t,command_index=index,phase=phase,
                command_q_rad=[0,0,0,.1,0,0],
                measured_q_rad=[0,0,0,measured,0,0],
                command_delta_rad=[0,0,0,delta,0,0],
                command_interval_s=.02,maximum_interval_since_record_s=.02)


class TraceReviewTests(unittest.TestCase):
    def test_sparse_rows_use_snapshot_window_not_control_tick(self):
        report=analyze_trace([row(1,50,.1),row(1.06,53,.124)])
        segment=report['segments'][0]
        self.assertAlmostEqual(segment['max_abs_measured_window_velocity_rad_s'][3],.4)
        self.assertAlmostEqual(segment['max_command_step_rad'],.0006)
        self.assertEqual(report['recorded_index_gaps'],1)
        self.assertIn('not SDK',report['measured_velocity_semantics'])

    def test_phase_boundary_has_no_cross_phase_velocity_or_repeat(self):
        report=analyze_trace([row(1,1,.1),row(1.1,2,.1),row(1.2,3,.5,'recovery')])
        first,last=report['segments']
        self.assertAlmostEqual(first['max_exact_repeat_window_s'][3],.1)
        self.assertEqual(last['measured_window_count'],0)
        self.assertEqual(last['max_abs_measured_window_velocity_rad_s'][3],0)
        self.assertEqual(last['entry_command_delta_rad'][3],.0006)

    def test_long_interval_between_logged_rows_is_retained(self):
        sample=row(1,1);sample['maximum_interval_since_record_s']=.278
        report=analyze_trace([sample])
        self.assertEqual(report['segments'][0]['max_recorded_command_interval_s'],.278)

    def test_missing_feedback_is_not_zero_or_fresh_feedback(self):
        sample=row(1,1);sample['measured_q_rad']=None
        report=analyze_trace([sample,row(1.1,2,.2)])
        self.assertEqual(report['segments'][0]['missing_measured_rows'],1)
        self.assertEqual(report['segments'][0]['measured_window_count'],0)
        self.assertEqual(report['feedback_freshness'],'not established by this trace')

    def test_invalid_samples_fail_instead_of_producing_plausible_statistics(self):
        for field,value in [('elapsed_s',float('nan')),('command_index',1.5),
                            ('command_interval_s',0),('command_q_rad',[0]*5),
                            ('measured_q_rad',[float('inf')]*6)]:
            sample=row(1,1);sample[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):analyze_trace([sample])
        for samples in [[],[row(1,1),row(1,2)],[row(1,2),row(2,1)]]:
            with self.assertRaises(ValueError):analyze_trace(samples)

    def test_report_never_overwrites_trace_or_existing_output(self):
        with tempfile.TemporaryDirectory() as folder:
            trace=Path(folder)/'trace.jsonl';trace.write_text(json.dumps(row(1,1))+'\n')
            before=trace.read_bytes()
            with self.assertRaises(SystemExit) as caught:main([str(trace),'--output',str(trace)])
            self.assertEqual(caught.exception.code,2)
            self.assertEqual(trace.read_bytes(),before)
            output=Path(folder)/'report.json'
            self.assertEqual(main([str(trace),'--output',str(output)]),0)
            self.assertEqual(json.loads(output.read_text())['recorded_rows'],1)
            self.assertEqual(trace.read_bytes(),before)


if __name__=='__main__':unittest.main()
