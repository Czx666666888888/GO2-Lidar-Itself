import json
from pathlib import Path
import unittest
import numpy as np
from demo_grasp.detect_science_target_rgbd import load_capture,load_config,detect_capture
from run_go2_visual_alignment import evaluate_safe_descent_endpoint,load_alignment_config,Kinematics
ROOT=Path(__file__).resolve().parents[1]

class FragmentReplayTests(unittest.TestCase):
    def test_complete_second_view_keeps_real_geometry_with_depth_holes(self):
        folder=ROOT/"data/go2_visual_alignment_runs/alignment_20261114-151159"
        frame=load_capture(folder/"search_view_02_capture.npz");before=frame["depth_m"].copy()
        cfg,_=load_config(ROOT/"config/wrist_cube_vision_go2_nocw_metalbracket_v1.yaml")
        cfg["workspace_roi"]["search_full_frame_on_miss"]=True
        result=detect_capture(frame,cfg)
        self.assertEqual(result["status"],"DETECTED_CAMERA_FRAME_ONLY")
        c=result["selected"]
        self.assertGreater(c["core_pixels"],1000)
        self.assertTrue(c["contour_completion"]["depth_measurements_unchanged"])
        self.assertLess(c["core_depth_valid_ratio"],.87)
        for side in c["orientation"]["rectangle_side_lengths_mm"]:
            self.assertGreater(side,45);self.assertLess(side,58)
        np.testing.assert_array_equal(before,frame["depth_m"])
    def test_logged_68mm_pregrasp_error_passes_10mm_acceptance(self):
        d=json.loads((ROOT/"data/go2_visual_alignment_runs/alignment_20261114-151441/run.json").read_text())
        _,cfg=load_alignment_config("config/go2_left_full_flow_size_adaptive_20261112_v1.json")
        config={**cfg["adaptive_pregrasp"],"maximum_endpoint_clearance_error_mm":10.0}
        plan=d["adaptive_pregrasp"]["planning"]
        result=evaluate_safe_descent_endpoint(plan,d["adaptive_pregrasp"]["endpoint"]["measured_q_rad"],descent_config=config,tcp_kinematics=Kinematics(verbose=False))
        self.assertTrue(result["passed"])
        self.assertLess(result["clearance_error_mm"],10)

if __name__=="__main__":unittest.main()
