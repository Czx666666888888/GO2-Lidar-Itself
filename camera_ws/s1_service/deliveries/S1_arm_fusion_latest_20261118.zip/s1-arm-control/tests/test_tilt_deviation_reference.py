"""Offline regressions for mount roll in the plausibility reference."""
import math
import unittest

import numpy as np

from s1_control.tilt_motion import commander_from_mount_record


class MountDeviationReferenceTests(unittest.TestCase):
    def setUp(self):
        self.mount = {
            "mount_measurement": {
                "rear_edge_lower_deg": 5.1,
                "left_right_tilt_deg": 4.0,
                "left_right_tilt_direction": "Go2右侧较低",
            },
            "diagnostic": {
                "allowed_scale_steps": [0.25, 0.5, 1.0],
                "correction_absolute_limits_nm": [1.2, .2, .2, .2, .2, .1],
            },
        }

    def commander(self, full=True, **kwargs):
        return commander_from_mount_record(
            None, self.mount, .25,
            deviation_reference_source=(
                "mount_record_pitch_roll" if full else "mount_record_pitch_only"
            ),
            support_normal_blend=.5,
            normal_transition_s=0,
            **kwargs,
        )

    def test_replay_battery_installed_passes_complete_reference(self):
        normal = [-.08455030539584471, -.09718270975168172, .9916686779276583]
        legacy = self.commander(False)
        legacy_result = legacy.set_support_up_normal(normal, source="logged_ground_plane")
        self.assertGreater(legacy_result["deviation_from_mount_nominal_deg"], 5)
        self.assertFalse(legacy_result["nominal_deviation_check_enabled"])
        corrected = self.commander()
        result = corrected.set_support_up_normal(normal, source="logged_ground_plane")
        self.assertAlmostEqual(result["deviation_from_mount_nominal_deg"], 1.608688, places=5)
        self.assertEqual(corrected.maximum_support_normal_deviation_deg, 5)

    def test_no_change_to_initial_blend_or_restore_compensation_reference(self):
        old = self.commander(False, maximum_support_normal_deviation_deg=6)
        new = self.commander()
        np.testing.assert_array_equal(old.nominal_support_up_normal_base,
                                      new.nominal_support_up_normal_base)
        np.testing.assert_array_equal(old._normal_target, new._normal_target)
        normal = [-.08455030539584471, -.09718270975168172, .9916686779276583]
        old.set_support_up_normal(normal, source="old_accepted_replay")
        result = new.set_support_up_normal(normal, source="corrected_replay")
        np.testing.assert_array_equal(old._normal_target, new._normal_target)
        restored = new.set_support_up_normal(new.nominal_support_up_normal_base,
                                             source="commissioned_restore")
        self.assertLess(restored["deviation_from_mount_nominal_deg"], 5)
        self.assertEqual(result["deviation_reference_source"], "mount_record_pitch_roll")

    def test_large_nominal_difference_is_diagnostic_only(self):
        n = np.array([-math.tan(math.radians(5.1)),
                      -math.tan(math.radians(10)), 1])
        n /= np.linalg.norm(n)
        result = self.commander(maximum_support_tilt_deg=15).set_support_up_normal(
            n, source="large_roll_change")
        self.assertGreater(result["deviation_from_mount_nominal_deg"], 5)
        self.assertFalse(result["nominal_deviation_check_enabled"])

    def test_missing_roll_does_not_silently_assume_zero(self):
        del self.mount["mount_measurement"]["left_right_tilt_deg"]
        with self.assertRaises(KeyError):
            self.commander()

    def test_unknown_direction_rejected(self):
        self.mount["mount_measurement"]["left_right_tilt_direction"] = "unknown"
        with self.assertRaisesRegex(ValueError, "roll direction"):
            self.commander()

    def test_left_edge_lower_has_opposite_sign(self):
        self.mount["mount_measurement"]["left_right_tilt_direction"] = "Go2左侧较低"
        self.assertGreater(self.commander().deviation_reference_support_up_normal_base[1], 0)

    def test_nonfinite_roll_rejected(self):
        self.mount["mount_measurement"]["left_right_tilt_deg"] = float("nan")
        with self.assertRaises(ValueError):
            self.commander()

    def test_legacy_factory_without_opt_in_unchanged(self):
        legacy = commander_from_mount_record(None, self.mount, .25)
        np.testing.assert_array_equal(legacy.nominal_support_up_normal_base,
                                      legacy.deviation_reference_support_up_normal_base)


if __name__ == "__main__":
    unittest.main()
