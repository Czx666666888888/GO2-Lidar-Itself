import json
import unittest
from pathlib import Path
from types import SimpleNamespace
from s1_control.arm import Arm, SafetyLimits

class J6TrackingLimitTests(unittest.TestCase):
    def feedback(self, measured):
        arm = Arm.__new__(Arm)
        arm.limits = SafetyLimits(max_track_err_rad=0.08,
                                  j6_max_track_err_rad=0.12,
                                  pause_on_tracking_lag=True)
        arm._arm = SimpleNamespace(get_pos=lambda: measured,
            get_vel=lambda: [0.] * 6, get_temp=lambda: [20.] * 7)
        arm.guard = lambda *args, **kwargs: None
        return arm._motion_feedback([0.] * 6, 'offline', False, False)[1]

    def test_logged_stall_can_continue(self):
        self.assertFalse(self.feedback([.020845, -.031639, .001377,
                                        .032889, .005541, .081453]))

    def test_j6_over_point_twelve_waits(self):
        self.assertTrue(self.feedback([0., 0., 0., 0., 0., .121]))

    def test_other_joints_keep_point_zero_eight(self):
        for index in range(5):
            measured = [0.] * 6
            measured[index] = .081
            self.assertTrue(self.feedback(measured))
