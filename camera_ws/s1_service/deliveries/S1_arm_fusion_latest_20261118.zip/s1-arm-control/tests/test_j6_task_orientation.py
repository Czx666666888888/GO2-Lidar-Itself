"""Complete-flow J6 endpoint precision follows the actual tool direction."""
import json,math
from pathlib import Path
import unittest
from scripts.run_go2_visual_alignment import evaluate_grasp_orientation_endpoint

class YawKinematics:
    def fk(self,q):return [q[0],0.,0.,0.,0.,math.sin(q[5]/2),math.cos(q[5]/2)]

class J6TaskOrientationTests(unittest.TestCase):
    def evaluate(self,task=True,q=None,window=.000381):
        root=Path(__file__).resolve().parents[1]
        cfg=json.loads((root/'config/go2_dual_white_light_full_flow_simplified_v1.json').read_text())['adaptive_grasp_orientation']
        q=q if q is not None else [.00248,.008965,.013021,.003741,.000155,.060087]
        return evaluate_grasp_orientation_endpoint([0.]*6,q,
            start_tcp_pose=[0.,0.,0.,0.,0.,0.,1.],target_quaternion=[0.,0.,0.,1.],
            config=cfg,tcp_kinematics=YawKinematics(),endpoint_window_range_rad=[window]*6,
            j6_checked_by_tool_orientation=task)

    def test_valid_tool_direction_is_not_rejected_again_by_j6_joint_angle(self):
        result=self.evaluate()
        self.assertTrue(result['passed'])
        self.assertEqual(result['joint_error_scope'],'J1-J5')
        self.assertAlmostEqual(result['evaluated_joint_error_rad'],.013021)
        self.assertAlmostEqual(result['tracking']['maximum_abs_joint_error_rad'],.060087)
        self.assertLess(result['orientation_error_deg'],4.)

    def test_legacy_endpoint_policy_retains_six_joint_acceptance(self):
        result=self.evaluate(task=False)
        self.assertFalse(result['passed']);self.assertIn('joint_tracking_error_too_large',result['reasons'])
        self.assertEqual(result['joint_error_scope'],'J1-J6')

    def test_arm_tracking_direction_and_tcp_errors_still_reject(self):
        cases=[([.00248,.04,.013021,0.,0.,.060087],'joint_tracking_error_too_large'),
               ([.00248,0.,0.,0.,0.,.08],'tool_orientation_error_too_large'),
               ([.006,0.,0.,0.,0.,.060087],'tcp_position_drift_too_large')]
        for q,reason in cases:
            with self.subTest(reason=reason):
                result=self.evaluate(q=q)
                self.assertFalse(result['passed']);self.assertIn(reason,result['reasons'])

    def test_unstable_endpoint_still_rejects(self):
        result=self.evaluate(window=.01)
        self.assertFalse(result['passed']);self.assertIn('endpoint_window_not_stable',result['reasons'])

if __name__=='__main__':unittest.main()
