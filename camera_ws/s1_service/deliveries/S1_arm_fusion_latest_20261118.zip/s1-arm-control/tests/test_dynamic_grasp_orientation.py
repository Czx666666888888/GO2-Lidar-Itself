# -*- coding: utf-8 -*-
"""Pure offline tests for square-yaw top-down grasp orientations."""
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from s1_control.kinematics import READY_Q
from scripts.plan_cube_hover import (
    TOPDOWN_R,
    candidate_selection_key,
    estimate_candidate_motion_metrics,
    load_base_hover_plan,
    orientation_candidates_from_pose,
    topdown_orientations_for_square_axis,
    validate_topdown_rotation,
)


class DynamicGraspOrientationTests(unittest.TestCase):
    def test_duration_scoring_prefers_short_wrist_route_for_20deg_square(self):
        def candidate(name, q_deg, margin_deg):
            q = [math.radians(value) for value in q_deg]
            record = {
                "orientation": name,
                "q": q,
                "max_delta_from_reference_rad": max(
                    abs(a - b) for a, b in zip(q, READY_Q)
                ),
                "minimum_joint_margin_deg": margin_deg,
                "position_error_mm": 0.0,
                "orientation_error_deg": 0.0,
            }
            record.update(estimate_candidate_motion_metrics(
                q,
                READY_Q,
                v_max_rad_s=0.20,
                j6_v_max_rad_s=0.10,
                motion_profile="s_curve",
            ))
            return record

        long_wrist = candidate(
            "edge90",
            [-0.75, 98.03, 65.73, 57.70, 0.0, 69.28],
            20.72,
        )
        short_wrist = candidate(
            "edge_roll180",
            [1.68, 99.10, 67.03, 57.87, 0.0, -18.30],
            29.13,
        )

        selected = min(
            [long_wrist, short_wrist],
            key=candidate_selection_key,
        )
        self.assertEqual(selected["orientation"], "edge_roll180")
        self.assertLess(
            short_wrist["estimated_motion_duration_s"],
            long_wrist["estimated_motion_duration_s"],
        )
        self.assertAlmostEqual(
            math.degrees(short_wrist["j6_delta_from_reference_rad"]),
            18.30,
            places=2,
        )
        self.assertGreater(
            long_wrist["estimated_motion_duration_s"],
            15.0,
        )
        self.assertLess(
            short_wrist["estimated_motion_duration_s"],
            10.0,
        )

    def test_square_axis_produces_four_equivalent_topdown_rotations(self):
        orientations = topdown_orientations_for_square_axis([1.0, 1.0, 0.02])
        self.assertEqual(
            [name for name, _ in orientations],
            ["edge", "edge_roll180", "edge90", "edge90_roll180"],
        )
        closing_axes = []
        for _, rotation in orientations:
            validated = validate_topdown_rotation(rotation)
            self.assertTrue(np.allclose(validated[:, 0], [0.0, 0.0, -1.0]))
            self.assertTrue(np.allclose(validated.T @ validated, np.eye(3)))
            self.assertAlmostEqual(float(np.linalg.det(validated)), 1.0)
            closing_axes.append(validated[:, 1])

        # Ignoring gripper-axis sign, the two unique axes are orthogonal.
        unique = [closing_axes[0], closing_axes[2]]
        self.assertAlmostEqual(float(unique[0] @ unique[1]), 0.0, places=12)
        self.assertTrue(np.allclose(closing_axes[1], -closing_axes[0]))
        self.assertTrue(np.allclose(closing_axes[3], -closing_axes[2]))

    def test_dynamic_pose_selects_square_candidates_and_legacy_still_loads(self):
        dynamic = {
            "visual_target": {
                "target_edge_axis_base": [0.6, 0.8, 0.0],
                "orientation_symmetry_period_deg": 90.0,
                "grasp_orientation_mode": "dynamic_topdown_square_edge_mod90",
            }
        }
        self.assertEqual(len(orientation_candidates_from_pose(dynamic)), 4)
        self.assertEqual(
            [name for name, _ in orientation_candidates_from_pose({})],
            ["as-is", "roll180"],
        )

    def test_dynamic_base_plan_locks_exact_selected_rotation(self):
        selected_name, selected_rotation = (
            topdown_orientations_for_square_axis([0.3, 0.95, 0.0])[2]
        )
        plan = {
            "joint_path": [
                {"name": "ready", "q": list(READY_Q)},
                {"name": "hover", "q": [0.1, 1.0, 1.0, 0.5, 0.1, 0.1]},
            ],
            "target_xyz_mm": [260.0, 10.0, 20.0],
            "target_rotation_matrix": selected_rotation.tolist(),
            "selected": {"orientation": selected_name},
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "hover.json"
            path.write_text(json.dumps(plan), encoding="utf-8")
            loaded = load_base_hover_plan(path)
        self.assertEqual(loaded[4], selected_name)
        self.assertTrue(np.allclose(loaded[5], selected_rotation))

    def test_invalid_non_vertical_approach_is_rejected(self):
        angle = math.radians(10.0)
        tilted = np.array([
            [math.cos(angle), 0.0, math.sin(angle)],
            [0.0, 1.0, 0.0],
            [-math.sin(angle), 0.0, math.cos(angle)],
        ])
        with self.assertRaises(ValueError):
            validate_topdown_rotation(tilted)

    def test_legacy_rotation_remains_valid(self):
        self.assertTrue(np.allclose(validate_topdown_rotation(TOPDOWN_R), TOPDOWN_R))


if __name__ == "__main__":
    unittest.main()
