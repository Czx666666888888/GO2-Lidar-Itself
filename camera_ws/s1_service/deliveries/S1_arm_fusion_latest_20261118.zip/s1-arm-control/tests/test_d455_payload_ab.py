import unittest

import numpy as np

from scripts.diagnose_d455_payload_ab import (
    comparison_record,
    payload_center_in_link,
)


class D455PayloadAbTests(unittest.TestCase):
    def test_camera_origin_is_transformed_into_gripper_frame(self):
        transform = np.eye(4)
        transform[:3, 3] = [0.089, -0.010, 0.060]
        np.testing.assert_allclose(
            payload_center_in_link(transform, [0.0, 0.0, 0.0]),
            [0.089, -0.010, 0.060],
        )

    def test_comparison_reports_b_minus_a_without_auto_enable(self):
        class LinearKinematics:
            def fk(self, q):
                return [q[0], q[1], q[2], 0.0, 0.0, 0.0, 1.0]

        command = [0.0] * 6
        condition_a = [0.010, 0.0, 0.0, 0.0, 0.0, 0.0]
        condition_b = [0.004, 0.0, 0.0, 0.0, 0.0, 0.0]
        result = comparison_record(
            command,
            condition_a,
            condition_b,
            {"camera_tilt_from_support_down_deg": 10.5},
            {"camera_tilt_from_support_down_deg": 9.5},
            LinearKinematics(),
        )
        self.assertAlmostEqual(
            result["maximum_joint_error_change_b_minus_a_rad"], -0.006
        )
        self.assertAlmostEqual(result["camera_tilt_change_b_minus_a_deg"], -1.0)
        self.assertIs(result["automatic_enable_decision"], False)


if __name__ == "__main__":
    unittest.main()
