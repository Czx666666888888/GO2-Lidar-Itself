import json
import tempfile
import unittest
from pathlib import Path

from scripts.execute_go2_observe_deployment import ramp_compensation_scale
from s1_control.go2_deployment import (
    file_sha256,
    interpolate_segment,
    joint_margin_deg,
    load_deployment_config,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)


class Go2DeploymentTests(unittest.TestCase):
    def test_compensation_scale_ramp_holds_pose_and_reaches_endpoint(self):
        class FakeCommander:
            def __init__(self):
                self.compensation_scale = 0.25
                self.history = []
                self.last_snapshot = {"clipped": False}

            def set_compensation_scale(self, value):
                self.compensation_scale = float(value)
                self.history.append(self.compensation_scale)

        class FakeArm:
            dt = 0.001

            def __init__(self):
                self.command_count = 0

            def command_position(self, _target_q):
                self.command_count += 1

            def get_pos(self):
                return [0.1] * 6 + [0.0]

            def get_vel(self):
                return [0.0] * 6

            def get_temp(self):
                return [30.0] * 7

            def guard(self, *_args, **_kwargs):
                return None

        arm = FakeArm()
        commander = FakeCommander()
        result = ramp_compensation_scale(
            arm,
            commander,
            [0.1] * 6,
            start_scale=0.25,
            end_scale=1.0,
            duration_s=0.01,
            label="test_ramp",
        )
        self.assertAlmostEqual(commander.compensation_scale, 1.0)
        self.assertGreaterEqual(result["sample_count"], 2)
        self.assertEqual(result["maximum_track_error_rad"], 0.0)
        self.assertEqual(commander.history, sorted(commander.history))

    def test_interpolation_respects_maximum_joint_step(self):
        rows = list(interpolate_segment([0] * 6, [0.0, 0.19, 0.38, 0.2, 0, 0], 0.01))
        self.assertEqual(rows[0][0], 0.0)
        self.assertEqual(rows[-1][0], 1.0)
        self.assertLessEqual(
            max(
                max_joint_delta(first[1], second[1])
                for first, second in zip(rows, rows[1:])
            ),
            0.0100001,
        )

    def test_start_window_accepts_measured_zero_neighborhood(self):
        windows = [
            [-0.08, 0.08], [-0.03, 0.08], [-0.03, 0.08],
            [-0.08, 0.12], [-0.08, 0.08], [-0.08, 0.08],
        ]
        self.assertEqual(start_window_violations([-0.02, -0.01, 0.01, 0.05, 0, 0], windows), [])
        self.assertTrue(start_window_violations([0.09, 0, 0, 0, 0, 0], windows))

    def test_ready_margin_is_about_ten_degrees(self):
        self.assertGreater(joint_margin_deg([0, 0.19, 0.38, 0.2, 0, 0]), 10.0)

    def test_config_has_expected_route(self):
        config = Path(__file__).resolve().parents[1] / "config" / "go2_crouch_right_observe_deployment.json"
        record = load_deployment_config(config)
        self.assertEqual(record["route"]["waypoints"][-1]["name"], "right_observe")
        schedule = record["motion"]["tilt_compensation"]
        self.assertEqual(schedule["transition_pose"], "right_ready")
        self.assertEqual(schedule["vertical_escape_scale"], 0.25)
        self.assertEqual(schedule["high_turn_scale"], 0.25)
        self.assertEqual(schedule["side_deploy_scale"], 1.0)
        self.assertGreater(schedule["scale_transition_s"], 0.0)

    def test_report_hash_binding(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            plan = root / "plan.json"
            mount = root / "mount.json"
            report = root / "report.json"
            plan.write_text("{}", encoding="utf-8")
            mount.write_text("{}", encoding="utf-8")
            report.write_text(json.dumps({
                "status": "OFFLINE_DEPLOYMENT_PASS",
                "source_plan_sha256": file_sha256(plan),
                "mount_config_sha256": file_sha256(mount),
                "self_collision_ok": True,
                "external_phase_envelope_ok": True,
                "joint_safety_ok": True,
                "tilt_torque_cap_ok": True,
            }), encoding="utf-8")
            self.assertEqual(verify_bound_report(plan, report, mount)["status"], "OFFLINE_DEPLOYMENT_PASS")
            plan.write_text('{"changed": true}', encoding="utf-8")
            with self.assertRaises(ValueError):
                verify_bound_report(plan, report, mount)

    def test_report_requires_tilt_torque_cap_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            plan = root / "plan.json"
            mount = root / "mount.json"
            report = root / "report.json"
            plan.write_text("{}", encoding="utf-8")
            mount.write_text("{}", encoding="utf-8")
            report.write_text(json.dumps({
                "status": "OFFLINE_DEPLOYMENT_PASS",
                "source_plan_sha256": file_sha256(plan),
                "mount_config_sha256": file_sha256(mount),
                "self_collision_ok": True,
                "external_phase_envelope_ok": True,
                "joint_safety_ok": True,
                "tilt_torque_cap_ok": False,
            }), encoding="utf-8")
            with self.assertRaises(ValueError):
                verify_bound_report(plan, report, mount)


if __name__ == "__main__":
    unittest.main()
