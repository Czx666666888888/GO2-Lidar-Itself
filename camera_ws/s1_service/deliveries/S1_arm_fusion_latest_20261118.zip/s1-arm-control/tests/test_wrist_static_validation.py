import csv
from pathlib import Path
import tempfile
import unittest

import numpy as np

from scripts.validate_wrist_target_static import (
    POSE_FIELDS,
    combine_pose_snapshots,
    evaluate_static_alignment,
    read_locked_pose_snapshot,
    support_plane_geometry,
)


POLICY = {
    "required_state": "locked",
    "maximum_age_s": 0.5,
    "window_s": 0.4,
    "minimum_samples": 5,
    "maximum_joint_span_rad": 0.003,
    "maximum_pre_post_delta_rad": 0.003,
}


class WristStaticValidationTests(unittest.TestCase):
    def write_pose_csv(self, rows):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        path = Path(temporary.name) / "pose.csv"
        with path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(POSE_FIELDS)
            writer.writerows(rows)
        return path

    @staticmethod
    def row(timestamp, state="locked", q1=1.0):
        return [timestamp, q1, 1.1, 1.2, 0.8, 0.1, 0.0, 1.0, state]

    def test_snapshot_accepts_fresh_stationary_locked_window(self):
        path = self.write_pose_csv(
            [self.row(99.7 + index * 0.05, q1=1.0 + index * 0.0001) for index in range(6)]
        )
        snapshot = read_locked_pose_snapshot(path, POLICY, now_s=100.0)
        self.assertEqual(snapshot["source_state"], "locked")
        self.assertEqual(snapshot["sample_count"], 6)
        self.assertLess(snapshot["maximum_joint_span_rad"], 0.003)

    def test_snapshot_rejects_non_locked_latest_state(self):
        rows = [self.row(99.7 + index * 0.05) for index in range(5)]
        rows.append(self.row(99.95, state="teaching"))
        path = self.write_pose_csv(rows)
        with self.assertRaisesRegex(RuntimeError, "expected 'locked'"):
            read_locked_pose_snapshot(path, POLICY, now_s=100.0)

    def test_snapshot_rejects_stale_data(self):
        path = self.write_pose_csv([self.row(90.0 + index * 0.05) for index in range(6)])
        with self.assertRaisesRegex(RuntimeError, "stale"):
            read_locked_pose_snapshot(path, POLICY, now_s=100.0)

    def test_snapshot_rejects_joint_motion(self):
        path = self.write_pose_csv(
            [self.row(99.7 + index * 0.05, q1=1.0 + index * 0.001) for index in range(6)]
        )
        with self.assertRaisesRegex(RuntimeError, "locked pose is moving"):
            read_locked_pose_snapshot(path, POLICY, now_s=100.0)

    def test_pre_post_pose_change_is_bounded(self):
        before = {"q_median_rad": [1.0, 1.1, 1.2, 0.8, 0.1, 0.0]}
        after = {"q_median_rad": [1.002, 1.1, 1.2, 0.8, 0.1, 0.0]}
        combined, delta = combine_pose_snapshots(before, after, POLICY)
        self.assertAlmostEqual(delta, 0.002)
        self.assertAlmostEqual(combined[0], 1.001)
        after["q_median_rad"][0] = 1.004
        with self.assertRaisesRegex(RuntimeError, "changed during RGB-D capture"):
            combine_pose_snapshots(before, after, POLICY)

    def test_static_alignment_pass_and_reject(self):
        safety = {
            "minimum_target_clearance_mm": 200.0,
            "maximum_target_clearance_mm": 300.0,
            "maximum_camera_tilt_from_down_deg": 15.0,
            "minimum_joint_margin_deg": 10.0,
        }
        static_policy = {"maximum_center_error_mm": 8.0}
        tcp = [0.2, 0.1, 0.3, 0.0, 0.0, 0.0, 1.0]
        target = [0.205, 0.096, 0.05]
        passed = evaluate_static_alignment(
            tcp,
            target,
            support_up_normal_base=[0.0, 0.0, 1.0],
            camera_optical_axis_base=[0.0, 0.0, -1.0],
            minimum_joint_margin_deg=20.0,
            safety=safety,
            static_policy=static_policy,
        )
        self.assertTrue(passed["passed"])
        self.assertAlmostEqual(
            passed["support_plane_horizontal_error_norm_mm"],
            np.hypot(5.0, -4.0),
        )

        target[0] = 0.215
        rejected = evaluate_static_alignment(
            tcp,
            target,
            support_up_normal_base=[0.0, 0.0, 1.0],
            camera_optical_axis_base=[0.0, 0.0, -1.0],
            minimum_joint_margin_deg=20.0,
            safety=safety,
            static_policy=static_policy,
        )
        self.assertFalse(rejected["passed"])
        self.assertIn("center_error_too_large", rejected["reasons"])

    def test_tilted_base_raw_xy_is_not_false_horizontal_error(self):
        safety = {
            "minimum_target_clearance_mm": 200.0,
            "maximum_target_clearance_mm": 300.0,
            "maximum_camera_tilt_from_down_deg": 15.0,
            "minimum_joint_margin_deg": 10.0,
        }
        static_policy = {"maximum_center_error_mm": 8.0}
        support_up = np.array([-0.08, -0.06, 0.9949874371])
        support_up /= np.linalg.norm(support_up)
        tcp = np.array([0.10, 0.20, 0.30, 0.0, 0.0, 0.0, 1.0])
        target = tcp[:3] - 0.250 * support_up
        result = evaluate_static_alignment(
            tcp,
            target,
            support_up_normal_base=support_up,
            camera_optical_axis_base=-support_up,
            minimum_joint_margin_deg=20.0,
            safety=safety,
            static_policy=static_policy,
        )
        self.assertTrue(result["passed"])
        self.assertGreater(result["raw_base_xy_error_norm_mm"], 20.0)
        self.assertAlmostEqual(
            result["support_plane_horizontal_error_norm_mm"], 0.0, places=6
        )
        self.assertAlmostEqual(result["normal_clearance_mm"], 250.0, places=6)

    def test_support_plane_geometry_transforms_normal_and_axis(self):
        transform = np.eye(4)
        angle = np.deg2rad(6.0)
        transform[:3, :3] = [
            [np.cos(angle), 0.0, np.sin(angle)],
            [0.0, 1.0, 0.0],
            [-np.sin(angle), 0.0, np.cos(angle)],
        ]
        geometry = support_plane_geometry([0.0, 0.0, -1.0], transform)
        normal = np.asarray(geometry["support_up_normal_base"])
        axis = np.asarray(geometry["camera_optical_axis_base"])
        self.assertGreater(normal[2], 0.0)
        np.testing.assert_allclose(axis, transform[:3, 2], atol=1e-12)


if __name__ == "__main__":
    unittest.main()
