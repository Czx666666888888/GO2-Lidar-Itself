import unittest
from types import SimpleNamespace
from unittest.mock import patch
import run_go2_visual_alignment as flow

class Arm:
    def __init__(self, fault=None):
        self.limits=SimpleNamespace(v_max_rad_s=0.75,j6_v_max_rad_s=0.75)
        self.q=[0.12,0,0,0,0,0]
        self.calls=[]
        self.fault=fault
    def get_pos(self):return self.q+[0]
    def move(self,*args):raise AssertionError("must not restart at each small segment")
    def move_waypoints(self,path,label):
        self.calls.append((path,self.limits.v_max_rad_s,self.limits.j6_v_max_rad_s))
        self.q=list(path[-1]);return self.fault

class ReturnTests(unittest.TestCase):
    def test_return_uses_full_speed_once_and_restores_descent_limits(self):
        for fault in [None,"tracking fault"]:
            with self.subTest(fault=fault):
                arm=Arm(fault)
                with patch.object(flow,"check_collision_path",return_value={"sample_count":20}) as collision:
                    kwargs=dict(label="return",collision_checker=object(),collision_step_rad=0.005,maximum_joint_step_rad=0.04,v_max_rad_s=1.5,j6_v_max_rad_s=1.5,continuous_path=True)
                    if fault:
                        with self.assertRaises(flow.SegmentedRecoveryError):
                            flow.execute_segmented_recovery(arm,[[0]*6],**kwargs)
                    else:
                        result=flow.execute_segmented_recovery(arm,[[0]*6],**kwargs)
                        self.assertEqual(result["status"],"completed")
                    self.assertEqual(collision.call_count,1)
                self.assertEqual(len(arm.calls),1)
                path,v,j6=arm.calls[0]
                self.assertEqual((v,j6),(1.5,1.5))
                self.assertEqual(path[0],[0.12,0,0,0,0,0])
                self.assertEqual(path[-1],[0]*6)
                self.assertEqual(arm.limits.v_max_rad_s,0.75)
                self.assertEqual(arm.limits.j6_v_max_rad_s,0.75)

if __name__=="__main__":unittest.main()
