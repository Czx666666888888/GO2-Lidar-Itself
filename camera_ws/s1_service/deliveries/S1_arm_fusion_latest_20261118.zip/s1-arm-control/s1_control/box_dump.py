"""Hinged-box taught path replay. No invented handle or pivot coordinates."""
import copy
from datetime import datetime
import json
import math
from pathlib import Path
from s1_control.integration import ZERO_Q


def load_dump_plan(path):
    plan=json.loads(Path(path).read_text())
    for name in ('approach_path_q_rad','tip_path_q_rad'):
        points=plan[name]
        if len(points)<2:
            raise ValueError('dump path not taught: '+name)
        if any(len(q)!=6 or not all(math.isfinite(float(v)) for v in q) for q in points):
            raise ValueError(name+' requires finite six-joint points')
    approach=plan['approach_path_q_rad'];tip=plan['tip_path_q_rad']
    if any(abs(a-b)>1e-6 for a,b in zip(approach[0],ZERO_Q)):
        raise ValueError('dump approach must begin at zero')
    if any(abs(a-b)>1e-6 for a,b in zip(approach[-1],tip[0])):
        raise ValueError('dump tip must begin at the handle grasp pose')
    for key in ('handle_closed_gap_mm','grip_force_nm','transit_speed_rad_s','tip_speed_rad_s','grip_hold_s','dump_hold_s','release_hold_s'):
        value=plan.get(key)
        if value is None or not math.isfinite(float(value)) or float(value)<=0:
            raise ValueError('dump requires positive finite '+key)
    return plan


def split_restore_path(path, fraction):
    if not math.isfinite(fraction) or not 0 < fraction <= 1:
        raise ValueError('restore_release_fraction must be in (0,1]')
    if fraction == 1:return path, [path[-1]]
    lengths=[math.dist(a,b) for a,b in zip(path,path[1:])]
    target=sum(lengths)*fraction
    distance=0.0
    for i,length in enumerate(lengths):
        if length and distance+length>=target:
            u=(target-distance)/length
            point=[a+(b-a)*u for a,b in zip(path[i],path[i+1])]
            return path[:i+1]+[point], [point]+path[i+1:]
        distance+=length
    return path,[path[-1]]


def distinct_waypoints(path):
    result=[]
    for q in path:
        point=[float(v) for v in q]
        if not result or point!=result[-1]:result.append(point)
    return result


def dump_steps(plan):
    approach=distinct_waypoints(plan['approach_path_q_rad']);tip=distinct_waypoints(plan['tip_path_q_rad'])
    restore,remaining=split_restore_path(list(reversed(tip)),float(plan.get('restore_release_fraction',1.0)))
    steps = [
        dict(name='dump_open',kind='hold',q=approach[0],closed=False,duration=plan['release_hold_s']),
        dict(name='dump_handle_approach',kind='move',path=approach,closed=False,speed=plan['transit_speed_rad_s']),
        dict(name='dump_handle_grip',kind='hold',q=tip[0],closed=True,duration=plan['grip_hold_s']),
        dict(name='dump_tip',kind='move',path=tip,closed=True,speed=plan['tip_speed_rad_s']),
        dict(name='dump_unload_hold',kind='hold',q=tip[-1],closed=True,duration=plan['dump_hold_s']),
        dict(name='dump_box_restore',kind='move',path=restore,closed=True,speed=plan.get('restore_speed_rad_s',plan['tip_speed_rad_s'])),
        dict(name='dump_handle_release',kind='hold',q=restore[-1],closed=False,duration=plan['release_hold_s']),
        dict(name='dump_return_zero',kind='move',path=list(reversed(approach)),closed=False,speed=plan['transit_speed_rad_s']),
    ]
    if len(remaining)>1:
        steps.insert(7,dict(name='dump_restore_released',kind='move',path=remaining,closed=False,speed=plan.get('restore_speed_rad_s',plan['tip_speed_rad_s'])))
    for step in steps:
        if step["kind"] == "move":step["path"]=distinct_waypoints(step["path"])
    return steps


def run_dump(session, plan, *, log_root, gripper_factory=None, hold_function=None):
    from s1_control.gripper import Gripper
    from scripts.execute_go2_observe_deployment import guarded_hold
    gripper_factory=gripper_factory or Gripper
    hold_function=hold_function or guarded_hold
    directory=Path(log_root)/datetime.now().strftime('dump_%Y%m%d-%H%M%S-%f')
    directory.mkdir(parents=True)
    log_path=directory/'run.json'
    log=dict(status='STARTED',plan=plan,steps=[],unload_confirmed=None)
    def save():log_path.write_text(json.dumps(log,ensure_ascii=False,indent=2)+'\n')
    save()
    limits=copy.copy(session.idle_limits)
    arm=session.acquire(limits)
    grip=gripper_factory(arm)
    closed=False
    try:
        for step in dump_steps(plan):
            closed=step['closed']
            gap=plan['handle_closed_gap_mm'] if closed else grip.max_gap_mm
            record=dict(name=step['name'],status='STARTED',command_gap_mm=gap)
            log['steps'].append(record);save()
            if step['kind']=='move':
                arm.limits.v_max_rad_s=arm.limits.j6_v_max_rad_s=step['speed']
                fault=arm.move_waypoints(step['path'],step['name'],grip_cmd=grip.mm_to_fb(gap),grip_force=plan['grip_force_nm'])
                if fault:raise RuntimeError(fault)
            else:
                hold_function(arm,step['q'],step['duration'],step['name'],gripper=grip,grip_gap_mm=gap,grip_force=plan['grip_force_nm'])
            record['status']='COMPLETED';save()
        log['status']='DUMP_MOTION_DONE_UNLOAD_UNVERIFIED';save()
        session.finish_task(at_zero=True,result=log['status'],log_path=str(log_path))
        return 0
    except Exception as exc:
        log['status']='ABORTED: '+str(exc);save()
        session.mark_fault(log['status'])
        session.finish_task(at_zero=False,result=log['status'],log_path=str(log_path),
            gripper=grip if closed else None,grip_gap_mm=plan['handle_closed_gap_mm'] if closed else None,grip_force=plan['grip_force_nm'] if closed else None)
        return 1
