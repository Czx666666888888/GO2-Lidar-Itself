"""Pure planning helpers for Go2-mounted wrist-camera center alignment.

The S1 base is tilted in both pitch and roll.  Consequently, "move above the
target" means motion in the measured support-plane tangent plane, not holding
base-frame Z constant and not matching base-frame X/Y independently.

This module has no serial, camera, MuJoCo or file-system side effects.
"""
from __future__ import annotations

import math
from typing import Any, Callable

import numpy as np

from .wrist_visual_servo import JOINT_LIMITS_RAD


def _finite_vector(value: Any, length: int, name: str) -> np.ndarray:
    vector = np.asarray(value, dtype=np.float64)
    if vector.shape != (length,) or not np.isfinite(vector).all():
        raise ValueError(f"{name} must contain {length} finite values")
    return vector


def unit_support_up(value: Any) -> np.ndarray:
    normal = _finite_vector(value, 3, "support_up_normal_base")
    norm = float(np.linalg.norm(normal))
    if norm < 1e-9:
        raise ValueError("support-up normal must be nonzero")
    normal /= norm
    if normal[2] <= 0.0:
        raise ValueError("support-up normal must point toward base +Z")
    return normal


def tangent_projection(vector: Any, support_up_normal_base: Any) -> np.ndarray:
    value = _finite_vector(vector, 3, "vector")
    normal = unit_support_up(support_up_normal_base)
    return value - float(np.dot(value, normal)) * normal


def blended_support_up_normal(
    nominal_support_up_normal_base: Any,
    observed_support_up_normal_base: Any,
    blend: float,
) -> np.ndarray:
    """Return the exact normal adopted by the tilt commander after blending."""
    nominal = unit_support_up(nominal_support_up_normal_base)
    observed = unit_support_up(observed_support_up_normal_base)
    blend = float(blend)
    if not math.isfinite(blend) or not 0.0 < blend <= 1.0:
        raise ValueError("support-normal blend must be in (0, 1]")
    mixed = (1.0 - blend) * nominal + blend * observed
    return unit_support_up(mixed)


def quaternion_error_deg(first: Any, second: Any) -> float:
    q1 = _finite_vector(first, 4, "first quaternion")
    q2 = _finite_vector(second, 4, "second quaternion")
    q1 /= np.linalg.norm(q1)
    q2 /= np.linalg.norm(q2)
    dot = float(np.clip(abs(float(q1 @ q2)), 0.0, 1.0))
    return math.degrees(2.0 * math.acos(dot))


def quaternion_to_rotation_matrix(quaternion: Any) -> np.ndarray:
    """Convert an XYZW quaternion to a finite right-handed rotation matrix."""
    value = _finite_vector(quaternion, 4, "quaternion")
    norm = float(np.linalg.norm(value))
    if norm < 1e-12:
        raise ValueError("quaternion must be nonzero")
    x, y, z, w = value / norm
    matrix = np.array(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )
    if not np.allclose(matrix.T @ matrix, np.eye(3), atol=1e-8):
        raise ValueError("quaternion did not produce an orthonormal rotation")
    if float(np.linalg.det(matrix)) < 0.999999:
        raise ValueError("quaternion rotation is not right handed")
    return matrix


def rotation_matrix_to_quaternion(matrix: Any) -> np.ndarray:
    """Convert a finite 3x3 rotation matrix to a normalized XYZW quaternion."""
    rotation = np.asarray(matrix, dtype=np.float64)
    if rotation.shape != (3, 3) or not np.isfinite(rotation).all():
        raise ValueError("rotation matrix must be finite 3x3")
    if not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-7):
        raise ValueError("rotation matrix must be orthonormal")
    if float(np.linalg.det(rotation)) < 0.999999:
        raise ValueError("rotation matrix must be right handed")

    trace = float(np.trace(rotation))
    if trace > 0.0:
        scale = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * scale
        x = (rotation[2, 1] - rotation[1, 2]) / scale
        y = (rotation[0, 2] - rotation[2, 0]) / scale
        z = (rotation[1, 0] - rotation[0, 1]) / scale
    else:
        diagonal = np.diag(rotation)
        index = int(np.argmax(diagonal))
        if index == 0:
            scale = math.sqrt(1.0 + rotation[0, 0] - rotation[1, 1] - rotation[2, 2]) * 2.0
            x = 0.25 * scale
            y = (rotation[0, 1] + rotation[1, 0]) / scale
            z = (rotation[0, 2] + rotation[2, 0]) / scale
            w = (rotation[2, 1] - rotation[1, 2]) / scale
        elif index == 1:
            scale = math.sqrt(1.0 + rotation[1, 1] - rotation[0, 0] - rotation[2, 2]) * 2.0
            x = (rotation[0, 1] + rotation[1, 0]) / scale
            y = 0.25 * scale
            z = (rotation[1, 2] + rotation[2, 1]) / scale
            w = (rotation[0, 2] - rotation[2, 0]) / scale
        else:
            scale = math.sqrt(1.0 + rotation[2, 2] - rotation[0, 0] - rotation[1, 1]) * 2.0
            x = (rotation[0, 2] + rotation[2, 0]) / scale
            y = (rotation[1, 2] + rotation[2, 1]) / scale
            z = 0.25 * scale
            w = (rotation[1, 0] - rotation[0, 1]) / scale
    quaternion = np.array([x, y, z, w], dtype=np.float64)
    quaternion /= np.linalg.norm(quaternion)
    if quaternion[3] < 0.0:
        quaternion = -quaternion
    return quaternion


def quaternion_slerp(first: Any, second: Any, alpha: float) -> np.ndarray:
    """Shortest-arc spherical interpolation between normalized XYZW quaternions."""
    q0 = _finite_vector(first, 4, "first quaternion")
    q1 = _finite_vector(second, 4, "second quaternion")
    q0 /= np.linalg.norm(q0)
    q1 /= np.linalg.norm(q1)
    alpha = float(alpha)
    if not math.isfinite(alpha) or not 0.0 <= alpha <= 1.0:
        raise ValueError("slerp alpha must be in [0, 1]")
    dot = float(q0 @ q1)
    if dot < 0.0:
        q1 = -q1
        dot = -dot
    dot = float(np.clip(dot, -1.0, 1.0))
    if dot > 0.9995:
        result = q0 + alpha * (q1 - q0)
        return result / np.linalg.norm(result)
    theta = math.acos(dot)
    sin_theta = math.sin(theta)
    result = (
        math.sin((1.0 - alpha) * theta) / sin_theta * q0
        + math.sin(alpha * theta) / sin_theta * q1
    )
    return result / np.linalg.norm(result)


def square_grasp_orientation_candidates(
    current_tcp_pose_xyz_xyzw: Any,
    target_edge_axis_base: Any,
    support_up_normal_base: Any,
    *,
    maximum_approach_tilt_from_support_down_deg: float,
) -> list[dict]:
    """Return four square-symmetric tool rotations around the current approach axis.

    S1 TCP +X is the approach axis and TCP +Y is the parallel-gripper closing
    axis.  Preserving the measured approach axis avoids introducing a new pitch
    or roll command on the tilted Go2 mount; only the wrist yaw family changes.
    """
    current = _finite_vector(current_tcp_pose_xyz_xyzw, 7, "current TCP pose")
    support_up = unit_support_up(support_up_normal_base)
    current_rotation = quaternion_to_rotation_matrix(current[3:])
    approach = current_rotation[:, 0]
    approach /= np.linalg.norm(approach)
    tilt_deg = math.degrees(
        math.acos(float(np.clip(np.dot(approach, -support_up), -1.0, 1.0)))
    )
    maximum_tilt = float(maximum_approach_tilt_from_support_down_deg)
    if not math.isfinite(maximum_tilt) or not 0.0 < maximum_tilt <= 20.0:
        raise ValueError("maximum approach tilt must be in (0, 20] degrees")
    if tilt_deg > maximum_tilt:
        raise RuntimeError(
            f"tool approach tilt {tilt_deg:.2f}deg exceeds {maximum_tilt:.2f}deg"
        )

    edge = _finite_vector(target_edge_axis_base, 3, "target edge axis base")
    edge = edge - float(np.dot(edge, approach)) * approach
    edge_norm = float(np.linalg.norm(edge))
    if edge_norm < 1e-6:
        raise ValueError("target edge axis is degenerate around the tool approach axis")
    edge /= edge_norm
    perpendicular = np.cross(approach, edge)
    perpendicular /= np.linalg.norm(perpendicular)

    result = []
    for name, closing_axis in (
        ("edge", edge),
        ("edge_roll180", -edge),
        ("edge90", perpendicular),
        ("edge90_roll180", -perpendicular),
    ):
        tool_z = np.cross(approach, closing_axis)
        rotation = np.column_stack((approach, closing_axis, tool_z))
        quaternion = rotation_matrix_to_quaternion(rotation)
        result.append(
            {
                "name": name,
                "target_quaternion_xyzw": quaternion.tolist(),
                "rotation_from_current_deg": quaternion_error_deg(
                    current[3:], quaternion
                ),
                "approach_tilt_from_support_down_deg": tilt_deg,
                "closing_axis_base": closing_axis.tolist(),
            }
        )
    return result


def build_fixed_position_orientation_path(
    current_tcp_pose_xyz_xyzw: Any,
    target_quaternion_xyzw: Any,
    *,
    maximum_orientation_step_deg: float,
) -> list[list[float]]:
    """Build a fixed-position, shortest-arc quaternion path."""
    current = _finite_vector(current_tcp_pose_xyz_xyzw, 7, "current TCP pose")
    target = _finite_vector(target_quaternion_xyzw, 4, "target quaternion")
    step_deg = float(maximum_orientation_step_deg)
    if not math.isfinite(step_deg) or not 0.5 <= step_deg <= 10.0:
        raise ValueError("maximum orientation step must be in [0.5, 10] degrees")
    rotation_deg = quaternion_error_deg(current[3:], target)
    segments = max(1, int(math.ceil(rotation_deg / step_deg)))
    poses = []
    for index in range(segments + 1):
        alpha = index / segments
        quaternion = quaternion_slerp(current[3:], target, alpha)
        poses.append([*current[:3].tolist(), *quaternion.tolist()])
    return poses


def joint_margin_deg(q: Any) -> float:
    values = _finite_vector(q, 6, "q")
    return math.degrees(
        min(
            min(value - lower, upper - value)
            for value, (lower, upper) in zip(values, JOINT_LIMITS_RAD)
        )
    )


def validate_workspace_point(xyz_m: Any, workspace: dict, label: str) -> None:
    xyz = _finite_vector(xyz_m, 3, label)
    if workspace.get("advisory_bounds") is True:
        strict = dict(workspace, advisory_bounds=False)
        try:
            validate_workspace_point(xyz, strict, label)
        except RuntimeError as exc:
            print(f"HISTORICAL_WORKSPACE_WARNING = {exc}")
        return
    x_mm, y_mm = 1000.0 * xyz[:2]
    x_range = [float(value) for value in workspace["tcp_base_x_mm"]]
    y_range = [float(value) for value in workspace["tcp_base_y_mm"]]
    if not x_range[0] <= x_mm <= x_range[1]:
        raise RuntimeError(
            f"{label} base X {x_mm:.1f}mm outside validated range {x_range}"
        )
    if not y_range[0] <= y_mm <= y_range[1]:
        raise RuntimeError(
            f"{label} base Y {y_mm:.1f}mm outside validated range {y_range}"
        )


def build_tangent_tcp_path(
    current_tcp_pose_xyz_xyzw: Any,
    target_surface_base_m: Any,
    support_up_normal_base: Any,
    *,
    maximum_initial_error_mm: float | None,
    convergence_mm: float,
    maximum_cartesian_step_mm: float,
    minimum_clearance_mm: float,
    maximum_clearance_mm: float,
    workspace: dict,
    force_correction: bool = False,
) -> dict:
    """Build a constant-orientation path in the measured support tangent plane."""
    current = _finite_vector(current_tcp_pose_xyz_xyzw, 7, "current_tcp_pose")
    target = _finite_vector(target_surface_base_m, 3, "target_surface_base")
    normal = unit_support_up(support_up_normal_base)
    if maximum_initial_error_mm is not None:
        maximum_initial_error_mm = float(maximum_initial_error_mm)
    convergence_mm = float(convergence_mm)
    maximum_cartesian_step_mm = float(maximum_cartesian_step_mm)
    if not (
        math.isfinite(convergence_mm)
        and math.isfinite(maximum_cartesian_step_mm)
        and 0.0 < convergence_mm
        and (
            maximum_initial_error_mm is None
            or (math.isfinite(maximum_initial_error_mm) and convergence_mm <= maximum_initial_error_mm)
        )
        and 0.0 < maximum_cartesian_step_mm <= 10.0
    ):
        raise ValueError("invalid tangent path limits")

    validate_workspace_point(current[:3], workspace, "current TCP")
    delta = target - current[:3]
    normal_clearance_mm = -1000.0 * float(np.dot(delta, normal))
    if not float(minimum_clearance_mm) <= normal_clearance_mm <= float(
        maximum_clearance_mm
    ):
        raise RuntimeError(
            f"normal clearance {normal_clearance_mm:.1f}mm outside "
            f"[{float(minimum_clearance_mm):.1f}, {float(maximum_clearance_mm):.1f}]"
        )
    validated_clearance = [
        float(value) for value in workspace["normal_clearance_mm"]
    ]
    if (not workspace.get("advisory_bounds", False)
            and not validated_clearance[0] <= normal_clearance_mm <= validated_clearance[1]):
        raise RuntimeError(
            f"normal clearance {normal_clearance_mm:.1f}mm outside validated "
            f"range {validated_clearance}"
        )

    tangent = tangent_projection(delta, normal)
    error_mm = 1000.0 * float(np.linalg.norm(tangent))
    if maximum_initial_error_mm is not None and error_mm > maximum_initial_error_mm + 1e-9:
        raise RuntimeError(
            f"tangent error {error_mm:.1f}mm exceeds bounded range "
            f"{maximum_initial_error_mm:.1f}mm"
        )
    within_tolerance = error_mm <= convergence_mm
    converged = within_tolerance and not (force_correction and error_mm > 0.0)
    segment_count = 0 if converged else max(
        1, int(math.ceil(error_mm / maximum_cartesian_step_mm))
    )
    poses = [current.tolist()]
    for index in range(1, segment_count + 1):
        alpha = index / segment_count
        pose = current.copy()
        pose[:3] += alpha * tangent
        validate_workspace_point(pose[:3], workspace, f"TCP path sample {index}")
        normal_step_mm = 1000.0 * float(np.dot(pose[:3] - current[:3], normal))
        if abs(normal_step_mm) > 1e-6:
            raise RuntimeError("planned tangent path changed normal clearance")
        poses.append(pose.tolist())

    return {
        "support_up_normal_base": normal.tolist(),
        "normal_clearance_mm": normal_clearance_mm,
        "initial_tangent_error_base_xyz_mm": (1000.0 * tangent).tolist(),
        "initial_tangent_error_norm_mm": error_mm,
        "convergence_mm": convergence_mm,
        "maximum_cartesian_step_mm": maximum_cartesian_step_mm,
        "segment_count": segment_count,
        "converged": converged,
        "within_success_tolerance": within_tolerance,
        "correction_forced": bool(force_correction),
        "tcp_poses_xyz_xyzw": poses,
    }


def _ik_seeds(q: np.ndarray) -> list[list[float]]:
    seeds = [q.tolist()]
    for joint, amount in ((0, 0.03), (1, 0.03), (2, 0.03), (3, 0.02), (5, 0.02)):
        for sign in (-1.0, 1.0):
            seed = q.copy()
            seed[joint] += sign * amount
            seeds.append(seed.tolist())
    return seeds


def solve_continuous_ik_path(
    kinematics: Any,
    start_q: Any,
    tcp_poses_xyz_xyzw: Any,
    *,
    maximum_joint_step_rad: float,
    minimum_joint_margin_deg: float,
    maximum_fk_position_error_mm: float,
    maximum_fk_orientation_error_deg: float,
) -> dict:
    """Solve each Cartesian sample from the preceding solution for continuity."""
    previous = _finite_vector(start_q, 6, "start_q")
    poses = [
        _finite_vector(value, 7, f"tcp pose {index}")
        for index, value in enumerate(tcp_poses_xyz_xyzw)
    ]
    if not poses:
        raise ValueError("TCP path cannot be empty")
    q_path = [previous.tolist()]
    evidence = []
    for index, pose in enumerate(poses[1:], start=1):
        candidates = []
        seen = set()
        for _ in range(3):
            for seed in _ik_seeds(previous):
                solution = kinematics.ik(pose[:3], pose[3:], seed)
                if solution is None:
                    continue
                q = _finite_vector(solution, 6, f"IK solution {index}")
                key = tuple(round(float(value), 7) for value in q)
                if key in seen:
                    continue
                seen.add(key)
                delta = np.abs(q - previous)
                maximum_delta = float(np.max(delta))
                margin = joint_margin_deg(q)
                if maximum_delta > float(maximum_joint_step_rad) + 1e-9:
                    continue
                if margin < float(minimum_joint_margin_deg):
                    continue
                fk = _finite_vector(kinematics.fk(q), 7, f"FK result {index}")
                position_error_mm = 1000.0 * float(np.linalg.norm(fk[:3] - pose[:3]))
                orientation_error_deg = quaternion_error_deg(fk[3:], pose[3:])
                if position_error_mm > float(maximum_fk_position_error_mm):
                    continue
                if orientation_error_deg > float(maximum_fk_orientation_error_deg):
                    continue
                candidates.append(
                    (
                        (maximum_delta, float(np.sum(delta)), position_error_mm),
                        q,
                        {
                            "sample_index": index,
                            "maximum_joint_delta_rad": maximum_delta,
                            "minimum_joint_margin_deg": margin,
                            "fk_position_error_mm": position_error_mm,
                            "fk_orientation_error_deg": orientation_error_deg,
                        },
                    )
                )
        if not candidates:
            raise RuntimeError(f"no safe continuous IK solution for TCP sample {index}")
        _, selected, record = min(candidates, key=lambda value: value[0])
        previous = selected
        q_path.append(selected.tolist())
        evidence.append(record)
    return {"joint_path": q_path, "samples": evidence}


def densify_joint_path(joint_path: Any, maximum_step_rad: float) -> list[list[float]]:
    """Linearly sample every segment, including both global endpoints."""
    rows = [_finite_vector(value, 6, f"joint waypoint {index}") for index, value in enumerate(joint_path)]
    if not rows:
        raise ValueError("joint path cannot be empty")
    maximum_step_rad = float(maximum_step_rad)
    if not math.isfinite(maximum_step_rad) or maximum_step_rad <= 0.0:
        raise ValueError("maximum joint sampling step must be positive")
    dense = [rows[0].tolist()]
    for first, second in zip(rows, rows[1:]):
        count = max(
            1,
            int(math.ceil(float(np.max(np.abs(second - first))) / maximum_step_rad)),
        )
        for index in range(1, count + 1):
            alpha = index / count
            dense.append(((1.0 - alpha) * first + alpha * second).tolist())
    return dense


def validate_torque_envelope(
    joint_path: Any,
    torque_for_q: Callable[[list[float]], Any],
    absolute_limits_nm: Any,
) -> dict:
    """Reject any path sample that would clip the differential torque term."""
    limits = _finite_vector(absolute_limits_nm, 6, "torque limits")
    if np.any(limits <= 0.0):
        raise ValueError("torque limits must be positive")
    maximum_fraction = np.zeros(6, dtype=np.float64)
    for index, q in enumerate(joint_path):
        torque = _finite_vector(torque_for_q(list(q)), 6, f"torque sample {index}")
        fraction = np.abs(torque) / limits
        maximum_fraction = np.maximum(maximum_fraction, fraction)
        if np.any(fraction >= 1.0 - 1e-9):
            joint = int(np.argmax(fraction)) + 1
            raise RuntimeError(
                f"tilt compensation torque cap at path sample {index}, J{joint}"
            )
    return {
        "sample_count": len(joint_path),
        "maximum_limit_fraction_per_joint": maximum_fraction.tolist(),
        "maximum_limit_fraction": float(np.max(maximum_fraction)),
    }
