"""Pure geometry helpers for S1 eye-in-hand camera calibration.

Transform naming follows ``T_parent_child``: the matrix maps coordinates from
``child`` into ``parent``.  Consequently the runtime camera pose is

    T_base_camera = T_base_flange @ T_flange_camera

and a fixed calibration target should satisfy

    T_base_target = T_base_flange @ T_flange_camera @ T_camera_target.

This module has no camera or robot side effects. OpenCV is imported lazily only
by the solver functions that require it, keeping the geometry and residual
checks testable in the normal S1 runtime environment.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Iterable, Sequence

import numpy as np


HAND_EYE_METHODS = (
    "PARK",
    "TSAI",
    "HORAUD",
    "ANDREFF",
    "DANIILIDIS",
)


def _finite_array(value, shape, name: str) -> np.ndarray:
    array = np.asarray(value, dtype=np.float64)
    if array.shape != shape:
        raise ValueError(f"{name} must have shape {shape}, got {array.shape}")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} must contain only finite values")
    return array


def validate_transform(value, name: str = "transform", atol: float = 1e-5) -> np.ndarray:
    """Validate and return a finite rigid 4x4 transform."""
    transform = _finite_array(value, (4, 4), name).copy()
    if not np.allclose(transform[3], [0.0, 0.0, 0.0, 1.0], atol=atol):
        raise ValueError(f"{name} has an invalid homogeneous last row")
    rotation = transform[:3, :3]
    if not np.allclose(rotation.T @ rotation, np.eye(3), atol=atol):
        raise ValueError(f"{name} rotation is not orthonormal")
    determinant = float(np.linalg.det(rotation))
    if not math.isclose(determinant, 1.0, abs_tol=atol):
        raise ValueError(f"{name} rotation determinant is {determinant:.8f}, not +1")
    return transform


def invert_transform(value) -> np.ndarray:
    transform = validate_transform(value)
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = transform[:3, :3].T
    result[:3, 3] = -result[:3, :3] @ transform[:3, 3]
    return result


def quaternion_xyzw_to_rotation(quaternion) -> np.ndarray:
    q = _finite_array(quaternion, (4,), "quaternion_xyzw")
    norm = float(np.linalg.norm(q))
    if norm <= 1e-12:
        raise ValueError("quaternion_xyzw has zero norm")
    x, y, z, w = q / norm
    return np.array(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def pose_xyz_quat_to_transform(pose) -> np.ndarray:
    """Convert ``[x,y,z,qx,qy,qz,qw]`` into a rigid transform."""
    values = _finite_array(pose, (7,), "pose_xyz_quat_xyzw")
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = quaternion_xyzw_to_rotation(values[3:])
    result[:3, 3] = values[:3]
    return validate_transform(result)


def rotation_angle_deg(rotation) -> float:
    matrix = _finite_array(rotation, (3, 3), "rotation")
    cosine = float(np.clip((np.trace(matrix) - 1.0) * 0.5, -1.0, 1.0))
    return math.degrees(math.acos(cosine))


def _project_rotation(matrix) -> np.ndarray:
    candidate = _finite_array(matrix, (3, 3), "rotation_accumulator")
    u, _, vt = np.linalg.svd(candidate)
    correction = np.eye(3)
    correction[2, 2] = 1.0 if np.linalg.det(u @ vt) >= 0.0 else -1.0
    return u @ correction @ vt


def average_transforms(transforms: Sequence[np.ndarray]) -> np.ndarray:
    if not transforms:
        raise ValueError("at least one transform is required")
    checked = [validate_transform(item, f"transform[{i}]") for i, item in enumerate(transforms)]
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = _project_rotation(sum(item[:3, :3] for item in checked))
    result[:3, 3] = np.median(
        np.stack([item[:3, 3] for item in checked], axis=0), axis=0
    )
    return result


@dataclass(frozen=True)
class ResidualSummary:
    translation_rms_mm: float
    translation_median_mm: float
    translation_max_mm: float
    rotation_rms_deg: float
    rotation_median_deg: float
    rotation_max_deg: float
    score: float

    def to_dict(self) -> dict:
        return asdict(self)


def fixed_target_residuals(
    base_flange_transforms: Sequence[np.ndarray],
    camera_target_transforms: Sequence[np.ndarray],
    flange_camera_transform: np.ndarray,
) -> tuple[np.ndarray, list[dict], ResidualSummary]:
    """Evaluate how constant the fixed target appears in the robot base frame."""
    if len(base_flange_transforms) != len(camera_target_transforms):
        raise ValueError("base_flange and camera_target sample counts differ")
    if len(base_flange_transforms) < 1:
        raise ValueError("at least one sample is required")

    flange_camera = validate_transform(
        flange_camera_transform, "T_flange_camera"
    )
    base_target_transforms = []
    for index, (base_flange, camera_target) in enumerate(
        zip(base_flange_transforms, camera_target_transforms)
    ):
        base_flange = validate_transform(base_flange, f"T_base_flange[{index}]")
        camera_target = validate_transform(camera_target, f"T_camera_target[{index}]")
        base_target_transforms.append(base_flange @ flange_camera @ camera_target)

    reference = average_transforms(base_target_transforms)
    details = []
    translation_errors = []
    rotation_errors = []
    for index, transform in enumerate(base_target_transforms):
        translation_mm = 1000.0 * float(
            np.linalg.norm(transform[:3, 3] - reference[:3, 3])
        )
        rotation_deg = rotation_angle_deg(reference[:3, :3].T @ transform[:3, :3])
        translation_errors.append(translation_mm)
        rotation_errors.append(rotation_deg)
        details.append(
            {
                "sample_index": index,
                "translation_error_mm": translation_mm,
                "rotation_error_deg": rotation_deg,
            }
        )

    translation_values = np.asarray(translation_errors, dtype=np.float64)
    rotation_values = np.asarray(rotation_errors, dtype=np.float64)
    summary = ResidualSummary(
        translation_rms_mm=float(np.sqrt(np.mean(translation_values**2))),
        translation_median_mm=float(np.median(translation_values)),
        translation_max_mm=float(np.max(translation_values)),
        rotation_rms_deg=float(np.sqrt(np.mean(rotation_values**2))),
        rotation_median_deg=float(np.median(rotation_values)),
        rotation_max_deg=float(np.max(rotation_values)),
        score=float(
            np.sqrt(np.mean(translation_values**2))
            + 2.0 * np.sqrt(np.mean(rotation_values**2))
        ),
    )
    return reference, details, summary


def fixed_reference_residuals(
    base_flange_transforms: Sequence[np.ndarray],
    camera_target_transforms: Sequence[np.ndarray],
    flange_camera_transform: np.ndarray,
    reference_base_target_transform: np.ndarray,
) -> tuple[list[dict], ResidualSummary]:
    """Evaluate samples against a pre-existing fixed-target reference.

    Unlike :func:`fixed_target_residuals`, this function never estimates a new
    reference from the evaluated samples. It is therefore suitable for
    holdout validation without allowing the validation set to absorb a rigid
    systematic offset.
    """
    if len(base_flange_transforms) != len(camera_target_transforms):
        raise ValueError("base_flange and camera_target sample counts differ")
    if len(base_flange_transforms) < 1:
        raise ValueError("at least one sample is required")

    flange_camera = validate_transform(
        flange_camera_transform, "T_flange_camera"
    )
    reference = validate_transform(
        reference_base_target_transform, "reference_T_base_target"
    )
    inverse_reference = invert_transform(reference)
    details = []
    translation_errors = []
    rotation_errors = []
    for index, (base_flange, camera_target) in enumerate(
        zip(base_flange_transforms, camera_target_transforms)
    ):
        base_flange = validate_transform(base_flange, f"T_base_flange[{index}]")
        camera_target = validate_transform(
            camera_target, f"T_camera_target[{index}]"
        )
        predicted = base_flange @ flange_camera @ camera_target
        error = inverse_reference @ predicted
        signed_base_translation_mm = 1000.0 * (
            predicted[:3, 3] - reference[:3, 3]
        )
        translation_mm = 1000.0 * float(np.linalg.norm(error[:3, 3]))
        rotation_deg = rotation_angle_deg(error[:3, :3])
        translation_errors.append(translation_mm)
        rotation_errors.append(rotation_deg)
        details.append(
            {
                "sample_index": index,
                "translation_error_mm": translation_mm,
                "translation_error_base_xyz_mm": (
                    signed_base_translation_mm.tolist()
                ),
                "rotation_error_deg": rotation_deg,
                "predicted_T_base_target": predicted.tolist(),
            }
        )

    translation_values = np.asarray(translation_errors, dtype=np.float64)
    rotation_values = np.asarray(rotation_errors, dtype=np.float64)
    summary = ResidualSummary(
        translation_rms_mm=float(np.sqrt(np.mean(translation_values**2))),
        translation_median_mm=float(np.median(translation_values)),
        translation_max_mm=float(np.max(translation_values)),
        rotation_rms_deg=float(np.sqrt(np.mean(rotation_values**2))),
        rotation_median_deg=float(np.median(rotation_values)),
        rotation_max_deg=float(np.max(rotation_values)),
        score=float(
            np.sqrt(np.mean(translation_values**2))
            + 2.0 * np.sqrt(np.mean(rotation_values**2))
        ),
    )
    return details, summary


def sample_motion_diversity(base_flange_transforms: Sequence[np.ndarray]) -> dict:
    checked = [
        validate_transform(item, f"T_base_flange[{i}]")
        for i, item in enumerate(base_flange_transforms)
    ]
    if len(checked) < 2:
        return {
            "maximum_pairwise_rotation_deg": 0.0,
            "maximum_pairwise_translation_mm": 0.0,
            "informative_rotation_pair_count": 0,
        }

    rotations = []
    translations = []
    informative = 0
    for i in range(len(checked)):
        for j in range(i + 1, len(checked)):
            angle = rotation_angle_deg(
                checked[i][:3, :3].T @ checked[j][:3, :3]
            )
            distance_mm = 1000.0 * float(
                np.linalg.norm(checked[i][:3, 3] - checked[j][:3, 3])
            )
            rotations.append(angle)
            translations.append(distance_mm)
            if angle >= 10.0:
                informative += 1
    return {
        "maximum_pairwise_rotation_deg": float(max(rotations)),
        "median_pairwise_rotation_deg": float(np.median(rotations)),
        "maximum_pairwise_translation_mm": float(max(translations)),
        "median_pairwise_translation_mm": float(np.median(translations)),
        "informative_rotation_pair_count": int(informative),
    }


def _opencv_method_id(cv2, method_name: str) -> int:
    normalized = str(method_name).upper()
    if normalized not in HAND_EYE_METHODS:
        raise ValueError(
            f"unknown hand-eye method {method_name!r}; choices={HAND_EYE_METHODS}"
        )
    return int(getattr(cv2, f"CALIB_HAND_EYE_{normalized}"))


def solve_hand_eye(
    base_flange_transforms: Sequence[np.ndarray],
    camera_target_transforms: Sequence[np.ndarray],
    method_name: str = "PARK",
) -> np.ndarray:
    """Solve and return ``T_flange_camera`` using OpenCV's hand-eye API."""
    try:
        import cv2
    except ImportError as exc:  # pragma: no cover - environment-specific
        raise RuntimeError("OpenCV is required for hand-eye calibration") from exc
    if not hasattr(cv2, "calibrateHandEye"):
        raise RuntimeError(
            "this OpenCV Python build has no calibrateHandEye; activate S1-calib"
        )
    if len(base_flange_transforms) != len(camera_target_transforms):
        raise ValueError("base_flange and camera_target sample counts differ")
    if len(base_flange_transforms) < 3:
        raise ValueError("OpenCV hand-eye calibration requires at least 3 samples")

    base_flange = [
        validate_transform(item, f"T_base_flange[{i}]")
        for i, item in enumerate(base_flange_transforms)
    ]
    camera_target = [
        validate_transform(item, f"T_camera_target[{i}]")
        for i, item in enumerate(camera_target_transforms)
    ]
    rotations_gripper_to_base = [item[:3, :3] for item in base_flange]
    translations_gripper_to_base = [item[:3, 3].reshape(3, 1) for item in base_flange]
    rotations_target_to_camera = [item[:3, :3] for item in camera_target]
    translations_target_to_camera = [item[:3, 3].reshape(3, 1) for item in camera_target]

    rotation_camera_to_gripper, translation_camera_to_gripper = cv2.calibrateHandEye(
        rotations_gripper_to_base,
        translations_gripper_to_base,
        rotations_target_to_camera,
        translations_target_to_camera,
        method=_opencv_method_id(cv2, method_name),
    )
    result = np.eye(4, dtype=np.float64)
    result[:3, :3] = np.asarray(rotation_camera_to_gripper, dtype=np.float64)
    result[:3, 3] = np.asarray(
        translation_camera_to_gripper, dtype=np.float64
    ).reshape(3)
    return validate_transform(result, "T_flange_camera_result", atol=1e-4)


def _transform_to_rodrigues_parameters(transform: np.ndarray) -> np.ndarray:
    import cv2

    checked = validate_transform(transform)
    rotation_vector, _ = cv2.Rodrigues(checked[:3, :3])
    return np.concatenate(
        [np.asarray(rotation_vector, dtype=np.float64).reshape(3), checked[:3, 3]]
    )


def _rodrigues_parameters_to_transform(parameters, name: str) -> np.ndarray:
    import cv2

    values = _finite_array(parameters, (6,), name)
    result = np.eye(4, dtype=np.float64)
    result[:3, :3], _ = cv2.Rodrigues(values[:3])
    result[:3, 3] = values[3:]
    return validate_transform(result, name, atol=1e-4)


def refine_hand_eye(
    base_flange_transforms: Sequence[np.ndarray],
    camera_target_transforms: Sequence[np.ndarray],
    initial_flange_camera_transform: np.ndarray,
    *,
    rotation_weight_m_per_rad: float = 0.5,
    maximum_iterations: int = 60,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Jointly refine ``T_flange_camera`` and the fixed target pose.

    OpenCV's closed-form hand-eye methods provide the initial camera transform.
    This deterministic damped Gauss-Newton stage then minimizes, over all
    samples, the fixed-target inconsistency

    ``inv(T_base_target) @ T_base_flange @ T_flange_camera @ T_camera_target``.

    Translation residuals are in metres. Rotation-vector residuals are scaled
    by a characteristic length (0.5 m by default), so one radian of angular
    inconsistency has the same objective magnitude as a 0.5 m displacement.
    No sample is discarded and no robust loss can silently hide an outlier.
    """
    try:
        import cv2
    except ImportError as exc:  # pragma: no cover - environment-specific
        raise RuntimeError("OpenCV is required for hand-eye refinement") from exc
    if not hasattr(cv2, "Rodrigues"):
        raise RuntimeError("this OpenCV Python build has no Rodrigues")
    if len(base_flange_transforms) != len(camera_target_transforms):
        raise ValueError("base_flange and camera_target sample counts differ")
    if len(base_flange_transforms) < 3:
        raise ValueError("hand-eye refinement requires at least 3 samples")
    weight = float(rotation_weight_m_per_rad)
    if not math.isfinite(weight) or weight <= 0.0:
        raise ValueError("rotation_weight_m_per_rad must be positive and finite")
    if not isinstance(maximum_iterations, int) or maximum_iterations < 1:
        raise ValueError("maximum_iterations must be a positive integer")

    base_flange = [
        validate_transform(item, f"T_base_flange[{i}]")
        for i, item in enumerate(base_flange_transforms)
    ]
    camera_target = [
        validate_transform(item, f"T_camera_target[{i}]")
        for i, item in enumerate(camera_target_transforms)
    ]
    initial_flange_camera = validate_transform(
        initial_flange_camera_transform, "initial_T_flange_camera"
    )
    initial_base_target, _, _ = fixed_target_residuals(
        base_flange, camera_target, initial_flange_camera
    )
    parameters = np.concatenate(
        [
            _transform_to_rodrigues_parameters(initial_flange_camera),
            _transform_to_rodrigues_parameters(initial_base_target),
        ]
    )

    def residual_vector(vector: np.ndarray) -> np.ndarray:
        flange_camera = _rodrigues_parameters_to_transform(
            vector[:6], "refined_T_flange_camera"
        )
        base_target = _rodrigues_parameters_to_transform(
            vector[6:], "refined_T_base_target"
        )
        residuals = []
        for base_flange_item, camera_target_item in zip(
            base_flange, camera_target
        ):
            predicted_base_target = (
                base_flange_item @ flange_camera @ camera_target_item
            )
            error = invert_transform(base_target) @ predicted_base_target
            rotation_vector, _ = cv2.Rodrigues(error[:3, :3])
            residuals.extend(error[:3, 3].tolist())
            residuals.extend(
                (weight * np.asarray(rotation_vector).reshape(3)).tolist()
            )
        return np.asarray(residuals, dtype=np.float64)

    current_residual = residual_vector(parameters)
    initial_objective = float(current_residual @ current_residual)
    current_objective = initial_objective
    damping = 1e-3
    accepted_steps = 0
    converged = False
    iterations_run = 0

    for iteration in range(maximum_iterations):
        iterations_run = iteration + 1
        jacobian = np.empty(
            (current_residual.size, parameters.size), dtype=np.float64
        )
        for column in range(parameters.size):
            epsilon = 1e-6
            shifted = parameters.copy()
            shifted[column] += epsilon
            jacobian[:, column] = (
                residual_vector(shifted) - current_residual
            ) / epsilon

        normal = jacobian.T @ jacobian
        gradient = jacobian.T @ current_residual
        diagonal = np.maximum(np.diag(normal), 1.0)
        regularized = normal + damping * np.diag(diagonal)
        try:
            step = np.linalg.solve(regularized, -gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(regularized, -gradient, rcond=None)[0]
        if not np.isfinite(step).all():
            raise RuntimeError("hand-eye refinement produced a non-finite step")

        proposal = parameters + step
        proposed_residual = residual_vector(proposal)
        proposed_objective = float(proposed_residual @ proposed_residual)
        if proposed_objective < current_objective:
            relative_change = (current_objective - proposed_objective) / max(
                current_objective, 1e-30
            )
            parameters = proposal
            current_residual = proposed_residual
            current_objective = proposed_objective
            accepted_steps += 1
            damping = max(1e-9, damping / 3.0)
            if float(np.linalg.norm(step)) < 1e-10 or relative_change < 1e-12:
                converged = True
                break
        else:
            damping = min(1e9, damping * 10.0)
            if damping >= 1e9:
                converged = True
                break

    refined_flange_camera = _rodrigues_parameters_to_transform(
        parameters[:6], "refined_T_flange_camera_result"
    )
    refined_base_target = _rodrigues_parameters_to_transform(
        parameters[6:], "refined_T_base_target_result"
    )
    improvement = initial_objective - current_objective
    diagnostics = {
        "algorithm": "deterministic_damped_gauss_newton_joint_X_and_base_target",
        "rotation_weight_m_per_rad": weight,
        "maximum_iterations": maximum_iterations,
        "iterations_run": iterations_run,
        "accepted_steps": accepted_steps,
        "converged": bool(converged),
        "initial_objective_m2": initial_objective,
        "final_objective_m2": current_objective,
        "objective_improvement_m2": improvement,
        "relative_objective_improvement": float(
            improvement / max(initial_objective, 1e-30)
        ),
        "sample_count": len(base_flange),
    }
    return refined_flange_camera, refined_base_target, diagnostics


def transforms_to_lists(transforms: Iterable[np.ndarray]) -> list[list[list[float]]]:
    return [validate_transform(item).tolist() for item in transforms]
