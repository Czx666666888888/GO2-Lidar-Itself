# -*- coding: utf-8 -*-
"""标定/配置加载。集中处理 calibration/ 与 config/ 的读取。

★设计意图★：标定值是【暂时的】，绑定 2026-07 的物理摆放，非永久常量。
加载时打印 provisional 提示，让每个使用者（含 agent）都看得见失效条件，
不把它当神圣常量。详见 calibration/README.md。
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import yaml

# 仓根 = 本文件的上两级（s1_control/calib.py → 仓根）
_ROOT = Path(__file__).resolve().parents[1]
_CALIB_DIR = _ROOT / "calibration"
_CONFIG_DIR = _ROOT / "config"


def _provisional_banner(name: str, value_repr: str, when: str, recal: str) -> None:
    """加载标定时打印一行醒目的 provisional 提示。"""
    print(f"[calib] {name} = {value_repr}  (★provisional★)")
    print(f"[calib]   仅当: {when}")
    print(f"[calib]   失效即重标: {recal}")


def load_tcp(verbose: bool = True) -> list[float]:
    """读 TCP 偏置 [x,y,z] m（喂给 S1_solver(end_offset)）。"""
    rec = json.loads((_CALIB_DIR / "tcp.json").read_text(encoding="utf-8"))
    tcp = [float(v) for v in rec["value_m"]]
    if verbose:
        _provisional_banner("TCP", f"{tcp} m", rec["valid_only_if"], rec["recalibrate_when"])
    return tcp


def load_extrinsic(verbose: bool = True) -> np.ndarray:
    """读相机外参 T_base_cam（4x4）。"""
    rec = json.loads((_CALIB_DIR / "extrinsic_camera.json").read_text(encoding="utf-8"))
    T = np.asarray(rec["value_T_base_cam"], dtype=float)
    if T.shape != (4, 4) or not np.all(np.isfinite(T)):
        raise ValueError(f"extrinsic_camera.json 不是有限的 4x4：shape={T.shape}")
    if verbose:
        _provisional_banner("外参 T_base_cam", "4x4", rec["valid_only_if"], rec["recalibrate_when"])
    return T


def load_gripper_config() -> dict:
    """读夹爪运行时参数（正弦常数 + control 段 + target）。"""
    return yaml.safe_load((_CONFIG_DIR / "gripper.yaml").read_text(encoding="utf-8"))


def load_grasp_targets() -> dict:
    """读取抓取目标参数档案。

    目标物的几何尺寸、预张开量和试验状态属于任务参数，不应写死在
    夹爪标定或运动执行代码中。返回值以目标名为键，例如 ``cap31``、
    ``cube50``。
    """
    rec = yaml.safe_load(
        (_CONFIG_DIR / "grasp_targets.yaml").read_text(encoding="utf-8")
    )
    targets = rec.get("targets", {})
    if not targets:
        raise ValueError("grasp_targets.yaml 未定义 targets")
    return targets
