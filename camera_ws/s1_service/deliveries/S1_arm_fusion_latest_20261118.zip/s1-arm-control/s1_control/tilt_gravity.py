"""URDF-based differential gravity compensation for a tilted S1 base.

The vendor SDK already supplies gravity compensation for a level base.  This
module computes only the missing differential term::

    tau_delta = tau(g_base_tilted) - tau(g_base_level)

It intentionally contains no hardware access and does not replace the vendor
gravity model.  The base-frame convention used by the Go2 installation is
``+x rear, +y right, +z away from the mounting plane``.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np


GRAVITY_M_S2 = 9.81


def _vector(text: str) -> np.ndarray:
    values = np.asarray([float(item) for item in text.split()], dtype=float)
    if values.shape != (3,) or not np.all(np.isfinite(values)):
        raise ValueError(f"expected three finite values, got {text!r}")
    return values


def _rpy_matrix(rpy: np.ndarray) -> np.ndarray:
    roll, pitch, yaw = (float(value) for value in rpy)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=float)
    ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=float)
    rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=float)
    return rz @ ry @ rx


def _axis_angle(axis: np.ndarray, angle: float) -> np.ndarray:
    norm = float(np.linalg.norm(axis))
    if norm <= 0.0:
        raise ValueError("joint axis cannot be zero")
    x, y, z = axis / norm
    skew = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]], dtype=float)
    return (
        np.eye(3)
        + math.sin(angle) * skew
        + (1.0 - math.cos(angle)) * (skew @ skew)
    )


def _transform(rotation: np.ndarray, translation: np.ndarray) -> np.ndarray:
    result = np.eye(4)
    result[:3, :3] = rotation
    result[:3, 3] = translation
    return result


@dataclass(frozen=True)
class LinkInertia:
    mass_kg: float
    center_of_mass_m: np.ndarray


@dataclass(frozen=True)
class Joint:
    name: str
    parent: str
    child: str
    kind: str
    origin_xyz_m: np.ndarray
    origin_rpy_rad: np.ndarray
    axis: np.ndarray
    q_index: int | None


class UrdfGravityModel:
    """Minimal serial/tree URDF gravity model for the six S1 revolute joints."""

    def __init__(
        self,
        links: dict[str, LinkInertia],
        joints: list[Joint],
        root_link: str,
        actuated_joint_count: int,
    ) -> None:
        if actuated_joint_count != 6:
            raise ValueError(
                f"S1 model must have exactly six revolute joints, got "
                f"{actuated_joint_count}"
            )
        self.links = links
        self.joints = joints
        self.root_link = root_link
        self.actuated_joint_count = actuated_joint_count

    @classmethod
    def from_file(cls, path: str | Path) -> "UrdfGravityModel":
        path = Path(path).expanduser().resolve()
        root = ET.parse(path).getroot()
        links: dict[str, LinkInertia] = {}
        for element in root.findall("link"):
            name = element.get("name")
            if not name:
                raise ValueError("URDF link is missing a name")
            inertial = element.find("inertial")
            if inertial is None:
                links[name] = LinkInertia(0.0, np.zeros(3))
                continue
            mass_element = inertial.find("mass")
            if mass_element is None:
                raise ValueError(f"link {name} inertial is missing mass")
            mass = float(mass_element.get("value"))
            origin = inertial.find("origin")
            xyz = _vector(origin.get("xyz", "0 0 0")) if origin is not None else np.zeros(3)
            if not math.isfinite(mass) or mass < 0.0:
                raise ValueError(f"link {name} has invalid mass")
            links[name] = LinkInertia(mass, xyz)

        children: set[str] = set()
        joints: list[Joint] = []
        q_index = 0
        for element in root.findall("joint"):
            kind = element.get("type", "")
            parent_element = element.find("parent")
            child_element = element.find("child")
            if parent_element is None or child_element is None:
                raise ValueError("URDF joint is missing parent or child")
            parent = parent_element.get("link")
            child = child_element.get("link")
            if parent not in links or child not in links:
                raise ValueError("URDF joint references an unknown link")
            origin = element.find("origin")
            xyz = _vector(origin.get("xyz", "0 0 0")) if origin is not None else np.zeros(3)
            rpy = _vector(origin.get("rpy", "0 0 0")) if origin is not None else np.zeros(3)
            axis_element = element.find("axis")
            axis = (
                _vector(axis_element.get("xyz", "0 0 1"))
                if axis_element is not None
                else np.array([0.0, 0.0, 1.0])
            )
            index = q_index if kind in {"revolute", "continuous"} else None
            if index is not None:
                q_index += 1
            joints.append(
                Joint(
                    name=element.get("name", "unnamed"),
                    parent=parent,
                    child=child,
                    kind=kind,
                    origin_xyz_m=xyz,
                    origin_rpy_rad=rpy,
                    axis=axis,
                    q_index=index,
                )
            )
            children.add(child)

        roots = sorted(set(links) - children)
        if len(roots) != 1:
            raise ValueError(f"URDF must have one root link, got {roots}")
        return cls(links, joints, roots[0], q_index)

    @property
    def total_mass_kg(self) -> float:
        return sum(link.mass_kg for link in self.links.values())

    def _forward_tree(
        self, q_rad: list[float] | np.ndarray
    ) -> tuple[
        dict[str, np.ndarray],
        dict[str, list[tuple[int, np.ndarray, np.ndarray]]],
    ]:
        """Resolve link transforms and their actuated-joint ancestors."""
        q = np.asarray(q_rad, dtype=float)
        if q.shape != (6,) or not np.all(np.isfinite(q)):
            raise ValueError("q_rad must contain six finite joint angles")

        transforms = {self.root_link: np.eye(4)}
        ancestors: dict[str, list[tuple[int, np.ndarray, np.ndarray]]] = {
            self.root_link: []
        }
        pending = list(self.joints)
        while pending:
            progressed = False
            for joint in pending[:]:
                if joint.parent not in transforms:
                    continue
                parent_transform = transforms[joint.parent]
                joint_transform = parent_transform @ _transform(
                    _rpy_matrix(joint.origin_rpy_rad), joint.origin_xyz_m
                )
                child_ancestors = list(ancestors[joint.parent])
                if joint.q_index is not None:
                    joint_origin = joint_transform[:3, 3].copy()
                    joint_axis = joint_transform[:3, :3] @ joint.axis
                    joint_axis = joint_axis / np.linalg.norm(joint_axis)
                    child_ancestors.append(
                        (joint.q_index, joint_origin, joint_axis)
                    )
                    joint_transform = joint_transform @ _transform(
                        _axis_angle(joint.axis, float(q[joint.q_index])),
                        np.zeros(3),
                    )
                transforms[joint.child] = joint_transform
                ancestors[joint.child] = child_ancestors
                pending.remove(joint)
                progressed = True
            if not progressed:
                unresolved = [joint.name for joint in pending]
                raise ValueError(f"URDF tree cannot be resolved: {unresolved}")
        return transforms, ancestors

    def gravity_compensation(
        self, q_rad: list[float] | np.ndarray, gravity_base_m_s2: list[float] | np.ndarray
    ) -> np.ndarray:
        gravity = np.asarray(gravity_base_m_s2, dtype=float)
        if gravity.shape != (3,) or not np.all(np.isfinite(gravity)):
            raise ValueError("gravity vector must contain three finite values")

        transforms, ancestors = self._forward_tree(q_rad)

        indices = []
        axes = []
        arms = []
        masses = []
        for link_name, inertia in self.links.items():
            if inertia.mass_kg <= 0.0:
                continue
            link_transform = transforms[link_name]
            center = (
                link_transform[:3, :3] @ inertia.center_of_mass_m
                + link_transform[:3, 3]
            )
            for index, origin, axis in ancestors[link_name]:
                indices.append(index)
                axes.append(axis)
                arms.append(center - origin)
                masses.append(inertia.mass_kg)
        if not indices:
            return np.zeros(6)
        # Sum the same link moments in one vector operation. Gravity is linear.
        moments = np.cross(np.asarray(arms), np.asarray(masses)[:, None] * gravity)
        contributions = -np.einsum("ij,ij->i", np.asarray(axes), moments)
        return np.bincount(indices, weights=contributions, minlength=6)

    def point_mass_gravity_compensation(
        self,
        q_rad: list[float] | np.ndarray,
        gravity_base_m_s2: list[float] | np.ndarray,
        *,
        link_name: str,
        mass_kg: float,
        center_of_mass_link_m: list[float] | np.ndarray,
    ) -> np.ndarray:
        """Return compensation for one externally attached point mass.

        ``center_of_mass_link_m`` is expressed in ``link_name``.  This keeps
        an unmodelled wrist payload separate from the official URDF masses,
        so callers can commission it with an explicit runtime scale.
        """
        gravity = np.asarray(gravity_base_m_s2, dtype=float)
        center_link = np.asarray(center_of_mass_link_m, dtype=float)
        mass = float(mass_kg)
        if link_name not in self.links:
            raise ValueError(f"unknown payload attachment link: {link_name}")
        if gravity.shape != (3,) or not np.all(np.isfinite(gravity)):
            raise ValueError("gravity vector must contain three finite values")
        if center_link.shape != (3,) or not np.all(np.isfinite(center_link)):
            raise ValueError(
                "center_of_mass_link_m must contain three finite values"
            )
        if not math.isfinite(mass) or mass <= 0.0:
            raise ValueError("payload mass_kg must be positive and finite")

        transforms, ancestors = self._forward_tree(q_rad)
        center_base = (
            transforms[link_name] @ np.append(center_link, 1.0)
        )[:3]
        force = mass * gravity
        compensation = np.zeros(6)
        for index, origin, axis in ancestors[link_name]:
            compensation[index] += -float(
                np.dot(axis, np.cross(center_base - origin, force))
            )
        return compensation


def gravity_vector_base_rear_down(
    rear_edge_lower_deg: float, gravity_m_s2: float = GRAVITY_M_S2
) -> np.ndarray:
    """Return gravity in the S1 base frame for a rear-down mounting plane.

    Positive ``rear_edge_lower_deg`` means the mounting plane descends toward
    base ``+x`` (Go2 rear).  Consequently the base ``+z`` normal leans toward
    the rear and gravity has a positive base-x component.
    """
    if not math.isfinite(rear_edge_lower_deg):
        raise ValueError("rear_edge_lower_deg must be finite")
    if abs(rear_edge_lower_deg) >= 30.0:
        raise ValueError("rear_edge_lower_deg is outside the supported range")
    if not math.isfinite(gravity_m_s2) or gravity_m_s2 <= 0.0:
        raise ValueError("gravity_m_s2 must be positive and finite")
    angle = math.radians(rear_edge_lower_deg)
    return np.array(
        [
            gravity_m_s2 * math.sin(angle),
            0.0,
            -gravity_m_s2 * math.cos(angle),
        ],
        dtype=float,
    )


def differential_tilt_compensation(
    model: UrdfGravityModel,
    q_rad: list[float] | np.ndarray,
    rear_edge_lower_deg: float,
) -> np.ndarray:
    level_gravity = np.array([0.0, 0.0, -GRAVITY_M_S2], dtype=float)
    tilted_gravity = gravity_vector_base_rear_down(rear_edge_lower_deg)
    return model.gravity_compensation(q_rad, tilted_gravity - level_gravity)


def gravity_vector_base_from_support_up(
    support_up_normal_base: list[float] | np.ndarray,
    gravity_m_s2: float = GRAVITY_M_S2,
) -> np.ndarray:
    """Return gravity from a unit world-up direction expressed in S1 base.

    This is valid only when the supplied normal is independently known to be
    world-up.  A wall or arbitrary sloped surface normal must never be passed
    here merely because it was observed by a camera.
    """
    support_up = np.asarray(support_up_normal_base, dtype=float)
    if support_up.shape != (3,) or not np.all(np.isfinite(support_up)):
        raise ValueError("support_up_normal_base must contain three finite values")
    norm = float(np.linalg.norm(support_up))
    if not 0.98 <= norm <= 1.02:
        raise ValueError("support_up_normal_base must be a unit vector")
    if support_up[2] <= 0.0:
        raise ValueError("support_up_normal_base must point toward base +z")
    if not math.isfinite(gravity_m_s2) or gravity_m_s2 <= 0.0:
        raise ValueError("gravity_m_s2 must be positive and finite")
    return -float(gravity_m_s2) * (support_up / norm)


def differential_tilt_compensation_from_support_up(
    model: UrdfGravityModel,
    q_rad: list[float] | np.ndarray,
    support_up_normal_base: list[float] | np.ndarray,
) -> np.ndarray:
    """Compute the level-to-current gravity difference for full pitch/roll."""
    level_gravity = np.array([0.0, 0.0, -GRAVITY_M_S2], dtype=float)
    current_gravity = gravity_vector_base_from_support_up(
        support_up_normal_base
    )
    return model.gravity_compensation(q_rad, current_gravity - level_gravity)


def limited_correction(
    correction_nm: list[float] | np.ndarray,
    scale: float,
    absolute_limits_nm: list[float] | np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    correction = np.asarray(correction_nm, dtype=float)
    limits = np.asarray(absolute_limits_nm, dtype=float)
    if correction.shape != (6,) or limits.shape != (6,):
        raise ValueError("correction and limits must each contain six values")
    if not np.all(np.isfinite(correction)) or not np.all(np.isfinite(limits)):
        raise ValueError("correction and limits must be finite")
    if np.any(limits <= 0.0):
        raise ValueError("all correction limits must be positive")
    if not math.isfinite(scale) or scale < 0.0 or scale > 1.0:
        raise ValueError("scale must be within [0, 1]")
    requested = correction * scale
    applied = np.clip(requested, -limits, limits)
    return requested, applied


def locate_official_gripper_urdf() -> Path:
    import S1_SDK

    path = Path(S1_SDK.__file__).resolve().parent / "resource" / "gripper.urdf"
    if not path.is_file():
        raise FileNotFoundError(f"official S1 gripper URDF not found: {path}")
    return path
