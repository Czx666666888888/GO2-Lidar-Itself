# -*- coding: utf-8 -*-
"""夹爪（达妙 ID7）运行时控制。照搬 industrial-agent/scripts/s1_gripper_sweep.py（已实机验证）。

★接口只收开口 mm，内部经 mm_to_fb 转成 control_gripper 的 [0,2.0] 命令★
  本项目前身踩过：把臆想的 fb 值（0.5/1.53）直接发给 control_gripper 导致夹爪不动。
  正确路径永远是 目标mm → mm_to_fb(mm) → control_gripper(fb, force)。
  （另注：前身那次“夹爪不动”的真因其实是夹爪被物理挡住；但接口只收 mm 这条纪律仍然成立。）

方向约定（官方 SDK，2026-07-20 定案）：fb ∈ [0,2.0]，0=全闭、2.0≈全开(102mm)，越大越开。
常数（正弦 A/k/phase/D、力、接触判据、开口范围）来自 config/gripper.yaml，不硬编。
"""
from __future__ import annotations

import math

from .calib import load_gripper_config


class Gripper:
    def __init__(self, arm, config: dict | None = None):
        """arm: s1_control.arm.Arm 实例（透传其 _arm.control_gripper / get_pos）。"""
        self._arm = arm
        cfg = config or load_gripper_config()
        s = cfg["motor"]["sinusoidal"]
        self.A, self.k, self.phase, self.D = s["A"], s["k"], s["phase"], s["D"]
        c = cfg["control"]
        self.force = float(c["grip_force_nm"])
        self.min_gap_mm = float(c["min_gap_mm"])
        self.max_gap_mm = float(c["max_gap_mm"])
        self.contact_follow_err_rad = float(c["contact_follow_err_rad"])
        self.cap_diameter_mm = float(cfg.get("target", {}).get("cap_diameter_mm", 31))

    # ---- mm ↔ fb 映射（照搬 sweep）----
    def gap_from_fb(self, fb: float) -> float:
        """fb → 开口 mm。gap = A*cos(k*(2.0853-fb)+phase)+D，钳到 acos 单调域。"""
        x = self.k * (2.0853 - fb) + self.phase
        x = max(0.0, min(math.pi, x))
        return self.A * math.cos(x) + self.D

    def mm_to_fb(self, mm: float) -> float:
        """目标开口 mm → control_gripper 的 fb 命令（[0,2.0]）。"""
        mm = max(self.min_gap_mm, min(self.max_gap_mm, mm))
        val = max(-1.0, min(1.0, (mm - self.D) / self.A))
        x = math.acos(val)
        return 2.0853 - (x - self.phase) / self.k

    # ---- 命令（只收 mm）----
    def command_mm(self, mm: float, force: float | None = None):
        """下发一次夹爪命令到目标开口 mm。

        ``force`` 省略时使用夹爪标定配置的默认值；目标档案可为轻质物块
        传入更低的试验力矩。返回 fb 命令值，供调用方与关节命令同拍使用。
        """
        fb = self.mm_to_fb(mm)
        self._arm._arm.control_gripper(fb, self.force if force is None else float(force))
        return fb

    def read_gap_mm(self) -> float:
        """读当前开口 mm（get_pos()[6] → gap_from_fb）。"""
        return self.gap_from_fb(self._arm.get_pos()[6])

    def is_holding(self, fb_cmd: float) -> tuple[bool, float]:
        """接触判据：合爪后 fb-cmd > contact_follow_err_rad 判为夹住（空夹趋0/负）。
        返回 (是否夹住, follow_err)。"""
        fb = self._arm.get_pos()[6]
        follow_err = fb - fb_cmd
        return follow_err > self.contact_follow_err_rad, follow_err

    def is_holding_mm(self, command_mm: float, min_excess_mm: float) -> tuple[bool, float, float]:
        """用毫米语义判断是否被目标物阻挡。

        对不同尺寸目标，固定的电机角跟随误差阈值并不等价。例如 50 mm
        方块只比闭合目标大几毫米时，沿用瓶盖的 0.10 rad 阈值会误判夹空。
        这里改用 ``实测开口 - 闭合命令``，返回
        ``(是否夹住, 开口超差mm, 实测开口mm)``。

        该判据仍需用空夹和实物重复试验标定，不能替代视觉确认或力传感器。
        """
        gap_mm = self.read_gap_mm()
        excess_mm = gap_mm - float(command_mm)
        return excess_mm >= float(min_excess_mm), excess_mm, gap_mm
