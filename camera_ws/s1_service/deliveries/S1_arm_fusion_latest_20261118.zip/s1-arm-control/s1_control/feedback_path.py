"""Opt-in shared-clock alignment governor; does not change gains or torque."""
from __future__ import annotations

import math
import time

from .arm import (
    _validated_joint_path, _joint_path_motion_duration_prepared,
    _joint_path_target_prepared, motion_profile_progress,
)


def forward_tracking_lag(expected, measured, direction):
    """Directional lag in physical coordinates, never command-minus-feedback."""
    values = list(expected) + list(measured) + list(direction)
    if len(values) != 18 or not all(math.isfinite(float(x)) for x in values):
        raise ValueError("feedback governor requires six finite joints")
    return max([0.0] + [
        (p-m) * (1.0 if d > 0 else -1.0)
        for p, m, d in zip(expected, measured, direction) if abs(d) > 1e-9
    ])


class SharedClockGovernor:
    """Slow the whole path, not individual joints, when physical tracking lags."""
    def __init__(self, soft_lag_rad=.002, stop_lag_rad=.004,
                 scale_slew_per_s=2.0):
        if not (0 < soft_lag_rad < stop_lag_rad <= .008):
            raise ValueError("invalid feedback lag limits")
        if not math.isfinite(scale_slew_per_s) or not 0 < scale_slew_per_s <= 2:
            raise ValueError("invalid clock slew")
        self.soft = soft_lag_rad
        self.stop = stop_lag_rad
        self.slew = scale_slew_per_s
        self.scale = 1.0

    def update(self, lag, dt):
        if not math.isfinite(lag) or lag < 0 or not math.isfinite(dt) or dt <= 0:
            raise ValueError("invalid feedback clock sample")
        target = max(0.0, min(1.0, (self.stop-lag)/(self.stop-self.soft)))
        # Immediate inhibit is intentional: do not advance a lagging path while
        # waiting for a smooth deceleration. Position remains continuous.
        if lag >= self.stop:
            self.scale = 0.0
        else:
            step = self.slew * dt
            self.scale += max(-step, min(step, target-self.scale))
        return self.scale


def move_feedback_synchronized(arm, command_path, physical_path, label, report):
    """Retiming only: execute exactly the preflighted constant-offset path.

    A stagnant/cached SDK feedback stream cannot authorize continued progress:
    lag freezes the shared clock and a bounded wait aborts. It does not prove
    per-motor frame freshness. Existing arm.guard and commander guards remain.
    """
    points, lengths, total = _validated_joint_path(command_path)
    physical, _, _ = _validated_joint_path(physical_path)
    if len(points) != len(physical):
        raise ValueError("physical and command paths must match")
    offset = [c-p for c,p in zip(points[0], physical[0])]
    if max(abs(x) for x in offset) > .05:
        raise ValueError("feedback path learned offset exceeds 0.05rad")
    if any(abs(c-p-b) > 1e-9 for cq,pq in zip(points,physical)
           for c,p,b in zip(cq,pq,offset)):
        raise ValueError("feedback path requires constant learned offset")
    limits = arm.limits
    ramp = _joint_path_motion_duration_prepared(
        points, lengths, total, limits.v_max_rad_s,
        limits.j6_v_max_rad_s, limits.motion_profile,
    )
    governor = SharedClockGovernor()
    started = time.monotonic()
    clock = 0.0
    blocked_since = None
    report.update(status="running", scope="center_alignment_only",
                  soft_lag_rad=governor.soft, stop_lag_rad=governor.stop,
                  maximum_blocked_s=3.0, nominal_duration_s=ramp,
                  cycles=0, inhibited_cycles=0, maximum_lag_rad=0.0,
                  minimum_clock_scale=1.0)
    while True:
        cycle_started = time.monotonic()
        if cycle_started-started > 3*ramp+5:
            report["status"] = "timeout"
            return label + ": feedback path exceeded bounded duration"
        progress = motion_profile_progress(min(1.0, clock/ramp), limits.motion_profile)
        target = _joint_path_target_prepared(points, lengths, total, progress)
        expected = [c-b for c,b in zip(target,offset)]
        ahead = _joint_path_target_prepared(
            points, lengths, total, min(1.0, progress+1e-5))
        direction = [b-a for a,b in zip(target,ahead)]
        measured = list(arm.get_pos()[:6])
        lag = forward_tracking_lag(expected, measured, direction)
        scale = governor.update(lag, arm.dt)
        report["cycles"] += 1
        report["maximum_lag_rad"] = max(report["maximum_lag_rad"],lag)
        report["minimum_clock_scale"] = min(report["minimum_clock_scale"],scale)
        report["last_expected_physical_q_rad"] = expected
        report["last_measured_q_rad"] = measured
        report["last_clock_scale"] = scale
        report["trajectory_clock_s"] = clock
        arm.command_position(target)
        fault = arm.guard(list(arm._arm.get_pos()), list(arm._arm.get_vel()),
                          list(arm._arm.get_temp()), target,
                          settling=clock < limits.settle_seconds)
        if fault:
            report["status"] = "guard_rejected"
            return label + ": " + fault
        if clock >= ramp:
            report["status"] = "path_issued_pending_endpoint_and_vision"
            report["elapsed_s"] = time.monotonic()-started
            return None
        if scale < .01:
            report["inhibited_cycles"] += 1
            if blocked_since is None:
                blocked_since = cycle_started
            if cycle_started-blocked_since >= 3.0:
                report["status"] = "tracking_stalled"
                return label + ": feedback progress stalled for 3s"
        else:
            blocked_since = None
        clock = min(ramp, clock + arm.dt*scale)
        time.sleep(max(0.0, arm.dt-(time.monotonic()-cycle_started)))
