# -*- coding: utf-8 -*-
"""FK/IK —— 纯 S1_SDK.S1_solver，不碰硬件、不碰相机、无需显示。

★自包含关键★：本模块【不】import 任何相机/串口代码。FK/IK 只需
`from S1_SDK import S1_solver` + TCP 数值（从 calibration/tcp.json 读）。

实现照搬 industrial-agent/scripts/s1_l4_hover_official.py 的 _fk_pose/_ik/
_ik_multi_seed（已实机验证），要点原样保留：
  - LMA 是【局部】解算器，可达域边缘不稳定，且【同种子同目标跨调用非确定】
    → 多种子 + 每轮多种子 + 5 轮重试，任一命中即返回；
  - 折叠位种子常无解，用触点标定实测的抓取区位形 GRASP_REGION_SEED_Q 做种子并施加确定性扰动。
"""
from __future__ import annotations

import math

import numpy as np

from .calib import load_tcp

# 触点标定位形（关节角两坐标系相同）。来自 s1_l4_hover_official.py:50。
GRASP_REGION_SEED_Q = [0.3344, 1.4662, 0.6231, -0.7307, -0.2256, -0.0235]
# 安全姿态（home/ready）。来自 s1_l4_hover_official.py:51。
READY_Q = [0.00, 0.19, 0.38, 0.20, 0.00, 0.00]


class Kinematics:
    """封装 S1_solver(TCP) 的 FK/IK。TCP 从标定文件读（provisional）。"""

    def __init__(self, tcp: list[float] | None = None, verbose: bool = True):
        self.tcp = list(tcp) if tcp is not None else load_tcp(verbose=verbose)

    def _solver(self):
        # 延迟 import：S1_SDK 只在真正解算时才需要（保持模块 import 轻量）。
        from S1_SDK import S1_solver
        return S1_solver(self.tcp)

    def fk(self, q) -> list[float]:
        """正解：6 关节 → [x,y,z,qx,qy,qz,qw]。"""
        pose = self._solver().forward_quat(list(q))
        if len(pose) != 7:
            raise RuntimeError(f"unexpected FK result: {pose}")
        return [float(v) for v in pose]

    def ik(self, target_xyz, orientation_xyzw, seed_q):
        """单次逆解：位姿 + 单种子 → 6 关节 或 None。"""
        sol = self._solver().inverse_quat(
            list(target_xyz) + list(orientation_xyzw), list(seed_q))
        return [float(v) for v in sol] if sol else None

    def ik_multi_seed(self, xyz, orient, seeds):
        """多种子 + 确定性扰动 + 5 轮重试的稳健逆解（LMA 非确定，见模块 docstring）。"""
        tried = list(seeds)
        for dj1 in (0.0, 0.25, -0.25):
            for dj2 in (0.0, 0.2, -0.2):
                s = list(GRASP_REGION_SEED_Q)
                s[0] += dj1
                s[1] += dj2
                tried.append(s)
        for _round in range(5):
            for s in tried:
                q = self.ik(list(xyz), list(orient), list(s))
                if q is not None:
                    return q
        return None


def quat_to_R(x, y, z, w) -> np.ndarray:
    """四元数 xyzw → 3x3 旋转矩阵。来自 s1_l4_hover_official.py:_quat_to_R。"""
    n = math.sqrt(x * x + y * y + z * z + w * w)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])
