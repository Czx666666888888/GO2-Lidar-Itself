"""Pure geometry and binding checks for wrist-camera high-hover alignment.

This module has no camera or serial access.  Corrections are expressed in the
measured support-plane tangent plane, not in the tilted S1 base X-Y plane.
Descent and grasping are outside the validated scope.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from .kinematics import quat_to_R


PROJECT_ROOT = Path(__file__).resolve().parents[1]
JOINT_LIMITS_RAD = [
    (math.radians(-170.0), math.radians(170.0)),
    (math.radians(0.0), math.radians(180.0)),
    (math.radians(0.0), math.radians(170.0)),
    (math.radians(-90.0), math.radians(87.0)),
    (math.radians(-90.0), math.radians(90.0)),
    (math.radians(-90.0), math.radians(90.0)),
]


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resolve_project_path(raw_path: str | Path, root: Path = PROJECT_ROOT) -> Path:
    from .project_paths import project_path
    return project_path(raw_path, root)


def _finite_vector(value: Any, length: int, name: str) -> np.ndarray:
    vector = np.asarray(value, dtype=np.float64)
    if vector.shape != (length,) or not np.isfinite(vector).all():
        raise ValueError(f"{name} must contain {length} finite values")
    return vector


def _finite_transform(value: Any, name: str) -> np.ndarray:
    transform = np.asarray(value, dtype=np.float64)
    if transform.shape != (4, 4) or not np.isfinite(transform).all():
        raise ValueError(f"{name} must be a finite 4x4 transform")
    if not np.allclose(transform[3], [0.0, 0.0, 0.0, 1.0], atol=1e-9):
        raise ValueError(f"{name} has an invalid homogeneous row")
    if not np.allclose(transform[:3, :3].T @ transform[:3, :3], np.eye(3), atol=1e-5):
        raise ValueError(f"{name} rotation is not orthonormal")
    if np.linalg.det(transform[:3, :3]) < 0.999:
        raise ValueError(f"{name} rotation determinant is invalid")
    return transform


def _unit_vector(value: Any, name: str) -> np.ndarray:
    vector = _finite_vector(value, 3, name)
    norm = float(np.linalg.norm(vector))
    if norm < 1e-9:
        raise ValueError(f"{name} must be non-zero")
    return vector / norm


def _finite_interval(value: Any, name: str) -> tuple[float, float]:
    interval = _finite_vector(value, 2, name)
    lower, upper = map(float, interval)
    if lower >= upper:
        raise ValueError(f"{name} lower bound must be below upper bound")
    return lower, upper


def _validate_workspace_record(workspace: dict) -> None:
    if not isinstance(workspace, dict):
        raise ValueError("validated workspace must be an object")
    _finite_interval(workspace.get("tcp_base_x_mm"), "tcp_base_x_mm")
    _finite_interval(workspace.get("tcp_base_y_mm"), "tcp_base_y_mm")
    _finite_interval(
        workspace.get("normal_clearance_mm"), "normal_clearance_mm"
    )
    tilt = float(
        workspace.get("maximum_camera_tilt_from_support_down_deg", float("nan"))
    )
    if not math.isfinite(tilt) or not 0.0 < tilt <= 15.0:
        raise ValueError(
            "maximum_camera_tilt_from_support_down_deg must be in (0, 15]"
        )


@dataclass(frozen=True)
class LoadedWristServoConfig:
    path: Path
    record: dict
    candidate_path: Path
    tcp_path: Path
    vision_config_path: Path
    transform_flange_camera: np.ndarray
    mount_config_path: Path | None = None
    static_validation_summary_path: Path | None = None


def load_wrist_servo_config(
    path: str | Path,
    *,
    root: str | Path = PROJECT_ROOT,
    verify_bindings: bool = True,
) -> LoadedWristServoConfig:
    root_path = Path(root).expanduser().resolve()
    config_path = resolve_project_path(path, root_path)
    record = json.loads(config_path.read_text(encoding="utf-8"))
    if record.get("schema_version") != 1:
        raise ValueError("wrist servo schema_version must be 1")
    mode = record.get("mode")
    supported_modes = {
        "high_hover_xy_only",
        "high_hover_support_tangent_only",
    }
    if mode not in supported_modes:
        raise ValueError(f"unsupported wrist servo mode: {mode!r}")
    if record.get("candidate_policy") != "coarse_closed_loop_only":
        raise ValueError("eye-in-hand candidate must be restricted to coarse closed loop")

    bindings = record.get("bindings")
    if not isinstance(bindings, dict):
        raise ValueError("wrist servo bindings are missing")
    resolved = {}
    for name in ("eye_in_hand_candidate", "tcp", "vision_config"):
        binding = bindings.get(name)
        if not isinstance(binding, dict):
            raise ValueError(f"missing binding: {name}")
        bound_path = resolve_project_path(binding.get("path", ""), root_path)
        if not bound_path.is_file():
            raise FileNotFoundError(f"bound file does not exist: {bound_path}")
        actual = file_sha256(bound_path)
        expected = str(binding.get("sha256", "")).lower()
        if verify_bindings and actual != expected:
            raise RuntimeError(
                f"{name} SHA-256 mismatch: expected={expected} actual={actual}"
            )
        resolved[name] = bound_path

    if mode == "high_hover_support_tangent_only":
        for name in ("mount_config", "static_validation_summary"):
            binding = bindings.get(name)
            if not isinstance(binding, dict):
                raise ValueError(f"missing binding: {name}")
            bound_path = resolve_project_path(binding.get("path", ""), root_path)
            if not bound_path.is_file():
                raise FileNotFoundError(f"bound file does not exist: {bound_path}")
            actual = file_sha256(bound_path)
            expected = str(binding.get("sha256", "")).lower()
            if verify_bindings and actual != expected:
                raise RuntimeError(
                    f"{name} SHA-256 mismatch: expected={expected} actual={actual}"
                )
            resolved[name] = bound_path

    candidate = json.loads(
        resolved["eye_in_hand_candidate"].read_text(encoding="utf-8")
    )
    if candidate.get("quantity") != "T_flange_camera":
        raise ValueError("candidate quantity must be T_flange_camera")
    if candidate.get("status") != "candidate_pending_physical_validation":
        raise ValueError("only the explicitly pending candidate status is supported")
    if candidate.get("runtime_approved") is not False:
        raise ValueError("candidate must remain runtime_approved=false at this stage")
    provenance = candidate.get("provenance", {})
    if str(provenance.get("camera_serial")) != str(record.get("camera_serial")):
        raise RuntimeError("candidate and servo config camera serials differ")

    if mode == "high_hover_support_tangent_only":
        summary = json.loads(
            resolved["static_validation_summary"].read_text(encoding="utf-8")
        )
        if summary.get("status") != "provisional_bounded_static_validated":
            raise ValueError("static validation summary has not passed the bounded gate")
        if summary.get("candidate_sha256") != file_sha256(
            resolved["eye_in_hand_candidate"]
        ):
            raise RuntimeError("static validation summary is bound to another candidate")
        if summary.get("mount_config_sha256") != file_sha256(
            resolved["mount_config"]
        ):
            raise RuntimeError("static validation summary is bound to another mount")
        workspace = record.get("validated_workspace")
        if not isinstance(workspace, dict):
            raise ValueError("validated_workspace is required for tangent mode")
        if workspace != summary.get("validated_runtime_envelope"):
            raise RuntimeError(
                "servo validated_workspace differs from static validation evidence"
            )
        tilt_compensation = record.get("tilt_compensation")
        if not isinstance(tilt_compensation, dict):
            raise ValueError("tilt_compensation is required for tangent mode")
        if tilt_compensation.get("required_for_position_control") is not True:
            raise ValueError(
                "tilt compensation must be required for all position commands"
            )
        if tilt_compensation.get("gravity_direction_source") != (
            "validated_horizontal_support_plane"
        ):
            raise ValueError(
                "ground tangent mode requires a validated horizontal "
                "support-plane gravity direction"
            )
        if tilt_compensation.get("fallback_before_first_valid_plane") != (
            "mount_record_pitch_only"
        ):
            raise ValueError("unsupported tilt-compensation fallback")
        scale = float(tilt_compensation.get("scale", float("nan")))
        if not math.isfinite(scale) or not 0.0 < scale <= 1.0:
            raise ValueError("tilt compensation scale must be in (0, 1]")
        mount_record = json.loads(
            resolved["mount_config"].read_text(encoding="utf-8")
        )
        allowed_scales = [
            float(value)
            for value in mount_record.get("diagnostic", {}).get(
                "allowed_scale_steps", []
            )
        ]
        if not any(
            math.isclose(scale, value, abs_tol=1e-9)
            for value in allowed_scales
        ):
            raise ValueError(
                f"tilt compensation scale {scale} is not approved by mount config"
            )
        maximum_support_tilt_deg = float(
            tilt_compensation.get("maximum_support_tilt_deg", float("nan"))
        )
        if (
            not math.isfinite(maximum_support_tilt_deg)
            or not 0.0 < maximum_support_tilt_deg <= 15.0
        ):
            raise ValueError("maximum support tilt must be in (0, 15] deg")
        maximum_support_deviation_deg = float(
            tilt_compensation.get(
                "maximum_support_normal_deviation_from_mount_deg",
                float("nan"),
            )
        )
        if (
            not math.isfinite(maximum_support_deviation_deg)
            or not 0.0 < maximum_support_deviation_deg <= 10.0
        ):
            raise ValueError(
                "maximum support-normal deviation must be in (0, 10] deg"
            )
        normal_transition_s = float(
            tilt_compensation.get("normal_transition_s", float("nan"))
        )
        if (
            not math.isfinite(normal_transition_s)
            or not 0.1 <= normal_transition_s <= 2.0
        ):
            raise ValueError("support-normal transition must be within [0.1, 2] s")
        support_normal_blend = float(
            tilt_compensation.get("support_normal_blend", float("nan"))
        )
        if (
            not math.isfinite(support_normal_blend)
            or not 0.0 < support_normal_blend <= 0.5
        ):
            raise ValueError(
                "first physical support-normal blend must be in (0, 0.5]"
            )

    safety = record.get("safety", {})
    required_positive = (
        "convergence_xy_mm",
        "maximum_initial_xy_error_mm",
        "maximum_xy_step_mm",
        "minimum_camera_target_depth_mm",
        "maximum_camera_target_depth_mm",
        "minimum_target_clearance_mm",
        "maximum_target_clearance_mm",
        "maximum_joint_step_rad",
        "minimum_joint_margin_deg",
        "worker_timeout_s",
        "final_hold_s",
        "collision_step_rad",
        "maximum_camera_tilt_from_down_deg",
        "maximum_post_motion_joint_error_rad",
        "minimum_post_motion_xy_progress_ratio",
        "maximum_post_motion_xy_progress_ratio",
        "minimum_post_motion_direction_cosine",
        "maximum_post_motion_tcp_z_drift_mm",
        "post_motion_settle_s",
    )
    for key in required_positive:
        value = float(safety.get(key, float("nan")))
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"safety.{key} must be positive and finite")
    if int(safety.get("maximum_iterations", 0)) < 1:
        raise ValueError("safety.maximum_iterations must be positive")
    if float(safety["maximum_xy_step_mm"]) > 10.0:
        raise ValueError("maximum_xy_step_mm cannot exceed 10 mm in first validation")
    if float(safety["maximum_joint_step_rad"]) > 0.15:
        raise ValueError("maximum_joint_step_rad cannot exceed 0.15 rad")
    if float(safety["maximum_camera_tilt_from_down_deg"]) > 15.0:
        raise ValueError(
            "maximum_camera_tilt_from_down_deg cannot exceed 15 deg "
            "during first wrist-camera validation"
        )
    if float(safety["minimum_camera_target_depth_mm"]) < 300.0:
        raise ValueError("minimum camera target depth cannot be below 300 mm")
    if float(safety["maximum_camera_target_depth_mm"]) <= float(
        safety["minimum_camera_target_depth_mm"]
    ):
        raise ValueError("maximum camera target depth must exceed minimum")
    if float(safety["minimum_target_clearance_mm"]) < 60.0:
        raise ValueError("minimum target clearance cannot be below 60 mm")
    if float(safety["maximum_target_clearance_mm"]) <= float(
        safety["minimum_target_clearance_mm"]
    ):
        raise ValueError("maximum target clearance must exceed minimum")
    minimum_progress = float(
        safety["minimum_post_motion_xy_progress_ratio"]
    )
    maximum_progress = float(
        safety["maximum_post_motion_xy_progress_ratio"]
    )
    if not minimum_progress < 1.0 < maximum_progress:
        raise ValueError(
            "post-motion tangent progress ratio range must contain 1.0"
        )
    if float(safety["minimum_post_motion_direction_cosine"]) > 1.0:
        raise ValueError(
            "minimum_post_motion_direction_cosine cannot exceed 1.0"
        )
    if float(safety["maximum_post_motion_joint_error_rad"]) > 0.03:
        raise ValueError(
            "maximum_post_motion_joint_error_rad cannot exceed 0.03 rad "
            "during first wrist-camera validation"
        )
    if float(safety["maximum_post_motion_tcp_z_drift_mm"]) > 5.0:
        raise ValueError(
            "maximum_post_motion_tcp_z_drift_mm (support-normal semantics) "
            "cannot exceed 5 mm during first wrist-camera validation"
        )
    post_motion_samples = int(safety.get("post_motion_sample_count", 0))
    if not 5 <= post_motion_samples <= 100:
        raise ValueError("post_motion_sample_count must be in [5, 100]")
    if mode == "high_hover_support_tangent_only":
        cumulative = float(
            safety.get("maximum_cumulative_tangent_motion_mm", float("nan"))
        )
        if not math.isfinite(cumulative) or cumulative <= 0.0 or cumulative > 30.0:
            raise ValueError(
                "maximum_cumulative_tangent_motion_mm must be in (0, 30]"
            )
        if (
            int(safety["maximum_iterations"])
            * float(safety["maximum_xy_step_mm"])
            > cumulative + 1e-9
        ):
            raise ValueError(
                "iteration count and step limit exceed cumulative tangent limit"
            )
        _validate_workspace_record(record["validated_workspace"])

    return LoadedWristServoConfig(
        path=config_path,
        record=record,
        candidate_path=resolved["eye_in_hand_candidate"],
        tcp_path=resolved["tcp"],
        vision_config_path=resolved["vision_config"],
        transform_flange_camera=_finite_transform(
            candidate["value_T_flange_camera"], "T_flange_camera"
        ),
        mount_config_path=resolved.get("mount_config"),
        static_validation_summary_path=resolved.get("static_validation_summary"),
    )


def pose_to_transform(pose_xyz_xyzw: Any) -> np.ndarray:
    pose = _finite_vector(pose_xyz_xyzw, 7, "pose_xyz_xyzw")
    transform = np.eye(4, dtype=np.float64)
    transform[:3, :3] = quat_to_R(*pose[3:])
    transform[:3, 3] = pose[:3]
    return transform


def dynamic_base_camera(
    flange_pose_xyz_xyzw: Any, transform_flange_camera: Any
) -> np.ndarray:
    return pose_to_transform(flange_pose_xyz_xyzw) @ _finite_transform(
        transform_flange_camera, "T_flange_camera"
    )


def camera_tilt_from_down_deg(
    flange_pose_xyz_xyzw: Any, transform_flange_camera: Any
) -> float:
    """Return the D455 optical +Z-axis angle from base-frame vertical down."""
    transform_base_camera = dynamic_base_camera(
        flange_pose_xyz_xyzw, transform_flange_camera
    )
    optical_axis_base = transform_base_camera[:3, 2]
    cosine = float(np.dot(optical_axis_base, [0.0, 0.0, -1.0]))
    cosine = min(1.0, max(-1.0, cosine))
    return math.degrees(math.acos(cosine))


def support_plane_geometry(
    normal_camera: Any,
    transform_base_camera: Any,
) -> dict:
    """Return the measured ground-up normal and camera axis in base frame."""
    transform = _finite_transform(transform_base_camera, "T_base_camera")
    support_up = _unit_vector(
        transform[:3, :3] @ _unit_vector(normal_camera, "support normal camera"),
        "support normal base",
    )
    if support_up[2] < 0.0:
        support_up = -support_up
    camera_axis = _unit_vector(
        transform[:3, 2], "camera optical axis base"
    )
    support_down = -support_up
    cosine = float(np.clip(np.dot(camera_axis, support_down), -1.0, 1.0))
    camera_tilt_deg = math.degrees(math.acos(cosine))
    return {
        "support_up_normal_base": support_up.tolist(),
        "camera_optical_axis_base": camera_axis.tolist(),
        "camera_tilt_from_support_down_deg": camera_tilt_deg,
        "rear_edge_lower_deg": math.degrees(
            math.atan2(-float(support_up[0]), float(support_up[2]))
        ),
        "right_edge_lower_deg": math.degrees(
            math.atan2(-float(support_up[1]), float(support_up[2]))
        ),
    }


def _tangent_projection(vector: Any, support_up_normal_base: Any) -> np.ndarray:
    value = _finite_vector(vector, 3, "vector")
    support_up = _unit_vector(support_up_normal_base, "support up normal base")
    return value - float(np.dot(value, support_up)) * support_up


def _validate_tcp_workspace(tcp_xyz_m: Any, workspace: dict, label: str) -> None:
    tcp = _finite_vector(tcp_xyz_m, 3, label)
    if workspace.get("advisory_bounds") is True:
        try:
            _validate_tcp_workspace(tcp, dict(workspace, advisory_bounds=False), label)
        except RuntimeError as exc:
            print(f"HISTORICAL_WORKSPACE_WARNING = {exc}")
        return
    x_range = _finite_interval(workspace["tcp_base_x_mm"], "tcp_base_x_mm")
    y_range = _finite_interval(workspace["tcp_base_y_mm"], "tcp_base_y_mm")
    x_mm, y_mm = 1000.0 * tcp[:2]
    if not x_range[0] <= x_mm <= x_range[1]:
        raise RuntimeError(
            f"{label} base X {x_mm:.1f} mm outside validated range {x_range}"
        )
    if not y_range[0] <= y_mm <= y_range[1]:
        raise RuntimeError(
            f"{label} base Y {y_mm:.1f} mm outside validated range {y_range}"
        )


def extract_single_surface_observation(
    detection: dict,
    capture_metadata: dict,
    transform_base_camera: Any,
    expected_camera_serial: str,
    safety: dict,
) -> dict:
    if capture_metadata.get("quality_pass") is not True:
        raise ValueError("RGB-D capture quality gate failed")
    if str(capture_metadata.get("serial")) != str(expected_camera_serial):
        raise RuntimeError("captured D455 serial does not match the bound camera")
    if detection.get("schema_version") != 2:
        raise ValueError("detection schema_version must be 2")
    if detection.get("status") != "DETECTED_CAMERA_FRAME_ONLY":
        raise ValueError(f"single-target detection failed: {detection.get('status')}")
    if detection.get("camera_frame_only") is not True:
        raise ValueError("detection must be marked camera_frame_only")
    if int(detection.get("accepted_candidate_count", 0)) != 1:
        raise ValueError("high-hover test requires exactly one accepted target")
    selected = detection.get("selected")
    if not isinstance(selected, dict) or selected.get("accepted") is not True:
        raise ValueError("detection has no accepted selected target")
    plane = detection.get("plane")
    if not isinstance(plane, dict) or plane.get("quality_pass") is not True:
        raise ValueError("support-plane quality gate failed")

    transform = _finite_transform(transform_base_camera, "T_base_camera")
    plane_geometry = support_plane_geometry(plane.get("normal_cam"), transform)
    maximum_support_tilt = float(
        safety["maximum_camera_tilt_from_down_deg"]
    )
    if (
        plane_geometry["camera_tilt_from_support_down_deg"]
        > maximum_support_tilt
    ):
        raise RuntimeError(
            "camera tilt from support down "
            f"{plane_geometry['camera_tilt_from_support_down_deg']:.2f} deg "
            f"exceeds {maximum_support_tilt:.2f} deg"
        )
    surface_cam = _finite_vector(
        selected.get("surface_point_cam_m"), 3, "surface_point_cam_m"
    )
    camera_target_depth_mm = 1000.0 * float(surface_cam[2])
    minimum_camera_depth_mm = float(safety["minimum_camera_target_depth_mm"])
    maximum_camera_depth_mm = float(safety["maximum_camera_target_depth_mm"])
    if (safety.get("camera_target_depth_window_enabled", True)
            and not minimum_camera_depth_mm <= camera_target_depth_mm <= maximum_camera_depth_mm):
        raise RuntimeError(
            f"camera target depth {camera_target_depth_mm:.1f} mm outside "
            f"[{minimum_camera_depth_mm:.1f}, {maximum_camera_depth_mm:.1f}]"
        )
    surface_base = transform @ np.r_[surface_cam, 1.0]
    orientation = selected.get("orientation")
    orientation_record = {}
    if isinstance(orientation, dict):
        symmetry_period_deg = float(
            orientation.get("symmetry_period_deg", float("nan"))
        )
        if (
            not math.isfinite(symmetry_period_deg)
            or abs(symmetry_period_deg - 90.0) > 1e-6
        ):
            raise ValueError("square target orientation must use 90 degree symmetry")
        orientation_confidence = float(
            orientation.get("confidence_score", float("nan"))
        )
        orientation_p90_deviation_deg = float(
            orientation.get("p90_deviation_deg", float("nan"))
        )
        applied_minimum_confidence = float(
            orientation.get("applied_min_confidence_score", float("nan"))
        )
        applied_maximum_deviation_deg = float(
            orientation.get("applied_max_p90_deviation_deg", float("nan"))
        )
        if not all(
            math.isfinite(value)
            for value in (
                orientation_confidence,
                orientation_p90_deviation_deg,
                applied_minimum_confidence,
                applied_maximum_deviation_deg,
            )
        ):
            raise ValueError("target orientation quality values must be finite")
        if orientation_confidence < applied_minimum_confidence:
            raise ValueError(
                "target orientation confidence is below its applied gate"
            )
        if orientation_p90_deviation_deg > applied_maximum_deviation_deg:
            raise ValueError("target orientation deviation exceeds its applied gate")
        edge_axis_camera = _unit_vector(
            orientation.get("axis_cam"), "target edge axis camera"
        )
        edge_axis_base = transform[:3, :3] @ edge_axis_camera
        support_up = _unit_vector(
            plane_geometry["support_up_normal_base"], "support up normal base"
        )
        edge_axis_base = edge_axis_base - float(
            np.dot(edge_axis_base, support_up)
        ) * support_up
        edge_axis_norm = float(np.linalg.norm(edge_axis_base))
        if edge_axis_norm < 1e-6:
            raise ValueError("target edge axis is degenerate in the support plane")
        edge_axis_base /= edge_axis_norm
        orientation_record = {
            "target_edge_axis_camera": edge_axis_camera.tolist(),
            "target_edge_axis_base": edge_axis_base.tolist(),
            "orientation_angle_in_table_basis_mod90_deg": float(
                orientation.get("angle_in_table_basis_mod90_deg", 0.0)
            ),
            "orientation_symmetry_period_deg": symmetry_period_deg,
            "orientation_confidence_score": orientation_confidence,
            "orientation_p90_deviation_deg": orientation_p90_deviation_deg,
            "orientation_quality_profile": orientation.get("quality_profile"),
        }
    return {
        "target_id": selected.get("target_id"),
        "component_id": selected.get("component_id"),
        "confidence_score": float(selected.get("confidence_score", 0.0)),
        "camera_target_depth_mm": camera_target_depth_mm,
        "surface_point_camera_m": surface_cam.tolist(),
        "surface_point_base_m": surface_base[:3].tolist(),
        **orientation_record,
        **plane_geometry,
    }


def plan_high_hover_tangent_correction(
    current_tcp_pose_xyz_xyzw: Any,
    target_surface_base_m: Any,
    support_up_normal_base: Any,
    safety: dict,
    validated_workspace: dict,
    *,
    cumulative_tangent_motion_mm: float = 0.0,
) -> dict:
    tcp = _finite_vector(current_tcp_pose_xyz_xyzw, 7, "current_tcp_pose")
    target = _finite_vector(target_surface_base_m, 3, "target_surface_base")
    support_up = _unit_vector(
        support_up_normal_base, "support up normal base"
    )
    if support_up[2] < 0.0:
        support_up = -support_up
    _validate_tcp_workspace(tcp[:3], validated_workspace, "current TCP")
    delta_m = target - tcp[:3]
    signed_up_m = float(np.dot(delta_m, support_up))
    clearance_mm = -1000.0 * signed_up_m
    minimum = float(safety["minimum_target_clearance_mm"])
    maximum = float(safety["maximum_target_clearance_mm"])
    workspace_clearance = _finite_interval(
        validated_workspace["normal_clearance_mm"], "normal_clearance_mm"
    )
    if not minimum <= clearance_mm <= maximum:
        raise RuntimeError(
            f"normal clearance {clearance_mm:.1f} mm outside "
            f"[{minimum:.1f}, {maximum:.1f}]"
        )
    if (not validated_workspace.get("advisory_bounds", False)
            and not workspace_clearance[0] <= clearance_mm <= workspace_clearance[1]):
        raise RuntimeError(
            f"normal clearance {clearance_mm:.1f} mm outside validated workspace "
            f"{workspace_clearance}"
        )

    tangent_error_m = _tangent_projection(delta_m, support_up)
    error_norm_mm = 1000.0 * float(np.linalg.norm(tangent_error_m))
    if error_norm_mm > float(safety["maximum_initial_xy_error_mm"]):
        raise RuntimeError(
            f"tangent error {error_norm_mm:.1f} mm exceeds bounded high-hover range"
        )
    converged = error_norm_mm <= float(safety["convergence_xy_mm"])
    step_limit_m = float(safety["maximum_xy_step_mm"]) / 1000.0
    step_tangent_m = tangent_error_m.copy()
    norm_m = float(np.linalg.norm(step_tangent_m))
    if norm_m > step_limit_m:
        step_tangent_m *= step_limit_m / norm_m

    cumulative_before = float(cumulative_tangent_motion_mm)
    if not math.isfinite(cumulative_before) or cumulative_before < 0.0:
        raise ValueError("cumulative tangent motion must be finite and nonnegative")
    step_norm_mm = 1000.0 * float(np.linalg.norm(step_tangent_m))
    cumulative_after = cumulative_before + (0.0 if converged else step_norm_mm)
    cumulative_limit = float(safety["maximum_cumulative_tangent_motion_mm"])
    if cumulative_after > cumulative_limit + 1e-9:
        raise RuntimeError(
            f"cumulative tangent motion {cumulative_after:.1f} mm exceeds "
            f"{cumulative_limit:.1f} mm"
        )

    desired = tcp.copy()
    if not converged:
        desired[:3] += step_tangent_m
    _validate_tcp_workspace(desired[:3], validated_workspace, "desired TCP")
    normal_step_mm = 1000.0 * float(
        np.dot(desired[:3] - tcp[:3], support_up)
    )
    return {
        "alignment_reference": "detected_support_plane_normal",
        "support_up_normal_base": support_up.tolist(),
        "normal_clearance_mm": clearance_mm,
        "tangent_error_base_xyz_mm": (1000.0 * tangent_error_m).tolist(),
        "tangent_error_norm_mm": error_norm_mm,
        "tangent_step_base_xyz_mm": (1000.0 * step_tangent_m).tolist(),
        "tangent_step_norm_mm": step_norm_mm,
        "commanded_normal_step_mm": normal_step_mm,
        "cumulative_tangent_motion_before_mm": cumulative_before,
        "cumulative_tangent_motion_after_mm": cumulative_after,
        "converged": bool(converged),
        "desired_tcp_pose_xyz_xyzw": desired.tolist(),
        "normal_height_and_orientation_unchanged": bool(
            abs(normal_step_mm) <= 1e-9
            and np.allclose(desired[3:], tcp[3:], atol=1e-12)
        ),
    }


def evaluate_executed_tangent_correction(
    commanded_q: Any,
    measured_q: Any,
    tcp_before_xyz_xyzw: Any,
    planned_tcp_after_xyz_xyzw: Any,
    measured_tcp_after_xyz_xyzw: Any,
    support_up_normal_base: Any,
    safety: dict,
) -> dict:
    """Check that a commanded support-tangent step physically took effect."""
    commanded = _finite_vector(commanded_q, 6, "commanded_q")
    measured = _finite_vector(measured_q, 6, "measured_q")
    before = _finite_vector(
        tcp_before_xyz_xyzw, 7, "tcp_before_xyz_xyzw"
    )
    planned_after = _finite_vector(
        planned_tcp_after_xyz_xyzw, 7, "planned_tcp_after_xyz_xyzw"
    )
    measured_after = _finite_vector(
        measured_tcp_after_xyz_xyzw, 7, "measured_tcp_after_xyz_xyzw"
    )

    support_up = _unit_vector(
        support_up_normal_base, "support up normal base"
    )
    commanded_displacement_m = planned_after[:3] - before[:3]
    measured_displacement_m = measured_after[:3] - before[:3]
    commanded_tangent_mm = 1000.0 * _tangent_projection(
        commanded_displacement_m, support_up
    )
    measured_tangent_mm = 1000.0 * _tangent_projection(
        measured_displacement_m, support_up
    )
    commanded_norm_mm = float(np.linalg.norm(commanded_tangent_mm))
    measured_norm_mm = float(np.linalg.norm(measured_tangent_mm))
    if commanded_norm_mm <= 1e-6:
        raise ValueError("post-motion verification requires a nonzero tangent step")

    dot_mm2 = float(np.dot(measured_tangent_mm, commanded_tangent_mm))
    projected_progress_mm = dot_mm2 / commanded_norm_mm
    progress_ratio = dot_mm2 / (commanded_norm_mm ** 2)
    direction_cosine = (
        dot_mm2 / (measured_norm_mm * commanded_norm_mm)
        if measured_norm_mm > 1e-6
        else 0.0
    )
    joint_error = np.abs(measured - commanded)
    maximum_joint_error_rad = float(np.max(joint_error))
    limiting_joint = int(np.argmax(joint_error)) + 1
    normal_drift_mm = 1000.0 * abs(
        float(np.dot(measured_displacement_m, support_up))
    )

    reasons = []
    if maximum_joint_error_rad > float(
        safety["maximum_post_motion_joint_error_rad"]
    ):
        reasons.append("joint_tracking_error_too_large")
    if progress_ratio < float(
        safety["minimum_post_motion_xy_progress_ratio"]
    ):
        reasons.append("tangent_progress_ratio_too_small")
    if progress_ratio > float(
        safety["maximum_post_motion_xy_progress_ratio"]
    ):
        reasons.append("tangent_progress_ratio_too_large")
    if direction_cosine < float(
        safety["minimum_post_motion_direction_cosine"]
    ):
        reasons.append("tangent_direction_mismatch")
    if normal_drift_mm > float(
        safety["maximum_post_motion_tcp_z_drift_mm"]
    ):
        reasons.append("support_normal_drift_too_large")

    return {
        "passed": not reasons,
        "reasons": reasons,
        "commanded_q_rad": commanded.tolist(),
        "measured_q_rad": measured.tolist(),
        "joint_error_rad": joint_error.tolist(),
        "maximum_joint_error_rad": maximum_joint_error_rad,
        "maximum_joint_error_joint": limiting_joint,
        "tcp_before_xyz_xyzw": before.tolist(),
        "planned_tcp_after_xyz_xyzw": planned_after.tolist(),
        "measured_tcp_after_xyz_xyzw": measured_after.tolist(),
        "support_up_normal_base": support_up.tolist(),
        "commanded_tangent_base_xyz_mm": commanded_tangent_mm.tolist(),
        "measured_tangent_base_xyz_mm": measured_tangent_mm.tolist(),
        "commanded_tangent_norm_mm": commanded_norm_mm,
        "measured_tangent_norm_mm": measured_norm_mm,
        "projected_progress_mm": projected_progress_mm,
        "tangent_progress_ratio": progress_ratio,
        "tangent_direction_cosine": direction_cosine,
        "support_normal_drift_mm": normal_drift_mm,
    }


def joint_margin_details(q: Any) -> list[dict]:
    joints = _finite_vector(q, 6, "joint vector")
    details = []
    for index, (value, (lower, upper)) in enumerate(
        zip(joints, JOINT_LIMITS_RAD), start=1
    ):
        inside = bool(lower <= value <= upper)
        margin_rad = min(value - lower, upper - value)
        details.append(
            {
                "joint": index,
                "value_rad": float(value),
                "value_deg": math.degrees(float(value)),
                "lower_rad": lower,
                "upper_rad": upper,
                "lower_deg": math.degrees(lower),
                "upper_deg": math.degrees(upper),
                "margin_rad": margin_rad,
                "margin_deg": math.degrees(margin_rad),
                "inside_hard_limit": inside,
            }
        )
    return details


def joint_margin_deg(q: Any) -> float:
    return min(item["margin_deg"] for item in joint_margin_details(q))


def validate_local_joint_step(q_from: Any, q_to: Any, safety: dict) -> dict:
    start = _finite_vector(q_from, 6, "q_from")
    end = _finite_vector(q_to, 6, "q_to")
    maximum_delta = float(np.max(np.abs(end - start)))
    margin = joint_margin_deg(end)
    if maximum_delta > float(safety["maximum_joint_step_rad"]):
        raise RuntimeError(
            f"local IK joint step {maximum_delta:.4f} rad exceeds limit"
        )
    if margin < float(safety["minimum_joint_margin_deg"]):
        raise RuntimeError(f"local IK joint margin {margin:.2f} deg is insufficient")
    return {"maximum_joint_delta_rad": maximum_delta, "minimum_joint_margin_deg": margin}
