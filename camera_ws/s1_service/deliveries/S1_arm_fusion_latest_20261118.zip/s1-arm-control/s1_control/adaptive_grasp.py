# -*- coding: utf-8 -*-
"""连续尺寸夹爪接触探测的纯判定层。

S1标准夹爪只暴露“目标位置+力矩上限”，没有速度控制接口。台架试验已证明：
用缓慢移动的位置设定值伪造匀速闭合时，夹爪会被静摩擦锁住。因此本模块
采用原生限力目标闭合：一次下发最小探测开口，等实际开口进入稳定窗口后，
再区分夹空与接触。

接触判定仍使用多重证据：

1. 稳定实际开口相对探测目标的超差显著大于同参数空载基线；
2. 力矩相对空载基线上升，或实际开口已经稳定，至少提供一种辅助证据；
3. 条件连续满足若干帧后，稳定开口的中位数作为接触跨度。

本模块不导入S1 SDK、不访问串口，也不发送运动命令。第7轴反馈是电机侧
估计，不能被解释为已经标定的指尖力。
"""
from __future__ import annotations

import json
import math
import statistics
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import yaml

_ROOT = Path(__file__).resolve().parents[1]
_DEFAULT_CONFIG = _ROOT / "config" / "adaptive_grasp.yaml"


def _percentile(values: Iterable[float], ratio: float) -> float:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        raise ValueError("不能对空样本计算分位数")
    index = round((len(ordered) - 1) * ratio)
    return ordered[max(0, min(len(ordered) - 1, index))]


def _finite(value: float, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name}必须是有限数，当前为{value!r}")
    return result


@dataclass(frozen=True)
class ProbeParameters:
    start_gap_mm: float
    target_gap_mm: float
    probe_force_nm: float
    hz: float
    open_hold_s: float
    minimum_observe_s: float
    timeout_s: float
    evaluation_window_s: float
    tracking_margin_over_empty_mm: float
    torque_margin_over_empty_nm: float
    max_settled_closing_speed_mm_s: float
    max_settled_gap_range_mm: float
    debounce_samples: int
    required_auxiliary_evidence: int
    secure_preload_command_mm: float
    secure_force_nm: float
    secure_hold_s: float
    max_joint_hold_error_rad: float
    max_temperature_c: float
    empty_max_final_excess_mm: float
    minimum_baseline_samples: int

    @classmethod
    def from_mapping(cls, record: Mapping) -> "ProbeParameters":
        probe = record["probe"]
        contact = record["contact"]
        secure = record["secure"]
        safety = record["safety"]
        result = cls(
            start_gap_mm=float(probe["start_gap_mm"]),
            target_gap_mm=float(probe["target_gap_mm"]),
            probe_force_nm=float(probe["force_nm"]),
            hz=float(probe["hz"]),
            open_hold_s=float(probe["open_hold_s"]),
            minimum_observe_s=float(probe["minimum_observe_s"]),
            timeout_s=float(probe["timeout_s"]),
            evaluation_window_s=float(probe["evaluation_window_s"]),
            tracking_margin_over_empty_mm=float(
                contact["tracking_margin_over_empty_mm"]
            ),
            torque_margin_over_empty_nm=float(
                contact["torque_margin_over_empty_nm"]
            ),
            max_settled_closing_speed_mm_s=float(
                contact["max_settled_closing_speed_mm_s"]
            ),
            max_settled_gap_range_mm=float(
                contact["max_settled_gap_range_mm"]
            ),
            debounce_samples=int(contact["debounce_samples"]),
            required_auxiliary_evidence=int(
                contact["required_auxiliary_evidence"]
            ),
            secure_preload_command_mm=float(secure["preload_command_mm"]),
            secure_force_nm=float(secure["force_nm"]),
            secure_hold_s=float(secure["hold_s"]),
            max_joint_hold_error_rad=float(
                safety["max_joint_hold_error_rad"]
            ),
            max_temperature_c=float(safety["max_temperature_c"]),
            empty_max_final_excess_mm=float(
                safety["empty_max_final_excess_mm"]
            ),
            minimum_baseline_samples=int(safety["minimum_baseline_samples"]),
        )
        result.validate()
        return result

    def validate(self) -> None:
        numeric = {
            name: getattr(self, name)
            for name in (
                "start_gap_mm",
                "target_gap_mm",
                "probe_force_nm",
                "hz",
                "open_hold_s",
                "minimum_observe_s",
                "timeout_s",
                "evaluation_window_s",
                "tracking_margin_over_empty_mm",
                "torque_margin_over_empty_nm",
                "max_settled_closing_speed_mm_s",
                "max_settled_gap_range_mm",
                "secure_preload_command_mm",
                "secure_force_nm",
                "secure_hold_s",
                "max_joint_hold_error_rad",
                "max_temperature_c",
                "empty_max_final_excess_mm",
            )
        }
        for name, value in numeric.items():
            _finite(value, name)
        if self.start_gap_mm <= self.target_gap_mm:
            raise ValueError("start_gap_mm必须大于target_gap_mm")
        positive = (
            self.probe_force_nm,
            self.secure_force_nm,
            self.hz,
            self.open_hold_s,
            self.minimum_observe_s,
            self.timeout_s,
            self.evaluation_window_s,
            self.max_joint_hold_error_rad,
            self.max_temperature_c,
            self.empty_max_final_excess_mm,
        )
        if any(value <= 0.0 for value in positive):
            raise ValueError("力矩、时间、频率和安全阈值必须为正")
        if self.hz < 10.0:
            raise ValueError("采样频率不得低于10 Hz")
        if self.probe_force_nm > self.secure_force_nm:
            raise ValueError("探测力矩上限不得高于预紧力矩上限")
        if self.minimum_observe_s >= self.timeout_s:
            raise ValueError("minimum_observe_s必须小于timeout_s")
        if self.evaluation_window_s >= self.timeout_s:
            raise ValueError("evaluation_window_s必须小于timeout_s")
        nonnegative = (
            self.tracking_margin_over_empty_mm,
            self.torque_margin_over_empty_nm,
            self.max_settled_closing_speed_mm_s,
            self.max_settled_gap_range_mm,
            self.secure_preload_command_mm,
        )
        if any(value < 0.0 for value in nonnegative):
            raise ValueError("接触阈值余量、稳定阈值和预紧量不得为负")
        if self.debounce_samples < 2:
            raise ValueError("去抖帧数不得小于2")
        if self.required_auxiliary_evidence not in (1, 2):
            raise ValueError("required_auxiliary_evidence只能是1或2")
        if self.minimum_baseline_samples < self.debounce_samples:
            raise ValueError("空载基线帧数不得小于接触去抖帧数")

    @property
    def evaluation_capacity(self) -> int:
        return max(
            self.minimum_baseline_samples,
            math.ceil(self.evaluation_window_s * self.hz) + 1,
        )


def load_probe_parameters(path: str | Path | None = None) -> ProbeParameters:
    config_path = Path(path).expanduser() if path else _DEFAULT_CONFIG
    record = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if record.get("schema_version") != 2:
        raise ValueError("adaptive_grasp.yaml的schema_version必须为2")
    return ProbeParameters.from_mapping(record)


@dataclass(frozen=True)
class ProbeSample:
    t_s: float
    command_gap_mm: float
    actual_gap_mm: float
    gripper_tau_nm: float

    def validate(self) -> None:
        for name in (
            "t_s",
            "command_gap_mm",
            "actual_gap_mm",
            "gripper_tau_nm",
        ):
            _finite(getattr(self, name), name)


def window_closing_speed_mm_s(samples: Sequence[ProbeSample]) -> float | None:
    if len(samples) < 2:
        return None
    first = samples[0]
    last = samples[-1]
    elapsed = last.t_s - first.t_s
    if elapsed <= 0.0:
        return None
    return (first.actual_gap_mm - last.actual_gap_mm) / elapsed


def settled_window(
    samples: Sequence[ProbeSample],
    parameters: ProbeParameters,
) -> bool:
    if len(samples) < parameters.minimum_baseline_samples:
        return False
    duration = samples[-1].t_s - samples[0].t_s
    if duration < parameters.evaluation_window_s * 0.8:
        return False
    speed = window_closing_speed_mm_s(samples)
    if speed is None:
        return False
    gaps = [sample.actual_gap_mm for sample in samples]
    return (
        abs(speed) <= parameters.max_settled_closing_speed_mm_s
        and max(gaps) - min(gaps)
        <= parameters.max_settled_gap_range_mm
    )


@dataclass(frozen=True)
class EmptyProbeBaseline:
    sample_count: int
    start_gap_mm: float
    target_gap_mm: float
    probe_force_nm: float
    timeout_s: float
    evaluation_window_s: float
    tracking_excess_p99_mm: float
    tau_center_nm: float
    tau_abs_deviation_p99_nm: float

    @classmethod
    def from_samples(
        cls,
        samples: Iterable[ProbeSample],
        parameters: ProbeParameters,
    ) -> "EmptyProbeBaseline":
        records = list(samples)
        if len(records) < parameters.minimum_baseline_samples:
            raise ValueError(
                f"空载稳定基线只有{len(records)}帧，至少需要"
                f"{parameters.minimum_baseline_samples}帧"
            )
        for sample in records:
            sample.validate()
        if not settled_window(records, parameters):
            raise ValueError("空载反馈尚未形成稳定窗口")
        tracking = [
            max(0.0, sample.actual_gap_mm - sample.command_gap_mm)
            for sample in records
        ]
        torque = [sample.gripper_tau_nm for sample in records]
        tau_center = statistics.median(torque)
        tau_deviation = [abs(value - tau_center) for value in torque]
        return cls(
            sample_count=len(records),
            start_gap_mm=parameters.start_gap_mm,
            target_gap_mm=parameters.target_gap_mm,
            probe_force_nm=parameters.probe_force_nm,
            timeout_s=parameters.timeout_s,
            evaluation_window_s=parameters.evaluation_window_s,
            tracking_excess_p99_mm=_percentile(tracking, 0.99),
            tau_center_nm=tau_center,
            tau_abs_deviation_p99_nm=_percentile(tau_deviation, 0.99),
        )

    def to_record(self) -> dict:
        return {"schema_version": 2, **asdict(self)}

    @classmethod
    def from_record(cls, record: Mapping) -> "EmptyProbeBaseline":
        if int(record.get("schema_version", -1)) != 2:
            raise ValueError("空载基线schema_version必须为2，请重新标定")
        return cls(
            sample_count=int(record["sample_count"]),
            start_gap_mm=float(record["start_gap_mm"]),
            target_gap_mm=float(record["target_gap_mm"]),
            probe_force_nm=float(record["probe_force_nm"]),
            timeout_s=float(record["timeout_s"]),
            evaluation_window_s=float(record["evaluation_window_s"]),
            tracking_excess_p99_mm=float(record["tracking_excess_p99_mm"]),
            tau_center_nm=float(record["tau_center_nm"]),
            tau_abs_deviation_p99_nm=float(
                record["tau_abs_deviation_p99_nm"]
            ),
        )

    def assert_compatible(self, parameters: ProbeParameters) -> None:
        expected = {
            "start_gap_mm": parameters.start_gap_mm,
            "target_gap_mm": parameters.target_gap_mm,
            "probe_force_nm": parameters.probe_force_nm,
            "timeout_s": parameters.timeout_s,
            "evaluation_window_s": parameters.evaluation_window_s,
        }
        mismatches = []
        for name, value in expected.items():
            baseline_value = getattr(self, name)
            if not math.isclose(
                baseline_value,
                value,
                rel_tol=0.0,
                abs_tol=1e-9,
            ):
                mismatches.append(
                    f"{name}: baseline={baseline_value} config={value}"
                )
        if mismatches:
            raise ValueError(
                "空载稳定基线与当前探测参数不兼容，必须重做空载标定: "
                + "; ".join(mismatches)
            )


def save_empty_baseline(path: str | Path, baseline: EmptyProbeBaseline) -> Path:
    output = Path(path).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(baseline.to_record(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return output


def load_empty_baseline(path: str | Path) -> EmptyProbeBaseline:
    source = Path(path).expanduser().resolve()
    return EmptyProbeBaseline.from_record(
        json.loads(source.read_text(encoding="utf-8"))
    )


@dataclass(frozen=True)
class ContactDecision:
    detected: bool
    tracking_excess_mm: float
    torque_delta_nm: float
    closing_speed_mm_s: float | None
    tracking_hit: bool
    torque_hit: bool
    stall_hit: bool
    consecutive_samples: int
    contact_gap_mm: float | None


class ContactDetector:
    """将稳定窗口反馈转换为带去抖的接触判定。"""

    def __init__(
        self,
        parameters: ProbeParameters,
        baseline: EmptyProbeBaseline,
    ):
        self.parameters = parameters
        self.baseline = baseline
        baseline.assert_compatible(parameters)
        self.tracking_threshold_mm = (
            baseline.tracking_excess_p99_mm
            + parameters.tracking_margin_over_empty_mm
        )
        self.torque_threshold_nm = (
            baseline.tau_abs_deviation_p99_nm
            + parameters.torque_margin_over_empty_nm
        )
        self._window: deque[ProbeSample] = deque(
            maxlen=parameters.evaluation_capacity
        )
        self._consecutive = 0
        self._candidate_gaps: deque[float] = deque(
            maxlen=parameters.debounce_samples
        )

    def update(self, sample: ProbeSample) -> ContactDecision:
        sample.validate()
        self._window.append(sample)
        closing_speed = window_closing_speed_mm_s(self._window)
        tracking_excess = sample.actual_gap_mm - sample.command_gap_mm
        torque_delta = abs(
            sample.gripper_tau_nm - self.baseline.tau_center_nm
        )
        tracking_hit = tracking_excess >= self.tracking_threshold_mm
        torque_hit = torque_delta >= self.torque_threshold_nm
        stall_hit = (
            closing_speed is not None
            and abs(closing_speed)
            <= self.parameters.max_settled_closing_speed_mm_s
        )
        auxiliary_count = int(torque_hit) + int(stall_hit)
        candidate = (
            tracking_hit
            and auxiliary_count
            >= self.parameters.required_auxiliary_evidence
        )
        if candidate:
            self._consecutive += 1
            self._candidate_gaps.append(sample.actual_gap_mm)
        else:
            self._consecutive = 0
            self._candidate_gaps.clear()
        detected = self._consecutive >= self.parameters.debounce_samples
        contact_gap = (
            statistics.median(self._candidate_gaps) if detected else None
        )
        return ContactDecision(
            detected=detected,
            tracking_excess_mm=tracking_excess,
            torque_delta_nm=torque_delta,
            closing_speed_mm_s=closing_speed,
            tracking_hit=tracking_hit,
            torque_hit=torque_hit,
            stall_hit=stall_hit,
            consecutive_samples=self._consecutive,
            contact_gap_mm=contact_gap,
        )
