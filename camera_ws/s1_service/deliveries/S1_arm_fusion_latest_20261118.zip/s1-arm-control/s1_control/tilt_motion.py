"""Hardware adapter for S1 position control on the tilted Go2 mount.

The pure URDF calculations remain in :mod:`s1_control.tilt_gravity`.  This
module is the single place that combines the vendor level-base gravity term
with the bounded differential term required by the measured Go2 crouch tilt.
"""
from __future__ import annotations

import math
import time
from typing import Any

import numpy as np

from .tilt_gravity import (
    GRAVITY_M_S2,
    differential_tilt_compensation_from_support_up,
    gravity_vector_base_from_support_up,
    gravity_vector_base_rear_down,
    limited_correction,
)


def _finite_vector(value: Any, length: int, name: str) -> np.ndarray:
    vector = np.asarray(value, dtype=float)
    if vector.shape != (length,) or not np.all(np.isfinite(vector)):
        raise ValueError(f"{name} must contain {length} finite values")
    return vector


def _unit_vector(value: Any, name: str) -> np.ndarray:
    vector = _finite_vector(value, 3, name)
    norm = float(np.linalg.norm(vector))
    if not 0.98 <= norm <= 1.02:
        raise ValueError(f"{name} must be a unit vector")
    vector = vector / norm
    if vector[2] <= 0.0:
        raise ValueError(f"{name} must point toward base +z")
    return vector


def _angle_deg(first: np.ndarray, second: np.ndarray) -> float:
    cosine = float(np.clip(np.dot(first, second), -1.0, 1.0))
    return math.degrees(math.acos(cosine))


def _json_safe_control_result(value: Any):
    """Preserve an opaque vendor return value without breaking JSON logs."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, np.generic):
        return value.item()
    return repr(value)


class TiltCompensatedPositionCommander:
    """Issue bounded position commands for a measured tilted S1 base.

    ``Arm`` deliberately installs this object explicitly.  This prevents old
    level-bench programs and already-compensated diagnostics from receiving a
    second, hidden compensation term.
    """

    def __init__(
        self,
        model,
        *,
        rear_edge_lower_deg: float,
        scale: float,
        correction_absolute_limits_nm,
        maximum_support_tilt_deg: float = 10.0,
        maximum_support_normal_deviation_deg: float = 5.0,
        support_normal_blend: float = 1.0,
        normal_transition_s: float = 0.5,
        deviation_reference_right_edge_lower_deg: float | None = None,
        payload_mass_kg: float = 0.0,
        payload_link_name: str = "gripper",
        payload_center_of_mass_link_m=(0.0, 0.0, 0.0),
        payload_scale: float = 0.0,
        payload_correction_absolute_limits_nm=(0.1, 0.2, 0.2, 0.1, 0.1, 0.05),
    ):
        self.model = model
        self.rear_edge_lower_deg = float(rear_edge_lower_deg)
        self.scale = float(scale)
        self.correction_absolute_limits_nm = _finite_vector(
            correction_absolute_limits_nm,
            6,
            "correction_absolute_limits_nm",
        )
        if not math.isfinite(self.rear_edge_lower_deg):
            raise ValueError("rear_edge_lower_deg must be finite")
        if not math.isfinite(self.scale) or not 0.0 < self.scale <= 1.0:
            raise ValueError("compensation scale must be in (0, 1]")
        if np.any(self.correction_absolute_limits_nm <= 0.0):
            raise ValueError("all correction torque limits must be positive")
        self.maximum_support_tilt_deg = float(maximum_support_tilt_deg)
        self.maximum_support_normal_deviation_deg = float(
            maximum_support_normal_deviation_deg
        )
        self.normal_transition_s = float(normal_transition_s)
        self.support_normal_blend = float(support_normal_blend)
        if (
            not math.isfinite(self.maximum_support_tilt_deg)
            or not 0.0 < self.maximum_support_tilt_deg <= 15.0
        ):
            raise ValueError("maximum support tilt must be in (0, 15] deg")
        if (
            not math.isfinite(self.maximum_support_normal_deviation_deg)
            or not 0.0 < self.maximum_support_normal_deviation_deg <= 10.0
        ):
            raise ValueError(
                "maximum support-normal deviation must be in (0, 10] deg"
            )
        if not math.isfinite(self.normal_transition_s) or self.normal_transition_s < 0.0:
            raise ValueError("normal transition duration must be finite and non-negative")
        if (
            not math.isfinite(self.support_normal_blend)
            or not 0.0 < self.support_normal_blend <= 1.0
        ):
            raise ValueError("support-normal blend must be in (0, 1]")
        nominal_gravity = gravity_vector_base_rear_down(
            self.rear_edge_lower_deg
        )
        self.nominal_support_up_normal_base = _unit_vector(
            -nominal_gravity / GRAVITY_M_S2,
            "nominal_support_up_normal_base",
        )
        # The measured mount reference for plausibility checks is separate
        # from the commissioned compensation blend/restore reference.
        self.deviation_reference_source = "mount_record_pitch_only"
        self.deviation_reference_support_up_normal_base = (
            self.nominal_support_up_normal_base.copy()
        )
        if deviation_reference_right_edge_lower_deg is not None:
            roll = float(deviation_reference_right_edge_lower_deg)
            if not math.isfinite(roll) or abs(roll) > 15.0:
                raise ValueError("reference right-edge slope must be within [-15, 15]deg")
            self.deviation_reference_support_up_normal_base = _unit_vector(
                self._mount_slope_normal(self.rear_edge_lower_deg, roll),
                "deviation_reference_support_up_normal_base",
            )
            self.deviation_reference_source = "mount_record_pitch_roll"
        self._normal_from = self.nominal_support_up_normal_base.copy()
        self._normal_target = self.nominal_support_up_normal_base.copy()
        self._normal_transition_started = time.monotonic()
        self.support_normal_source = "mount_record_pitch_only"
        self._position_bias_rad = np.zeros(6, dtype=float)
        self.payload_mass_kg = float(payload_mass_kg)
        self.payload_link_name = str(payload_link_name)
        self.payload_center_of_mass_link_m = _finite_vector(
            payload_center_of_mass_link_m,
            3,
            "payload_center_of_mass_link_m",
        )
        self.payload_correction_absolute_limits_nm = _finite_vector(
            payload_correction_absolute_limits_nm,
            6,
            "payload_correction_absolute_limits_nm",
        )
        self._payload_scale = float(payload_scale)
        if not math.isfinite(self.payload_mass_kg) or self.payload_mass_kg < 0.0:
            raise ValueError("payload mass must be finite and non-negative")
        if not self.payload_link_name:
            raise ValueError("payload link name must not be empty")
        if np.any(self.payload_correction_absolute_limits_nm <= 0.0):
            raise ValueError("all payload correction torque limits must be positive")
        if not math.isfinite(self._payload_scale) or not 0.0 <= self._payload_scale <= 1.0:
            raise ValueError("payload scale must be within [0, 1]")
        if self.payload_mass_kg == 0.0 and self._payload_scale != 0.0:
            raise ValueError("payload scale must be zero when payload mass is zero")
        self.command_count = 0
        self.last_snapshot = None
        self.tilt_compensation_enabled = True

    @property
    def compensation_scale(self) -> float:
        return float(self.scale) if self.tilt_compensation_enabled else 0.0

    @staticmethod
    def _mount_slope_normal(rear_deg, right_deg):
        normal = np.array([
            -math.tan(math.radians(rear_deg)),
            -math.tan(math.radians(right_deg)),
            1.0,
        ])
        return normal / np.linalg.norm(normal)

    def set_compensation_scale(self, value: float) -> float:
        """Set a bounded runtime scale for an explicitly supervised ramp.

        The mount-record factory still restricts the initial scale to an
        approved commissioning step.  Intermediate values are allowed only
        so a caller can move smoothly between two approved steps while the
        joint target is held fixed.  Torque hard caps remain active in every
        command cycle.
        """
        scale = float(value)
        if not math.isfinite(scale) or not 0.0 < scale <= 1.0:
            raise ValueError("compensation scale must be in (0, 1]")
        self.scale = scale
        return self.compensation_scale

    @property
    def payload_scale(self) -> float:
        return float(self._payload_scale)

    def set_payload_scale(self, value: float) -> float:
        """Set the explicit external-payload scale for supervised A/B tests."""
        scale = float(value)
        if not math.isfinite(scale) or not 0.0 <= scale <= 1.0:
            raise ValueError("payload scale must be within [0, 1]")
        if self.payload_mass_kg <= 0.0 and scale != 0.0:
            raise ValueError("cannot enable payload compensation without a payload")
        self._payload_scale = scale
        return self.payload_scale

    @property
    def position_bias_rad(self) -> list[float]:
        return self._position_bias_rad.tolist()

    def set_position_bias_rad(self, value) -> list[float]:
        """Set an explicit outer-loop position bias.

        The caller owns all joint-limit, collision and task-space guards.  The
        bias is kept here so every hold cycle uses the same corrected command
        while higher layers continue to reason about the physical target.
        """
        self._position_bias_rad = _finite_vector(
            value,
            6,
            "position_bias_rad",
        )
        return self.position_bias_rad

    def clear_position_bias(self) -> list[float]:
        return self.set_position_bias_rad([0.0] * 6)

    def _current_support_up_normal(self) -> tuple[np.ndarray, float]:
        if self.normal_transition_s <= 0.0:
            return self._normal_target.copy(), 1.0
        u = min(
            1.0,
            max(
                0.0,
                (time.monotonic() - self._normal_transition_started)
                / self.normal_transition_s,
            ),
        )
        blend = u * u * (3.0 - 2.0 * u)
        mixed = (1.0 - blend) * self._normal_from + blend * self._normal_target
        return mixed / np.linalg.norm(mixed), u

    def set_support_up_normal(self, value, *, source: str) -> dict:
        """Adopt a quality-gated world-up estimate for ground operation only."""
        if not isinstance(source, str) or not source.strip():
            raise ValueError("support-normal source must be a non-empty string")
        support_up = _unit_vector(value, "support_up_normal_base")
        base_up = np.array([0.0, 0.0, 1.0], dtype=float)
        tilt_deg = _angle_deg(support_up, base_up)
        deviation_deg = _angle_deg(
            support_up, self.deviation_reference_support_up_normal_base
        )
        if tilt_deg > self.maximum_support_tilt_deg:
            raise RuntimeError(
                f"support tilt {tilt_deg:.3f}deg exceeds "
                f"{self.maximum_support_tilt_deg:.3f}deg"
            )
        # Difference from the historical mount normal is diagnostic only.
        applied_support_up = (
            (1.0 - self.support_normal_blend)
            * self.nominal_support_up_normal_base
            + self.support_normal_blend * support_up
        )
        applied_support_up = applied_support_up / np.linalg.norm(
            applied_support_up
        )
        current, _ = self._current_support_up_normal()
        self._normal_from = current
        self._normal_target = applied_support_up
        self._normal_transition_started = time.monotonic()
        self.support_normal_source = source.strip()
        return {
            "source": self.support_normal_source,
            "observed_support_up_normal_base": support_up.tolist(),
            "applied_support_up_normal_base": applied_support_up.tolist(),
            "support_tilt_from_base_up_deg": tilt_deg,
            "deviation_from_mount_nominal_deg": deviation_deg,
            "nominal_deviation_check_enabled": False,
            "deviation_reference_source": self.deviation_reference_source,
            "deviation_reference_support_up_normal_base": (
                self.deviation_reference_support_up_normal_base.tolist()
            ),
            "compensation_nominal_support_up_normal_base": (
                self.nominal_support_up_normal_base.tolist()
            ),
            "support_normal_blend": self.support_normal_blend,
            "transition_s": self.normal_transition_s,
        }

    def __call__(self, arm, target_q):
        target = _finite_vector(target_q, 6, "target_q")
        command_target = target + self._position_bias_rad
        measured = _finite_vector(arm.get_pos()[:6], 6, "measured_q")
        vendor_gravity = _finite_vector(
            arm._arm.motor.gravity(measured.tolist()),
            6,
            "vendor_gravity",
        )
        support_up, transition_progress = self._current_support_up_normal()
        differential = (
            differential_tilt_compensation_from_support_up(self.model, measured, support_up)
            if self.tilt_compensation_enabled else np.zeros(6)
        )
        requested, applied = limited_correction(
            differential,
            self.scale,
            self.correction_absolute_limits_nm,
        )
        tilt_clipped = bool(np.max(np.abs(requested - applied)) > 1e-9)
        payload_full = np.zeros(6, dtype=float)
        payload_requested = np.zeros(6, dtype=float)
        payload_applied = np.zeros(6, dtype=float)
        payload_clipped = False
        if self.payload_mass_kg > 0.0:
            payload_full = self.model.point_mass_gravity_compensation(
                measured,
                gravity_vector_base_from_support_up(support_up),
                link_name=self.payload_link_name,
                mass_kg=self.payload_mass_kg,
                center_of_mass_link_m=self.payload_center_of_mass_link_m,
            )
            payload_requested, payload_applied = limited_correction(
                payload_full,
                self.payload_scale,
                self.payload_correction_absolute_limits_nm,
            )
            payload_clipped = bool(
                np.max(np.abs(payload_requested - payload_applied)) > 1e-9
            )
        clipped = tilt_clipped or payload_clipped
        command_tau = vendor_gravity + applied + payload_applied
        snapshot = {
            "measured_q_rad": measured.tolist(),
            "target_q_rad": target.tolist(),
            "position_bias_rad": self.position_bias_rad,
            "command_target_q_rad": command_target.tolist(),
            "differential_nm": differential.tolist(),
            "support_up_normal_base": support_up.tolist(),
            "support_normal_source": self.support_normal_source,
            "support_normal_transition_progress": transition_progress,
            "compensation_scale": self.compensation_scale,
            "tilt_compensation_enabled": self.tilt_compensation_enabled,
            "requested_nm": requested.tolist(),
            "applied_nm": applied.tolist(),
            "clipped": clipped,
            "tilt_clipped": tilt_clipped,
            "payload_mass_kg": self.payload_mass_kg,
            "payload_link_name": self.payload_link_name,
            "payload_center_of_mass_link_m": (
                self.payload_center_of_mass_link_m.tolist()
            ),
            "payload_scale": self.payload_scale,
            "payload_full_nm": payload_full.tolist(),
            "payload_requested_nm": payload_requested.tolist(),
            "payload_applied_nm": payload_applied.tolist(),
            "payload_clipped": payload_clipped,
            "vendor_gravity_nm": vendor_gravity.tolist(),
            "command_tau_nm": command_tau.tolist(),
        }
        self.last_snapshot = snapshot
        if tilt_clipped:
            raise RuntimeError("tilt compensation reached a hard torque cap")
        if payload_clipped:
            raise RuntimeError("payload compensation reached a hard torque cap")
        result = arm._arm.motor.control_pos(
            command_target.tolist(),
            snapshot["command_tau_nm"],
        )
        snapshot["native_control_pos_return"] = _json_safe_control_result(
            result
        )
        self.last_snapshot = snapshot
        self.command_count += 1
        return result


def commander_from_mount_record(
    model,
    mount_record: dict,
    scale: float,
    *,
    maximum_support_tilt_deg: float = 10.0,
    maximum_support_normal_deviation_deg: float = 5.0,
    support_normal_blend: float = 1.0,
    normal_transition_s: float = 0.5,
    deviation_reference_source: str = "mount_record_pitch_only",
    payload_mass_kg: float = 0.0,
    payload_link_name: str = "gripper",
    payload_center_of_mass_link_m=(0.0, 0.0, 0.0),
    payload_scale: float = 0.0,
    payload_correction_absolute_limits_nm=(0.1, 0.2, 0.2, 0.1, 0.1, 0.05),
):
    """Build a commander only from an explicitly measured mount record."""
    if not isinstance(mount_record, dict):
        raise ValueError("mount record must be an object")
    measurement = mount_record.get("mount_measurement", {})
    diagnostic = mount_record.get("diagnostic", {})
    if deviation_reference_source not in {
        "mount_record_pitch_only", "mount_record_pitch_roll"
    }:
        raise ValueError("unsupported mount deviation reference source")
    reference_roll = None
    if deviation_reference_source == "mount_record_pitch_roll":
        roll_magnitude = float(measurement["left_right_tilt_deg"])
        direction = measurement["left_right_tilt_direction"]
        if not math.isfinite(roll_magnitude) or not 0.0 <= roll_magnitude <= 15.0:
            raise ValueError("recorded mount roll magnitude must be in [0, 15]deg")
        if direction == "Go2右侧较低":
            reference_roll = roll_magnitude
        elif direction == "Go2左侧较低":
            reference_roll = -roll_magnitude
        else:
            raise ValueError("recorded mount roll direction is missing or unsupported")
    allowed_scales = [
        float(value) for value in diagnostic.get("allowed_scale_steps", [])
    ]
    if not any(math.isclose(scale, item, abs_tol=1e-9) for item in allowed_scales):
        raise ValueError(
            f"compensation scale {scale} is not an approved step {allowed_scales}"
        )
    return TiltCompensatedPositionCommander(
        model,
        rear_edge_lower_deg=float(measurement["rear_edge_lower_deg"]),
        scale=float(scale),
        correction_absolute_limits_nm=diagnostic[
            "correction_absolute_limits_nm"
        ],
        maximum_support_tilt_deg=maximum_support_tilt_deg,
        maximum_support_normal_deviation_deg=(
            maximum_support_normal_deviation_deg
        ),
        support_normal_blend=support_normal_blend,
        normal_transition_s=normal_transition_s,
        deviation_reference_right_edge_lower_deg=reference_roll,
        payload_mass_kg=payload_mass_kg,
        payload_link_name=payload_link_name,
        payload_center_of_mass_link_m=payload_center_of_mass_link_m,
        payload_scale=payload_scale,
        payload_correction_absolute_limits_nm=(
            payload_correction_absolute_limits_nm
        ),
    )
