"""Pure helpers for checked Go2-mounted S1 observation deployment routes."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path


JOINT_LIMITS_RAD = [
    (math.radians(-170.0), math.radians(170.0)),
    (math.radians(0.0), math.radians(180.0)),
    (math.radians(0.0), math.radians(170.0)),
    (math.radians(-90.0), math.radians(87.0)),
    (math.radians(-90.0), math.radians(90.0)),
    (math.radians(-90.0), math.radians(90.0)),
]


def file_sha256(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite_joint_vector(value, name: str = "q") -> list[float]:
    q = [float(item) for item in value]
    if len(q) != 6 or not all(math.isfinite(item) for item in q):
        raise ValueError(f"{name} must contain six finite joint values")
    return q


def max_joint_delta(first, second) -> float:
    a = finite_joint_vector(first, "first")
    b = finite_joint_vector(second, "second")
    return max(abs(x - y) for x, y in zip(a, b))


def joint_margin_deg(q) -> float:
    values = finite_joint_vector(q)
    return min(
        math.degrees(min(value - lower, upper - value))
        for value, (lower, upper) in zip(values, JOINT_LIMITS_RAD)
    )


def joint_hard_limit_violations(q) -> list[str]:
    values = finite_joint_vector(q)
    violations = []
    for index, (value, (lower, upper)) in enumerate(
        zip(values, JOINT_LIMITS_RAD), start=1
    ):
        if not lower <= value <= upper:
            violations.append(
                f"J{index}={value:.6f} outside [{lower:.6f},{upper:.6f}]"
            )
    return violations


def start_window_violations(q, windows) -> list[str]:
    values = finite_joint_vector(q)
    if len(windows) != 6:
        raise ValueError("start_safe_windows_rad must contain six ranges")
    violations = []
    for index, (value, raw_window) in enumerate(
        zip(values, windows), start=1
    ):
        if len(raw_window) != 2:
            raise ValueError(f"start window J{index} must contain two values")
        lower, upper = (float(raw_window[0]), float(raw_window[1]))
        if not math.isfinite(lower) or not math.isfinite(upper) or lower > upper:
            raise ValueError(f"start window J{index} is invalid")
        if not lower <= value <= upper:
            violations.append(
                f"J{index}={value:.6f}rad allowed=[{lower:.3f},{upper:.3f}]rad"
            )
    return violations


def load_deployment_config(path: str | Path) -> dict:
    record = json.loads(Path(path).read_text(encoding="utf-8"))
    if int(record.get("schema_version", 0)) != 1:
        raise ValueError("unsupported deployment config schema")
    waypoints = record.get("route", {}).get("waypoints")
    if not isinstance(waypoints, list) or len(waypoints) < 2:
        raise ValueError("deployment route requires at least two waypoints")
    names = []
    for index, item in enumerate(waypoints):
        if not isinstance(item, dict) or not str(item.get("name", "")).strip():
            raise ValueError(f"waypoint {index} has no name")
        name = str(item["name"])
        if name in names:
            raise ValueError(f"duplicate waypoint name: {name}")
        names.append(name)
        item["q"] = finite_joint_vector(item.get("q", []), f"waypoint {name}")
    side = record.get("route", {}).get("side", "right")
    required = [
        "zero_reference",
        "rear_ready",
        "high_turn_mid",
        f"{side}_ready",
        f"{side}_observe_mid",
        f"{side}_observe",
    ]
    if names != required:
        raise ValueError(f"unexpected deployment waypoint order: {names}")
    return record


def route_waypoints(record: dict) -> list[dict]:
    return [
        {"name": str(item["name"]), "q": finite_joint_vector(item["q"])}
        for item in record["route"]["waypoints"]
    ]


def interpolate_segment(q_from, q_to, maximum_step_rad: float):
    if not math.isfinite(maximum_step_rad) or maximum_step_rad <= 0.0:
        raise ValueError("maximum_step_rad must be positive")
    first = finite_joint_vector(q_from, "q_from")
    second = finite_joint_vector(q_to, "q_to")
    delta = max_joint_delta(first, second)
    steps = max(1, math.ceil(delta / maximum_step_rad))
    for index in range(steps + 1):
        alpha = index / steps
        yield alpha, [
            start + alpha * (end - start)
            for start, end in zip(first, second)
        ]


def verify_bound_report(
    plan_path: str | Path,
    report_path: str | Path,
    mount_path: str | Path,
) -> dict:
    report = json.loads(Path(report_path).read_text(encoding="utf-8"))
    errors = []
    if report.get("status") != "OFFLINE_DEPLOYMENT_PASS":
        errors.append("report status is not OFFLINE_DEPLOYMENT_PASS")
    if report.get("source_plan_sha256") != file_sha256(plan_path):
        errors.append("report is not bound to the current plan hash")
    if report.get("mount_config_sha256") != file_sha256(mount_path):
        errors.append("report is not bound to the current mount config hash")
    if not report.get("self_collision_ok"):
        errors.append("self collision check did not pass")
    if not report.get("external_phase_envelope_ok"):
        errors.append("Go2 phase-envelope check did not pass")
    if not report.get("joint_safety_ok"):
        errors.append("joint safety check did not pass")
    if not report.get("tilt_torque_cap_ok"):
        errors.append("tilt-compensation torque-cap check did not pass")
    if errors:
        raise ValueError("deployment report verification failed: " + "; ".join(errors))
    return report
