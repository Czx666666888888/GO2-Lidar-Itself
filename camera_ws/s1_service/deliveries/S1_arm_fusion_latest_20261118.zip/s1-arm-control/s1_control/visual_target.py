# -*- coding: utf-8 -*-
"""Fail-closed camera-to-base bridge for the temporary visual-grasp bench."""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


_ROOT = Path(__file__).resolve().parents[1]
_DEFAULT_CALIBRATION = (
    _ROOT / "calibration" / "temp_bench_visual_grasp.json"
)


@dataclass(frozen=True)
class LoadedVisualGraspCalibration:
    path: Path
    record: dict[str, Any]
    transform_base_camera: np.ndarray
    binding_paths: dict[str, Path]


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _finite_float(value: Any, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{name}必须是有限数")
    return result


def _finite_vector(value: Any, length: int, name: str) -> np.ndarray:
    vector = np.asarray(value, dtype=float)
    if vector.shape != (length,) or not np.all(np.isfinite(vector)):
        raise ValueError(f"{name}必须是{length}维有限向量")
    return vector


def _finite_bounds(value: Any, name: str) -> tuple[float, float]:
    bounds = _finite_vector(value, 2, name)
    lower, upper = (float(bounds[0]), float(bounds[1]))
    if lower >= upper:
        raise ValueError(f"{name}下界必须小于上界")
    return lower, upper


def _orientation_quality_limits(
    orientation: dict[str, Any],
    geometry: dict[str, Any],
) -> tuple[str, int | None, float, float]:
    """Re-validate the detector's scale-aware orientation quality profile."""
    standard_min_confidence = _finite_float(
        geometry["minimum_orientation_confidence_score"],
        "minimum_orientation_confidence_score",
    )
    standard_max_deviation = _finite_float(
        geometry["maximum_orientation_p90_deviation_deg"],
        "maximum_orientation_p90_deviation_deg",
    )
    profile_name = str(orientation.get("quality_profile", "standard"))
    sample_point_count_raw = orientation.get("sample_point_count")
    sample_point_count = (
        None if sample_point_count_raw is None else int(sample_point_count_raw)
    )

    minimum_confidence = standard_min_confidence
    maximum_deviation = standard_max_deviation
    if profile_name == "small_sample":
        small = geometry.get("small_sample_orientation")
        if not isinstance(small, dict):
            raise ValueError("small_sample方向档案未在标定记录中声明")
        maximum_points = int(small["max_points"])
        if sample_point_count is None or not 0 <= sample_point_count <= maximum_points:
            raise ValueError("small_sample方向档案的采样点数无效")
        minimum_confidence = _finite_float(
            small["minimum_confidence_score"],
            "small_sample_orientation.minimum_confidence_score",
        )
        maximum_deviation = _finite_float(
            small["maximum_p90_deviation_deg"],
            "small_sample_orientation.maximum_p90_deviation_deg",
        )
    elif profile_name != "standard":
        raise ValueError(f"未知目标方向质量档案: {profile_name}")

    applied_minimum = orientation.get("applied_min_confidence_score")
    applied_maximum = orientation.get("applied_max_p90_deviation_deg")
    if profile_name != "standard" or applied_minimum is not None or applied_maximum is not None:
        if applied_minimum is None or applied_maximum is None:
            raise ValueError("目标方向质量档案缺少实际应用门槛")
        if not math.isclose(
            _finite_float(applied_minimum, "applied_min_confidence_score"),
            minimum_confidence,
            rel_tol=0.0,
            abs_tol=1e-9,
        ):
            raise ValueError("目标方向最低置信度与标定档案不一致")
        if not math.isclose(
            _finite_float(applied_maximum, "applied_max_p90_deviation_deg"),
            maximum_deviation,
            rel_tol=0.0,
            abs_tol=1e-9,
        ):
            raise ValueError("目标方向P90门槛与标定档案不一致")
    return profile_name, sample_point_count, minimum_confidence, maximum_deviation


def _resolve_project_path(raw_path: str, root: Path) -> Path:
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = root / path
    path = path.resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"绑定文件必须位于项目内: {path}") from exc
    return path


def load_visual_grasp_calibration(
    path: str | Path | None = None,
    *,
    root: str | Path = _ROOT,
    verify_bindings: bool = True,
    verbose: bool = True,
) -> LoadedVisualGraspCalibration:
    root = Path(root).expanduser().resolve()
    calibration_path = Path(path or _DEFAULT_CALIBRATION).expanduser()
    if not calibration_path.is_absolute():
        calibration_path = root / calibration_path
    calibration_path = calibration_path.resolve()
    record = json.loads(calibration_path.read_text(encoding="utf-8"))

    if record.get("schema_version") != 1:
        raise ValueError("视觉抓取标定schema_version必须为1")
    if not str(record.get("status", "")).startswith("provisional_"):
        raise ValueError("视觉抓取标定必须显式标记为provisional")

    bindings = record.get("bindings")
    if not isinstance(bindings, dict):
        raise ValueError("视觉抓取标定缺少bindings")
    binding_paths: dict[str, Path] = {}
    for name in ("extrinsic", "tcp", "vision_config"):
        binding = bindings.get(name)
        if not isinstance(binding, dict):
            raise ValueError(f"视觉抓取标定缺少{name}绑定")
        binding_path = _resolve_project_path(str(binding.get("path", "")), root)
        if not binding_path.is_file():
            raise FileNotFoundError(f"绑定文件不存在: {binding_path}")
        expected_hash = str(binding.get("sha256", "")).lower()
        actual_hash = file_sha256(binding_path)
        if verify_bindings and actual_hash != expected_hash:
            raise ValueError(
                f"{name}绑定SHA-256失配；当前物理/配置基线可能已改变: "
                f"expected={expected_hash} actual={actual_hash}"
            )
        binding_paths[name] = binding_path

    extrinsic_record = json.loads(
        binding_paths["extrinsic"].read_text(encoding="utf-8")
    )
    transform = np.asarray(
        extrinsic_record.get("value_T_base_cam"), dtype=float
    )
    if transform.shape != (4, 4) or not np.all(np.isfinite(transform)):
        raise ValueError("外参T_base_cam必须是有限4x4矩阵")
    if not np.allclose(transform[3], [0.0, 0.0, 0.0, 1.0], atol=1e-9):
        raise ValueError("外参T_base_cam齐次矩阵末行无效")

    bounds = record.get("workspace_center_bounds_base_mm", {})
    _finite_bounds(bounds.get("x"), "workspace.x")
    _finite_bounds(bounds.get("y"), "workspace.y")
    _finite_vector(
        record.get("empirical_target_center_bias_base_mm"),
        3,
        "empirical_target_center_bias_base_mm",
    )
    geometry = record.get("geometry", {})
    for key in (
        "tcp_table_clearance_mm",
        "hover_lift_mm",
        "prealign_clearance_above_detected_top_mm",
        "maximum_cartesian_descent_step_mm",
        "maximum_descent_lateral_deviation_mm",
        "minimum_tcp_z_mm",
        "minimum_target_height_mm",
        "maximum_target_height_mm",
        "minimum_table_normal_z",
        "reference_table_z_mm",
        "maximum_reference_table_z_deviation_mm",
        "minimum_orientation_confidence_score",
        "maximum_orientation_p90_deviation_deg",
        "maximum_orientation_axis_normal_abs_dot",
        "empirical_grasp_yaw_bias_deg",
    ):
        _finite_float(geometry.get(key), f"geometry.{key}")
    if (
        geometry.get("grasp_orientation_mode")
        != "dynamic_topdown_square_edge_mod90"
    ):
        raise ValueError("geometry.grasp_orientation_mode不受支持")
    if not 0.0 <= float(geometry["minimum_orientation_confidence_score"]) <= 1.0:
        raise ValueError("minimum_orientation_confidence_score必须位于[0,1]")
    if not 0.0 < float(geometry["maximum_orientation_p90_deviation_deg"]) < 45.0:
        raise ValueError("maximum_orientation_p90_deviation_deg必须位于(0,45)")
    small_orientation = geometry.get("small_sample_orientation")
    if not isinstance(small_orientation, dict):
        raise ValueError("geometry.small_sample_orientation必须是映射")
    small_max_points = int(small_orientation.get("max_points", 0))
    small_min_confidence = _finite_float(
        small_orientation.get("minimum_confidence_score"),
        "geometry.small_sample_orientation.minimum_confidence_score",
    )
    small_max_deviation = _finite_float(
        small_orientation.get("maximum_p90_deviation_deg"),
        "geometry.small_sample_orientation.maximum_p90_deviation_deg",
    )
    if small_max_points <= 0:
        raise ValueError("small_sample_orientation.max_points必须大于0")
    if not 0.0 <= small_min_confidence <= float(
        geometry["minimum_orientation_confidence_score"]
    ):
        raise ValueError("small_sample_orientation最低置信度超出放宽范围")
    if not float(geometry["maximum_orientation_p90_deviation_deg"]) <= (
        small_max_deviation
    ) < 45.0:
        raise ValueError("small_sample_orientation最大P90偏差超出放宽范围")
    if not 0.0 <= float(geometry["maximum_orientation_axis_normal_abs_dot"]) < 0.2:
        raise ValueError("maximum_orientation_axis_normal_abs_dot超出合理范围")
    if abs(float(geometry["empirical_grasp_yaw_bias_deg"])) > 15.0:
        raise ValueError("empirical_grasp_yaw_bias_deg超过临时标定允许范围")
    seed = _finite_vector(
        record.get("planner_seed_joint_rad"),
        6,
        "planner_seed_joint_rad",
    )
    if np.max(np.abs(seed)) > 4.0:
        raise ValueError("planner_seed_joint_rad明显超出弧度范围")

    if verbose:
        print(
            "[calib] TEMP_BENCH_VISUAL_GRASP =",
            record.get("name"),
            "(★provisional★)",
        )
        print("[calib]   仅当:", record.get("valid_only_if"))
        print("[calib]   失效即重标:", record.get("recalibrate_when"))

    return LoadedVisualGraspCalibration(
        path=calibration_path,
        record=record,
        transform_base_camera=transform,
        binding_paths=binding_paths,
    )


def load_capture_metadata(path: str | Path) -> dict[str, Any]:
    capture_path = Path(path).expanduser().resolve()
    with np.load(capture_path, allow_pickle=False) as replay:
        if "metadata_json" not in replay.files:
            raise ValueError("RGB-D采集缺少metadata_json")
        metadata = json.loads(str(replay["metadata_json"].item()))
    if not isinstance(metadata, dict):
        raise ValueError("RGB-D metadata_json必须解码为对象")
    return metadata


def derive_visual_grasp_target(
    detection: dict[str, Any],
    calibration: LoadedVisualGraspCalibration,
    capture_metadata: dict[str, Any],
    *,
    source_detection: str | Path,
    source_capture: str | Path,
) -> dict[str, Any]:
    """Validate one detected target and derive hover/grasp TCPs in base frame."""
    if detection.get("schema_version") != 2:
        raise ValueError("检测结果schema_version必须为2")
    if detection.get("status") != "DETECTED_CAMERA_FRAME_ONLY":
        raise ValueError(f"检测状态不可用于抓取: {detection.get('status')}")
    if detection.get("camera_frame_only") is not True:
        raise ValueError("检测结果必须明确标记camera_frame_only=true")
    if int(detection.get("accepted_candidate_count", 0)) != 1:
        raise ValueError("视觉抓取只允许唯一候选")
    selected = detection.get("selected")
    if not isinstance(selected, dict) or selected.get("accepted") is not True:
        raise ValueError("检测结果缺少唯一已接受目标")

    if capture_metadata.get("quality_pass") is not True:
        raise ValueError("RGB-D采集质量门控未通过")
    expected_serial = str(calibration.record.get("camera_serial"))
    actual_serial = str(capture_metadata.get("serial", ""))
    if actual_serial != expected_serial:
        raise ValueError(
            f"D455序列号不匹配: expected={expected_serial} actual={actual_serial}"
        )

    surface_cam = _finite_vector(
        selected.get("surface_point_cam_m"), 3, "surface_point_cam_m"
    )
    plane = detection.get("plane")
    if not isinstance(plane, dict) or plane.get("quality_pass") is not True:
        raise ValueError("台面平面质量门控未通过")
    normal_cam = _finite_vector(plane.get("normal_cam"), 3, "normal_cam")
    normal_norm = float(np.linalg.norm(normal_cam))
    if normal_norm < 1e-9:
        raise ValueError("台面法向长度为0")
    normal_cam /= normal_norm
    offset_cam_m = _finite_float(plane.get("offset_m"), "plane.offset_m")
    offset_cam_m /= normal_norm

    transform = calibration.transform_base_camera
    surface_base = transform.dot(np.r_[surface_cam, 1.0])[:3]
    plane_point_cam = -offset_cam_m * normal_cam
    plane_point_base = transform.dot(np.r_[plane_point_cam, 1.0])[:3]
    normal_base = transform[:3, :3].dot(normal_cam)
    normal_base /= np.linalg.norm(normal_base)
    if normal_base[2] < 0.0:
        normal_base *= -1.0
    if normal_base[2] <= 1e-6:
        raise ValueError("变换后的台面法向无法用于计算局部台面高度")

    selected_orientation = selected.get("orientation")
    if not isinstance(selected_orientation, dict):
        raise ValueError("目标缺少三维台面方向估计")
    if float(selected_orientation.get("symmetry_period_deg", 0.0)) != 90.0:
        raise ValueError("当前方块方向必须明确采用90度对称周期")
    orientation_confidence = _finite_float(
        selected_orientation.get("confidence_score"),
        "orientation.confidence_score",
    )
    orientation_p90_deviation_deg = _finite_float(
        selected_orientation.get("p90_deviation_deg"),
        "orientation.p90_deviation_deg",
    )
    orientation_axis_cam = _finite_vector(
        selected_orientation.get("axis_cam"), 3, "orientation.axis_cam"
    )
    orientation_axis_cam_norm = float(np.linalg.norm(orientation_axis_cam))
    if orientation_axis_cam_norm < 1e-9:
        raise ValueError("目标方向轴长度为0")
    orientation_axis_cam /= orientation_axis_cam_norm

    geometry = calibration.record["geometry"]
    (
        orientation_quality_profile,
        orientation_sample_point_count,
        minimum_orientation_confidence,
        maximum_orientation_deviation_deg,
    ) = _orientation_quality_limits(
        selected_orientation,
        geometry,
    )
    maximum_axis_normal_dot = _finite_float(
        geometry["maximum_orientation_axis_normal_abs_dot"],
        "maximum_orientation_axis_normal_abs_dot",
    )
    if orientation_confidence < minimum_orientation_confidence:
        raise ValueError(
            f"目标方向置信度{orientation_confidence:.3f}低于"
            f"{minimum_orientation_confidence:.3f}"
        )
    if orientation_p90_deviation_deg > maximum_orientation_deviation_deg:
        raise ValueError(
            f"目标方向P90偏差{orientation_p90_deviation_deg:.3f}度超过"
            f"{maximum_orientation_deviation_deg:.3f}度"
        )
    camera_tangent_error = abs(float(orientation_axis_cam @ normal_cam))
    if camera_tangent_error > maximum_axis_normal_dot:
        raise ValueError(
            f"目标方向未落在相机台面内: |axis·normal|="
            f"{camera_tangent_error:.6f}"
        )

    orientation_axis_base = transform[:3, :3].dot(orientation_axis_cam)
    orientation_axis_base -= (
        normal_base * float(orientation_axis_base @ normal_base)
    )
    axis_base_norm = float(np.linalg.norm(orientation_axis_base))
    if axis_base_norm < 1e-9:
        raise ValueError("变换后的目标方向退化")
    orientation_axis_base /= axis_base_norm
    yaw_bias_deg = _finite_float(
        geometry["empirical_grasp_yaw_bias_deg"],
        "empirical_grasp_yaw_bias_deg",
    )
    yaw_bias_rad = math.radians(yaw_bias_deg)
    if abs(yaw_bias_rad) > 0.0:
        # Rodrigues rotation about the measured table normal.
        orientation_axis_base = (
            orientation_axis_base * math.cos(yaw_bias_rad)
            + np.cross(normal_base, orientation_axis_base)
            * math.sin(yaw_bias_rad)
            + normal_base
            * float(normal_base @ orientation_axis_base)
            * (1.0 - math.cos(yaw_bias_rad))
        )
        orientation_axis_base /= np.linalg.norm(orientation_axis_base)
    for value in orientation_axis_base:
        if abs(float(value)) > 1e-9:
            if value < 0.0:
                orientation_axis_base *= -1.0
            break
    base_tangent_error = abs(float(orientation_axis_base @ normal_base))
    if base_tangent_error > maximum_axis_normal_dot:
        raise ValueError(
            f"目标方向未落在base台面内: |axis·normal|="
            f"{base_tangent_error:.6f}"
        )

    minimum_normal_z = _finite_float(
        geometry["minimum_table_normal_z"], "minimum_table_normal_z"
    )
    if normal_base[2] < minimum_normal_z:
        raise ValueError(
            f"台面法向偏离标定过大: normal_z={normal_base[2]:.6f} "
            f"minimum={minimum_normal_z:.6f}"
        )

    x_m, y_m = (float(surface_base[0]), float(surface_base[1]))
    table_z_m = float(
        plane_point_base[2]
        - (
            normal_base[0] * (x_m - plane_point_base[0])
            + normal_base[1] * (y_m - plane_point_base[1])
        ) / normal_base[2]
    )
    height_m = float(normal_base.dot(surface_base - plane_point_base))

    bounds = calibration.record["workspace_center_bounds_base_mm"]
    x_bounds = _finite_bounds(bounds["x"], "workspace.x")
    y_bounds = _finite_bounds(bounds["y"], "workspace.y")
    raw_x_mm, raw_y_mm = x_m * 1000.0, y_m * 1000.0
    if not x_bounds[0] <= raw_x_mm <= x_bounds[1]:
        raise ValueError(
            f"原始目标X={raw_x_mm:.1f}mm超出已批准范围{x_bounds}mm"
        )
    if not y_bounds[0] <= raw_y_mm <= y_bounds[1]:
        raise ValueError(
            f"原始目标Y={raw_y_mm:.1f}mm超出已批准范围{y_bounds}mm"
        )

    target_bias_mm = _finite_vector(
        calibration.record["empirical_target_center_bias_base_mm"],
        3,
        "empirical_target_center_bias_base_mm",
    )
    corrected_x_mm = raw_x_mm + float(target_bias_mm[0])
    corrected_y_mm = raw_y_mm + float(target_bias_mm[1])
    if not x_bounds[0] <= corrected_x_mm <= x_bounds[1]:
        raise ValueError(
            f"补偿后目标X={corrected_x_mm:.1f}mm超出已批准范围{x_bounds}mm"
        )
    if not y_bounds[0] <= corrected_y_mm <= y_bounds[1]:
        raise ValueError(
            f"补偿后目标Y={corrected_y_mm:.1f}mm超出已批准范围{y_bounds}mm"
        )

    height_mm = height_m * 1000.0
    minimum_height_mm = _finite_float(
        geometry["minimum_target_height_mm"], "minimum_target_height_mm"
    )
    maximum_height_mm = _finite_float(
        geometry["maximum_target_height_mm"], "maximum_target_height_mm"
    )
    if not minimum_height_mm <= height_mm <= maximum_height_mm:
        raise ValueError(
            f"目标高程{height_mm:.1f}mm超出"
            f"[{minimum_height_mm:.1f}, {maximum_height_mm:.1f}]mm"
        )

    table_z_mm = table_z_m * 1000.0
    reference_table_z_mm = _finite_float(
        geometry["reference_table_z_mm"], "reference_table_z_mm"
    )
    maximum_table_deviation_mm = _finite_float(
        geometry["maximum_reference_table_z_deviation_mm"],
        "maximum_reference_table_z_deviation_mm",
    )
    if abs(table_z_mm - reference_table_z_mm) > maximum_table_deviation_mm:
        raise ValueError(
            "局部台面高度偏离临时标定过大: "
            f"current={table_z_mm:.2f}mm reference={reference_table_z_mm:.2f}mm"
        )

    clearance_mm = _finite_float(
        geometry["tcp_table_clearance_mm"], "tcp_table_clearance_mm"
    )
    hover_lift_mm = _finite_float(
        geometry["hover_lift_mm"], "hover_lift_mm"
    )
    prealign_top_clearance_mm = _finite_float(
        geometry["prealign_clearance_above_detected_top_mm"],
        "prealign_clearance_above_detected_top_mm",
    )
    if prealign_top_clearance_mm <= 0.0:
        raise ValueError(
            "prealign_clearance_above_detected_top_mm必须大于0"
        )
    grasp_tcp_mm = [
        corrected_x_mm,
        corrected_y_mm,
        table_z_mm + clearance_mm,
    ]
    prealign_z_mm = max(
        grasp_tcp_mm[2] + hover_lift_mm,
        table_z_mm + height_mm + prealign_top_clearance_mm,
    )
    hover_tcp_mm = [
        corrected_x_mm,
        corrected_y_mm,
        prealign_z_mm,
    ]
    minimum_tcp_z_mm = _finite_float(
        geometry["minimum_tcp_z_mm"], "minimum_tcp_z_mm"
    )
    if grasp_tcp_mm[2] < minimum_tcp_z_mm:
        raise ValueError(
            f"抓取TCP Z={grasp_tcp_mm[2]:.2f}mm低于"
            f"{minimum_tcp_z_mm:.2f}mm安全线"
        )

    seed = _finite_vector(
        calibration.record["planner_seed_joint_rad"],
        6,
        "planner_seed_joint_rad",
    )
    selected_height = selected.get("core_height_mm", {}).get("median")
    detector_height_mm = _finite_float(
        selected_height, "selected.core_height_mm.median"
    )

    return {
        "schema_version": 2,
        "name": "visual_science_target",
        "status": "PROVISIONAL_VISUAL_TARGET_OFFLINE_ONLY",
        "control_ready_after_external_transform": True,
        "source_detection": str(Path(source_detection).expanduser().resolve()),
        "source_capture": str(Path(source_capture).expanduser().resolve()),
        "source_calibration": str(calibration.path),
        "camera_serial": actual_serial,
        "joint_rad": seed.tolist(),
        "tcp_xyz_mm": hover_tcp_mm,
        "visual_target": {
            "surface_point_cam_m": surface_cam.tolist(),
            "surface_point_base_mm": (surface_base * 1000.0).tolist(),
            "raw_target_base_xy_mm": [raw_x_mm, raw_y_mm],
            "empirical_target_center_bias_base_mm": target_bias_mm.tolist(),
            "corrected_target_base_xy_mm": [
                corrected_x_mm,
                corrected_y_mm,
            ],
            "table_normal_base": normal_base.tolist(),
            "table_z_at_target_mm": table_z_mm,
            "height_along_table_normal_mm": height_mm,
            "detector_core_height_mm": detector_height_mm,
            "confidence_score": _finite_float(
                selected.get("confidence_score"), "confidence_score"
            ),
            "orientation_symmetry_period_deg": 90.0,
            "target_edge_axis_cam": orientation_axis_cam.tolist(),
            "target_edge_axis_base": orientation_axis_base.tolist(),
            "orientation_confidence_score": orientation_confidence,
            "orientation_p90_deviation_deg": (
                orientation_p90_deviation_deg
            ),
            "orientation_quality_profile": orientation_quality_profile,
            "orientation_sample_point_count": orientation_sample_point_count,
            "orientation_applied_min_confidence_score": (
                minimum_orientation_confidence
            ),
            "orientation_applied_max_p90_deviation_deg": (
                maximum_orientation_deviation_deg
            ),
            "empirical_grasp_yaw_bias_deg": yaw_bias_deg,
            "tcp_table_clearance_mm": clearance_mm,
            "minimum_hover_to_grasp_lift_mm": hover_lift_mm,
            "prealign_clearance_above_detected_top_mm": (
                prealign_top_clearance_mm
            ),
            "hover_to_grasp_descent_mm": (
                hover_tcp_mm[2] - grasp_tcp_mm[2]
            ),
            "hover_tcp_mm": hover_tcp_mm,
            "grasp_tcp_mm": grasp_tcp_mm,
            "workspace_bounds_base_mm": {
                "x": list(x_bounds),
                "y": list(y_bounds),
            },
            "grasp_orientation_mode": geometry["grasp_orientation_mode"],
        },
        "binding_sha256": {
            name: file_sha256(path)
            for name, path in calibration.binding_paths.items()
        },
    }


def _accepted_detection_targets(
    detection: dict[str, Any],
) -> list[dict[str, Any]]:
    accepted_targets = detection.get("accepted_targets")
    if isinstance(accepted_targets, list):
        targets = [
            target for target in accepted_targets
            if isinstance(target, dict) and target.get("accepted") is True
        ]
    else:
        targets = [
            candidate for candidate in detection.get("candidates", [])
            if isinstance(candidate, dict)
            and candidate.get("accepted") is True
        ]
    targets.sort(key=lambda target: int(target.get("component_id", 0)))
    declared_count = int(detection.get("accepted_candidate_count", len(targets)))
    if declared_count != len(targets):
        raise ValueError(
            "accepted_candidate_count与实际已接受目标数量不一致"
        )
    return targets


def derive_visual_grasp_targets(
    detection: dict[str, Any],
    calibration: LoadedVisualGraspCalibration,
    capture_metadata: dict[str, Any],
    *,
    source_detection: str | Path,
    source_capture: str | Path,
) -> dict[str, Any]:
    """Derive independently bound base-frame records for every target.

    The existing single-target validator remains the only authority for each
    candidate.  Multi-target handling only isolates one accepted component at
    a time, so center/depth/orientation fields can never be mixed across
    components.
    """
    if detection.get("schema_version") != 2:
        raise ValueError("检测结果schema_version必须为2")
    if detection.get("camera_frame_only") is not True:
        raise ValueError("检测结果必须明确标记camera_frame_only=true")
    if detection.get("status") not in {
        "DETECTED_CAMERA_FRAME_ONLY",
        "MULTIPLE_TARGETS_CAMERA_FRAME_ONLY",
        "AMBIGUOUS",  # Backward-compatible replay of earlier detector output.
    }:
        raise ValueError(
            f"检测状态不包含可用目标: {detection.get('status')}"
        )

    accepted_targets = _accepted_detection_targets(detection)
    if not accepted_targets:
        raise ValueError("检测结果不包含已接受目标")

    records = []
    rejected = []
    for index, candidate in enumerate(accepted_targets, start=1):
        component_id = int(candidate.get("component_id", index))
        target_id = str(
            candidate.get("target_id", f"component_{component_id:03d}")
        )
        isolated = dict(detection)
        isolated["status"] = "DETECTED_CAMERA_FRAME_ONLY"
        isolated["accepted_candidate_count"] = 1
        isolated["accepted_targets"] = [candidate]
        isolated["selected"] = candidate
        try:
            record = derive_visual_grasp_target(
                isolated,
                calibration,
                capture_metadata,
                source_detection=source_detection,
                source_capture=source_capture,
            )
        except ValueError as exc:
            rejected.append({
                "target_id": target_id,
                "component_id": component_id,
                "reason": f"{type(exc).__name__}: {exc}",
            })
            continue
        record["name"] = f"visual_science_target_{target_id}"
        record["source_target_id"] = target_id
        record["source_component_id"] = component_id
        record["visual_target"]["source_target_id"] = target_id
        record["visual_target"]["source_component_id"] = component_id
        records.append(record)

    status = (
        "MULTI_TARGETS_BASE_FRAME_READY"
        if records
        else "NO_TARGET_IN_APPROVED_BASE_WORKSPACE"
    )
    return {
        "schema_version": 1,
        "status": status,
        "source_detection": str(Path(source_detection).expanduser().resolve()),
        "source_capture": str(Path(source_capture).expanduser().resolve()),
        "source_calibration": str(calibration.path),
        "detected_target_count": len(accepted_targets),
        "base_frame_target_count": len(records),
        "rejected_target_count": len(rejected),
        "targets": records,
        "rejected_targets": rejected,
    }


def derive_visual_grasp_target_from_files(
    detection_path: str | Path,
    capture_path: str | Path,
    *,
    calibration_path: str | Path | None = None,
    output_path: str | Path | None = None,
    root: str | Path = _ROOT,
    overwrite: bool = False,
    verbose: bool = True,
) -> dict[str, Any]:
    detection_path = Path(detection_path).expanduser().resolve()
    capture_path = Path(capture_path).expanduser().resolve()
    detection = json.loads(detection_path.read_text(encoding="utf-8"))
    metadata = load_capture_metadata(capture_path)
    calibration = load_visual_grasp_calibration(
        calibration_path,
        root=root,
        verbose=verbose,
    )
    record = derive_visual_grasp_target(
        detection,
        calibration,
        metadata,
        source_detection=detection_path,
        source_capture=capture_path,
    )
    if output_path is not None:
        output_path = Path(output_path).expanduser().resolve()
        if output_path.exists() and not overwrite:
            raise FileExistsError(f"目标记录已存在: {output_path}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(
                record,
                ensure_ascii=False,
                indent=2,
                allow_nan=False,
            )
            + "\n",
            encoding="utf-8",
        )
    return record
