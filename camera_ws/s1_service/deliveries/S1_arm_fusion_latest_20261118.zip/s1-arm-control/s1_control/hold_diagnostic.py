"""Pure analysis helpers for supervised S1 joint-hold diagnostics."""
from __future__ import annotations

import math
import statistics
from collections.abc import Callable, Sequence


JOINT_COUNT = 6


def _finite_vector(values, length: int, label: str) -> list[float]:
    result = [float(value) for value in values]
    if len(result) != length or not all(math.isfinite(value) for value in result):
        raise ValueError(f"{label} must contain {length} finite values")
    return result


def _median_columns(rows: Sequence[Sequence[float]]) -> list[float]:
    return [
        statistics.median(row[index] for row in rows)
        for index in range(JOINT_COUNT)
    ]


def _linear_slopes(times: Sequence[float], rows: Sequence[Sequence[float]]) -> list[float]:
    mean_time = statistics.fmean(times)
    denominator = sum((value - mean_time) ** 2 for value in times)
    if denominator <= 0.0:
        return [0.0] * JOINT_COUNT
    return [
        sum(
            (time_s - mean_time)
            * (row[joint] - statistics.fmean(item[joint] for item in rows))
            for time_s, row in zip(times, rows)
        )
        / denominator
        for joint in range(JOINT_COUNT)
    ]


def summarize_hold_samples(
    reference_q,
    reference_tcp,
    samples,
    fk: Callable[[list[float]], Sequence[float]],
    *,
    final_window_s: float = 1.0,
    tracking_tolerance_rad: float = 0.01,
    stationarity_range_rad: float = 0.003,
    stationarity_slope_rad_s: float = 0.01,
    maximum_tcp_z_drift_mm: float = 3.0,
) -> dict:
    """Summarize whether an unchanged joint target develops a stable offset.

    This function is deliberately hardware-independent so its classification
    can be unit-tested.  ``STEADY_OFFSET_DETECTED`` means only that a repeatable
    target/feedback offset exists; it does not by itself prove payload error.
    """
    reference = _finite_vector(reference_q, JOINT_COUNT, "reference_q")
    tcp_reference = _finite_vector(reference_tcp, 7, "reference_tcp")
    if not math.isfinite(final_window_s) or final_window_s <= 0.0:
        raise ValueError("final_window_s must be positive and finite")
    if len(samples) < 2:
        raise ValueError("at least two hold samples are required")

    normalized = []
    previous_time = -math.inf
    for index, sample in enumerate(samples):
        elapsed = float(sample["elapsed_s"])
        position = _finite_vector(
            sample["position_rad"], JOINT_COUNT, f"samples[{index}].position_rad"
        )
        if not math.isfinite(elapsed) or elapsed < previous_time:
            raise ValueError("sample elapsed_s values must be finite and ordered")
        normalized.append((elapsed, position, sample))
        previous_time = elapsed

    end_time = normalized[-1][0]
    final = [item for item in normalized if item[0] >= end_time - final_window_s]
    if len(final) < 2:
        final = normalized[-min(10, len(normalized)) :]

    final_times = [item[0] for item in final]
    final_positions = [item[1] for item in final]
    final_q = _median_columns(final_positions)
    final_error = [value - target for value, target in zip(final_q, reference)]
    maximum_error = max(abs(value) for value in final_error)
    maximum_error_joint = 1 + max(
        range(JOINT_COUNT), key=lambda index: abs(final_error[index])
    )
    final_ranges = [
        max(row[joint] for row in final_positions)
        - min(row[joint] for row in final_positions)
        for joint in range(JOINT_COUNT)
    ]
    final_slopes = _linear_slopes(final_times, final_positions)

    tcp_final = _finite_vector(fk(list(final_q)), 7, "fk(final_q)")
    tcp_delta_mm = [
        1000.0 * (tcp_final[index] - tcp_reference[index])
        for index in range(3)
    ]

    stationary = (
        max(final_ranges) <= stationarity_range_rad
        and max(abs(value) for value in final_slopes) <= stationarity_slope_rad_s
    )
    tracking_ok = (
        maximum_error <= tracking_tolerance_rad
        and abs(tcp_delta_mm[2]) <= maximum_tcp_z_drift_mm
    )
    if tracking_ok:
        status = "HOLD_TRACKING_OK"
    elif stationary:
        status = "STEADY_OFFSET_DETECTED"
    else:
        status = "NOT_SETTLED"

    fresh_torque_rows = []
    for _, _, sample in normalized:
        if not sample.get("torque_fresh", False):
            continue
        try:
            fresh_torque_rows.append(
                _finite_vector(sample["torque_nm"], JOINT_COUNT, "torque_nm")
            )
        except (KeyError, TypeError, ValueError):
            continue
    torque_median = (
        _median_columns(fresh_torque_rows) if fresh_torque_rows else None
    )

    return {
        "status": status,
        "sample_count": len(normalized),
        "duration_s": end_time - normalized[0][0],
        "final_window_sample_count": len(final),
        "reference_q_rad": reference,
        "final_q_median_rad": final_q,
        "final_error_rad": final_error,
        "final_error_deg": [math.degrees(value) for value in final_error],
        "maximum_abs_error_rad": maximum_error,
        "maximum_abs_error_joint": maximum_error_joint,
        "final_window_range_rad": final_ranges,
        "final_window_slope_rad_s": final_slopes,
        "stationary": stationary,
        "tracking_ok": tracking_ok,
        "reference_tcp_xyz_xyzw": tcp_reference,
        "final_tcp_xyz_xyzw": tcp_final,
        "tcp_delta_mm": tcp_delta_mm,
        "fresh_torque_sample_count": len(fresh_torque_rows),
        "feedback_torque_median_nm": torque_median,
        "thresholds": {
            "tracking_tolerance_rad": tracking_tolerance_rad,
            "stationarity_range_rad": stationarity_range_rad,
            "stationarity_slope_rad_s": stationarity_slope_rad_s,
            "maximum_tcp_z_drift_mm": maximum_tcp_z_drift_mm,
            "final_window_s": final_window_s,
        },
    }
