"""Resolve bound legacy paths without rewriting evidence hashes."""
from pathlib import Path

LEGACY_ROOT = Path("/home/ljw/桌面/s1-arm-control")

def project_path(raw, root):
    path = Path(raw).expanduser()
    if path.is_relative_to(LEGACY_ROOT):
        path = Path(root) / path.relative_to(LEGACY_ROOT)
    elif not path.is_absolute():
        path = Path(root) / path
    return path.resolve()
