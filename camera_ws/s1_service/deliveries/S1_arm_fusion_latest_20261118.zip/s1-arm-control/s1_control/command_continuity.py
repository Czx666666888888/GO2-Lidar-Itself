"""Command-boundary helpers and streamed diagnostics; no hardware access."""
from __future__ import annotations

import json
import math
from pathlib import Path
import time


def _q(value):
    q = [float(x) for x in value]
    if len(q) != 6 or not all(math.isfinite(x) for x in q):
        raise ValueError("command path requires six finite joints")
    return q


def continuous_command_path(previous_command, physical_path):
    """Keep the physical plan, but start its command stream at the last command.

    The measured planning seed is not sent as a new setpoint. The caller must
    independently preflight the resulting command path and measured envelope.
    """
    previous = _q(previous_command)
    points = [_q(q) for q in physical_path]
    if len(points) < 2:
        raise ValueError("continuous motion requires at least two planned points")
    result = [previous]
    for point in points[1:]:
        if max(abs(a-b) for a, b in zip(result[-1], point)) > 1e-12:
            result.append(point)
    return result


def offset_command_path(
    previous_command, physical_path, maximum_offset_rad=0.05, *, clip_learned_offset=False
):
    """Carry the measured offset into the checked path from the previous command."""
    previous = _q(previous_command)
    points = [_q(q) for q in physical_path]
    if len(points) < 2:
        raise ValueError("offset mapping requires at least two physical points")
    limit = float(maximum_offset_rad)
    if not math.isfinite(limit) or not 0 < limit <= .05:
        raise ValueError("learned position offset limit must be in (0, 0.05]rad")
    offset = [c-p for c,p in zip(previous, points[0])]
    if max(abs(x) for x in offset) > limit:
        if not clip_learned_offset:
            raise RuntimeError("learned position offset exceeds bounded limit")
        offset = [min(limit, max(-limit, value)) for value in offset]
    commands = [[p+b for p,b in zip(q,offset)] for q in points]
    commands[0] = list(previous)  # Preserve exact first-command identity.
    return commands, offset


class CommandTrace:
    """Proxy a position commander and log existing snapshots at up to 20Hz.

    Large boundary steps and long intervals are always recorded. All control
    calls contribute to the maximum interval statistic even between rows.
    Position feedback here is SDK feedback, not proof of fresh motor frames.
    """
    def __init__(self, commander, path, sample_period_s=0.05):
        self.commander = commander
        self.path = Path(path)
        self.stream = self.path.open("x", encoding="utf-8", buffering=65536)
        self.sample_period_s = float(sample_period_s)
        self.phase = "deployment_or_hold"
        self.last_command_q_rad = None
        self.last_started = None
        self.last_written = None
        self.maximum_interval_since_record = 0.0
        self.started = time.monotonic()
        self.row_count = 0
        self.command_count = 0
        self.downward_guard = None

    def set_downward_guard(self, height_function, reference_height_mm, limit_mm):
        """A None limit records displacement without a diagnostic abort."""
        if not callable(height_function) or not math.isfinite(reference_height_mm):
            raise ValueError("invalid live height reference")
        if limit_mm is not None and (not math.isfinite(limit_mm) or not 0 < limit_mm <= 3.0):
            raise ValueError("live downward limit must be in (0, 3]mm")
        self.downward_guard = (height_function, reference_height_mm, limit_mm)

    def clear_downward_guard(self):
        self.downward_guard = None

    def __getattr__(self, name):
        return getattr(self.commander, name)

    def __call__(self, arm, target):
        target = _q(target)
        started = time.monotonic()
        interval = None if self.last_started is None else started-self.last_started
        if interval is not None:
            self.maximum_interval_since_record = max(
                self.maximum_interval_since_record, interval
            )
        delta = None if self.last_command_q_rad is None else [
            a-b for a, b in zip(target, self.last_command_q_rad)
        ]
        result = self.commander(arm, target)
        completed = time.monotonic()
        self.last_command_q_rad = list(target)
        self.last_started = started
        self.command_count += 1
        snapshot = getattr(self.commander, "last_snapshot", None) or {}
        displacement = None
        violation = False
        guard_armed = self.phase in {
            "support_tangent_center_alignment", "support_tangent_residual_alignment"
        } or (self.phase.startswith("alignment_endpoint_pass_") and (
            "_trim_" in self.phase or "_hold_" in self.phase
        ))
        if self.downward_guard is not None:
            height_function, reference, limit = self.downward_guard
            measured = snapshot.get("measured_q_rad")
            if measured is None:
                raise RuntimeError("live normal guard requires measured joint feedback")
            displacement = float(height_function(_q(measured)))-reference
            if not math.isfinite(displacement):
                raise RuntimeError("live normal displacement is non-finite")
            violation = guard_armed and limit is not None and displacement < -limit
        step = 0.0 if delta is None else max(abs(x) for x in delta)
        if (self.last_written is None
                or completed-self.last_written >= self.sample_period_s
                or step > 0.002
                or (interval is not None and interval > 0.1) or violation):
            row = {
                "monotonic_s": started,
                "elapsed_s": started-self.started,
                "phase": self.phase,
                "command_index": self.command_count,
                "command_q_rad": target,
                "command_delta_rad": delta,
                "command_interval_s": interval,
                "maximum_interval_since_record_s": self.maximum_interval_since_record,
                "commander_call_s": completed-started,
                "measured_q_rad": snapshot.get("measured_q_rad"),
                "measurement_timing": "before_current_command",
                "command_tau_nm": snapshot.get("command_tau_nm"),
                "applied_tilt_nm": snapshot.get("applied_nm"),
                "support_up_normal_base": snapshot.get("support_up_normal_base"),
                "compensation_scale": snapshot.get("compensation_scale"),
                "support_normal_displacement_mm": displacement,
                "live_downward_guard_triggered": violation,
                "live_downward_guard_armed": guard_armed and self.downward_guard is not None and self.downward_guard[2] is not None,
                "live_downward_monitor_only": self.downward_guard is not None and self.downward_guard[2] is None,
            }
            self.stream.write(json.dumps(row, separators=(",", ":"))+"\n")
            self.row_count += 1
            self.last_written = completed
            self.maximum_interval_since_record = 0.0
            if self.row_count % 20 == 0:
                self.stream.flush()
        if violation:
            self.stream.flush()
            raise RuntimeError(
                f"live alignment downward displacement {displacement:.3f}mm "
                f"exceeds {-limit:.3f}mm limit"
            )
        return result

    def close(self):
        self.stream.close()
