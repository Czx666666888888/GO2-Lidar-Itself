# 环境搭建（新机子从零跑起来）

面向**一台新的 Ubuntu 机器**，从零把本项目跑起来。分两层：
- **core（机械臂控制）** —— 只需第 1、2 节，自包含，是机械臂能动的前提。
- **demo（红盖抓取）** —— 另需第 3 节的重环境，见 `demo_grasp/README.md`。

> 版本基线（本项目验证于此机）：Ubuntu 22.04；miniforge/conda；机械臂串口 udev 别名 `/dev/s1-arm`
> （**不要写死 `/dev/ttyUSB0`**，断电重连会变号）；相机 RealSense D455 serial `231622302209`。

---

## 1. S1_SDK（机械臂控制根依赖，必装）

来源：`https://github.com/YHRG-Robotics/S1_SDK_V2`（MIT，Python 3.10）。提供 `S1_arm`（运动/夹爪/使能/碰撞）与 `S1_solver`（FK/IK）。

```bash
# 建 core 用的 conda 环境
conda create -n S1 python=3.10 -y
conda activate S1
pip install pybind11 numpy pyyaml        # install.sh 需要 pybind11；本项目 core 需 numpy+pyyaml

# 取 SDK 并安装（含 C++ 扩展的 cmake 编译；aarch64 会自动加 -DIS_ARM=ON）
cd ~/thirdparty            # 或任意位置
git clone https://github.com/YHRG-Robotics/S1_SDK_V2.git S1_SDK_V2-official
cd S1_SDK_V2-official
bash install.sh            # = pip install -e .  +  cmake/build（需已装 cmake、编译器）

# 验证
python -c "from S1_SDK import S1_arm, S1_solver, control_mode; print('S1_SDK OK')"
```

> 装 SDK 时若报 pybind11/cmake 缺失：`pip install pybind11`、`sudo apt install cmake build-essential`。
> SDK 用法与 API 详见其自带 `readme.md`；官方示例见本仓 `environment/S1_SDK_examples.md`。

## 2. 本项目 core（机械臂控制）

core 纯 Python，不含编译产物，装好 S1_SDK 后即可跑：

```bash
conda activate S1
pip install numpy pyyaml                 # 若第 1 步已装可跳过
cd <本仓>                                # git clone 本仓后的目录

# 离线自检（不通电）：
python -c "import s1_control"            # 应【不】拉入 pyrealsense2/cv2/serial（自包含红线）
python scripts/goto_hold.py --ready-only # 预检，打印 FK + 标定 provisional 提示

# 通电（★有人看护，手在断电开关上★）：
python scripts/goto_hold.py --ready-only --execute
```

标定值（`calibration/`）随仓入库，clone 即在，但**是 provisional**——绑定 2026-07 物理摆放，
相机移动/换末端即须重标，见 `calibration/README.md`。

## 3. demo 重环境（可选，抓取才需要）

capture 步用 core 的 `S1` 环境另加相机库；infer 步需独立的 `graspness` 重环境（torch + 编译算子 + 权重）。
**完整重建步骤（含各 github 来源、CUDA 编译参数、权重下载）见 `demo_grasp/README.md` 的“环境重建”节。**

```bash
# 相机（S1 环境即可跑 capture）
conda activate S1
pip install pyrealsense2 opencv-python
```

---

## 关系速览

| 层 | conda 环境 | 关键依赖 | 用途 |
|---|---|---|---|
| core | `S1` | S1_SDK + numpy + pyyaml | 机械臂运动/夹爪/IK（自包含） |
| 相机 | `S1` | +pyrealsense2 +opencv | demo capture 拍帧 |
| 推理 | `graspness` | torch+ME+pointnet2+权重 | demo infer（见 demo_grasp/README） |
