# S1_SDK 官方示例参考索引

做**新动作/新功能**时的第一手参考。位置：`<S1_SDK 安装目录>/examples/python/`
（本机为 `~/thirdparty/S1_SDK_V2-official/examples/python/`）。SDK 是编译库、源码不可读，
**这些官方示例 + SDK 自带 `readme.md` 是理解 API 的权威入口**。

> 说明取自各文件 docstring 首行并经核实。⚠️ 标注处为官方 docstring 与实际文件名/行为不符，
> 已按实际用途纠正——沿用时以代码为准，别只信 docstring。

## 状态 / 基础

| 示例 | 用途 | 做新东西时看它学 |
|---|---|---|
| `read_pos.py` | 读当前关节位置，**不使能**，`get_pos()` | 安全地读状态、`get_pos()[6]`=夹爪 |
| `enable.py` | 使能（`enable()`，开始输出力矩） | 通电前的标准使能；`S1_arm(...)` 构造参数 |
| `disable.py` | 失能 | 收尾/急停兜底 |
| `check_arm.py` | 机械臂连通/自检 | 首次连线排查 |
| `gravity.py` | 重力补偿（`gravity()`） | 让臂“浮”在原地、手动摆位 |

## 运动控制

| 示例 | 用途 | 做新东西时看它学 |
|---|---|---|
| `keyboard_joint.py` | ⚠️docstring 写“笛卡尔”，按名/常理是**关节空间**键控 | 关节角增量控制、`joint_control_mit` |
| `keyboard_end_effect.py` | **笛卡尔空间**末端键控（`S1_solver.inverse_euler` + `joint_control_mit`） | 末端位姿控制、IK 驱动走位（本项目 kinematics 的官方参照） |
| `collision.py` | 自碰撞检测（`check_collision`） | 路点预检（本项目 arm.preflight 的官方参照） |
| `teaching.py` | 示教：`python3 teaching.py 1` 记录模式，拖动机械臂记轨迹 | 采点/录轨迹（标定采位姿可参考） |
| `teleop_demo.py` | 主从臂遥操 demo（**需两条臂**：主+从） | 遥操场景 |
| `test.py` | 杂项测试 | — |

## 零位设置（NVM 写入，谨慎）

| 示例 | 用途 | 备注 |
|---|---|---|
| `set_zero_position.py` | ⚠️docstring 误写“使能”，实为**整臂零位**设置 | 谨慎：持久 NVM 写 |
| `set_zero_position_gripper.py` | **夹爪(ID7)零位**设置，不使能 | 本机夹爪零位已写在全闭处（2026-07-20）；换机/漂移才需重跑 |
| `set_zero_position_teach_gripper.py` | 夹爪零位（示教变体） | 同上 |

## 本项目哪块参照了哪个示例

- `s1_control/arm.py`（构造/enable/joint_control_mit/check_collision/disable）← `enable.py` + `collision.py` + `read_pos.py`
- `s1_control/kinematics.py`（S1_solver FK/IK）← `keyboard_end_effect.py`（官方用 `inverse_euler`；本项目用 `inverse_quat`）
- `s1_control/gripper.py`（control_gripper）← 夹爪语义定案见本仓 `config/gripper.yaml` 注释；零位示例见上表
- 更细的项目内溯源：各模块 docstring 标了“照搬 industrial-agent/scripts/xxx”。

## 提示

- SDK API 全貌看 `~/thirdparty/S1_SDK_V2-official/readme.md`（含初始化/状态/运动/运动学/高级功能/FAQ 目录）。
- `S1_arm` 公开方法：`enable/disable/close/get_pos/get_vel/get_tau/get_temp/joint_control/joint_control_mit/control_gripper/control_mix*/control_teach*/check_collision/gravity/set_zero_position/set_end_zero_position`。
