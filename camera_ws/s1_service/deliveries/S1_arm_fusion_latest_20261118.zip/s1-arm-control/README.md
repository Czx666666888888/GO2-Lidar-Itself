# S1机械臂融合交付 2026-11-18

本包包含最新左右抓取、零位保持、一次漏抓重试和转轴收纳盒倾倒代码，以及绑定计划、标定、SDK源码和离线回归样本。

先阅读 START_HERE.md 和 docs/TEAM_INTEGRATION.md。在安装依赖及SDK后，从本目录执行：

```bash
python -B scripts/verify_handoff.py
```

右侧服务：

```bash
OPENBLAS_NUM_THREADS=1 python -uB scripts/run_arm_integration.py --execute
```

左侧服务：

```bash
OPENBLAS_NUM_THREADS=1 python -uB scripts/run_go2_left_grasp.py --execute
```

服务启动后回零并持续保持。导航端在采样点停止后请求 grasp，等待任务结束并回到 ZERO_HOLD 后再移动。全部探索和采集结束、返回卸载区后，由导航端单独请求 dump。

```bash
python scripts/arm_task_client.py status
python scripts/arm_task_client.py grasp
python scripts/arm_task_client.py dump
```

默认全自动。左右服务二选一启动。转轴盒示教依赖原安装位置和机身支撑构型。

本版最终夹紧保持力矩0.50Nm，工具旋转方向验收4度，J6跟踪门槛0.12rad。下降融合居中修正，漏抓后返回观察位重新识别一次，任务最多抓取两次。

解压迁移后的左右预检及198项离线回归通过，验证未读取原工程目录。最新动作改动仍待实车验证。视觉落盒和卸空确认仍需外部确认。
