#!/usr/bin/env python3
"""Supervised differential gravity compensation diagnostic for S1 on Go2.

The official SDK's level-base gravity term is preserved.  At every control
cycle this script adds only the URDF-predicted difference caused by the fixed
Go2 crouch mounting pitch.  It never accesses a camera or commands a gripper.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import statistics
import sys
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
for path in (PROJECT_ROOT, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from diagnose_small_joint_motion import (
    ENDPOINT_SETTLE_SECONDS,
    MOTION_START_MAX_DRIFT_RAD,
    MOTION_START_MAX_SPAN_RAD,
    read_motion_start,
    teaching_until_locked,
    tcp_delta_mm,
)
from diagnose_wrist_hold_tracking import finite_vector, wait_for_valid_feedback
from s1_control.arm import SafetyLimits, Arm, motion_duration_s, motion_profile_progress
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    differential_tilt_compensation,
    limited_correction,
    locate_official_gripper_urdf,
)
from s1_control.wrist_visual_servo import joint_margin_details


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "go2_crouch_mount.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "tilt_compensation_runs"
REFERENCE_FAILED_Q = [
    1.499007,
    2.152857,
    1.481460,
    0.900091,
    0.078775,
    -0.002480,
]
MAX_J1_DIAGNOSTIC_DELTA_RAD = 0.05
DEFAULT_MIN_OBSERVED_J1_RATIO = 0.80
ENDPOINT_J1_TOLERANCE_RAD = 0.003
ENDPOINT_MAX_ERROR_RAD = 0.01
ENDPOINT_TRIM_STEP_RAD = 0.004
ENDPOINT_TRIM_MAX_BIAS_RAD = 0.012
ENDPOINT_TRIM_MAX_ATTEMPTS = 3
ENDPOINT_TRIM_HOLD_SECONDS = 0.8


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="Go2趴下6度固定倾角：S1差分重力补偿安全诊断"
    )
    ap.add_argument("--dev", default="/dev/ttyUSB0")
    ap.add_argument("--end", default="gripper")
    ap.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    ap.add_argument("--mode", choices=("hold", "j1-motion"), default="hold")
    ap.add_argument("--compensation-scale", type=float)
    ap.add_argument("--j1-delta-rad", type=float, default=0.02)
    ap.add_argument("--v-max-rad-s", type=float, default=0.05)
    ap.add_argument("--teach-hz", type=float, default=50.0)
    ap.add_argument("--lock-sample-hz", type=float, default=10.0)
    ap.add_argument("--lock-sample-count", type=int, default=15)
    ap.add_argument("--min-joint-margin-deg", type=float, default=15.0)
    ap.add_argument("--max-tcp-displacement-mm", type=float, default=20.0)
    ap.add_argument("--max-tcp-z-change-mm", type=float, default=2.0)
    ap.add_argument(
        "--max-motion-track-error-rad",
        type=float,
        default=0.025,
        help="仅用于J1运动途中的瞬时跟踪误差上限",
    )
    ap.add_argument(
        "--min-observed-j1-ratio",
        type=float,
        default=DEFAULT_MIN_OBSERVED_J1_RATIO,
        help="往返稳定端点之间的实测J1行程/指令行程下限",
    )
    ap.add_argument("--run-id")
    ap.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    ap.add_argument("--execute", action="store_true")
    return ap


def load_configuration(path: Path) -> dict:
    record = json.loads(path.expanduser().resolve().read_text(encoding="utf-8"))
    mount = record["mount_measurement"]
    diagnostic = record["diagnostic"]
    rear_down = float(mount["rear_edge_lower_deg"])
    if not math.isfinite(rear_down) or abs(rear_down) >= 30.0:
        raise ValueError("configured rear-edge-lower angle is invalid")
    scales = [float(value) for value in diagnostic["allowed_scale_steps"]]
    if not scales or any(
        not math.isfinite(value) or value <= 0.0 or value > 1.0
        for value in scales
    ):
        raise ValueError("allowed compensation scales must be in (0, 1]")
    limits = [float(value) for value in diagnostic["correction_absolute_limits_nm"]]
    if len(limits) != 6 or any(
        not math.isfinite(value) or value <= 0.0 for value in limits
    ):
        raise ValueError("six positive correction limits are required")
    return record


def resolve_scale(args, config: dict) -> float:
    diagnostic = config["diagnostic"]
    scale = (
        float(diagnostic["initial_compensation_scale"])
        if args.compensation_scale is None
        else float(args.compensation_scale)
    )
    allowed = [float(value) for value in diagnostic["allowed_scale_steps"]]
    if not any(math.isclose(scale, item, abs_tol=1e-9) for item in allowed):
        raise ValueError(
            f"compensation scale {scale} is not an approved step {allowed}"
        )
    return scale


def correction_snapshot(model, q_rad, rear_down_deg, scale, limits):
    differential = differential_tilt_compensation(
        model, q_rad, rear_down_deg
    )
    requested, applied = limited_correction(differential, scale, limits)
    return {
        "differential_nm": differential.tolist(),
        "requested_nm": requested.tolist(),
        "applied_nm": applied.tolist(),
        "clipped": bool(max(abs(a - b) for a, b in zip(requested, applied)) > 1e-9),
    }


def evaluate_observed_j1_motion(
    commanded_delta_rad: float,
    target_median_j1_rad: float,
    return_median_j1_rad: float,
    minimum_ratio: float = DEFAULT_MIN_OBSERVED_J1_RATIO,
) -> dict:
    """Evaluate real J1 separation between the two settled endpoints.

    Endpoint errors alone are insufficient: opposite-signed errors can each
    remain within tolerance while the arm travels only a small fraction of the
    requested motion.  This metric therefore checks both direction and travel.
    """
    values = (
        commanded_delta_rad,
        target_median_j1_rad,
        return_median_j1_rad,
        minimum_ratio,
    )
    if not all(math.isfinite(value) for value in values):
        raise ValueError("J1 motion observation requires finite values")
    if commanded_delta_rad == 0.0:
        raise ValueError("commanded J1 delta must be non-zero")
    if not 0.0 < minimum_ratio <= 1.0:
        raise ValueError("minimum observed J1 ratio must be in (0, 1]")

    observed_delta_rad = target_median_j1_rad - return_median_j1_rad
    signed_ratio = observed_delta_rad / commanded_delta_rad
    direction_ok = signed_ratio > 0.0
    return {
        "commanded_delta_rad": commanded_delta_rad,
        "observed_delta_rad": observed_delta_rad,
        "observed_ratio": signed_ratio,
        "minimum_ratio": minimum_ratio,
        "direction_ok": direction_ok,
        "passed": direction_ok and signed_ratio >= minimum_ratio,
    }


def build_tilt_j1_target(q_reference, delta_rad: float) -> list[float]:
    """Build the bounded J1 target used only by this tilt diagnostic."""
    q = finite_vector(q_reference, 6, "q_reference")
    if (
        not math.isfinite(delta_rad)
        or delta_rad <= 0.0
        or delta_rad > MAX_J1_DIAGNOSTIC_DELTA_RAD
    ):
        raise ValueError(
            "tilt diagnostic J1 delta must be in "
            f"(0, {MAX_J1_DIAGNOSTIC_DELTA_RAD}]rad"
        )
    target = list(q)
    target[0] += float(delta_rad)
    return target


def guard_tilt_motion(
    arm,
    position,
    velocity,
    temperature,
    target,
    maximum_track_error_rad: float,
):
    """Apply a motion-only track limit while preserving Arm speed/temp guards."""
    if (
        not math.isfinite(maximum_track_error_rad)
        or maximum_track_error_rad <= 0.0
    ):
        raise ValueError("motion track-error limit must be positive and finite")
    error = [position[index] - target[index] for index in range(6)]
    if max(abs(value) for value in error) > maximum_track_error_rad:
        return (
            f"track_err>{maximum_track_error_rad:.3f}: "
            f"{['%+.4f' % value for value in error]}"
        )

    # Neutralize only Arm.guard's position-error branch. Its measured-speed
    # three-strike debounce, temperature gate, and diagnostic windows remain
    # active and unchanged.
    return arm.guard(
        position,
        velocity,
        temperature,
        position,
        settling=False,
    )


def guard_endpoint_trim(
    arm,
    position,
    velocity,
    temperature,
    command_target,
    desired_target,
    maximum_command_error_rad: float,
    maximum_desired_error_rad: float,
    maximum_non_j1_error_rad: float,
    settling: bool,
):
    """Guard a biased J1 trim without confusing bias with physical error."""
    limits = (
        maximum_command_error_rad,
        maximum_desired_error_rad,
        maximum_non_j1_error_rad,
    )
    if not all(math.isfinite(value) and value > 0.0 for value in limits):
        raise ValueError("endpoint trim guard limits must be positive and finite")

    command_error = [
        position[index] - command_target[index] for index in range(6)
    ]
    desired_error = [
        position[index] - desired_target[index] for index in range(6)
    ]
    if abs(desired_error[0]) > maximum_desired_error_rad:
        return (
            f"J1_desired_err>{maximum_desired_error_rad:.3f}: "
            f"{desired_error[0]:+.4f}"
        )
    if max(abs(value) for value in desired_error[1:]) > maximum_non_j1_error_rad:
        return (
            f"non_J1_desired_err>{maximum_non_j1_error_rad:.3f}: "
            f"{['%+.4f' % value for value in desired_error[1:]]}"
        )
    if abs(command_error[0]) > maximum_command_error_rad:
        return (
            f"J1_command_err>{maximum_command_error_rad:.3f}: "
            f"{command_error[0]:+.4f}"
        )

    # Position error has already been checked against both the physical target
    # and the deliberately biased J1 command. Delegate with a neutral target so
    # Arm.guard keeps its speed-strike and temperature protections unchanged.
    return arm.guard(
        position,
        velocity,
        temperature,
        position,
        settling=settling,
    )


def next_endpoint_trim_bias(
    current_bias_rad: float,
    desired_error_rad: float,
    maximum_step_rad: float = ENDPOINT_TRIM_STEP_RAD,
    maximum_bias_rad: float = ENDPOINT_TRIM_MAX_BIAS_RAD,
) -> float:
    """Return a bounded command bias opposing the measured endpoint error."""
    values = (
        current_bias_rad,
        desired_error_rad,
        maximum_step_rad,
        maximum_bias_rad,
    )
    if not all(math.isfinite(value) for value in values):
        raise ValueError("endpoint trim requires finite values")
    if maximum_step_rad <= 0.0 or maximum_bias_rad <= 0.0:
        raise ValueError("endpoint trim bounds must be positive")
    if maximum_step_rad > maximum_bias_rad:
        raise ValueError("endpoint trim step cannot exceed total bias limit")
    requested_step = max(
        -maximum_step_rad,
        min(maximum_step_rad, -desired_error_rad),
    )
    return max(
        -maximum_bias_rad,
        min(maximum_bias_rad, current_bias_rad + requested_step),
    )


def trim_endpoint_j1(
    arm,
    model,
    desired_q,
    initial_hold,
    rear_down_deg,
    scale,
    correction_limits_nm,
    label,
    maximum_command_error_rad,
    maximum_desired_error_rad,
):
    """Apply a bounded outer-loop J1 trim after a settled endpoint hold."""
    summary = initial_hold
    bias = 0.0
    attempts = []
    failure = None

    for attempt in range(ENDPOINT_TRIM_MAX_ATTEMPTS + 1):
        desired_error = [
            summary["median_q_rad"][index] - desired_q[index]
            for index in range(6)
        ]
        if max(abs(value) for value in desired_error[1:]) > ENDPOINT_MAX_ERROR_RAD:
            failure = f"{label}: non-J1 endpoint error exceeds 0.01rad"
            break
        if abs(desired_error[0]) <= ENDPOINT_J1_TOLERANCE_RAD:
            break
        if attempt >= ENDPOINT_TRIM_MAX_ATTEMPTS:
            failure = (
                f"{label}: J1 endpoint error {desired_error[0]:+.5f}rad "
                f"remains above {ENDPOINT_J1_TOLERANCE_RAD:.3f}rad"
            )
            break

        previous_command_q = list(desired_q)
        previous_command_q[0] += bias
        next_bias = next_endpoint_trim_bias(bias, desired_error[0])
        if math.isclose(next_bias, bias, abs_tol=1e-12):
            failure = f"{label}: endpoint trim bias reached its hard limit"
            break
        bias = next_bias
        command_q = list(desired_q)
        command_q[0] += bias
        if not all(
            item["inside_hard_limit"] for item in joint_margin_details(command_q)
        ):
            failure = f"{label}: endpoint trim command exceeds a joint hard limit"
            break

        trace, hold_failure = compensated_hold(
            arm,
            model,
            command_q,
            rear_down_deg,
            scale,
            correction_limits_nm,
            duration_s=ENDPOINT_TRIM_HOLD_SECONDS,
            ramp_s=ENDPOINT_SETTLE_SECONDS,
            label=f"{label}_attempt_{attempt + 1}",
            initial_scale=scale,
            command_start_q=previous_command_q,
            guard_desired_q=desired_q,
            maximum_command_error_rad=maximum_command_error_rad,
            maximum_desired_error_rad=maximum_desired_error_rad,
            maximum_non_j1_error_rad=maximum_desired_error_rad,
        )
        desired_error_after = [
            trace["median_q_rad"][index] - desired_q[index]
            for index in range(6)
        ]
        attempts.append(
            {
                "attempt": attempt + 1,
                "command_bias_j1_rad": bias,
                "command_q_rad": command_q,
                "desired_error_before_rad": desired_error,
                "desired_error_after_rad": desired_error_after,
                "hold_trace": trace,
            }
        )
        print(
            f"{label.upper()}_TRIM attempt={attempt + 1} "
            f"bias={bias:+.6f}rad "
            f"J1_error={desired_error_after[0]:+.6f}rad"
        )
        summary = trace
        if hold_failure:
            failure = hold_failure
            break

    final_error = [
        summary["median_q_rad"][index] - desired_q[index]
        for index in range(6)
    ]
    return {
        "label": label,
        "desired_q_rad": list(desired_q),
        "attempt_count": len(attempts),
        "final_command_bias_j1_rad": bias,
        "final_median_q_rad": list(summary["median_q_rad"]),
        "final_desired_error_rad": final_error,
        "j1_tolerance_rad": ENDPOINT_J1_TOLERANCE_RAD,
        "maximum_step_rad": ENDPOINT_TRIM_STEP_RAD,
        "maximum_bias_rad": ENDPOINT_TRIM_MAX_BIAS_RAD,
        "maximum_command_error_rad": maximum_command_error_rad,
        "maximum_desired_error_rad": maximum_desired_error_rad,
        "attempts": attempts,
        "failure": failure,
        "passed": failure is None and abs(final_error[0]) <= ENDPOINT_J1_TOLERANCE_RAD,
    }, failure


def send_compensated_position(
    arm,
    model,
    target_q,
    measured_q,
    rear_down_deg,
    scale,
    correction_limits_nm,
):
    measured = finite_vector(measured_q, 6, "measured_q")
    target = finite_vector(target_q, 6, "target_q")
    vendor_gravity = finite_vector(
        arm._arm.motor.gravity(list(measured)), 6, "vendor_gravity"
    )
    snapshot = correction_snapshot(
        model,
        measured,
        rear_down_deg,
        scale,
        correction_limits_nm,
    )
    command_tau = [
        vendor_gravity[index] + snapshot["applied_nm"][index]
        for index in range(6)
    ]
    arm._arm.motor.control_pos(list(target), list(command_tau))
    return {
        **snapshot,
        "vendor_gravity_nm": vendor_gravity,
        "command_tau_nm": command_tau,
    }


def compensated_hold(
    arm,
    model,
    target_q,
    rear_down_deg,
    requested_scale,
    correction_limits_nm,
    duration_s,
    ramp_s,
    label,
    initial_scale=0.0,
    command_start_q=None,
    guard_desired_q=None,
    maximum_command_error_rad=None,
    maximum_desired_error_rad=None,
    maximum_non_j1_error_rad=None,
):
    if not 0.0 <= initial_scale <= requested_scale <= 1.0:
        raise ValueError("hold compensation scales are invalid")
    if not math.isfinite(ramp_s) or ramp_s <= 0.0:
        raise ValueError("hold ramp duration must be positive and finite")
    trim_guard_enabled = guard_desired_q is not None
    trim_guard_values = (
        maximum_command_error_rad,
        maximum_desired_error_rad,
        maximum_non_j1_error_rad,
    )
    if trim_guard_enabled:
        if command_start_q is None or any(value is None for value in trim_guard_values):
            raise ValueError("endpoint trim hold requires complete guard inputs")
        command_start_q = finite_vector(command_start_q, 6, "command_start_q")
        guard_desired_q = finite_vector(guard_desired_q, 6, "guard_desired_q")
    elif command_start_q is not None or any(value is not None for value in trim_guard_values):
        raise ValueError("endpoint trim hold guard inputs must be supplied together")
    started = time.monotonic()
    samples = []
    temperature = finite_vector(arm.get_temp(), 7, "temperature")
    measured_tau = finite_vector(arm.get_tau(), 7, "measured_tau")[:6]
    failure = None
    cycle = 0
    while True:
        cycle_started = time.monotonic()
        elapsed = cycle_started - started
        ramp_progress = min(1.0, elapsed / ramp_s)
        scale = initial_scale + (
            requested_scale - initial_scale
        ) * ramp_progress
        command_target = list(target_q)
        if trim_guard_enabled:
            command_target = [
                command_start_q[index]
                + ramp_progress * (target_q[index] - command_start_q[index])
                for index in range(6)
            ]
        position = finite_vector(arm.get_pos(), 7, "position")[:6]
        command = send_compensated_position(
            arm,
            model,
            command_target,
            position,
            rear_down_deg,
            scale,
            correction_limits_nm,
        )
        velocity = finite_vector(arm.get_vel(), 7, "velocity")[:6]
        if cycle % 5 == 0:
            temperature = finite_vector(arm.get_temp(), 7, "temperature")
            measured_tau = finite_vector(arm.get_tau(), 7, "measured_tau")[:6]
        error = [position[i] - command_target[i] for i in range(6)]
        sample = {
            "elapsed_s": elapsed,
            "effective_scale": scale,
            "command_target_q_rad": command_target,
            "position_q_rad": position,
            "velocity_rad_s": velocity,
            "error_rad": error,
            "measured_tau_nm": measured_tau,
            **command,
        }
        if trim_guard_enabled:
            sample["desired_error_rad"] = [
                position[index] - guard_desired_q[index] for index in range(6)
            ]
        samples.append(sample)
        if trim_guard_enabled:
            bad = guard_endpoint_trim(
                arm,
                position,
                velocity,
                temperature,
                command_target,
                guard_desired_q,
                maximum_command_error_rad,
                maximum_desired_error_rad,
                maximum_non_j1_error_rad,
                settling=elapsed < ramp_s,
            )
        else:
            bad = arm.guard(
                position,
                velocity,
                temperature,
                target_q,
                settling=elapsed < ramp_s,
            )
        if bad:
            failure = f"{label}: {bad}"
            break
        if command["clipped"]:
            failure = f"{label}: requested correction reached a hard cap"
            break
        if elapsed >= duration_s:
            break
        cycle += 1
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))

    evaluation = [
        sample for sample in samples if sample["elapsed_s"] >= ramp_s
    ] or [samples[-1]]
    median_q = [
        statistics.median(sample["position_q_rad"][joint] for sample in evaluation)
        for joint in range(6)
    ]
    return {
        "label": label,
        "sample_count": len(samples),
        "median_q_rad": median_q,
        "final_error_rad": [median_q[i] - target_q[i] for i in range(6)],
        "maximum_track_error_rad": max(
            abs(value) for sample in samples for value in sample["error_rad"]
        ),
        "temperature_c": temperature,
        "failure": failure,
        "samples": samples,
    }, failure


def compensated_move(
    arm,
    model,
    q_from,
    q_to,
    rear_down_deg,
    scale,
    correction_limits_nm,
    label,
    maximum_track_error_rad,
):
    limits = arm.limits
    delta = max(abs(a - b) for a, b in zip(q_from, q_to))
    duration = motion_duration_s(
        delta, limits.v_max_rad_s, limits.motion_profile
    )
    trajectory_time = 0.0
    wall_started = time.monotonic()
    temperature = finite_vector(arm.get_temp(), 7, "temperature")
    measured_tau = finite_vector(arm.get_tau(), 7, "measured_tau")[:6]
    samples = []
    failure = None
    cycle = 0
    while True:
        cycle_started = time.monotonic()
        progress = motion_profile_progress(
            min(1.0, trajectory_time / duration), limits.motion_profile
        )
        target = [
            q_from[index] + progress * (q_to[index] - q_from[index])
            for index in range(6)
        ]
        position = finite_vector(arm.get_pos(), 7, "position")[:6]
        command = send_compensated_position(
            arm,
            model,
            target,
            position,
            rear_down_deg,
            scale,
            correction_limits_nm,
        )
        velocity = finite_vector(arm.get_vel(), 7, "velocity")[:6]
        if cycle % 5 == 0:
            temperature = finite_vector(arm.get_temp(), 7, "temperature")
            measured_tau = finite_vector(arm.get_tau(), 7, "measured_tau")[:6]
        error = [position[i] - target[i] for i in range(6)]
        samples.append(
            {
                "wall_elapsed_s": time.monotonic() - wall_started,
                "trajectory_time_s": trajectory_time,
                "progress": progress,
                "target_q_rad": target,
                "position_q_rad": position,
                "velocity_rad_s": velocity,
                "error_rad": error,
                "measured_tau_nm": measured_tau,
                **command,
            }
        )
        bad = guard_tilt_motion(
            arm,
            position,
            velocity,
            temperature,
            target,
            maximum_track_error_rad,
        )
        if bad:
            failure = f"{label}: {bad}"
            break
        if command["clipped"]:
            failure = f"{label}: requested correction reached a hard cap"
            break
        if trajectory_time >= duration:
            break
        trajectory_time = min(duration, trajectory_time + arm.dt)
        cycle += 1
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    return {
        "label": label,
        "planned_duration_s": duration,
        "sample_count": len(samples),
        "failure": failure,
        "samples": samples,
    }, failure


def print_snapshot(snapshot: dict) -> None:
    print(
        "TILT_DIFFERENTIAL_NM =",
        [round(value, 6) for value in snapshot["differential_nm"]],
    )
    print(
        "REQUESTED_CORRECTION_NM =",
        [round(value, 6) for value in snapshot["requested_nm"]],
    )
    print(
        "APPLIED_CORRECTION_NM =",
        [round(value, 6) for value in snapshot["applied_nm"]],
    )
    print("CORRECTION_CLIPPED =", snapshot["clipped"])


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    config_path = args.config.expanduser().resolve()
    config = load_configuration(config_path)
    scale = resolve_scale(args, config)
    mount = config["mount_measurement"]
    diagnostic = config["diagnostic"]
    rear_down_deg = float(mount["rear_edge_lower_deg"])
    correction_limits = [
        float(value) for value in diagnostic["correction_absolute_limits_nm"]
    ]
    if (
        not math.isfinite(args.j1_delta_rad)
        or not 0.0 < args.j1_delta_rad <= MAX_J1_DIAGNOSTIC_DELTA_RAD
    ):
        raise ValueError(
            "--j1-delta-rad must be in "
            f"(0, {MAX_J1_DIAGNOSTIC_DELTA_RAD}]"
        )
    if not math.isfinite(args.v_max_rad_s) or not 0.0 < args.v_max_rad_s <= 0.08:
        raise ValueError("--v-max-rad-s must be in (0, 0.08]")
    static_track_error_limit = float(diagnostic["maximum_track_error_rad"])
    if (
        not math.isfinite(args.max_motion_track_error_rad)
        or not static_track_error_limit <= args.max_motion_track_error_rad <= 0.03
    ):
        raise ValueError(
            "--max-motion-track-error-rad must be between the configured "
            f"static limit {static_track_error_limit} and 0.03"
        )
    if (
        not math.isfinite(args.min_observed_j1_ratio)
        or not 0.0 < args.min_observed_j1_ratio <= 1.0
    ):
        raise ValueError("--min-observed-j1-ratio must be in (0, 1]")
    if args.lock_sample_count < 10:
        raise ValueError("--lock-sample-count must be at least 10")

    urdf_path = locate_official_gripper_urdf()
    model = UrdfGravityModel.from_file(urdf_path)
    preview = correction_snapshot(
        model,
        REFERENCE_FAILED_Q,
        rear_down_deg,
        scale,
        correction_limits,
    )
    print("MODE = tilt-gravity-" + args.mode)
    print("CAMERA_ACCESS = False")
    print("GRIPPER_COMMANDS = False")
    print("OFFICIAL_SDK_FILES_MODIFIED = False")
    print("CONFIG =", config_path)
    print("URDF =", urdf_path)
    print("URDF_TOTAL_MASS_KG =", round(model.total_mass_kg, 6))
    print("BASE_FRAME = +x Go2 rear/S1 front, +y Go2 right, +z mount normal")
    print("MOUNT = Go2 rear/S1 front edge lower by", rear_down_deg, "deg")
    print("COMPENSATION_SCALE =", scale)
    print("STATIC_TRACK_ERROR_LIMIT_RAD =", static_track_error_limit)
    print("MOTION_TRACK_ERROR_LIMIT_RAD =", args.max_motion_track_error_rad)
    print("ENDPOINT_J1_TOLERANCE_RAD =", ENDPOINT_J1_TOLERANCE_RAD)
    print(
        "ENDPOINT_TRIM =",
        f"step<={ENDPOINT_TRIM_STEP_RAD}rad",
        f"bias<={ENDPOINT_TRIM_MAX_BIAS_RAD}rad",
        f"attempts<={ENDPOINT_TRIM_MAX_ATTEMPTS}",
    )
    print(
        "ENDPOINT_TRIM_GUARDS =",
        f"J1_command<={args.max_motion_track_error_rad}rad",
        f"J1_desired/non_J1<={static_track_error_limit}rad",
    )
    print("REFERENCE_FAILED_Q =", REFERENCE_FAILED_Q)
    print_snapshot(preview)
    print("PAYLOAD_NOT_MODELLED = D455 and printed bracket")
    if not args.execute:
        print("OFFLINE_ONLY：未构造Arm、未访问串口、未使能机械臂。")
        return 0

    print("\n实机条件：Go2保持当前已测6度的稳定趴下姿态；")
    print("机械臂常红、持续人工托住并有软支撑，D455线束和运动范围无干涉。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("CANCELLED_BEFORE_ARM_ACCESS")
        return 1

    run_id = args.run_id or datetime.now().strftime("tilt_%Y%m%d-%H%M%S")
    run_dir = args.output_root.expanduser().resolve() / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    run_dir.mkdir(parents=True)
    output_path = run_dir / "run.json"
    record = {
        "schema_version": 1,
        "mode": "tilt-gravity-" + args.mode,
        "run_id": run_id,
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "config": config,
        "config_path": str(config_path),
        "urdf_path": str(urdf_path),
        "urdf_total_mass_kg": model.total_mass_kg,
        "compensation_scale": scale,
        "static_track_error_limit_rad": static_track_error_limit,
        "motion_track_error_limit_rad": args.max_motion_track_error_rad,
        "endpoint_trim": {
            "j1_tolerance_rad": ENDPOINT_J1_TOLERANCE_RAD,
            "maximum_endpoint_error_rad": ENDPOINT_MAX_ERROR_RAD,
            "maximum_step_rad": ENDPOINT_TRIM_STEP_RAD,
            "maximum_bias_rad": ENDPOINT_TRIM_MAX_BIAS_RAD,
            "maximum_attempts": ENDPOINT_TRIM_MAX_ATTEMPTS,
            "maximum_command_error_rad": args.max_motion_track_error_rad,
            "maximum_desired_error_rad": static_track_error_limit,
            "maximum_non_j1_error_rad": static_track_error_limit,
        },
        "preview_at_previous_failure": preview,
        "result": "STARTED",
    }
    arm = None
    return_code = 1
    try:
        limits = SafetyLimits(
            hz=float(diagnostic["control_hz"]),
            v_max_rad_s=args.v_max_rad_s,
            j6_v_max_rad_s=args.v_max_rad_s,
            motion_profile="s_curve",
            max_track_err_rad=float(diagnostic["maximum_track_error_rad"]),
            max_speed_rad_s=float(diagnostic["maximum_speed_rad_s"]),
            max_temp_c=float(diagnostic["maximum_temperature_c"]),
            max_joint_delta_rad=MAX_J1_DIAGNOSTIC_DELTA_RAD,
            settle_seconds=1.0,
        )
        # teaching_until_locked() is shared with the established diagnostic
        # and reads this explicit Namespace field.
        args.max_temp_c = limits.max_temp_c
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=limits,
            check_collision=False,
        )
        connected_q, connected_temperature, startup = wait_for_valid_feedback(
            arm, limits.max_temp_c
        )
        record["startup_feedback"] = startup
        print("STARTUP_FEEDBACK_READY =", startup["ready"])
        print("CONNECTED_Q =", [round(value, 6) for value in connected_q])
        print(
            "CONNECTED_TEMPERATURE_C =",
            [round(value, 1) for value in connected_temperature],
        )
        if input("确认继续托稳且示教范围无碰撞，输入 e：").strip().lower() != "e":
            record["result"] = "CANCELLED_BEFORE_TEACHING"
            raise KeyboardInterrupt

        arm.enable()
        arm.gravity()
        q_lock, teach_lock = teaching_until_locked(arm, args)
        if q_lock is None:
            record["result"] = "CANCELLED_DURING_TEACHING"
            raise KeyboardInterrupt
        record["teach_lock"] = teach_lock
        lock_snapshot = correction_snapshot(
            model, q_lock, rear_down_deg, scale, correction_limits
        )
        print("LOCKED_Q =", [round(value, 6) for value in q_lock])
        print_snapshot(lock_snapshot)
        if lock_snapshot["clipped"]:
            raise RuntimeError("locked-pose correction exceeds a hard cap")

        if args.mode == "j1-motion":
            kinematics = Kinematics(verbose=True)
            preview_target = build_tilt_j1_target(q_lock, args.j1_delta_rad)
            margins = joint_margin_details(preview_target)
            minimum_margin = min(item["margin_deg"] for item in margins)
            reference_tcp = finite_vector(kinematics.fk(q_lock), 7, "reference_tcp")
            target_tcp = finite_vector(kinematics.fk(preview_target), 7, "target_tcp")
            cartesian = tcp_delta_mm(reference_tcp, target_tcp)
            if minimum_margin < args.min_joint_margin_deg:
                raise RuntimeError("preview target has insufficient joint margin")
            if cartesian["norm_mm"] > args.max_tcp_displacement_mm:
                raise RuntimeError("preview target exceeds TCP displacement limit")
            if abs(cartesian["z_change_mm"]) > args.max_tcp_z_change_mm:
                raise RuntimeError("preview target exceeds TCP z-change limit")
            record["preview_target_q_rad"] = preview_target
            record["preview_tcp_delta"] = cartesian
            print("PREVIEW_TCP_DELTA_MM =", [round(v, 3) for v in cartesian["xyz_mm"]])

        print("本次先平滑加入差分力矩；错误方向、漂移、超速或超温均会中止。")
        if input("确认持续托住且软支撑不限制微小运动，输入 e：").strip().lower() != "e":
            record["result"] = "CANCELLED_BEFORE_COMPENSATION"
            raise KeyboardInterrupt

        start_summary = read_motion_start(arm)
        q_start = list(start_summary["median_q_rad"])
        drift = [q_start[i] - q_lock[i] for i in range(6)]
        if start_summary["maximum_span_rad"] > MOTION_START_MAX_SPAN_RAD:
            raise RuntimeError("pre-compensation feedback is not stationary")
        if max(abs(value) for value in drift) > MOTION_START_MAX_DRIFT_RAD:
            raise RuntimeError("pre-compensation pose drift exceeds limit")
        record["compensation_start_sampling"] = start_summary
        record["compensation_start_q_rad"] = q_start
        record["compensation_start_drift_rad"] = drift
        print("COMPENSATION_START_Q =", [round(value, 6) for value in q_start])

        hold_trace, failure = compensated_hold(
            arm,
            model,
            q_start,
            rear_down_deg,
            scale,
            correction_limits,
            duration_s=float(diagnostic["hold_seconds"]),
            ramp_s=float(diagnostic["ramp_seconds"]),
            label="compensation_hold",
        )
        record["compensation_hold"] = hold_trace
        if failure:
            raise RuntimeError(failure)
        print(
            "COMPENSATION_HOLD_FINAL_ERROR_RAD =",
            [round(value, 6) for value in hold_trace["final_error_rad"]],
        )
        print("COMPENSATION_HOLD_OK = True")

        if args.mode == "hold":
            record["result"] = "TILT_COMPENSATION_HOLD_DONE"
            print("DIAGNOSTIC_STATUS = TILT_COMPENSATION_HOLD_OK")
            return_code = 0
        else:
            q_target = build_tilt_j1_target(q_start, args.j1_delta_rad)
            kinematics = Kinematics(verbose=False)
            start_tcp = finite_vector(kinematics.fk(q_start), 7, "start_tcp")
            target_tcp = finite_vector(kinematics.fk(q_target), 7, "target_tcp")
            cartesian = tcp_delta_mm(start_tcp, target_tcp)
            margins = joint_margin_details(q_target)
            minimum_margin = min(item["margin_deg"] for item in margins)
            if minimum_margin < args.min_joint_margin_deg:
                raise RuntimeError("rebased target has insufficient joint margin")
            if cartesian["norm_mm"] > args.max_tcp_displacement_mm:
                raise RuntimeError("rebased target exceeds TCP displacement limit")
            if abs(cartesian["z_change_mm"]) > args.max_tcp_z_change_mm:
                raise RuntimeError("rebased target exceeds TCP z-change limit")
            record["motion_start_q_rad"] = q_start
            record["target_q_rad"] = q_target
            record["rebased_tcp_delta"] = cartesian
            print("TARGET_Q =", [round(value, 6) for value in q_target])
            print("REBASED_TCP_DELTA_MM =", [round(v, 3) for v in cartesian["xyz_mm"]])
            print("ENABLED：开始带倾角补偿的J1小范围往返。")

            outbound, failure = compensated_move(
                arm,
                model,
                q_start,
                q_target,
                rear_down_deg,
                scale,
                correction_limits,
                "start->j1_target",
                args.max_motion_track_error_rad,
            )
            record["outbound_trace"] = outbound
            if failure:
                raise RuntimeError(failure)
            target_hold, failure = compensated_hold(
                arm,
                model,
                q_target,
                rear_down_deg,
                scale,
                correction_limits,
                duration_s=0.8,
                ramp_s=ENDPOINT_SETTLE_SECONDS,
                label="target_hold",
                initial_scale=scale,
            )
            record["target_hold"] = target_hold
            if failure:
                raise RuntimeError(failure)
            target_error = max(
                abs(a - b) for a, b in zip(target_hold["median_q_rad"], q_target)
            )
            if target_error > ENDPOINT_MAX_ERROR_RAD:
                raise RuntimeError(f"target median error {target_error:.5f}rad")
            target_trim, failure = trim_endpoint_j1(
                arm,
                model,
                q_target,
                target_hold,
                rear_down_deg,
                scale,
                correction_limits,
                "target_endpoint",
                args.max_motion_track_error_rad,
                static_track_error_limit,
            )
            record["target_endpoint_trim"] = target_trim
            if failure:
                raise RuntimeError(failure)
            target_final_q = target_trim["final_median_q_rad"]
            target_error = max(
                abs(value) for value in target_trim["final_desired_error_rad"]
            )

            return_trace, failure = compensated_move(
                arm,
                model,
                target_final_q,
                q_start,
                rear_down_deg,
                scale,
                correction_limits,
                "j1_target->start",
                args.max_motion_track_error_rad,
            )
            record["return_trace"] = return_trace
            if failure:
                raise RuntimeError(failure)
            return_hold, failure = compensated_hold(
                arm,
                model,
                q_start,
                rear_down_deg,
                scale,
                correction_limits,
                duration_s=0.8,
                ramp_s=ENDPOINT_SETTLE_SECONDS,
                label="return_hold",
                initial_scale=scale,
            )
            record["return_hold"] = return_hold
            if failure:
                raise RuntimeError(failure)
            return_error = max(
                abs(a - b) for a, b in zip(return_hold["median_q_rad"], q_start)
            )
            if return_error > ENDPOINT_MAX_ERROR_RAD:
                raise RuntimeError(f"return median error {return_error:.5f}rad")
            return_trim, failure = trim_endpoint_j1(
                arm,
                model,
                q_start,
                return_hold,
                rear_down_deg,
                scale,
                correction_limits,
                "return_endpoint",
                args.max_motion_track_error_rad,
                static_track_error_limit,
            )
            record["return_endpoint_trim"] = return_trim
            if failure:
                raise RuntimeError(failure)
            return_final_q = return_trim["final_median_q_rad"]
            return_error = max(
                abs(value) for value in return_trim["final_desired_error_rad"]
            )
            observed_delta = (
                target_final_q[0]
                - return_final_q[0]
            )
            motion_observation = evaluate_observed_j1_motion(
                q_target[0] - q_start[0],
                target_final_q[0],
                return_final_q[0],
                args.min_observed_j1_ratio,
            )
            record["observed_j1_delta_rad"] = observed_delta
            record["j1_motion_observation"] = motion_observation
            record["target_median_error_rad"] = target_error
            record["return_median_error_rad"] = return_error
            print("OBSERVED_J1_DELTA_RAD =", round(observed_delta, 6))
            print(
                "OBSERVED_J1_RATIO =",
                round(motion_observation["observed_ratio"], 3),
                "minimum =",
                round(motion_observation["minimum_ratio"], 3),
            )
            print("TARGET_MEDIAN_ERROR_RAD =", round(target_error, 6))
            print("RETURN_MEDIAN_ERROR_RAD =", round(return_error, 6))
            if not motion_observation["direction_ok"]:
                raise RuntimeError("observed J1 motion has the wrong direction")
            if not motion_observation["passed"]:
                raise RuntimeError(
                    "observed J1 motion ratio "
                    f"{motion_observation['observed_ratio']:.3f} is below "
                    f"{motion_observation['minimum_ratio']:.3f}"
                )
            record["result"] = "TILT_COMPENSATED_J1_ROUND_TRIP_DONE"
            print("DIAGNOSTIC_STATUS = TILT_COMPENSATED_J1_MOTION_OK")
            return_code = 0
    except KeyboardInterrupt:
        if record["result"] == "STARTED":
            record["result"] = "CANCELLED"
        print("CANCELLED")
    except Exception as exc:
        record["result"] = f"ABORTED: {type(exc).__name__}: {exc}"
        record["error"] = repr(exc)
        print(record["result"])
    finally:
        if arm is not None:
            try:
                arm.disable()
                print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
            except Exception as exc:
                record["disable_error"] = repr(exc)
                print("DISABLE_FAILED:", repr(exc))
        record["finished_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
        output_path.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print("LOG_SAVED =", output_path)
        print("RESULT =", record["result"])
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
