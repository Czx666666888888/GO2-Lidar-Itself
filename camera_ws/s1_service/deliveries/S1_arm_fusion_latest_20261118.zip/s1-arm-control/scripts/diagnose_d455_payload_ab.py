#!/usr/bin/env python3
"""Supervised 0/0.5 D455 payload-compensation A/B at right_observe.

This diagnostic never performs visual alignment, descent, gripper motion,
lifting or box placement.  The new payload term is ramped back to zero before
the already-validated deployment path is reversed.  Its result is evidence,
not permission to enable payload compensation in the full grasp workflow.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import sys
import time

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SCRIPTS_DIR, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from execute_go2_observe_deployment import (  # noqa: E402
    guarded_hold,
    planned_phases,
    ramp_compensation_scale,
    wait_for_valid_feedback,
    write_json,
)
from run_go2_visual_alignment import (  # noqa: E402
    ObservationEndpointConvergenceError,
    check_collision_path,
    compute_observation,
    converge_observation_endpoint,
    endpoint_tracking_record,
    load_alignment_config,
    load_bound_deployment_source,
    load_detector_config,
    run_capture_process_while_holding,
)
from s1_control.arm import Arm, SafetyLimits  # noqa: E402
from s1_control.go2_deployment import (  # noqa: E402
    file_sha256,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)
from s1_control.kinematics import Kinematics  # noqa: E402
from s1_control.tilt_gravity import (  # noqa: E402
    UrdfGravityModel,
    gravity_vector_base_from_support_up,
    gravity_vector_base_rear_down,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record  # noqa: E402
from s1_control.wrist_visual_servo import load_wrist_servo_config  # noqa: E402


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "go2_crouch_right_visual_alignment.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "d455_payload_ab_runs"


def resolve_project_path(raw: str | Path) -> Path:
    path = Path(raw).expanduser()
    return path.resolve() if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def payload_center_in_link(transform_link_camera, center_camera_m) -> np.ndarray:
    transform = np.asarray(transform_link_camera, dtype=float)
    center = np.asarray(center_camera_m, dtype=float)
    if transform.shape != (4, 4) or not np.all(np.isfinite(transform)):
        raise ValueError("T_link_camera must be a finite 4x4 transform")
    if center.shape != (3,) or not np.all(np.isfinite(center)):
        raise ValueError("payload camera-frame center must contain three values")
    return (transform @ np.r_[center, 1.0])[:3]


def ramp_payload_scale(
    arm,
    commander,
    target_q,
    *,
    start_scale: float,
    end_scale: float,
    duration_s: float,
    label: str,
) -> dict:
    """Smoothly change only the external-payload term while holding position."""
    values = [float(start_scale), float(end_scale), float(duration_s)]
    if not all(math.isfinite(value) for value in values):
        raise ValueError(f"{label}: non-finite payload transition")
    start_scale, end_scale, duration_s = values
    if not 0.0 <= start_scale <= 1.0 or not 0.0 <= end_scale <= 1.0:
        raise ValueError(f"{label}: payload scales must be within [0, 1]")
    if duration_s <= 0.0:
        raise ValueError(f"{label}: duration must be positive")
    if not math.isclose(commander.payload_scale, start_scale, abs_tol=1e-9):
        raise RuntimeError(
            f"{label}: current payload scale {commander.payload_scale:.3f} "
            f"does not match {start_scale:.3f}"
        )
    started = time.monotonic()
    next_tick = started
    maximum_track_error = 0.0
    sample_count = 0
    while True:
        elapsed = time.monotonic() - started
        u = min(1.0, max(0.0, elapsed / duration_s))
        smooth = u * u * (3.0 - 2.0 * u)
        commander.set_payload_scale(
            start_scale + (end_scale - start_scale) * smooth
        )
        arm.command_position(target_q)
        snapshot = commander.last_snapshot or {}
        measured = [float(value) for value in snapshot.get("measured_q_rad", [])]
        if len(measured) != 6:
            measured = [float(value) for value in arm.get_pos()[:6]]
        maximum_track_error = max(
            maximum_track_error,
            max(abs(actual - target) for actual, target in zip(measured, target_q)),
        )
        fault = arm.guard(
            measured, arm.get_vel(), arm.get_temp(), list(target_q), settling=False
        )
        if fault:
            raise RuntimeError(f"{label}: {fault}")
        sample_count += 1
        if u >= 1.0:
            break
        next_tick += arm.dt
        time.sleep(max(0.0, next_tick - time.monotonic()))
    commander.set_payload_scale(end_scale)
    return {
        "label": label,
        "start_scale": start_scale,
        "end_scale": end_scale,
        "requested_duration_s": duration_s,
        "actual_duration_s": time.monotonic() - started,
        "sample_count": sample_count,
        "maximum_track_error_rad": maximum_track_error,
        "final_commander_snapshot": commander.last_snapshot,
    }


def comparison_record(
    command_q,
    a_q,
    b_q,
    a_observation,
    b_observation,
    kinematics,
    *,
    condition_b_payload_scale: float = 0.5,
):
    a_tracking = endpoint_tracking_record(command_q, a_q, kinematics)
    b_tracking = endpoint_tracking_record(command_q, b_q, kinematics)
    a_tilt = float(a_observation["camera_tilt_from_support_down_deg"])
    b_tilt = float(b_observation["camera_tilt_from_support_down_deg"])
    return {
        "condition_a_payload_scale": 0.0,
        "condition_b_payload_scale": float(condition_b_payload_scale),
        "condition_a_tracking": a_tracking,
        "condition_b_tracking": b_tracking,
        "condition_a_camera_tilt_from_support_down_deg": a_tilt,
        "condition_b_camera_tilt_from_support_down_deg": b_tilt,
        "maximum_joint_error_change_b_minus_a_rad": (
            b_tracking["maximum_abs_joint_error_rad"]
            - a_tracking["maximum_abs_joint_error_rad"]
        ),
        "tcp_error_change_b_minus_a_mm": (
            b_tracking["tcp_error_norm_mm"] - a_tracking["tcp_error_norm_mm"]
        ),
        "camera_tilt_change_b_minus_a_deg": b_tilt - a_tilt,
        "automatic_enable_decision": False,
        "interpretation": (
            "Negative B-minus-A values indicate improvement. Review physical "
            "motion and logs before changing the full alignment default."
        ),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Go2右侧观察位：D455 77g点质量补偿0/0.5监督A/B诊断"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--run-id")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)

    config_path, config = load_alignment_config(args.config)
    plan_path = resolve_project_path(config["deployment_plan"])
    report_path = resolve_project_path(config["deployment_collision_report"])
    wrist_path = resolve_project_path(config["wrist_servo_config"])
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    _, deployment_source = load_bound_deployment_source(plan)
    mount_path = resolve_project_path(plan["mount_config"])
    mount_record = json.loads(mount_path.read_text(encoding="utf-8"))
    report = verify_bound_report(plan_path, report_path, mount_path)
    loaded = load_wrist_servo_config(wrist_path)
    if loaded.mount_config_path != mount_path:
        raise RuntimeError("deployment and wrist alignment use different mount records")

    waypoints = plan["joint_path"]
    if waypoints[-1]["name"] != "right_observe":
        raise RuntimeError("deployment plan must terminate at right_observe")
    deployment_motion = plan["motion"]
    tilt_schedule = deployment_motion["tilt_compensation"]
    tilt_config = loaded.record["tilt_compensation"]
    runtime = config["runtime"]
    endpoint_config = dict(config["observation_endpoint_convergence"])
    endpoint_config["validated_workspace"] = dict(loaded.record["validated_workspace"])
    payload = config["d455_payload"]
    payload_scale = float(payload["ab_scale"])
    payload_com_link = payload_center_in_link(
        loaded.transform_flange_camera,
        payload["center_of_mass_camera_m"],
    )
    observation_safety = dict(loaded.record["safety"])
    observation_safety["maximum_camera_tilt_from_down_deg"] = float(
        config["geometry_quality_override"]["maximum_camera_tilt_from_down_deg"]
    )
    maximum_segment_delta_rad = float(
        deployment_source["safety"]["maximum_segment_delta_rad"]
    )

    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    q_observe = [float(value) for value in waypoints[-1]["q"]]
    nominal_support_up = -gravity_vector_base_rear_down(
        float(mount_record["mount_measurement"]["rear_edge_lower_deg"])
    ) / 9.81
    payload_full = tilt_model.point_mass_gravity_compensation(
        q_observe,
        gravity_vector_base_from_support_up(nominal_support_up),
        link_name=str(payload["attachment_link"]),
        mass_kg=float(payload["mass_kg"]),
        center_of_mass_link_m=payload_com_link,
    )
    payload_requested = payload_scale * payload_full
    payload_limits = np.asarray(payload["maximum_correction_nm"], dtype=float)
    if np.any(np.abs(payload_requested) > payload_limits + 1e-12):
        raise RuntimeError("offline payload torque prediction exceeds configured cap")

    print("MODE = D455_PAYLOAD_COMPENSATION_AB")
    print("CONFIG =", config_path)
    print("PLAN_SHA256 =", file_sha256(plan_path))
    print("COLLISION_REPORT_VERIFIED = True")
    print("D455_MASS_KG =", float(payload["mass_kg"]))
    print("PAYLOAD_COM_GRIPPER_M =", payload_com_link.tolist())
    print("PAYLOAD_SCALE_A_B =", [0.0, payload_scale])
    print("PAYLOAD_HALF_SCALE_PREDICTION_NM =", payload_requested.tolist())
    print("FULL_ALIGNMENT_PAYLOAD_DEFAULT = disabled")
    print("FORBIDDEN = visual-alignment, descent, gripper-close, lift, box-place")
    print("UNMODELLED_EXTERNAL_OBSTACLES =", report["unmodelled_external_obstacles"])

    if not args.execute:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("CAMERA_ACCESS = False")
        print("RESULT = PAYLOAD_AB_OFFLINE_PREFLIGHT_OK")
        return 0

    print("\n本次仅在已验证右侧观察位比较负载补偿0与0.5；不进行中心对准或抓取。")
    print("Go2必须趴下且静止，500g配重、D455、线束和单个目标保持当前构型。")
    if input("确认路径净空、软支撑不阻挡且可随时急停，输入 e：").strip().lower() != "e":
        print("RESULT = CANCELLED_BEFORE_CONNECTION")
        return 2

    run_id = args.run_id or datetime.now().strftime("payload_ab_%Y%m%d-%H%M%S")
    run_dir = DEFAULT_OUTPUT_ROOT / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": "d455_payload_compensation_ab",
        "status": "started",
        "config_sha256": file_sha256(config_path),
        "plan_sha256": file_sha256(plan_path),
        "candidate_sha256": file_sha256(loaded.candidate_path),
        "payload_config": payload,
        "payload_center_of_mass_gripper_m": payload_com_link.tolist(),
        "payload_half_scale_prediction_nm": payload_requested.tolist(),
    }
    write_json(log_path, log)

    motion = config["motion"]
    limits = SafetyLimits(
        hz=float(motion["hz"]),
        v_max_rad_s=float(motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(motion["j6_v_max_rad_s"]),
        motion_profile=str(motion["profile"]),
        max_track_err_rad=float(motion["maximum_track_error_rad"]),
        max_speed_rad_s=float(motion["maximum_measured_speed_rad_s"]),
        max_temp_c=float(motion["maximum_temperature_c"]),
        max_joint_delta_rad=maximum_segment_delta_rad,
        settle_seconds=float(motion["settle_seconds"]),
    )
    from S1_SDK.hardware.collision import CollisionChecker

    collision_checker = CollisionChecker("gripper")
    if collision_checker.model is None:
        collision_checker._load_model(gripper=True)
    if collision_checker.model is None or collision_checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")
    tcp_kinematics = Kinematics(verbose=True)
    flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
    _, vision_config_path = load_detector_config(loaded.vision_config_path)
    vertical_scale = float(tilt_schedule["vertical_escape_scale"])
    side_scale = float(tilt_schedule["side_deploy_scale"])
    transition_s = float(tilt_schedule["scale_transition_s"])
    commander = commander_from_mount_record(
        tilt_model,
        mount_record,
        vertical_scale,
        maximum_support_tilt_deg=float(tilt_config["maximum_support_tilt_deg"]),
        maximum_support_normal_deviation_deg=float(
            tilt_config["maximum_support_normal_deviation_from_mount_deg"]
        ),
        support_normal_blend=float(tilt_config["support_normal_blend"]),
        normal_transition_s=float(tilt_config["normal_transition_s"]),
        payload_mass_kg=float(payload["mass_kg"]),
        payload_link_name=str(payload["attachment_link"]),
        payload_center_of_mass_link_m=payload_com_link,
        payload_scale=0.0,
        payload_correction_absolute_limits_nm=payload_limits,
    )

    arm = None
    enabled = False
    deployed = False
    phases = None
    observation_command_q = None
    result = "ABORTED"
    try:
        arm = Arm(dev=args.dev, end_effector="gripper", limits=limits, check_collision=False)
        arm.set_position_commander(commander)
        start_q, temperature, readiness = wait_for_valid_feedback(arm, limits.max_temp_c)
        violations = start_window_violations(start_q, plan["start_safe_windows_rad"])
        rear_ready = [float(value) for value in waypoints[1]["q"]]
        start_delta = max_joint_delta(start_q, rear_ready)
        live_ok = not violations and start_delta <= limits.max_joint_delta_rad
        print("STARTUP_FEEDBACK_READY =", readiness["ready"])
        print("START_Q =", [round(value, 6) for value in start_q])
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        print("START_SAFE_WINDOW_OK =", not violations)
        print("LIVE_PRECHECK_OK =", live_ok)
        log.update({"start_q": start_q, "startup_readiness": readiness})
        write_json(log_path, log)
        if not live_ok:
            result = "LIVE_PRECHECK_REJECTED"
            return 2
        arm.preflight(
            [(item["name"], item["q"]) for item in waypoints[1:]],
            start_q,
            collision_report_verified=True,
        )
        if input("确认实际净空仍满足，输入 d：").strip().lower() != "d":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        phases = planned_phases(start_q, waypoints, "right_observe")
        arm.enable()
        enabled = True
        guarded_hold(arm, start_q, 0.5, "initial_hold")
        for name, points in phases:
            if name == "side_deploy":
                ramp_compensation_scale(
                    arm, commander, points[0], start_scale=vertical_scale,
                    end_scale=side_scale, duration_s=transition_s,
                    label="right_ready_scale_up",
                )
            print("DEPLOY_PHASE =", name)
            fault = arm.move_waypoints(points, name)
            if fault:
                raise RuntimeError(fault)
        deployed = True
        q_observe = list(phases[-1][1][-1])
        guarded_hold(arm, q_observe, 1.0, "observation_hold")
        try:
            endpoint = converge_observation_endpoint(
                arm, q_observe, endpoint_config=endpoint_config,
                kinematics=tcp_kinematics, collision_checker=collision_checker,
                tilt_model=tilt_model,
                support_up_normal_base=commander.nominal_support_up_normal_base,
                compensation_scale=side_scale,
                torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
            )
        except ObservationEndpointConvergenceError as exc:
            log["observation_endpoint_convergence"] = exc.record
            write_json(log_path, log)
            raise
        log["observation_endpoint_convergence"] = endpoint
        observation_command_q = list(endpoint["final_command_q_rad"])
        write_json(log_path, log)

        setup_capture, setup_q = run_capture_process_while_holding(
            arm, observation_command_q, wrist_config_path=loaded.path,
            vision_config_path=vision_config_path, run_dir=run_dir,
            capture_label="setup", timeout_s=float(runtime["worker_timeout_s"]),
            label="payload_setup_capture", hold_hz=float(runtime["capture_hold_hz"]),
            velocity_guard_hz=float(runtime["capture_velocity_guard_hz"]),
            temperature_period_s=float(runtime["capture_temperature_period_s"]),
            camera_attempts=int(runtime["camera_attempts"]),
            camera_retry_delay_s=float(runtime["camera_retry_delay_s"]),
            capture_quality_override=dict(config["capture_quality_override"]),
        )
        setup_observation = compute_observation(
            setup_capture, setup_q, loaded=loaded,
            flange_kinematics=flange_kinematics,
            observation_safety=observation_safety,
        )["observation"]
        support_update = commander.set_support_up_normal(
            setup_observation["support_up_normal_base"],
            source="validated_support_plane:d455_payload_ab",
        )
        guarded_hold(
            arm, observation_command_q,
            float(tilt_config["normal_transition_s"]) + 0.25,
            "payload_ab_support_normal_transition",
        )

        a_capture, a_q = run_capture_process_while_holding(
            arm, observation_command_q, wrist_config_path=loaded.path,
            vision_config_path=vision_config_path, run_dir=run_dir,
            capture_label="payload_a_scale_0", timeout_s=float(runtime["worker_timeout_s"]),
            label="payload_condition_a_capture", hold_hz=float(runtime["capture_hold_hz"]),
            velocity_guard_hz=float(runtime["capture_velocity_guard_hz"]),
            temperature_period_s=float(runtime["capture_temperature_period_s"]),
            camera_attempts=int(runtime["camera_attempts"]),
            camera_retry_delay_s=float(runtime["camera_retry_delay_s"]),
            capture_quality_override=dict(config["capture_quality_override"]),
        )
        a_observation = compute_observation(
            a_capture, a_q, loaded=loaded, flange_kinematics=flange_kinematics,
            observation_safety=observation_safety,
        )["observation"]
        transition_up = ramp_payload_scale(
            arm, commander, observation_command_q, start_scale=0.0,
            end_scale=payload_scale, duration_s=float(payload["transition_s"]),
            label="payload_scale_up",
        )
        guarded_hold(arm, observation_command_q, float(payload["hold_s"]), "payload_b_hold")
        b_capture, b_q = run_capture_process_while_holding(
            arm, observation_command_q, wrist_config_path=loaded.path,
            vision_config_path=vision_config_path, run_dir=run_dir,
            capture_label="payload_b_scale_050", timeout_s=float(runtime["worker_timeout_s"]),
            label="payload_condition_b_capture", hold_hz=float(runtime["capture_hold_hz"]),
            velocity_guard_hz=float(runtime["capture_velocity_guard_hz"]),
            temperature_period_s=float(runtime["capture_temperature_period_s"]),
            camera_attempts=int(runtime["camera_attempts"]),
            camera_retry_delay_s=float(runtime["camera_retry_delay_s"]),
            capture_quality_override=dict(config["capture_quality_override"]),
        )
        b_observation = compute_observation(
            b_capture, b_q, loaded=loaded, flange_kinematics=flange_kinematics,
            observation_safety=observation_safety,
        )["observation"]
        comparison = comparison_record(
            observation_command_q, a_q, b_q, a_observation, b_observation,
            tcp_kinematics, condition_b_payload_scale=payload_scale,
        )
        log.update({
            "support_normal_update": support_update,
            "condition_a": {"capture": a_capture, "q_rad": a_q, "observation": a_observation},
            "payload_transition_up": transition_up,
            "condition_b": {"capture": b_capture, "q_rad": b_q, "observation": b_observation},
            "comparison": comparison,
        })
        write_json(log_path, log)
        print("PAYLOAD_AB_COMPARISON =", comparison)
        print("AUTOMATIC_FULL_ALIGNMENT_ENABLE = False")

        transition_down = ramp_payload_scale(
            arm, commander, observation_command_q, start_scale=payload_scale,
            end_scale=0.0, duration_s=float(payload["transition_s"]),
            label="payload_scale_down",
        )
        log["payload_transition_down"] = transition_down
        commander.set_support_up_normal(
            commander.nominal_support_up_normal_base,
            source="mount_record_pitch_only:payload_ab_return",
        )
        guarded_hold(
            arm, observation_command_q,
            float(tilt_config["normal_transition_s"]) + 0.25,
            "payload_ab_normal_restore",
        )
        current_q = [float(value) for value in arm.get_pos()[:6]]
        check_collision_path(
            collision_checker, [current_q, q_observe],
            float(endpoint_config["collision_step_rad"]),
        )
        fault = arm.move_waypoints([current_q, q_observe], "payload_ab_endpoint_return")
        if fault:
            raise RuntimeError(fault)
        for name, points in reversed(phases):
            fault = arm.move_waypoints(list(reversed(points)), f"{name}_return")
            if fault:
                raise RuntimeError(fault)
            if name == "side_deploy":
                ramp_compensation_scale(
                    arm, commander, points[0], start_scale=side_scale,
                    end_scale=vertical_scale, duration_s=transition_s,
                    label="right_ready_scale_down",
                )
        deployed = False
        result = "PAYLOAD_AB_CAPTURED_PENDING_REVIEW"
        return 0
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        print(result)
        if arm is not None and enabled and deployed and phases is not None:
            try:
                current_q = [float(value) for value in arm.get_pos()[:6]]
                if commander.payload_scale > 0.0:
                    try:
                        ramp_payload_scale(
                            arm,
                            commander,
                            current_q,
                            start_scale=commander.payload_scale,
                            end_scale=0.0,
                            duration_s=float(payload["transition_s"]),
                            label="fault_payload_scale_down",
                        )
                    except Exception as payload_recovery_exc:
                        print(
                            "PAYLOAD_SCALE_RECOVERY_WARNING =",
                            repr(payload_recovery_exc),
                        )
                        commander.set_payload_scale(0.0)
                commander.set_support_up_normal(
                    commander.nominal_support_up_normal_base,
                    source="mount_record_pitch_only:payload_ab_fault_return",
                )
                guarded_hold(
                    arm,
                    current_q,
                    float(tilt_config["normal_transition_s"]) + 0.25,
                    "payload_ab_fault_normal_restore",
                )
                q_observe = list(phases[-1][1][-1])
                current_q = [float(value) for value in arm.get_pos()[:6]]
                check_collision_path(
                    collision_checker, [current_q, q_observe],
                    float(endpoint_config["collision_step_rad"]),
                )
                fault = arm.move_waypoints([current_q, q_observe], "payload_ab_fault_endpoint_return")
                if fault:
                    raise RuntimeError(fault)
                for name, points in reversed(phases):
                    fault = arm.move_waypoints(list(reversed(points)), f"fault_{name}_return")
                    if fault:
                        raise RuntimeError(fault)
                    if name == "side_deploy":
                        ramp_compensation_scale(
                            arm,
                            commander,
                            points[0],
                            start_scale=side_scale,
                            end_scale=vertical_scale,
                            duration_s=transition_s,
                            label="fault_right_ready_scale_down",
                        )
                print("SAFE_RETURN_AFTER_REJECT = True")
            except Exception as recovery_exc:
                print("SAFE_RETURN_WARNING =", repr(recovery_exc))
        return 1
    finally:
        if arm is not None:
            try:
                arm.disable()
            except Exception as exc:
                print("DISABLE_WARNING =", repr(exc))
        log["status"] = result
        write_json(log_path, log)
        print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
        print("LOG_SAVED =", log_path)
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
