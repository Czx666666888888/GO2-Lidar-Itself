#!/usr/bin/env python3
"""Static physical validation for a pending wrist D455 eye-in-hand candidate.

This program never constructs an Arm, never opens the arm serial device and
never commands the robot.  A separate, already validated tilt-compensation
publisher owns the S1 serial bus and writes a live pose CSV while holding the
arm locked.  Forward kinematics may still use the SDK's offline solver.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
import json
import math
from pathlib import Path
import re
import statistics
import sys
import time

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from demo_grasp.capture_rgbd import capture_aligned_rgbd, save_capture
from demo_grasp.detect_science_target_rgbd import (
    detect_capture,
    load_config as load_vision_config,
    save_preview,
    save_result,
)
from s1_control.kinematics import Kinematics
from s1_control.wrist_visual_servo import (
    camera_tilt_from_down_deg,
    dynamic_base_camera,
    extract_single_surface_observation,
    file_sha256,
    joint_margin_details,
    load_wrist_servo_config,
    resolve_project_path,
)


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "wrist_static_extrinsic_validation.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "wrist_static_validation_runs"
RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
POSE_FIELDS = (
    "time",
    "q1",
    "q2",
    "q3",
    "q4",
    "q5",
    "q6",
    "gripper",
    "source_state",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "腕载D455静态外参物理验证；只读取locked姿态CSV和D455，"
            "不连接S1串口、不产生运动"
        )
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--pose-csv", required=True)
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--run-id")
    parser.add_argument("--execute", action="store_true")
    return parser


def _finite_float(raw, name: str) -> float:
    value = float(raw)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def _pose_row(record: dict, row_number: int) -> dict:
    try:
        timestamp = _finite_float(record["time"], f"row {row_number} time")
        q = [
            _finite_float(record[f"q{index}"], f"row {row_number} q{index}")
            for index in range(1, 7)
        ]
        gripper = _finite_float(record["gripper"], f"row {row_number} gripper")
        source_state = str(record["source_state"]).strip()
    except KeyError as exc:
        raise ValueError(f"pose CSV row {row_number} is missing {exc.args[0]}") from exc
    return {
        "timestamp_s": timestamp,
        "q_rad": q,
        "gripper_rad": gripper,
        "source_state": source_state,
    }


def read_locked_pose_snapshot(
    path: str | Path,
    policy: dict,
    *,
    now_s: float | None = None,
) -> dict:
    pose_path = Path(path).expanduser().resolve()
    if not pose_path.is_file():
        raise FileNotFoundError(f"pose CSV does not exist: {pose_path}")
    with pose_path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or tuple(reader.fieldnames) != POSE_FIELDS:
            raise ValueError("pose CSV header does not match the tilt publisher schema")
        rows = [_pose_row(record, index) for index, record in enumerate(reader, 2)]
    if not rows:
        raise ValueError("pose CSV contains no samples")

    latest = rows[-1]
    required_state = str(policy["required_state"])
    if latest["source_state"] != required_state:
        raise RuntimeError(
            f"pose publisher is {latest['source_state']!r}, expected {required_state!r}"
        )
    now = time.time() if now_s is None else _finite_float(now_s, "now_s")
    age_s = now - latest["timestamp_s"]
    maximum_age_s = _finite_float(policy["maximum_age_s"], "maximum_age_s")
    if age_s < -0.1:
        raise RuntimeError(f"pose CSV timestamp is {abs(age_s):.3f}s in the future")
    if age_s > maximum_age_s:
        raise RuntimeError(
            f"pose CSV is stale: age={age_s:.3f}s limit={maximum_age_s:.3f}s"
        )

    window_s = _finite_float(policy["window_s"], "window_s")
    recent = [
        row
        for row in rows
        if row["source_state"] == required_state
        and latest["timestamp_s"] - row["timestamp_s"] <= window_s
    ]
    minimum_samples = int(policy["minimum_samples"])
    if len(recent) < minimum_samples:
        raise RuntimeError(
            f"only {len(recent)} recent locked samples; need {minimum_samples}"
        )
    q_median = [
        statistics.median(row["q_rad"][joint] for row in recent)
        for joint in range(6)
    ]
    joint_spans = [
        max(row["q_rad"][joint] for row in recent)
        - min(row["q_rad"][joint] for row in recent)
        for joint in range(6)
    ]
    maximum_span = max(joint_spans)
    maximum_span_allowed = _finite_float(
        policy["maximum_joint_span_rad"], "maximum_joint_span_rad"
    )
    if maximum_span > maximum_span_allowed:
        raise RuntimeError(
            f"locked pose is moving: span={maximum_span:.6f}rad "
            f"limit={maximum_span_allowed:.6f}rad"
        )
    return {
        "path": str(pose_path),
        "latest_timestamp_s": latest["timestamp_s"],
        "age_s": age_s,
        "sample_count": len(recent),
        "q_median_rad": q_median,
        "joint_span_rad": joint_spans,
        "maximum_joint_span_rad": maximum_span,
        "source_state": required_state,
    }


def combine_pose_snapshots(before: dict, after: dict, policy: dict) -> tuple[list[float], float]:
    before_q = np.asarray(before["q_median_rad"], dtype=np.float64)
    after_q = np.asarray(after["q_median_rad"], dtype=np.float64)
    if before_q.shape != (6,) or after_q.shape != (6,):
        raise ValueError("pose snapshots must contain six joints")
    delta = float(np.max(np.abs(after_q - before_q)))
    maximum = _finite_float(
        policy["maximum_pre_post_delta_rad"], "maximum_pre_post_delta_rad"
    )
    if delta > maximum:
        raise RuntimeError(
            f"locked pose changed during RGB-D capture: delta={delta:.6f}rad "
            f"limit={maximum:.6f}rad"
        )
    return (0.5 * (before_q + after_q)).tolist(), delta


def _unit_vector(value, name: str) -> np.ndarray:
    vector = np.asarray(value, dtype=np.float64)
    if vector.shape != (3,) or not np.isfinite(vector).all():
        raise ValueError(f"{name} must contain three finite values")
    norm = float(np.linalg.norm(vector))
    if norm < 1e-9:
        raise ValueError(f"{name} must be non-zero")
    return vector / norm


def support_plane_geometry(
    normal_camera,
    transform_base_camera,
) -> dict:
    """Transform the camera-facing support-plane normal into the S1 base frame.

    The plane fitter orients its normal toward the camera.  For the supported
    high-hover setup that direction is ground-up.  We nevertheless force a
    positive base-frame Z component so a harmless plane-normal sign flip can
    never invert clearance.
    """
    transform = np.asarray(transform_base_camera, dtype=np.float64)
    if transform.shape != (4, 4) or not np.isfinite(transform).all():
        raise ValueError("T_base_camera must be a finite 4x4 matrix")
    support_up_base = _unit_vector(
        transform[:3, :3] @ _unit_vector(normal_camera, "support normal camera"),
        "support normal base",
    )
    if support_up_base[2] < 0.0:
        support_up_base = -support_up_base
    camera_optical_axis_base = _unit_vector(
        transform[:3, 2], "camera optical axis base"
    )
    return {
        "support_up_normal_base": support_up_base.tolist(),
        "camera_optical_axis_base": camera_optical_axis_base.tolist(),
    }


def evaluate_static_alignment(
    tcp_pose,
    target_surface_base_m,
    *,
    support_up_normal_base,
    camera_optical_axis_base,
    minimum_joint_margin_deg: float,
    safety: dict,
    static_policy: dict,
    mount_measurement: dict | None = None,
) -> dict:
    tcp = np.asarray(tcp_pose, dtype=np.float64)
    target = np.asarray(target_surface_base_m, dtype=np.float64)
    if tcp.shape != (7,) or not np.isfinite(tcp).all():
        raise ValueError("tcp pose must contain seven finite values")
    if target.shape != (3,) or not np.isfinite(target).all():
        raise ValueError("target surface must contain three finite values")
    support_up = _unit_vector(support_up_normal_base, "support up normal base")
    if support_up[2] < 0.0:
        support_up = -support_up
    camera_axis = _unit_vector(
        camera_optical_axis_base, "camera optical axis base"
    )

    # Alignment is defined relative to gravity/the support plane, not relative
    # to the tilted S1 base X-Y plane.  Remove the component along ground-up;
    # the remainder is the true horizontal centering error.
    delta_m = target - tcp[:3]
    signed_up_m = float(np.dot(delta_m, support_up))
    horizontal_error_m = delta_m - signed_up_m * support_up
    horizontal_error_mm = 1000.0 * horizontal_error_m
    horizontal_error_norm_mm = float(np.linalg.norm(horizontal_error_mm))
    normal_clearance_mm = -1000.0 * signed_up_m

    raw_base_error_mm = 1000.0 * delta_m
    raw_base_xy_error_mm = raw_base_error_mm[:2]
    raw_base_xy_error_norm_mm = float(np.linalg.norm(raw_base_xy_error_mm))

    support_down = -support_up
    camera_cosine = float(np.clip(np.dot(camera_axis, support_down), -1.0, 1.0))
    camera_tilt_support_deg = math.degrees(math.acos(camera_cosine))
    camera_base_cosine = float(np.clip(np.dot(camera_axis, [0.0, 0.0, -1.0]), -1.0, 1.0))
    camera_tilt_base_deg = math.degrees(math.acos(camera_base_cosine))

    # Signed engineering slopes under this project's base-frame convention:
    # +x points to Go2 rear and +y to Go2 right.  Positive values mean that
    # named edge of the S1 mounting plane is lower than the opposite edge.
    rear_edge_lower_deg = math.degrees(
        math.atan2(-float(support_up[0]), float(support_up[2]))
    )
    right_edge_lower_deg = math.degrees(
        math.atan2(-float(support_up[1]), float(support_up[2]))
    )
    maximum_center_error_mm = float(static_policy["maximum_center_error_mm"])
    reasons = []
    if horizontal_error_norm_mm > maximum_center_error_mm:
        reasons.append("center_error_too_large")
    if not float(safety["minimum_target_clearance_mm"]) <= normal_clearance_mm <= float(
        safety["maximum_target_clearance_mm"]
    ):
        reasons.append("target_clearance_out_of_range")
    if camera_tilt_support_deg > float(safety["maximum_camera_tilt_from_down_deg"]):
        reasons.append("camera_tilt_too_large")
    if minimum_joint_margin_deg < float(safety["minimum_joint_margin_deg"]):
        reasons.append("joint_margin_too_small")
    result = {
        "alignment_reference": "detected_support_plane_normal",
        "support_up_normal_base": support_up.tolist(),
        "raw_base_error_xyz_mm": raw_base_error_mm.tolist(),
        "raw_base_xy_error_mm": raw_base_xy_error_mm.tolist(),
        "raw_base_xy_error_norm_mm": raw_base_xy_error_norm_mm,
        "support_plane_horizontal_error_base_xyz_mm": horizontal_error_mm.tolist(),
        "support_plane_horizontal_error_norm_mm": horizontal_error_norm_mm,
        "maximum_center_error_mm": maximum_center_error_mm,
        "normal_clearance_mm": normal_clearance_mm,
        "camera_tilt_from_support_down_deg": camera_tilt_support_deg,
        "camera_tilt_from_base_down_deg": camera_tilt_base_deg,
        "measured_rear_edge_lower_deg": rear_edge_lower_deg,
        "measured_right_edge_lower_deg": right_edge_lower_deg,
        "minimum_joint_margin_deg": float(minimum_joint_margin_deg),
        "passed": not reasons,
        "reasons": reasons,
    }
    if mount_measurement is not None:
        nominal_rear = float(mount_measurement["rear_edge_lower_deg"])
        nominal_lateral = float(mount_measurement["left_right_tilt_deg"])
        result.update(
            {
                "nominal_rear_edge_lower_deg": nominal_rear,
                "nominal_left_right_tilt_deg": nominal_lateral,
                "rear_edge_lower_delta_from_nominal_deg": rear_edge_lower_deg
                - nominal_rear,
                "right_edge_lower_delta_from_nominal_deg": right_edge_lower_deg
                - nominal_lateral,
                "mount_angle_diagnostic_only": True,
            }
        )
    return result


def resolve_output_dir(output_root, run_id: str | None) -> Path:
    root = resolve_project_path(output_root)
    try:
        root.relative_to(PROJECT_ROOT)
    except ValueError as exc:
        raise ValueError("output root must be inside the project") from exc
    name = run_id or time.strftime("wrist_static_%Y%m%d-%H%M%S")
    if not RUN_ID_PATTERN.fullmatch(name):
        raise ValueError("run id contains unsupported characters")
    run_dir = root / name
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    return run_dir


def write_json(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def verify_mount_binding(loaded) -> tuple[Path, str]:
    binding = loaded.record.get("bindings", {}).get("mount_config")
    if not isinstance(binding, dict):
        raise ValueError("static validation config is missing mount_config binding")
    path = resolve_project_path(binding.get("path", ""))
    if not path.is_file():
        raise FileNotFoundError(f"mount config does not exist: {path}")
    actual = file_sha256(path)
    expected = str(binding.get("sha256", "")).lower()
    if actual != expected:
        raise RuntimeError(
            f"mount config SHA-256 mismatch: expected={expected} actual={actual}"
        )
    return path, actual


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    loaded = load_wrist_servo_config(args.config)
    mount_path, mount_hash = verify_mount_binding(loaded)
    mount_record = json.loads(mount_path.read_text(encoding="utf-8"))
    mount_measurement = mount_record["mount_measurement"]
    vision_config, _ = load_vision_config(loaded.vision_config_path)
    pose_path = Path(args.pose_csv).expanduser().resolve()
    print("MODE = WRIST_STATIC_EXTRINSIC_VALIDATION")
    print("ARM_SERIAL_ACCESS = False")
    print("ARM_COMMANDS = False")
    print("CONFIG =", loaded.path)
    print("EYE_IN_HAND_CANDIDATE =", loaded.candidate_path)
    print("CANDIDATE_SHA256 =", file_sha256(loaded.candidate_path))
    print("MOUNT_CONFIG =", mount_path)
    print("MOUNT_CONFIG_SHA256 =", mount_hash)
    print("POSE_CSV =", pose_path)
    print("CAMERA_SERIAL =", loaded.record["camera_serial"])
    print("FORBIDDEN = S1-serial, enable, motion, descent, gripper-close, lift")
    if not args.execute:
        print("OFFLINE_PREFLIGHT_OK：未访问D455或机械臂串口。")
        return 0

    print("\n实机条件：倾角补偿发布器必须持续运行并显示LOCKED_READY_FOR_CAPTURE；")
    print("Go2保持最终趴下与配重构型，画面内只有一个50mm方块；")
    print("人工确认TCP中心已位于方块中心正上方，机械臂有软支撑。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("CANCELLED：未访问D455。")
        return 2

    run_dir = resolve_output_dir(args.output_root, args.run_id)
    run_dir.mkdir(parents=True)
    result_path = run_dir / "run.json"
    record = {
        "schema_version": 1,
        "mode": "wrist_static_extrinsic_validation",
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "initializing",
        "config": str(loaded.path.relative_to(PROJECT_ROOT)),
        "config_sha256": file_sha256(loaded.path),
        "candidate": str(loaded.candidate_path.relative_to(PROJECT_ROOT)),
        "candidate_sha256": file_sha256(loaded.candidate_path),
        "pose_csv": str(pose_path),
        "arm_serial_access": False,
        "arm_commands": False,
        "operator_asserted_tcp_centered_above_target": True,
    }
    write_json(result_path, record)
    try:
        pose_policy = loaded.record["pose_source"]
        before = read_locked_pose_snapshot(pose_path, pose_policy)
        print(
            "POSE_BEFORE_CAPTURE = locked",
            f"age={before['age_s']:.3f}s",
            f"samples={before['sample_count']}",
            f"span={before['maximum_joint_span_rad']:.6f}rad",
        )

        capture_cfg = loaded.record["capture"]
        capture = capture_aligned_rgbd(
            serial=loaded.record["camera_serial"],
            width=int(capture_cfg["width"]),
            height=int(capture_cfg["height"]),
            fps=int(capture_cfg["fps"]),
            warmup_frames=int(capture_cfg["warmup_frames"]),
            depth_frames=int(capture_cfg["depth_frames"]),
            timeout_ms=int(capture_cfg["timeout_ms"]),
            min_valid_depth_ratio=float(capture_cfg["minimum_valid_depth_ratio"]),
            max_frame_interval_ms=float(capture_cfg["maximum_frame_interval_ms"]),
        )
        capture_path = run_dir / "capture.npz"
        save_capture(capture, capture_path, write_preview=True)
        detection_capture = dict(capture)
        detection_capture["path"] = capture_path
        detection = detect_capture(detection_capture, vision_config)
        detection_path = run_dir / "detection.json"
        preview_path = run_dir / "detection.png"
        save_result(detection, detection_path)
        save_preview(capture["rgb"], detection, preview_path)

        after = read_locked_pose_snapshot(pose_path, pose_policy)
        q_observed, pre_post_delta = combine_pose_snapshots(before, after, pose_policy)
        print(
            "POSE_AFTER_CAPTURE = locked",
            f"age={after['age_s']:.3f}s",
            f"samples={after['sample_count']}",
            f"pre_post_delta={pre_post_delta:.6f}rad",
        )

        flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
        tcp_kinematics = Kinematics(verbose=True)
        flange_pose = flange_kinematics.fk(q_observed)
        transform_base_camera = dynamic_base_camera(
            flange_pose, loaded.transform_flange_camera
        )
        observation = extract_single_surface_observation(
            detection,
            capture["metadata"],
            transform_base_camera,
            loaded.record["camera_serial"],
            loaded.record["safety"],
        )
        tcp_pose = tcp_kinematics.fk(q_observed)
        raw_base_tilt_deg = camera_tilt_from_down_deg(
            flange_pose, loaded.transform_flange_camera
        )
        plane_geometry = support_plane_geometry(
            detection["plane"]["normal_cam"], transform_base_camera
        )
        margin_details = joint_margin_details(q_observed)
        minimum_margin_deg = min(item["margin_deg"] for item in margin_details)
        evaluation = evaluate_static_alignment(
            tcp_pose,
            observation["surface_point_base_m"],
            support_up_normal_base=plane_geometry["support_up_normal_base"],
            camera_optical_axis_base=plane_geometry["camera_optical_axis_base"],
            minimum_joint_margin_deg=minimum_margin_deg,
            safety=loaded.record["safety"],
            static_policy=loaded.record["static_validation"],
            mount_measurement=mount_measurement,
        )
        record.update(
            {
                "status": "passed_single_pose" if evaluation["passed"] else "rejected",
                "pose_before": before,
                "pose_after": after,
                "pose_pre_post_delta_rad": pre_post_delta,
                "q_observed_rad": q_observed,
                "flange_pose_xyz_xyzw": flange_pose,
                "tcp_pose_xyz_xyzw": tcp_pose,
                "T_base_camera": transform_base_camera.tolist(),
                "joint_margin_details": margin_details,
                "capture_metadata": capture["metadata"],
                "observation": observation,
                "evaluation": evaluation,
                "artifacts": {
                    "capture": str(capture_path.relative_to(PROJECT_ROOT)),
                    "detection": str(detection_path.relative_to(PROJECT_ROOT)),
                    "preview": str(preview_path.relative_to(PROJECT_ROOT)),
                },
                "candidate_runtime_approved": False,
                "next_gate": (
                    "repeat at distinct poses before any motion validation"
                    if evaluation["passed"]
                    else "inspect physical centering and calibration assumptions"
                ),
            }
        )
        write_json(result_path, record)
        print("TARGET_BASE_XYZ_MM =", [round(1000.0 * value, 3) for value in observation["surface_point_base_m"]])
        print("TCP_BASE_XYZ_MM =", [round(1000.0 * value, 3) for value in tcp_pose[:3]])
        print("RAW_BASE_XY_ERROR_MM =", [round(value, 3) for value in evaluation["raw_base_xy_error_mm"]])
        print("RAW_BASE_XY_ERROR_NORM_MM =", round(evaluation["raw_base_xy_error_norm_mm"], 3))
        print(
            "SUPPORT_PLANE_HORIZONTAL_ERROR_BASE_XYZ_MM =",
            [
                round(value, 3)
                for value in evaluation["support_plane_horizontal_error_base_xyz_mm"]
            ],
        )
        print(
            "SUPPORT_PLANE_HORIZONTAL_ERROR_NORM_MM =",
            round(evaluation["support_plane_horizontal_error_norm_mm"], 3),
        )
        print("NORMAL_CLEARANCE_MM =", round(evaluation["normal_clearance_mm"], 3))
        print(
            "MEASURED_MOUNT_SLOPE_DEG =",
            {
                "rear_edge_lower": round(evaluation["measured_rear_edge_lower_deg"], 3),
                "right_edge_lower": round(evaluation["measured_right_edge_lower_deg"], 3),
            },
        )
        print(
            "CAMERA_TILT_FROM_SUPPORT_DOWN_DEG =",
            round(evaluation["camera_tilt_from_support_down_deg"], 3),
        )
        print("CAMERA_TILT_FROM_BASE_DOWN_DEG =", round(raw_base_tilt_deg, 3))
        print("STATIC_VALIDATION_PASS =", evaluation["passed"])
        if evaluation["reasons"]:
            print("REJECTION_REASONS =", evaluation["reasons"])
        print("LOG_SAVED =", result_path)
        print(
            "RESULT =",
            "STATIC_SINGLE_POSE_PASS_PENDING_REPETITION"
            if evaluation["passed"]
            else "STATIC_VALIDATION_REJECTED",
        )
        return 0 if evaluation["passed"] else 3
    except BaseException as exc:
        record["status"] = "aborted"
        record["error"] = f"{type(exc).__name__}: {exc}"
        write_json(result_path, record)
        print("ABORTED:", record["error"])
        print("LOG_SAVED =", result_path)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
