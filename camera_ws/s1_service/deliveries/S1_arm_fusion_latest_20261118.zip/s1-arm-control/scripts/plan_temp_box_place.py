#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Plan a provisional top-down drop route for the fixed cardboard box.

The captured pose supplies only the box-centre XY and tool orientation.  Its Z
is deliberately raised before IK because the taught pose did not leave enough
clearance above the cardboard rim.  This script is offline-only: it imports no
serial or camera code and never constructs an Arm object.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.kinematics import Kinematics, READY_Q  # noqa: E402


JOINT_LIMITS = [
    (math.radians(-170), math.radians(170)),
    (math.radians(0), math.radians(180)),
    (math.radians(0), math.radians(170)),
    (math.radians(-90), math.radians(87)),
    (math.radians(-90), math.radians(90)),
    (math.radians(-90), math.radians(90)),
]


def resolve_project_path(raw_path: str | Path) -> Path:
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON根节点必须是对象: {path}")
    return value


def finite_vector(raw, length: int, name: str) -> list[float]:
    if not isinstance(raw, list) or len(raw) != length:
        raise ValueError(f"{name}必须是{length}维数组")
    values = [float(item) for item in raw]
    if not all(math.isfinite(item) for item in values):
        raise ValueError(f"{name}包含NaN或Inf")
    return values


def unit_quaternion(raw) -> np.ndarray:
    quaternion = np.asarray(
        finite_vector(list(raw), 4, "orientation_xyzw"),
        dtype=float,
    )
    norm = float(np.linalg.norm(quaternion))
    if norm < 1e-9:
        raise ValueError("orientation_xyzw不能为零四元数")
    return quaternion / norm


def quaternion_to_rotation(raw) -> np.ndarray:
    x, y, z, w = unit_quaternion(raw)
    return np.array([
        [
            1.0 - 2.0 * (y * y + z * z),
            2.0 * (x * y - z * w),
            2.0 * (x * z + y * w),
        ],
        [
            2.0 * (x * y + z * w),
            1.0 - 2.0 * (x * x + z * z),
            2.0 * (y * z - x * w),
        ],
        [
            2.0 * (x * z - y * w),
            2.0 * (y * z + x * w),
            1.0 - 2.0 * (x * x + y * y),
        ],
    ])


def rotation_error_deg(first, second) -> float:
    first_matrix = np.asarray(first, dtype=float)
    second_matrix = np.asarray(second, dtype=float)
    cosine = (np.trace(first_matrix.T @ second_matrix) - 1.0) / 2.0
    return math.degrees(math.acos(float(np.clip(cosine, -1.0, 1.0))))


def orientation_report(quaternion) -> dict:
    rotation = quaternion_to_rotation(quaternion)
    approach = rotation[:, 0]
    closing_axis = rotation[:, 1]
    approach_cosine = float(np.clip(np.dot(
        approach,
        np.array([0.0, 0.0, -1.0]),
    ), -1.0, 1.0))
    return {
        "rotation_matrix": rotation.tolist(),
        "approach_axis_base": approach.tolist(),
        "closing_axis_base": closing_axis.tolist(),
        "topdown_approach_error_deg": math.degrees(
            math.acos(approach_cosine)
        ),
        "closing_axis_vertical_abs": abs(float(closing_axis[2])),
    }


def joint_report(q) -> dict:
    values = finite_vector(list(q), 6, "joint_rad")
    hard_ok = True
    margins_deg = []
    for value, (lower, upper) in zip(values, JOINT_LIMITS):
        if not lower <= value <= upper:
            hard_ok = False
        margins_deg.append(math.degrees(min(
            value - lower,
            upper - value,
        )))
    return {
        "hard_limit_ok": hard_ok,
        "joint_margins_deg": margins_deg,
        "minimum_joint_margin_deg": min(margins_deg),
    }


def evenly_spaced_levels(
    start_mm: float,
    end_mm: float,
    maximum_step_mm: float,
) -> list[float]:
    if not all(math.isfinite(value) for value in (
        start_mm, end_mm, maximum_step_mm
    )):
        raise ValueError("Z层参数必须为有限数")
    if maximum_step_mm <= 0.0:
        raise ValueError("maximum_step_mm必须大于0")
    if end_mm <= start_mm:
        raise ValueError("hover Z必须高于release Z")
    segments = max(1, math.ceil((end_mm - start_mm) / maximum_step_mm))
    return [
        start_mm + (end_mm - start_mm) * index / segments
        for index in range(segments + 1)
    ]


def build_transit_waypoints(
    q_start,
    q_end,
    maximum_segment_delta_rad: float,
) -> list[dict]:
    start = finite_vector(list(q_start), 6, "q_start")
    end = finite_vector(list(q_end), 6, "q_end")
    if (
        not math.isfinite(maximum_segment_delta_rad)
        or maximum_segment_delta_rad <= 0.0
    ):
        raise ValueError("maximum_segment_delta_rad必须大于0")
    maximum_delta = max(abs(a - b) for a, b in zip(start, end))
    segments = max(1, math.ceil(
        maximum_delta / maximum_segment_delta_rad
    ))
    return [
        {
            "name": f"transit_{index:02d}",
            "q": [
                a + (b - a) * index / segments
                for a, b in zip(start, end)
            ],
        }
        for index in range(1, segments)
    ]


def derive_geometry(config: dict, pose: dict) -> dict:
    box = config.get("box", {})
    geometry = config.get("geometry", {})
    table_z_mm = float(geometry["reference_table_z_mm"])
    box_height_mm = float(box["outer_height_mm"])
    raise_mm = float(geometry["raise_from_taught_mm"])
    hover_raise_mm = float(geometry["hover_above_release_mm"])
    if min(box_height_mm, raise_mm, hover_raise_mm) <= 0.0:
        raise ValueError("纸盒高度、释放抬高量和悬停抬高量必须大于0")

    taught_pose = finite_vector(
        pose.get("tcp_xyz_quat_xyzw"),
        7,
        "source_pose.tcp_xyz_quat_xyzw",
    )
    taught_xyz_mm = [1000.0 * value for value in taught_pose[:3]]
    orientation_xyzw = unit_quaternion(taught_pose[3:]).tolist()
    rim_z_mm = table_z_mm + box_height_mm
    release_xyz_mm = list(taught_xyz_mm)
    release_xyz_mm[2] += raise_mm
    hover_xyz_mm = list(release_xyz_mm)
    hover_xyz_mm[2] += hover_raise_mm
    rim_clearance_mm = release_xyz_mm[2] - rim_z_mm
    minimum_clearance_mm = float(
        geometry["minimum_release_rim_clearance_mm"]
    )
    if rim_clearance_mm < minimum_clearance_mm:
        raise ValueError(
            f"释放位上沿净空{rim_clearance_mm:.3f}mm小于"
            f"要求{minimum_clearance_mm:.3f}mm"
        )
    return {
        "taught_xyz_mm": taught_xyz_mm,
        "orientation_xyzw": orientation_xyzw,
        "box_rim_z_mm": rim_z_mm,
        "release_xyz_mm": release_xyz_mm,
        "hover_xyz_mm": hover_xyz_mm,
        "release_rim_clearance_mm": rim_clearance_mm,
    }


def candidate_seeds(reference_q, taught_q) -> list[list[float]]:
    reference = finite_vector(list(reference_q), 6, "reference_q")
    taught = finite_vector(list(taught_q), 6, "taught_q")
    seeds = [reference, taught, list(READY_Q)]
    for index, amount in (
        (0, 0.08), (0, -0.08),
        (1, 0.08), (1, -0.08),
        (3, 0.08), (3, -0.08),
    ):
        seed = list(reference)
        seed[index] += amount
        seeds.append(seed)
    return seeds


def solve_pose(
    kinematics: Kinematics,
    xyz_mm,
    quaternion,
    reference_q,
    taught_q,
    planning: dict,
) -> tuple[dict, list[dict]]:
    target_xyz_m = np.asarray(
        finite_vector(list(xyz_mm), 3, "target_xyz_mm"),
        dtype=float,
    ) / 1000.0
    target_rotation = quaternion_to_rotation(quaternion)
    reference = finite_vector(list(reference_q), 6, "reference_q")
    max_position_error_mm = float(planning["maximum_position_error_mm"])
    max_orientation_error_deg = float(
        planning["maximum_orientation_error_deg"]
    )
    minimum_margin_deg = float(planning["minimum_joint_margin_deg"])
    maximum_delta_rad = float(
        planning["maximum_vertical_joint_delta_rad"]
    )
    rounds = int(planning["ik_rounds"])
    if rounds < 1:
        raise ValueError("ik_rounds必须至少为1")

    candidates = []
    unique = []
    for _ in range(rounds):
        for seed in candidate_seeds(reference, taught_q):
            q = kinematics.ik(
                target_xyz_m.tolist(),
                list(quaternion),
                seed,
            )
            if q is None or len(q) != 6:
                continue
            q = [float(value) for value in q]
            if not all(math.isfinite(value) for value in q):
                continue
            if any(
                max(abs(a - b) for a, b in zip(q, previous)) < 1e-5
                for previous in unique
            ):
                continue
            unique.append(q)

            fk = kinematics.fk(q)
            fk_xyz = np.asarray(fk[:3], dtype=float)
            fk_rotation = quaternion_to_rotation(fk[3:])
            position_error_mm = float(
                np.linalg.norm(fk_xyz - target_xyz_m) * 1000.0
            )
            orientation_error_deg = rotation_error_deg(
                fk_rotation,
                target_rotation,
            )
            report = joint_report(q)
            reference_delta_rad = max(
                abs(a - b) for a, b in zip(q, reference)
            )
            rejection_reasons = []
            if not report["hard_limit_ok"]:
                rejection_reasons.append("hard_joint_limit")
            if report["minimum_joint_margin_deg"] < minimum_margin_deg:
                rejection_reasons.append("joint_margin")
            if position_error_mm > max_position_error_mm:
                rejection_reasons.append("position_error")
            if orientation_error_deg > max_orientation_error_deg:
                rejection_reasons.append("orientation_error")
            if reference_delta_rad > maximum_delta_rad:
                rejection_reasons.append("vertical_joint_delta")
            candidates.append({
                "q": q,
                "fk_xyz_mm": (fk_xyz * 1000.0).tolist(),
                "position_error_mm": position_error_mm,
                "orientation_error_deg": orientation_error_deg,
                "minimum_joint_margin_deg": (
                    report["minimum_joint_margin_deg"]
                ),
                "joint_margins_deg": report["joint_margins_deg"],
                "reference_delta_rad": reference_delta_rad,
                "rejection_reasons": rejection_reasons,
                "valid": not rejection_reasons,
            })

    valid = [item for item in candidates if item["valid"]]
    valid.sort(key=lambda item: (
        item["reference_delta_rad"],
        -item["minimum_joint_margin_deg"],
        item["position_error_mm"],
        item["orientation_error_deg"],
    ))
    if not valid:
        summary = [
            {
                "reference_delta_rad": round(
                    item["reference_delta_rad"], 4
                ),
                "minimum_joint_margin_deg": round(
                    item["minimum_joint_margin_deg"], 3
                ),
                "rejection_reasons": item["rejection_reasons"],
            }
            for item in candidates[:10]
        ]
        raise RuntimeError(
            "没有满足纸盒垂直路径约束的IK解 "
            f"target_xyz_mm={target_xyz_m.tolist()}: "
            + json.dumps(summary, ensure_ascii=False)
        )
    return valid[0], candidates


def segment_reports(joint_path: list[dict]) -> list[dict]:
    reports = []
    for previous, current in zip(joint_path, joint_path[1:]):
        reports.append({
            "from": previous["name"],
            "to": current["name"],
            "max_joint_delta_rad": max(
                abs(a - b)
                for a, b in zip(previous["q"], current["q"])
            ),
        })
    return reports


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="固定临时纸盒的纯离线悬停/释放IK规划"
    )
    parser.add_argument(
        "--config",
        default="calibration/temp_box_drop.json",
    )
    parser.add_argument(
        "--output",
        default="data/plans/temp_box_place_plan.json",
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)

    config_path = resolve_project_path(args.config)
    output_path = resolve_project_path(args.output)
    config = load_json(config_path)
    if int(config.get("schema_version", 0)) != 1:
        raise ValueError("临时纸盒配置schema_version必须为1")

    source = config.get("source_pose", {})
    pose_path = resolve_project_path(source.get("path", ""))
    if not pose_path.is_file():
        raise FileNotFoundError(f"纸盒示教位不存在: {pose_path}")
    actual_pose_sha256 = file_sha256(pose_path)
    expected_pose_sha256 = str(source.get("sha256", ""))
    if actual_pose_sha256 != expected_pose_sha256:
        raise RuntimeError(
            "纸盒示教位哈希不匹配；禁止使用可能已变更的姿态"
        )
    pose = load_json(pose_path)
    if pose.get("replay_recommended") is not True:
        raise RuntimeError("纸盒示教位未通过capture_pose建议余量检查")
    taught_q = finite_vector(pose.get("joint_rad"), 6, "source_pose.joint_rad")

    derived = derive_geometry(config, pose)
    report = orientation_report(derived["orientation_xyzw"])
    planning = config["planning"]
    if (
        report["topdown_approach_error_deg"]
        > float(planning["maximum_topdown_approach_error_deg"])
    ):
        raise RuntimeError("纸盒示教姿态不是足够垂直的自上而下姿态")
    if (
        report["closing_axis_vertical_abs"]
        > float(planning["maximum_closing_axis_vertical_abs"])
    ):
        raise RuntimeError("纸盒示教的夹爪闭合轴没有保持水平")

    z_levels = evenly_spaced_levels(
        derived["release_xyz_mm"][2],
        derived["hover_xyz_mm"][2],
        float(config["geometry"]["maximum_vertical_step_mm"]),
    )
    kinematics = Kinematics(verbose=True)
    reference_q = taught_q
    upward_solutions = []
    candidate_counts = []
    for z_mm in z_levels:
        xyz_mm = [
            derived["release_xyz_mm"][0],
            derived["release_xyz_mm"][1],
            z_mm,
        ]
        selected, candidates = solve_pose(
            kinematics,
            xyz_mm,
            derived["orientation_xyzw"],
            reference_q,
            taught_q,
            planning,
        )
        upward_solutions.append({
            "z_mm": z_mm,
            "q": selected["q"],
            "selected": selected,
        })
        candidate_counts.append(len(candidates))
        reference_q = selected["q"]

    release_solution = upward_solutions[0]
    hover_solution = upward_solutions[-1]
    joint_path = [{"name": "ready", "q": list(READY_Q)}]
    joint_path.extend(build_transit_waypoints(
        READY_Q,
        hover_solution["q"],
        float(planning["maximum_transit_joint_delta_rad"]),
    ))
    joint_path.append({"name": "hover", "q": hover_solution["q"]})

    descending = list(reversed(upward_solutions[:-1]))
    for index, solution in enumerate(descending, start=1):
        terminal = index == len(descending)
        joint_path.append({
            # Existing collision checker treats the terminal name "grasp" as
            # the end of a vertical tool path.  Metadata below overrides its
            # operational meaning to OPEN_GRIPPER_RELEASE.
            "name": "grasp" if terminal else f"descent_{index:02d}",
            "q": solution["q"],
        })

    segments = segment_reports(joint_path)
    plan = {
        "schema_version": 1,
        "status": "KINEMATICS_ONLY_COLLISION_NOT_CHECKED",
        "mode": "TEMP_BOX_TOPDOWN_DROP",
        "terminal_action": "OPEN_GRIPPER_RELEASE",
        "warning": (
            "纸盒不在MuJoCo外部环境模型中；必须完成空盒对准实测后"
            "才能携带物块投放。"
        ),
        "source_config": str(config_path),
        "source_pose": str(pose_path),
        "bindings": {
            "source_pose_sha256": actual_pose_sha256,
            "config_sha256": file_sha256(config_path),
        },
        "box": config["box"],
        "derived_geometry": derived,
        "orientation_report": report,
        "target_xyz_mm": derived["release_xyz_mm"],
        "target_rotation_matrix": report["rotation_matrix"],
        "selected": {
            "orientation": "captured_box_long_axis",
            **release_solution["selected"],
        },
        "vertical_z_levels_mm": z_levels,
        "ik_candidate_counts": candidate_counts,
        "joint_path": joint_path,
        "segment_deltas": segments,
        "thresholds": {
            **planning,
            "minimum_release_rim_clearance_mm": config["geometry"][
                "minimum_release_rim_clearance_mm"
            ],
            "maximum_vertical_step_mm": config["geometry"][
                "maximum_vertical_step_mm"
            ],
            "maximum_vertical_lateral_deviation_mm": config["geometry"][
                "maximum_vertical_lateral_deviation_mm"
            ],
        },
        "execution_defaults": config["execution"],
    }

    if output_path.exists() and not args.overwrite:
        raise FileExistsError(
            f"{output_path}已存在；如需覆盖请添加--overwrite"
        )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(plan, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("OFFLINE_ONLY：未访问相机、串口或机械臂。")
    print("SOURCE_POSE_SHA256 =", actual_pose_sha256)
    print("TAUGHT_TCP_MM =", [round(v, 3) for v in derived["taught_xyz_mm"]])
    print("BOX_RIM_Z_MM =", round(derived["box_rim_z_mm"], 3))
    print("RELEASE_TCP_MM =", [round(v, 3) for v in derived["release_xyz_mm"]])
    print("RELEASE_RIM_CLEARANCE_MM =", round(
        derived["release_rim_clearance_mm"], 3
    ))
    print("HOVER_TCP_MM =", [round(v, 3) for v in derived["hover_xyz_mm"]])
    print("TOPDOWN_APPROACH_ERROR_DEG =", round(
        report["topdown_approach_error_deg"], 3
    ))
    print("VERTICAL_Z_LEVELS_MM =", [round(v, 3) for v in z_levels])
    print("PLANNED_JOINT_PATH:")
    for waypoint in joint_path:
        print(
            f"  {waypoint['name']}:",
            ",".join(f"{value:.6f}" for value in waypoint["q"]),
        )
    for segment in segments:
        print(
            f"  {segment['from']}->{segment['to']}: "
            f"delta={segment['max_joint_delta_rad']:.3f}rad"
        )
    print("PLAN_SAVED =", output_path)
    print("COLLISION_NOT_CHECKED：禁止直接执行该纸盒放置计划。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
