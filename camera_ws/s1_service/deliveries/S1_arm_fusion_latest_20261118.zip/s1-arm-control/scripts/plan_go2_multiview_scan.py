#!/usr/bin/env python3
"""Build a conservative multi-view D455 scan plan for the Go2 right side.

The planner is offline-only.  It keeps the commissioned right-observe TCP
orientation, samples a small set of support-plane translations and upward
offsets, proves a reversible hub-to-view path, estimates detector-ROI coverage,
and greedily selects the smallest useful set of views.  The Go2 body envelope
is checked in addition to the S1 MuJoCo collision model.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SCRIPTS_DIR, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from plan_go2_observe_deployment import (  # noqa: E402
    collision_sets,
    geom_positions_mm,
    set_model_q,
)
from run_go2_visual_alignment import (  # noqa: E402
    apply_local_j2_tilt_limit,
    apply_local_j3_tilt_limit,
    check_collision_path,
    load_alignment_config,
    resolve_project_path,
)
from scan_go2_ground_grasp_workspace import (  # noqa: E402
    cartesian_line,
    finite_vector,
    load_json,
    support_plane_basis,
    unit_vector,
)
from s1_control.go2_deployment import file_sha256  # noqa: E402
from s1_control.go2_visual_alignment import (  # noqa: E402
    densify_joint_path,
    solve_continuous_ik_path,
    validate_torque_envelope,
)
from s1_control.kinematics import Kinematics  # noqa: E402
from s1_control.tilt_gravity import (  # noqa: E402
    UrdfGravityModel,
    differential_tilt_compensation_from_support_up,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record  # noqa: E402
from s1_control.wrist_visual_servo import (  # noqa: E402
    dynamic_base_camera,
    load_wrist_servo_config,
)


DEFAULT_BASELINE = (
    PROJECT_ROOT
    / "data/go2_visual_alignment_runs/"
    "new_s1_go2_50mm40g_random_orientation_full_flow_v10/run.json"
)
DEFAULT_SCAN = (
    PROJECT_ROOT
    / "data/workspace_scans/"
    "new_s1_go2_right_ground_workspace_sparse_extended_v1.json"
)
DEFAULT_OUTPUT_PLAN = (
    PROJECT_ROOT
    / "data/plans/go2_right_multiview_observation_scan_candidate_v1.json"
)
DEFAULT_OUTPUT_REPORT = (
    PROJECT_ROOT
    / "data/plans/go2_right_multiview_observation_scan_collision_report_v1.json"
)


def parse_values(raw: str, label: str) -> list[float]:
    values = [float(item.strip()) for item in str(raw).split(",") if item.strip()]
    if not values or not all(math.isfinite(item) for item in values):
        raise ValueError(f"{label} must contain finite comma-separated values")
    return sorted(set(values))


def detector_projection(
    point_base_m: Any,
    transform_base_camera: Any,
    intrinsics: Any,
    roi_px: Any,
    margin_px: float,
    minimum_depth_mm: float,
    maximum_depth_mm: float,
) -> dict:
    point = finite_vector(point_base_m, 3, "target point")
    transform = np.asarray(transform_base_camera, dtype=np.float64)
    camera_matrix = np.asarray(intrinsics, dtype=np.float64)
    roi = finite_vector(roi_px, 4, "detector ROI")
    point_camera = np.linalg.inv(transform) @ np.concatenate([point, [1.0]])
    depth_m = float(point_camera[2])
    if depth_m <= 1e-9:
        pixel = [float("nan"), float("nan")]
    else:
        pixel = [
            float(camera_matrix[0, 0] * point_camera[0] / depth_m + camera_matrix[0, 2]),
            float(camera_matrix[1, 1] * point_camera[1] / depth_m + camera_matrix[1, 2]),
        ]
    depth_mm = 1000.0 * depth_m
    visible = bool(
        math.isfinite(pixel[0])
        and math.isfinite(pixel[1])
        and roi[0] + margin_px <= pixel[0] <= roi[2] - margin_px
        and roi[1] + margin_px <= pixel[1] <= roi[3] - margin_px
        and minimum_depth_mm <= depth_mm <= maximum_depth_mm
    )
    return {
        "visible": visible,
        "pixel_uv": pixel,
        "depth_mm": depth_mm,
    }


def go2_envelope_check(checker, joint_path, deployment_source) -> dict:
    side_sign = -1 if deployment_source["route"]["side"] == "left" else 1
    body = deployment_source["safety"]["go2_body_envelope"]
    minimum_tcp_y = float(
        deployment_source["safety"]["side_deploy"]["minimum_tcp_y_mm"]
    )
    half_width = float(body["body_half_width_y_mm"])
    minimum_z = float(body["minimum_distal_geom_center_z_inside_body_width_mm"])
    distal_geoms = [str(item) for item in body["distal_geoms"]]
    tcp_kinematics = Kinematics(verbose=False)
    violations = []
    sample_count = 0
    for index, q in enumerate(joint_path):
        sample_count += 1
        tcp_mm = [1000.0 * float(value) for value in tcp_kinematics.fk(q)[:3]]
        if side_sign * tcp_mm[1] < minimum_tcp_y:
            violations.append(
                {
                    "sample": index,
                    "reason": "scan_tcp_not_outside_go2_body",
                    "tcp_base_xyz_mm": tcp_mm,
                }
            )
        model_q = set_model_q(checker, q)
        active, _, floor = collision_sets(checker, model_q)
        if active:
            violations.append(
                {
                    "sample": index,
                    "reason": "active_collision",
                    "pairs": [list(pair) for pair in sorted(active)],
                }
            )
        if floor:
            violations.append(
                {
                    "sample": index,
                    "reason": "floor_collision",
                    "pairs": [list(pair) for pair in sorted(floor)],
                }
            )
        for geom, position in geom_positions_mm(checker, distal_geoms).items():
            if abs(position[1]) < half_width and position[2] < minimum_z:
                violations.append(
                    {
                        "sample": index,
                        "reason": "distal_geom_low_inside_go2_body_width",
                        "geom": geom,
                        "position_mm": position,
                    }
                )
    return {
        "sample_count": sample_count,
        "violations": violations,
        "pass": not violations,
    }


def candidate_name(u_mm: float, v_mm: float, normal_mm: float) -> str:
    def token(value: float) -> str:
        rounded = int(round(abs(value)))
        return ("p" if value >= 0.0 else "m") + f"{rounded:03d}"

    return f"view_u{token(u_mm)}_v{token(v_mm)}_n{token(normal_mm)}"


def greedy_cover(
    candidates: list[dict],
    universe: set[str],
    maximum_views: int,
    mandatory_name: str,
    point_priorities: dict[str, int] | None = None,
    reserve_backup_view: bool = False,
) -> list[dict]:
    priorities = point_priorities or {}
    mandatory = next(
        (item for item in candidates if item["name"] == mandatory_name),
        None,
    )
    if mandatory is None:
        raise RuntimeError(f"mandatory hub view did not pass: {mandatory_name}")
    selected = [mandatory]
    uncovered = set(universe) - set(mandatory["covered_point_ids"])
    remaining = [item for item in candidates if item["name"] != mandatory_name]
    def rank(item, points):
        gain = set(item["covered_point_ids"]) & points
        return (
            -sum(priorities.get(point, 0) for point in gain),
            -len(gain),
            float(item["path_cost_rad"]),
            float(item["offset_norm_mm"]),
            item["name"],
        )

    while uncovered and remaining and len(selected) < maximum_views:
        choice = min(remaining, key=lambda item: rank(item, uncovered))
        gain = set(choice["covered_point_ids"]) & uncovered
        if not gain:
            break
        selected.append(choice)
        uncovered.difference_update(gain)
        remaining = [item for item in remaining if item["name"] != choice["name"]]
    if reserve_backup_view and len(selected) == 1 and remaining and maximum_views > 1:
        # A second view can resolve real occlusions even when the hub's
        # projected coverage already includes every offline candidate.
        backup = min(remaining, key=lambda item: rank(item, universe))
        if backup["covered_point_ids"]:
            selected.append(backup)
    return selected


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Offline generation of a conservative Go2 right-side D455 multi-view scan"
    )
    parser.add_argument("--baseline-run", default=str(DEFAULT_BASELINE))
    parser.add_argument("--workspace-scan", default=str(DEFAULT_SCAN))
    parser.add_argument("--u-offsets-mm", default="-100,0,100")
    parser.add_argument("--v-offsets-mm", default="-100,0,100")
    parser.add_argument("--normal-offsets-mm", default="0,40")
    parser.add_argument("--roi-margin-px", type=float, default=40.0)
    parser.add_argument("--cartesian-step-mm", type=float, default=10.0)
    parser.add_argument("--maximum-views", type=int, default=7)
    parser.add_argument("--output-plan", default=str(DEFAULT_OUTPUT_PLAN))
    parser.add_argument("--output-report", default=str(DEFAULT_OUTPUT_REPORT))
    parser.add_argument(
        "--grasp-search", action="store_true",
        help="score full-frame coverage of offline grasp candidates",
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)

    baseline_path = resolve_project_path(args.baseline_run)
    scan_path = resolve_project_path(args.workspace_scan)
    output_plan = resolve_project_path(args.output_plan)
    output_report = resolve_project_path(args.output_report)
    for path in (output_plan, output_report):
        if path.exists() and not args.overwrite:
            raise FileExistsError(f"output exists: {path}")

    baseline = load_json(baseline_path)
    scan = load_json(scan_path)
    if scan.get("status") != "offline_candidate_only_pending_staged_physical_validation":
        raise ValueError("workspace scan status is incompatible")
    if file_sha256(baseline_path) != str(scan["baseline"]["run_sha256"]).lower():
        raise RuntimeError("workspace scan is not bound to this baseline run")
    baseline_status = baseline.get("status")
    if baseline_status != "VISUAL_ADAPTIVE_GRASP_BOX_PLACE_ROUND_TRIP_DONE" and not (
        baseline_status == "VISUAL_ADAPTIVE_GRASP_BOX_MOTION_DONE_PLACEMENT_UNVERIFIED"
        and scan["baseline"].get("placement_confirmed_by_operator") is True
    ):
        raise ValueError("baseline needs a complete flow with confirmed placement")

    config_path = resolve_project_path(baseline["config"])
    _, config = load_alignment_config(config_path)
    plan_path = resolve_project_path(config["deployment_plan"])
    wrist_path = resolve_project_path(config["wrist_servo_config"])
    if file_sha256(plan_path) != str(baseline["plan_sha256"]).lower():
        raise RuntimeError("deployment plan changed since baseline")
    if file_sha256(wrist_path) != str(baseline["wrist_config_sha256"]).lower():
        raise RuntimeError("wrist config changed since baseline")
    deployment_plan = load_json(plan_path)
    source_path = resolve_project_path(deployment_plan["source_config"])
    deployment_source = load_json(source_path)
    if file_sha256(source_path) != str(deployment_plan["source_config_sha256"]).lower():
        raise RuntimeError("deployment source config changed")
    mount_path = resolve_project_path(deployment_plan["mount_config"])
    mount = load_json(mount_path)
    loaded = load_wrist_servo_config(wrist_path)

    capture_path = baseline_path.parent / "initial_capture.npz"
    capture = np.load(capture_path, allow_pickle=False)
    intrinsics = np.asarray(capture["K"], dtype=np.float64)
    detector_roi = baseline["planning"]["initial_capture"]["detection"][
        "workspace_roi_px"
    ]
    if args.grasp_search:
        height, width = capture["rgb"].shape[:2]
        detector_roi = [0, 0, width, height]
        mount, _ = apply_local_j3_tilt_limit(mount, config["runtime"])
        mount, _ = apply_local_j2_tilt_limit(mount, config["runtime"])
    minimum_depth_mm = float(loaded.record["safety"]["minimum_camera_target_depth_mm"])
    maximum_depth_mm = float(loaded.record["safety"]["maximum_camera_target_depth_mm"])
    alignment = dict(config["alignment"])
    support_up = unit_vector(
        scan["support_plane_frame"]["support_up_normal_base"],
        "support_up_normal_base",
    )
    axis_u, axis_v = support_plane_basis(support_up)

    hub_record = deployment_plan["joint_path"][-1]
    if hub_record["name"] != "right_observe":
        raise RuntimeError("deployment plan does not end at right_observe")
    hub_q = finite_vector(hub_record["q"], 6, "right_observe q")
    tcp_kinematics = Kinematics(verbose=False)
    flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
    hub_pose = finite_vector(tcp_kinematics.fk(hub_q.tolist()), 7, "hub TCP pose")

    from S1_SDK.hardware.collision import CollisionChecker

    checker = CollisionChecker("gripper")
    if checker.model is None:
        checker._load_model(gripper=True)
    if checker.model is None or checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")
    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    side_scale = float(
        deployment_plan["motion"]["tilt_compensation"]["side_deploy_scale"]
    )
    torque_limits = mount["diagnostic"]["correction_absolute_limits_nm"]
    motion_support_up = support_up
    if args.grasp_search:
        # Search spokes run before the target-based support-normal update.
        motion_support_up = commander_from_mount_record(
            tilt_model, mount, side_scale
        ).nominal_support_up_normal_base

    universe_points = [
        point
        for point in scan["points"]
        if point.get(
            "any_orientation_grasp_geometry_pass"
            if args.grasp_search else "all_orientations_grasp_geometry_pass"
        ) is True
    ]
    universe = {
        f"u{float(point['u_offset_mm']):+.0f}_v{float(point['v_offset_mm']):+.0f}"
        for point in universe_points
    }
    if not universe:
        raise RuntimeError("workspace scan contains no complete grasp candidates")

    u_offsets = parse_values(args.u_offsets_mm, "u offsets")
    v_offsets = parse_values(args.v_offsets_mm, "v offsets")
    normal_offsets = parse_values(args.normal_offsets_mm, "normal offsets")
    if args.maximum_views < 1 or args.maximum_views > 12:
        raise ValueError("maximum-views must be within [1, 12]")
    if not 20.0 <= float(args.roi_margin_px) <= 80.0:
        raise ValueError("roi-margin-px must be within [20, 80]")

    print("OFFLINE_ONLY = True")
    print("ARM_SERIAL_ACCESS = False")
    print("CAMERA_ACCESS = False")
    print("UNIVERSE_POINT_COUNT =", len(universe))
    print("CANDIDATE_GRID =", [u_offsets, v_offsets, normal_offsets])

    candidates = []
    rejected = []
    for u_mm in u_offsets:
        for v_mm in v_offsets:
            for normal_mm in normal_offsets:
                name = candidate_name(u_mm, v_mm, normal_mm)
                target_pose = hub_pose.copy()
                target_pose[:3] += (
                    (u_mm / 1000.0) * axis_u
                    + (v_mm / 1000.0) * axis_v
                    + (normal_mm / 1000.0) * support_up
                )
                try:
                    tcp_path = cartesian_line(
                        hub_pose,
                        target_pose,
                        float(args.cartesian_step_mm),
                    )
                    ik = solve_continuous_ik_path(
                        tcp_kinematics,
                        hub_q.tolist(),
                        tcp_path,
                        maximum_joint_step_rad=float(
                            alignment["maximum_joint_step_rad"]
                        ),
                        minimum_joint_margin_deg=float(
                            alignment["minimum_joint_margin_deg"]
                        ),
                        maximum_fk_position_error_mm=float(
                            alignment["maximum_fk_position_error_mm"]
                        ),
                        maximum_fk_orientation_error_deg=float(
                            alignment["maximum_fk_orientation_error_deg"]
                        ),
                    )
                    joint_path = ik["joint_path"]
                    dense_path = densify_joint_path(
                        joint_path,
                        float(alignment["collision_step_rad"]),
                    )
                    collision = check_collision_path(
                        checker,
                        joint_path,
                        float(alignment["collision_step_rad"]),
                    )
                    torque = validate_torque_envelope(
                        dense_path,
                        lambda q: side_scale
                        * differential_tilt_compensation_from_support_up(
                            tilt_model,
                            q,
                            motion_support_up,
                        ),
                        torque_limits,
                    )
                    envelope = go2_envelope_check(
                        checker,
                        dense_path,
                        deployment_source,
                    )
                    if not envelope["pass"]:
                        raise RuntimeError(
                            "Go2 envelope rejected candidate: "
                            + ",".join(
                                sorted({item["reason"] for item in envelope["violations"]})
                            )
                        )
                    final_q = finite_vector(joint_path[-1], 6, "candidate final q")
                    transform_base_camera = dynamic_base_camera(
                        flange_kinematics.fk(final_q.tolist()),
                        loaded.transform_flange_camera,
                    )
                    coverage = []
                    projections = {}
                    for point in universe_points:
                        point_id = (
                            f"u{float(point['u_offset_mm']):+.0f}_"
                            f"v{float(point['v_offset_mm']):+.0f}"
                        )
                        projection = detector_projection(
                            np.asarray(point["target_top_base_xyz_mm"], dtype=float)
                            / 1000.0,
                            transform_base_camera,
                            intrinsics,
                            detector_roi,
                            float(args.roi_margin_px),
                            minimum_depth_mm,
                            maximum_depth_mm,
                        )
                        projections[point_id] = projection
                        if projection["visible"]:
                            coverage.append(point_id)
                    path_cost = sum(
                        max(abs(float(a) - float(b)) for a, b in zip(q0, q1))
                        for q0, q1 in zip(joint_path[:-1], joint_path[1:])
                    )
                    candidates.append(
                        {
                            "name": name,
                            "offset_support_plane_mm": [u_mm, v_mm, normal_mm],
                            "offset_norm_mm": math.sqrt(
                                u_mm * u_mm + v_mm * v_mm + normal_mm * normal_mm
                            ),
                            "tcp_pose_xyz_xyzw": target_pose.tolist(),
                            "q_rad": final_q.tolist(),
                            "path_from_hub_q_rad": joint_path,
                            "path_cost_rad": path_cost,
                            "minimum_joint_margin_deg": min(
                                float(item["minimum_joint_margin_deg"])
                                for item in ik.get("samples", [])
                            )
                            if ik.get("samples")
                            else None,
                            "collision_sample_count": int(collision["sample_count"]),
                            "go2_envelope_sample_count": int(
                                envelope["sample_count"]
                            ),
                            "maximum_torque_fraction": float(
                                torque["maximum_limit_fraction"]
                            ),
                            "transform_base_camera": np.asarray(
                                transform_base_camera,
                                dtype=float,
                            ).tolist(),
                            "covered_point_ids": sorted(coverage),
                            "coverage_count": len(coverage),
                            "projections": projections,
                        }
                    )
                    print(
                        "CANDIDATE_PASS ="
                        f" {name} coverage={len(coverage)}/{len(universe)}"
                        f" torque={float(torque['maximum_limit_fraction']):.3f}"
                    )
                except Exception as exc:
                    rejected.append(
                        {
                            "name": name,
                            "offset_support_plane_mm": [u_mm, v_mm, normal_mm],
                            "failure_type": type(exc).__name__,
                            "failure": str(exc),
                        }
                    )
                    print("CANDIDATE_REJECT =", name, type(exc).__name__, str(exc))

    point_priorities = {
        f"u{float(point['u_offset_mm']):+.0f}_v{float(point['v_offset_mm']):+.0f}": (
            2 * (not point["fixed_observation"]["fixed_observation_visible"])
            + (not point["fixed_observation"]["center_inside_detector_roi"])
        )
        for point in universe_points
    } if args.grasp_search else {}
    selected = greedy_cover(
        candidates,
        universe,
        int(args.maximum_views),
        candidate_name(0.0, 0.0, 0.0),
        point_priorities=point_priorities,
        reserve_backup_view=args.grasp_search,
    )
    covered = set()
    for item in selected:
        covered.update(item["covered_point_ids"])
    uncovered = sorted(universe - covered)
    usable = bool(selected) and (
        len(selected) > 1 if args.grasp_search else not uncovered
    )
    status = (
        "offline_multiview_scan_candidate_pending_physical_validation"
        if usable
        else "offline_multiview_scan_incomplete"
    )
    selected_compact = []
    for index, item in enumerate(selected, start=1):
        compact = {
            key: value
            for key, value in item.items()
            if key != "projections"
        }
        compact["visit_order"] = index
        selected_compact.append(compact)

    plan = {
        "schema_version": 1,
        "mode": "go2_right_multiview_observation_scan_offline_plan",
        "status": status,
        "grasp_search": args.grasp_search,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "arm_serial_access": False,
        "camera_access": False,
        "baseline_run": str(baseline_path),
        "baseline_run_sha256": file_sha256(baseline_path),
        "workspace_scan": str(scan_path),
        "workspace_scan_sha256": file_sha256(scan_path),
        "flow_config": str(config_path),
        "flow_config_sha256": file_sha256(config_path),
        "deployment_plan": str(plan_path),
        "deployment_plan_sha256": file_sha256(plan_path),
        "wrist_config": str(wrist_path),
        "wrist_config_sha256": file_sha256(wrist_path),
        "mount_config": str(mount_path),
        "mount_config_sha256": file_sha256(mount_path),
        "route_policy": "deploy_to_right_observe_then_reversible_hub_and_spoke",
        "hub": {
            "name": "right_observe",
            "q_rad": hub_q.tolist(),
            "tcp_pose_xyz_xyzw": hub_pose.tolist(),
        },
        "support_plane_frame": scan["support_plane_frame"],
        "detector_visibility_model": {
            "roi_px": list(detector_roi),
            "roi_center_margin_px": float(args.roi_margin_px),
            "depth_range_mm": [minimum_depth_mm, maximum_depth_mm],
            "warning": (
                "center/depth pinhole coverage only; occlusion, reflection and "
                "actual detector confidence require physical validation"
            ),
        },
        "universe_point_ids": sorted(universe),
        "selected_views": selected_compact,
        "covered_point_ids": sorted(covered),
        "uncovered_point_ids": uncovered,
        "covered_priority_point_ids": sorted(
            point for point in covered if point_priorities.get(point, 0)
        ),
        "candidate_count": len(candidates),
        "rejected_candidate_count": len(rejected),
        "unmodelled_external_obstacles": deployment_plan[
            "external_environment_model"
        ]["unmodelled_external_obstacles"],
        "restrictions": [
            "scan_only",
            "settled_capture_only",
            "no_center_alignment",
            "no_orientation_change",
            "no_descent",
            "no_gripper_command",
            "no_lift",
            "no_box_place",
        ] if not args.grasp_search else [
            "settled_capture_only",
            "grasp_motion_uses_live_flow_planner",
        ],
    }
    output_plan.parent.mkdir(parents=True, exist_ok=True)
    output_plan.write_text(
        json.dumps(plan, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    report = {
        "schema_version": 1,
        "status": (
            "OFFLINE_MULTIVIEW_SCAN_PASS"
            if usable
            else "OFFLINE_MULTIVIEW_SCAN_REJECT"
        ),
        "source_plan": str(output_plan),
        "source_plan_sha256": file_sha256(output_plan),
        "candidate_count": len(candidates),
        "rejected_candidates": rejected,
        "selected_view_count": len(selected),
        "selected_view_names": [item["name"] for item in selected],
        "universe_point_count": len(universe),
        "covered_point_count": len(covered),
        "uncovered_point_ids": uncovered,
        "self_collision_ok": True,
        "go2_phase_envelope_ok": True,
        "tilt_torque_cap_ok": True,
        "warning": (
            "offline evidence only; Go2 body is a conservative envelope and the "
            "box, cables, soft supports and people are not fully modelled"
        ),
    }
    output_report.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print("SELECTED_VIEW_COUNT =", len(selected))
    print("SELECTED_VIEWS =", [item["name"] for item in selected])
    print("COVERED_POINT_COUNT =", len(covered), "/", len(universe))
    print("UNCOVERED_POINT_IDS =", uncovered)
    print("PLAN_SAVED =", output_plan)
    print("REPORT_SAVED =", output_report)
    print("RESULT =", report["status"])
    return 0 if report["status"] == "OFFLINE_MULTIVIEW_SCAN_PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
