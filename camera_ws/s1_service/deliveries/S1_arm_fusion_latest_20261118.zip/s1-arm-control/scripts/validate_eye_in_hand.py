#!/usr/bin/env python3
"""Offline holdout validation for a wrist-mounted D455 hand-eye candidate."""
from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
import sys

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
for import_path in (PROJECT_ROOT, SCRIPTS_DIR):
    if str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from s1_control.hand_eye import (
    fixed_reference_residuals,
    fixed_target_residuals,
    invert_transform,
    rotation_angle_deg,
    sample_motion_diversity,
    validate_transform,
)
from solve_eye_in_hand import (
    file_sha256,
    load_training_samples,
    resolve_path,
    write_json,
)


DEFAULT_CALIBRATION_CONFIG = (
    PROJECT_ROOT / "config" / "eye_in_hand_calibration.json"
)
DEFAULT_VALIDATION_CONFIG = (
    PROJECT_ROOT / "config" / "eye_in_hand_validation.json"
)
DEFAULT_CANDIDATE = (
    PROJECT_ROOT / "calibration" / "eye_in_hand_camera_candidate.json"
)


def load_json(path: Path, description: str) -> dict:
    if not path.is_file():
        raise FileNotFoundError(f"missing {description}: {path}")
    record = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(record, dict):
        raise ValueError(f"{description} must be a JSON object: {path}")
    return record


def load_bound_candidate(
    candidate_path: Path,
    calibration_config_path: Path,
    calibration_config: dict,
) -> dict:
    candidate = load_json(candidate_path, "candidate calibration")
    if candidate.get("quantity") != "T_flange_camera":
        raise ValueError("candidate quantity must be T_flange_camera")
    if candidate.get("status") not in {
        "candidate_pending_physical_validation",
        "physically_validated",
    }:
        raise RuntimeError(f"unsupported candidate status: {candidate.get('status')!r}")
    provenance = candidate.get("provenance")
    if not isinstance(provenance, dict):
        raise ValueError("candidate provenance is missing")

    current_config_hash = file_sha256(calibration_config_path)
    if provenance.get("config_sha256") != current_config_hash:
        raise RuntimeError("candidate does not match the current calibration config")
    if str(provenance.get("camera_serial")) != str(
        calibration_config["camera_serial"]
    ):
        raise RuntimeError("candidate camera serial does not match calibration config")
    if provenance.get("checkerboard") != calibration_config.get("checkerboard"):
        raise RuntimeError("candidate checkerboard does not match calibration config")

    raw_sessions = provenance.get("sessions")
    if raw_sessions is None:
        raw_sessions = [provenance.get("session")]
    if (
        not isinstance(raw_sessions, list)
        or not raw_sessions
        or not all(isinstance(value, str) and value for value in raw_sessions)
    ):
        raise ValueError("candidate training session provenance is invalid")
    training_sessions = [resolve_path(value) for value in raw_sessions]

    return {
        "record": candidate,
        "T_flange_camera": validate_transform(
            candidate["value_T_flange_camera"], "candidate.T_flange_camera"
        ),
        "T_base_target": validate_transform(
            provenance["T_base_target_estimate"],
            "candidate.provenance.T_base_target_estimate",
        ),
        "training_sessions": training_sessions,
        "config_sha256": current_config_hash,
    }


def nearest_training_pose(
    validation_pose: np.ndarray,
    training_poses: list[np.ndarray],
    minimum_translation_mm: float,
    minimum_rotation_deg: float,
) -> dict:
    if not training_poses:
        raise ValueError("training pose list is empty")
    candidates = []
    for index, training_pose in enumerate(training_poses):
        delta = invert_transform(training_pose) @ validation_pose
        translation_mm = 1000.0 * float(np.linalg.norm(delta[:3, 3]))
        rotation_deg = rotation_angle_deg(delta[:3, :3])
        normalized_distance = max(
            translation_mm / minimum_translation_mm,
            rotation_deg / minimum_rotation_deg,
        )
        candidates.append(
            {
                "training_sample_index": index,
                "translation_difference_mm": translation_mm,
                "rotation_difference_deg": rotation_deg,
                "normalized_distance": normalized_distance,
            }
        )
    nearest = min(candidates, key=lambda item: item["normalized_distance"])
    nearest["novel"] = bool(nearest["normalized_distance"] >= 1.0)
    return nearest


def validation_failures(
    quality: dict,
    samples: list[dict],
    diversity: dict,
    novelty: list[dict],
    residual_summary: dict,
    maximum_reprojection_rms_px: float,
) -> list[str]:
    reasons = []
    if len(samples) < int(quality["minimum_samples"]):
        reasons.append(
            f"sample_count={len(samples)} < minimum={quality['minimum_samples']}"
        )
    if diversity["maximum_pairwise_rotation_deg"] < float(
        quality["minimum_max_pairwise_rotation_deg"]
    ):
        reasons.append(
            "maximum_pairwise_rotation_deg="
            f"{diversity['maximum_pairwise_rotation_deg']:.3f} is insufficient"
        )
    if diversity["maximum_pairwise_translation_mm"] < float(
        quality["minimum_max_pairwise_translation_mm"]
    ):
        reasons.append(
            "maximum_pairwise_translation_mm="
            f"{diversity['maximum_pairwise_translation_mm']:.3f} is insufficient"
        )
    if diversity["informative_rotation_pair_count"] < int(
        quality["minimum_informative_rotation_pairs"]
    ):
        reasons.append(
            "informative_rotation_pair_count="
            f"{diversity['informative_rotation_pair_count']} is insufficient"
        )
    for index, item in enumerate(novelty):
        if not item["novel"]:
            reasons.append(
                f"validation_sample_{index + 1} is too close to training sample "
                f"{item['training_sample_index'] + 1}"
            )
    for sample in samples:
        if sample["record"]["observation"].get("accepted") is not True:
            reasons.append(f"{sample['path'].name} was not accepted during capture")
        if sample["reprojection_rms_px"] > maximum_reprojection_rms_px:
            reasons.append(
                f"{sample['path'].name} reprojection_rms_px="
                f"{sample['reprojection_rms_px']:.4f} > "
                f"{maximum_reprojection_rms_px:.4f}"
            )
    comparisons = (
        ("translation_rms_mm", "maximum_translation_rms_mm"),
        ("translation_max_mm", "maximum_translation_max_mm"),
        ("rotation_rms_deg", "maximum_rotation_rms_deg"),
        ("rotation_max_deg", "maximum_rotation_max_deg"),
    )
    for metric_name, limit_name in comparisons:
        value = float(residual_summary[metric_name])
        limit = float(quality[limit_name])
        if value > limit:
            reasons.append(f"{metric_name}={value:.4f} > {limit_name}={limit:.4f}")
    return reasons


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "用一个或多个新会话离线验证T_flange_camera候选；"
            "不访问相机、串口或机械臂"
        )
    )
    parser.add_argument(
        "--session",
        action="append",
        required=True,
        help="新采集的留出验证会话；可重复传入以合并多个独立会话",
    )
    parser.add_argument("--candidate", default=str(DEFAULT_CANDIDATE))
    parser.add_argument(
        "--calibration-config", default=str(DEFAULT_CALIBRATION_CONFIG)
    )
    parser.add_argument("--validation-config", default=str(DEFAULT_VALIDATION_CONFIG))
    parser.add_argument(
        "--output",
        help="默认写入第一个验证会话/validation_report.json",
    )
    parser.add_argument(
        "--allow-base-target-relocation",
        action="store_true",
        help=(
            "允许训练与验证之间整体移动S1基座；在全部验证会话内重新拟合一个"
            "固定T_base_target，同时单独报告相对训练参考的刚体位移"
        ),
    )
    parser.add_argument("--overwrite", action="store_true")
    return parser


def resolve_validation_sessions(raw_sessions: list[str]) -> list[Path]:
    session_dirs = [resolve_path(value) for value in raw_sessions]
    normalized = [str(path) for path in session_dirs]
    if len(set(normalized)) != len(normalized):
        raise ValueError("validation sessions must be distinct")
    return session_dirs


def evaluate_candidate_residuals(
    validation_poses: list[np.ndarray],
    camera_targets: list[np.ndarray],
    flange_camera: np.ndarray,
    training_base_target: np.ndarray,
    *,
    allow_base_target_relocation: bool,
) -> dict:
    """Evaluate a candidate with either a fixed or refit base-target reference."""
    if allow_base_target_relocation:
        validation_base_target, details, summary = fixed_target_residuals(
            validation_poses,
            camera_targets,
            flange_camera,
        )
        enriched_details = []
        for pose, camera_target, detail in zip(
            validation_poses, camera_targets, details
        ):
            predicted = pose @ flange_camera @ camera_target
            signed_base_translation_mm = 1000.0 * (
                predicted[:3, 3] - validation_base_target[:3, 3]
            )
            enriched_details.append(
                {
                    **detail,
                    "translation_error_base_xyz_mm": (
                        signed_base_translation_mm.tolist()
                    ),
                    "predicted_T_base_target": predicted.tolist(),
                }
            )
        details = enriched_details
        reference_mode = "validation_session_refit"
    else:
        validation_base_target = np.asarray(
            training_base_target, dtype=np.float64
        ).copy()
        details, summary = fixed_reference_residuals(
            validation_poses,
            camera_targets,
            flange_camera,
            training_base_target,
        )
        reference_mode = "training_reference_fixed"

    reference_delta = (
        invert_transform(training_base_target) @ validation_base_target
    )
    return {
        "reference_mode": reference_mode,
        "T_base_target": validation_base_target,
        "details": details,
        "summary": summary,
        "shift_from_training_translation_mm": 1000.0
        * float(np.linalg.norm(reference_delta[:3, 3])),
        "shift_from_training_rotation_deg": rotation_angle_deg(
            reference_delta[:3, :3]
        ),
    }


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    validation_session_dirs = resolve_validation_sessions(args.session)
    primary_session_dir = validation_session_dirs[0]
    candidate_path = resolve_path(args.candidate)
    calibration_config_path = resolve_path(args.calibration_config)
    validation_config_path = resolve_path(args.validation_config)
    output_path = (
        resolve_path(args.output)
        if args.output
        else primary_session_dir / "validation_report.json"
    )
    if output_path.exists() and not args.overwrite:
        raise FileExistsError(f"{output_path} already exists; pass --overwrite to replace")

    calibration_config = load_json(
        calibration_config_path, "calibration config"
    )
    quality = load_json(validation_config_path, "validation config")
    candidate = load_bound_candidate(
        candidate_path, calibration_config_path, calibration_config
    )
    training_sessions = candidate["training_sessions"]
    overlapping_sessions = [
        path for path in validation_session_dirs if path in training_sessions
    ]
    if overlapping_sessions:
        raise RuntimeError("validation session must differ from all training sessions")

    training_samples = load_training_samples(
        training_sessions, calibration_config_path, calibration_config
    )
    validation_samples = load_training_samples(
        validation_session_dirs, calibration_config_path, calibration_config
    )
    training_poses = [item["T_base_flange"] for item in training_samples]
    validation_poses = [item["T_base_flange"] for item in validation_samples]
    camera_targets = [item["T_camera_target"] for item in validation_samples]

    minimum_novel_translation_mm = float(
        quality["minimum_novel_translation_mm"]
    )
    minimum_novel_rotation_deg = float(quality["minimum_novel_rotation_deg"])
    if minimum_novel_translation_mm <= 0.0 or minimum_novel_rotation_deg <= 0.0:
        raise ValueError("novelty thresholds must be positive")
    novelty = [
        nearest_training_pose(
            pose,
            training_poses,
            minimum_novel_translation_mm,
            minimum_novel_rotation_deg,
        )
        for pose in validation_poses
    ]
    diversity = sample_motion_diversity(validation_poses)
    residual_evaluation = evaluate_candidate_residuals(
        validation_poses,
        camera_targets,
        candidate["T_flange_camera"],
        candidate["T_base_target"],
        allow_base_target_relocation=args.allow_base_target_relocation,
    )
    residual_details = residual_evaluation["details"]
    residual_summary_object = residual_evaluation["summary"]
    residual_summary = residual_summary_object.to_dict()
    signed_translation_errors = np.asarray(
        [item["translation_error_base_xyz_mm"] for item in residual_details],
        dtype=np.float64,
    )
    mean_signed_translation_error_mm = (
        np.mean(signed_translation_errors, axis=0).tolist()
        if len(signed_translation_errors)
        else [float("nan")] * 3
    )
    maximum_reprojection_rms_px = float(
        calibration_config["capture_quality"]["maximum_reprojection_rms_px"]
    )
    failures = validation_failures(
        quality,
        validation_samples,
        diversity,
        novelty,
        residual_summary,
        maximum_reprojection_rms_px,
    )

    per_sample = []
    for sample, residual, nearest in zip(
        validation_samples, residual_details, novelty
    ):
        per_sample.append(
            {
                "sample": str(sample["path"].relative_to(PROJECT_ROOT)),
                "sha256": file_sha256(sample["path"]),
                "reprojection_rms_px": sample["reprojection_rms_px"],
                "nearest_training_pose": nearest,
                **residual,
            }
        )
    report = {
        "schema_version": 1,
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "pass" if not failures else "fail",
        "mode": "eye_in_hand_holdout_validation",
        "hardware_access": False,
        "candidate": str(candidate_path.relative_to(PROJECT_ROOT)),
        "candidate_sha256": file_sha256(candidate_path),
        "candidate_status": candidate["record"]["status"],
        "training_sessions": [
            str(path.relative_to(PROJECT_ROOT)) for path in training_sessions
        ],
        "validation_session": str(primary_session_dir.relative_to(PROJECT_ROOT)),
        "validation_sessions": [
            str(path.relative_to(PROJECT_ROOT))
            for path in validation_session_dirs
        ],
        "calibration_config": str(
            calibration_config_path.relative_to(PROJECT_ROOT)
        ),
        "calibration_config_sha256": candidate["config_sha256"],
        "validation_config": str(validation_config_path.relative_to(PROJECT_ROOT)),
        "validation_config_sha256": file_sha256(validation_config_path),
        "sample_count": len(validation_samples),
        "motion_diversity": diversity,
        "base_target_reference_mode": residual_evaluation["reference_mode"],
        "validation_T_base_target_estimate": residual_evaluation[
            "T_base_target"
        ].tolist(),
        "base_target_shift_from_training": {
            "translation_mm": residual_evaluation[
                "shift_from_training_translation_mm"
            ],
            "rotation_deg": residual_evaluation[
                "shift_from_training_rotation_deg"
            ],
        },
        "residual_summary": residual_summary,
        "mean_signed_translation_error_base_xyz_mm": (
            mean_signed_translation_error_mm
        ),
        "per_sample": per_sample,
        "quality_failures": failures,
        "physical_validity_assumption": (
            "checkerboard and S1 base remained fixed within all validation "
            "sessions; one new T_base_target was refit after an explicitly "
            "allowed rigid relocation between training and validation"
            if args.allow_base_target_relocation
            else (
                "checkerboard and S1 base remained fixed from training "
                "through validation"
            )
        ),
    }
    write_json(output_path, report)

    print("OFFLINE_ONLY = True")
    print("NO_CAMERA_OR_ARM_ACCESS = True")
    print("TRAINING_SESSIONS =", training_sessions)
    print("VALIDATION_SESSIONS =", validation_session_dirs)
    print("CANDIDATE_STATUS =", candidate["record"]["status"])
    print("SAMPLE_COUNT =", len(validation_samples))
    print("MOTION_DIVERSITY =", diversity)
    print(
        "BASE_TARGET_REFERENCE_MODE =",
        residual_evaluation["reference_mode"],
    )
    print(
        "BASE_TARGET_SHIFT_FROM_TRAINING_MM =",
        residual_evaluation["shift_from_training_translation_mm"],
    )
    print(
        "BASE_TARGET_ROTATION_FROM_TRAINING_DEG =",
        residual_evaluation["shift_from_training_rotation_deg"],
    )
    for item in per_sample:
        nearest = item["nearest_training_pose"]
        print(
            f"SAMPLE {Path(item['sample']).name}: "
            f"translation={item['translation_error_mm']:.3f}mm "
            f"rotation={item['rotation_error_deg']:.3f}deg "
            f"novel={nearest['novel']}"
        )
    print("RESIDUAL_SUMMARY =", residual_summary)
    print(
        "MEAN_SIGNED_TRANSLATION_ERROR_BASE_XYZ_MM =",
        mean_signed_translation_error_mm,
    )
    print("REPORT_SAVED =", output_path)
    if failures:
        for reason in failures:
            print("QUALITY_REJECT =", reason)
        print("VALIDATION_RESULT = REJECTED")
        return 2
    print("VALIDATION_RESULT = HOLDOUT_PASS_PENDING_HIGH_HOVER_TEST")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
