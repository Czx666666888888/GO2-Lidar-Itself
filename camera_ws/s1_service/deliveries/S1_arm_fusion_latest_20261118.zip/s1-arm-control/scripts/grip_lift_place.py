# -*- coding: utf-8 -*-
"""通用目标抓取执行器：接近→夹取→小幅提升→放回→撤离。

默认模式是【真正离线】：只做 FK、参数与路点增量检查，不构造 ``Arm``，
不访问串口，也不会在退出时失能。只有显式传入 ``--execute`` 才会连接
机械臂；连接前仍要求操作者确认电机常红、机械臂有软支撑。

目标物参数来自 ``config/grasp_targets.yaml``。原瓶盖流程保留为 ``cap31``，
50 mm PLA 方块为 ``cube50``。方块参数在实物标定前均属于 provisional。

首次方块测试顺序：
  1. --hover-only 离线检查；
  2. --hover-only --execute 空载往返；
  3. --alignment-only 开爪到grasp保持后张开撤回，绝不合爪；
  4. --contact-only 只合爪判定后张开撤回，绝不提升；
  5. 接触判据验证后，完整抓取才允许提升 20~30 mm。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from s1_control.arm import Arm, SafetyLimits  # noqa: E402
from s1_control.adaptive_grasp import (  # noqa: E402
    ContactDetector,
    load_empty_baseline,
    load_probe_parameters,
    window_closing_speed_mm_s,
)
from s1_control.calib import load_grasp_targets  # noqa: E402
from s1_control.gripper import Gripper  # noqa: E402
from s1_control.kinematics import Kinematics, READY_Q  # noqa: E402
from scripts.gripper_contact_probe import BenchRunner  # noqa: E402


S1_JOINT_LIMITS_RAD = [
    (math.radians(-170.0), math.radians(170.0)),
    (math.radians(0.0), math.radians(180.0)),
    (math.radians(0.0), math.radians(170.0)),
    (math.radians(-90.0), math.radians(87.0)),
    (math.radians(-90.0), math.radians(90.0)),
    (math.radians(-90.0), math.radians(90.0)),
]

_ROOT = Path(__file__).resolve().parents[1]
_PLAN_READY_TOLERANCE_RAD = 1e-5
_CONTINUOUS_TRANSIT_TOLERANCE_RAD = 1e-5
_DEFAULT_COLLISION_REPORT = (
    "data/plans/cube50_hover_collision_report.json"
)
_DEFAULT_ADAPTIVE_CONFIG = "config/adaptive_grasp.yaml"
_DEFAULT_ADAPTIVE_BASELINE = "data/adaptive_grasp/empty_baseline.json"
_DEFAULT_V_MAX_RAD_S = {
    "linear": 0.05,
    "s_curve": 0.20,
}
_DEFAULT_J6_V_MAX_RAD_S = 0.10
_MAX_DIAGNOSTIC_LOG_BYTES = 64 * 1024
_START_SAFE_WINDOWS_RAD = [
    (-0.08, 0.08),
    (-0.02, 0.08),
    (-0.02, 0.08),
    (-0.08, 0.12),
    (-0.08, 0.08),
    (-0.08, 0.08),
]
_MAX_START_READY_DELTA_RAD = 1.0
_MAX_START_DRIFT_RAD = 0.02
_MAX_SERIAL_READ_MS = 20.0
_SERIAL_READINESS_DURATION_S = 3.0
_SERIAL_READINESS_PERIOD_S = 0.05
_FIRST_GRASP_MIN_LIFT_MM = 20.0
_FIRST_GRASP_MAX_LIFT_MM = 30.0
_FIRST_GRASP_GEOMETRY_TOLERANCE_MM = 0.001
_FIRST_GRASP_MAX_LATERAL_MM = 8.0
_FIRST_GRASP_MAX_JOINT_DELTA_RAD = 0.5
_MULTI_DESCENT_MIN_TOTAL_MM = 20.0
_MULTI_DESCENT_MAX_TOTAL_MM = 100.0
_MULTI_DESCENT_MAX_STEP_MM = 15.0
_MULTI_DESCENT_MAX_LATERAL_MM = 3.0


def write_execution_diagnostic(raw_path, record):
    """Persist one bounded JSON diagnostic without buffering trajectory data."""
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = _ROOT / path
    path = path.resolve()
    payload = dict(record)
    encoded = json.dumps(
        payload, ensure_ascii=False, indent=2, allow_nan=False
    ) + "\n"
    if len(encoded.encode("utf-8")) > _MAX_DIAGNOSTIC_LOG_BYTES:
        payload["result"] = str(payload.get("result", ""))[:16000]
        if "exception_message" in payload:
            payload["exception_message"] = str(
                payload["exception_message"]
            )[:16000]
        payload["diagnostic_truncated"] = True
        encoded = json.dumps(
            payload, ensure_ascii=False, indent=2, allow_nan=False
        ) + "\n"
    if len(encoded.encode("utf-8")) > _MAX_DIAGNOSTIC_LOG_BYTES:
        payload = {
            "schema_version": payload.get("schema_version", 1),
            "result": str(payload.get("result", ""))[:16000],
            "exception_type": payload.get("exception_type"),
            "exception_message": str(
                payload.get("exception_message", "")
            )[:16000],
            "diagnostic_truncated": True,
        }
        encoded = json.dumps(
            payload, ensure_ascii=False, indent=2, allow_nan=False
        ) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(encoded, encoding="utf-8")
    return path
_MULTI_DESCENT_MAX_JOINT_DELTA_RAD = 0.5
_MAX_COLLISION_SAMPLE_STEP_RAD = 0.02
_MIN_COLLISION_JOINT_MARGIN_DEG = 10.0
# 当前工作台、S1安装与TCP示教的临时下限。示教grasp为-42.375 mm，
# 实测夹爪最低点仍离桌面20~30 mm；换台面、底座、夹爪或TCP后必须重标。
_MIN_COLLISION_TCP_Z_MM = -47.0
_PROVISIONAL_BENCH_NAME = "s1_cube50_bench_v1"


def parse_q(raw: str | None, name: str, required: bool = True) -> list[float] | None:
    if raw is None:
        if required:
            raise ValueError(f"--{name} 必填")
        return None
    q = [float(x) for x in raw.split(",")]
    if len(q) != 6 or not all(math.isfinite(x) for x in q):
        raise ValueError(f"--{name} 需要6个有限数，实际为 {q}")
    return q


def max_delta(q_from: list[float], q_to: list[float]) -> float:
    return max(abs(a - b) for a, b in zip(q_from, q_to))


def resolve_v_max_rad_s(
    motion_profile: str,
    requested_v_max_rad_s: float | None,
) -> float:
    """Resolve the CLI speed without accelerating legacy linear runs."""
    if motion_profile not in _DEFAULT_V_MAX_RAD_S:
        raise ValueError(f"未知运动曲线: {motion_profile}")
    value = (
        _DEFAULT_V_MAX_RAD_S[motion_profile]
        if requested_v_max_rad_s is None
        else float(requested_v_max_rad_s)
    )
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError("--v-max-rad-s 必须是大于0的有限数")
    return value


def resolve_j6_v_max_rad_s(
    requested_j6_v_max_rad_s: float | None,
) -> float:
    """Resolve the independent planned J6 peak-speed limit."""
    value = (
        _DEFAULT_J6_V_MAX_RAD_S
        if requested_j6_v_max_rad_s is None
        else float(requested_j6_v_max_rad_s)
    )
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError("--j6-v-max-rad-s 必须是大于0的有限数")
    return value


def _plan_q(raw, name: str) -> list[float]:
    if not isinstance(raw, list) or len(raw) != 6:
        raise ValueError(f"计划路点 {name} 的q必须是6元素数组")
    try:
        q = [float(value) for value in raw]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"计划路点 {name} 的q包含非数值") from exc
    if not all(math.isfinite(value) for value in q):
        raise ValueError(f"计划路点 {name} 的q包含NaN或Inf")
    return q


def route_from_plan_record(plan: dict) -> tuple[
    list[float] | None,
    list[float],
    list[tuple[str, list[float]]],
    list[float] | None,
    list[str],
]:
    """从规划记录提取接近、高位预对准、分段下降和抓取路点。

    当前正式支持两种路径：``ready -> hover``，以及
    ``ready -> midpoint/approach -> hover/standoff -> descent_XX -> grasp``。
    hover前仍最多一个中间路点；hover后的下降点必须从01连续编号。
    """
    if not isinstance(plan, dict):
        raise ValueError("计划JSON根节点必须是对象")
    raw_path = plan.get("joint_path")
    if not isinstance(raw_path, list) or len(raw_path) < 2:
        raise ValueError("计划必须包含至少两个joint_path路点")

    points: list[tuple[str, list[float]]] = []
    for index, item in enumerate(raw_path):
        if not isinstance(item, dict):
            raise ValueError(f"joint_path[{index}]必须是对象")
        name = str(item.get("name", "")).strip().lower()
        if not name:
            raise ValueError(f"joint_path[{index}]缺少name")
        points.append((name, _plan_q(item.get("q"), name)))

    names = [name for name, _ in points]
    if len(set(names)) != len(names):
        raise ValueError(f"计划路点名称不能重复: {names}")
    if names[0] != "ready":
        raise ValueError(f"计划首路点必须为ready，实际为 {names[0]}")
    if max_delta(points[0][1], list(READY_Q)) > _PLAN_READY_TOLERANCE_RAD:
        raise ValueError("计划中的ready关节角与项目READY_Q不一致")

    standoff_indices = [
        index for index, name in enumerate(names) if name in {"hover", "standoff"}
    ]
    if len(standoff_indices) != 1:
        raise ValueError("计划必须且只能包含一个hover或standoff路点")
    standoff_index = standoff_indices[0]

    intermediate = points[1:standoff_index]
    if len(intermediate) > 1:
        raise ValueError("当前执行器最多支持一个midpoint/approach中间路点")
    if intermediate and intermediate[0][0] not in {"midpoint", "approach"}:
        raise ValueError(
            f"hover前的中间路点必须名为midpoint或approach，实际为 {intermediate[0][0]}"
        )
    approach_q = intermediate[0][1] if intermediate else None
    standoff_q = points[standoff_index][1]

    tail = points[standoff_index + 1:]
    grasp_q = None
    if tail and tail[-1][0] == "grasp":
        grasp_q = tail[-1][1]
        descent_waypoints = tail[:-1]
    else:
        descent_waypoints = tail
    expected_descent_names = [
        f"descent_{index:02d}"
        for index in range(1, len(descent_waypoints) + 1)
    ]
    actual_descent_names = [name for name, _ in descent_waypoints]
    if actual_descent_names != expected_descent_names:
        raise ValueError(
            "hover/standoff后的下降路点必须从descent_01连续编号，"
            f"实际为 {actual_descent_names}"
        )
    return approach_q, standoff_q, descent_waypoints, grasp_q, names


def load_plan_route(raw_path: str) -> tuple[
    Path,
    list[float] | None,
    list[float],
    list[tuple[str, list[float]]],
    list[float] | None,
    list[str],
]:
    plan_path = Path(raw_path).expanduser()
    if not plan_path.is_absolute():
        plan_path = _ROOT / plan_path
    plan_path = plan_path.resolve()
    if not plan_path.is_file():
        raise FileNotFoundError(f"计划文件不存在: {plan_path}")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    (
        approach_q,
        standoff_q,
        descent_waypoints,
        grasp_q,
        names,
    ) = route_from_plan_record(plan)
    return (
        plan_path,
        approach_q,
        standoff_q,
        descent_waypoints,
        grasp_q,
        names,
    )


def _resolve_project_path(raw_path: str) -> Path:
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = _ROOT / path
    return path.resolve()


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_collision_report(
    plan_path: Path, raw_report_path: str
) -> tuple[Path, dict]:
    """验证碰撞报告确实对应当前计划文件，而不只检查一个PASS字符串。"""
    report_path = _resolve_project_path(raw_report_path)
    if not report_path.is_file():
        raise FileNotFoundError(f"碰撞报告不存在: {report_path}")

    report = json.loads(report_path.read_text(encoding="utf-8"))
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    has_multi_descent = any(
        str(item.get("name", "")).lower().startswith("descent_")
        for item in plan.get("joint_path", [])
        if isinstance(item, dict)
    )
    errors = []
    if report.get("schema_version") != 2:
        errors.append("schema_version不是2，请用新版检查器重新生成")
    if report.get("status") != "OFFLINE_MODEL_PASS":
        errors.append("status不是OFFLINE_MODEL_PASS")
    for key in ("hard_limit_ok", "height_ok", "self_collision_ok"):
        if report.get(key) is not True:
            errors.append(f"{key}不是true")
    if report.get("active_collisions") != []:
        errors.append("active_collisions非空")
    if has_multi_descent and report.get("descent_lateral_ok") is not True:
        errors.append("多段下降计划的descent_lateral_ok不是true")
    try:
        sample_count = int(report.get("sample_count", 0))
        sample_step_rad = float(report.get("sample_step_rad", math.inf))
        required_margin_deg = float(
            report.get("required_joint_margin_deg", -math.inf)
        )
        required_min_tcp_z_mm = float(
            report.get("required_min_tcp_z_mm", -math.inf)
        )
        required_max_descent_lateral_mm = float(
            report.get("required_max_descent_lateral_mm", math.inf)
        )
    except (TypeError, ValueError):
        sample_count = 0
        sample_step_rad = math.inf
        required_margin_deg = -math.inf
        required_min_tcp_z_mm = -math.inf
        required_max_descent_lateral_mm = math.inf
        errors.append("报告采样或安全阈值字段不是有效数值")
    if sample_count <= 0:
        errors.append("sample_count无效")
    if (
        not math.isfinite(sample_step_rad)
        or not 0.0 < sample_step_rad <= _MAX_COLLISION_SAMPLE_STEP_RAD
    ):
        errors.append(
            f"sample_step_rad必须在(0, {_MAX_COLLISION_SAMPLE_STEP_RAD}]"
        )
    if (
        not math.isfinite(required_margin_deg)
        or required_margin_deg < _MIN_COLLISION_JOINT_MARGIN_DEG
    ):
        errors.append(
            "required_joint_margin_deg低于"
            f"{_MIN_COLLISION_JOINT_MARGIN_DEG:.1f}deg"
        )
    if (
        not math.isfinite(required_min_tcp_z_mm)
        or required_min_tcp_z_mm < _MIN_COLLISION_TCP_Z_MM
    ):
        errors.append(
            "required_min_tcp_z_mm低于"
            f"{_MIN_COLLISION_TCP_Z_MM:.1f}mm"
        )
    if has_multi_descent and (
        not math.isfinite(required_max_descent_lateral_mm)
        or required_max_descent_lateral_mm > _MULTI_DESCENT_MAX_LATERAL_MM
        or required_max_descent_lateral_mm <= 0.0
    ):
        errors.append(
            "required_max_descent_lateral_mm必须在(0, "
            f"{_MULTI_DESCENT_MAX_LATERAL_MM:.1f}]mm"
        )

    expected_sha256 = file_sha256(plan_path)
    actual_sha256 = report.get("source_plan_sha256")
    if actual_sha256 != expected_sha256:
        errors.append(
            "source_plan_sha256与当前计划不一致，禁止复用旧报告"
        )
    if errors:
        raise ValueError("碰撞报告验证失败: " + "; ".join(errors))
    return report_path, report


def start_pose_window_violations(q: list[float]) -> list[str]:
    if len(q) != len(_START_SAFE_WINDOWS_RAD):
        return [
            f"joint_count={len(q)} expected={len(_START_SAFE_WINDOWS_RAD)}"
        ]

    violations = []
    for index, (value, (lower, upper)) in enumerate(
        zip(q, _START_SAFE_WINDOWS_RAD),
        start=1,
    ):
        if not math.isfinite(value):
            violations.append(f"J{index}=non-finite")
        elif not lower <= value <= upper:
            violations.append(
                f"J{index}={value:.6f}rad allowed=[{lower:.3f},{upper:.3f}]rad"
            )
    return violations


def start_pose_is_safe(q: list[float]) -> bool:
    return not start_pose_window_violations(q)


def temperature_is_safe(
    temperature: list[float],
    expected_count: int = 7,
    max_temperature_c: float = 50.0,
) -> bool:
    return (
        len(temperature) >= expected_count
        and all(math.isfinite(value) for value in temperature)
        and max(temperature) <= max_temperature_c
    )


def serial_numeric_readiness(
    arm: Arm,
    reference_q: list[float],
    duration_s: float = _SERIAL_READINESS_DURATION_S,
) -> dict:
    """低负载检查状态数组、读取耗时和静止漂移。

    S1 SDK 没有暴露底层UART超时计数，因此本检查不能替代操作者观察
    ``motor timeout`` 日志，只能拒绝明显无效或不稳定的数值状态。
    """
    deadline = time.monotonic() + duration_s
    next_tick = time.monotonic()
    samples = 0
    max_read_ms = 0.0
    max_drift_rad = 0.0
    finite_ok = True

    while time.monotonic() < deadline:
        before = time.monotonic()
        position = list(arm.get_pos())
        read_ms = (time.monotonic() - before) * 1000.0
        max_read_ms = max(max_read_ms, read_ms)
        samples += 1

        if len(position) < 7 or not all(
            math.isfinite(value) for value in position
        ):
            finite_ok = False
            break

        drift = max(
            abs(position[index] - reference_q[index])
            for index in range(6)
        )
        max_drift_rad = max(max_drift_rad, drift)

        next_tick += _SERIAL_READINESS_PERIOD_S
        delay = next_tick - time.monotonic()
        if delay > 0.0:
            time.sleep(delay)
        else:
            next_tick = time.monotonic()

    minimum_samples = max(
        1,
        int(duration_s / _SERIAL_READINESS_PERIOD_S) - 10,
    )
    passed = (
        finite_ok
        and samples >= minimum_samples
        and max_read_ms <= _MAX_SERIAL_READ_MS
        and max_drift_rad <= _MAX_START_DRIFT_RAD
    )
    return {
        "passed": passed,
        "samples": samples,
        "max_read_ms": max_read_ms,
        "max_drift_rad": max_drift_rad,
        "finite_ok": finite_ok,
    }


def validate_first_grasp_geometry(
    kin: Kinematics,
    standoff_q: list[float],
    grasp_q: list[float],
) -> dict:
    """限制首次实物抓取只能近似竖直下降并提升20~30 mm。"""
    standoff_xyz_mm = [1000.0 * value for value in kin.fk(standoff_q)[:3]]
    grasp_xyz_mm = [1000.0 * value for value in kin.fk(grasp_q)[:3]]
    lift_mm = standoff_xyz_mm[2] - grasp_xyz_mm[2]
    lateral_mm = math.hypot(
        standoff_xyz_mm[0] - grasp_xyz_mm[0],
        standoff_xyz_mm[1] - grasp_xyz_mm[1],
    )
    joint_delta_rad = max_delta(standoff_q, grasp_q)

    errors = []
    if (
        lift_mm < (
            _FIRST_GRASP_MIN_LIFT_MM
            - _FIRST_GRASP_GEOMETRY_TOLERANCE_MM
        )
        or lift_mm > (
            _FIRST_GRASP_MAX_LIFT_MM
            + _FIRST_GRASP_GEOMETRY_TOLERANCE_MM
        )
    ):
        errors.append(
            f"提升高度{lift_mm:.1f}mm不在"
            f"[{_FIRST_GRASP_MIN_LIFT_MM:.1f}, "
            f"{_FIRST_GRASP_MAX_LIFT_MM:.1f}]mm"
        )
    if lateral_mm > _FIRST_GRASP_MAX_LATERAL_MM:
        errors.append(
            f"水平偏移{lateral_mm:.1f}mm超过"
            f"{_FIRST_GRASP_MAX_LATERAL_MM:.1f}mm"
        )
    if joint_delta_rad > _FIRST_GRASP_MAX_JOINT_DELTA_RAD:
        errors.append(
            f"standoff->grasp关节增量{joint_delta_rad:.3f}rad超过"
            f"{_FIRST_GRASP_MAX_JOINT_DELTA_RAD:.3f}rad"
        )
    if errors:
        raise ValueError("首次抓取几何不安全: " + "; ".join(errors))
    return {
        "lift_mm": lift_mm,
        "lateral_mm": lateral_mm,
        "joint_delta_rad": joint_delta_rad,
        "standoff_xyz_mm": standoff_xyz_mm,
        "grasp_xyz_mm": grasp_xyz_mm,
    }


def validate_multi_descent_geometry(
    kin: Kinematics,
    standoff_q: list[float],
    descent_waypoints: list[tuple[str, list[float]]],
    grasp_q: list[float],
) -> dict:
    """验证动态高位预对准到grasp的分段下降几何。"""
    points = [("standoff", standoff_q)] + list(descent_waypoints) + [
        ("grasp", grasp_q)
    ]
    xyz = {
        name: [1000.0 * value for value in kin.fk(q)[:3]]
        for name, q in points
    }
    grasp_xy = xyz["grasp"][:2]
    total_descent_mm = xyz["standoff"][2] - xyz["grasp"][2]
    maximum_step_mm = 0.0
    maximum_lateral_mm = 0.0
    maximum_joint_delta_rad = 0.0
    errors = []

    if not (
        _MULTI_DESCENT_MIN_TOTAL_MM - _FIRST_GRASP_GEOMETRY_TOLERANCE_MM
        <= total_descent_mm
        <= _MULTI_DESCENT_MAX_TOTAL_MM + _FIRST_GRASP_GEOMETRY_TOLERANCE_MM
    ):
        errors.append(
            f"总下降{total_descent_mm:.1f}mm不在"
            f"[{_MULTI_DESCENT_MIN_TOTAL_MM:.1f}, "
            f"{_MULTI_DESCENT_MAX_TOTAL_MM:.1f}]mm"
        )

    for (name_a, q_a), (name_b, q_b) in zip(points, points[1:]):
        step_mm = xyz[name_a][2] - xyz[name_b][2]
        lateral_mm = math.hypot(
            xyz[name_b][0] - grasp_xy[0],
            xyz[name_b][1] - grasp_xy[1],
        )
        joint_delta_rad = max_delta(q_a, q_b)
        maximum_step_mm = max(maximum_step_mm, step_mm)
        maximum_lateral_mm = max(maximum_lateral_mm, lateral_mm)
        maximum_joint_delta_rad = max(
            maximum_joint_delta_rad, joint_delta_rad
        )
        if step_mm <= 0.0:
            errors.append(f"{name_a}->{name_b}没有严格向下运动")
        elif step_mm > (
            _MULTI_DESCENT_MAX_STEP_MM
            + _FIRST_GRASP_GEOMETRY_TOLERANCE_MM
        ):
            errors.append(
                f"{name_a}->{name_b}下降{step_mm:.1f}mm超过"
                f"{_MULTI_DESCENT_MAX_STEP_MM:.1f}mm"
            )
        if lateral_mm > _MULTI_DESCENT_MAX_LATERAL_MM:
            errors.append(
                f"{name_b}相对grasp横向偏差{lateral_mm:.1f}mm超过"
                f"{_MULTI_DESCENT_MAX_LATERAL_MM:.1f}mm"
            )
        if joint_delta_rad > _MULTI_DESCENT_MAX_JOINT_DELTA_RAD:
            errors.append(
                f"{name_a}->{name_b}关节增量{joint_delta_rad:.3f}rad超过"
                f"{_MULTI_DESCENT_MAX_JOINT_DELTA_RAD:.3f}rad"
            )
    if errors:
        raise ValueError("分段下降几何不安全: " + "; ".join(errors))
    return {
        "total_descent_mm": total_descent_mm,
        "maximum_step_mm": maximum_step_mm,
        "maximum_lateral_mm": maximum_lateral_mm,
        "maximum_joint_delta_rad": maximum_joint_delta_rad,
        "waypoint_count": len(points) - 1,
    }


def validate_execution_mode(
    hover_only: bool,
    contact_only: bool,
    alignment_only: bool,
    has_grasp: bool,
    adaptive_grip: bool = False,
) -> None:
    """拒绝含糊或缺少抓取路点的执行模式组合。"""
    enabled_modes = sum((hover_only, contact_only, alignment_only))
    if enabled_modes > 1:
        raise ValueError(
            "--hover-only、--alignment-only与--contact-only不能同时使用"
        )
    if not hover_only and not has_grasp:
        raise ValueError(
            "接触/完整抓取需要计划包含grasp路点，或使用--grasp-q提供"
        )
    if adaptive_grip and (hover_only or alignment_only):
        raise ValueError(
            "--adaptive-grip只允许用于--contact-only或完整抓取，"
            "不能与--hover-only/--alignment-only组合"
        )


def resolve_parameters(args, profiles: dict) -> dict:
    profile = dict(profiles[args.target_profile])
    overrides = {
        "open_gap_mm": args.open_mm,
        "close_gap_mm": args.close_mm,
        "grip_force_nm": args.grip_force_nm,
        "contact_min_excess_mm": args.contact_min_excess_mm,
    }
    for key, value in overrides.items():
        if value is not None:
            profile[key] = float(value)

    required = (
        "nominal_width_mm",
        "open_gap_mm",
        "close_gap_mm",
        "grip_force_nm",
        "contact_min_excess_mm",
    )
    missing = [key for key in required if key not in profile]
    if missing:
        raise ValueError(f"目标档案 {args.target_profile} 缺少字段: {missing}")
    if not (
        0.0
        < profile["close_gap_mm"]
        < profile["nominal_width_mm"]
        < profile["open_gap_mm"]
        <= 102.2
    ):
        raise ValueError(
            "需要满足 0 < close_gap_mm < nominal_width_mm < "
            "open_gap_mm <= 102.2"
        )
    if not 0.0 < profile["grip_force_nm"] <= 0.4:
        raise ValueError("grip_force_nm 必须在 (0, 0.4] 内")
    if profile["contact_min_excess_mm"] <= 0.0:
        raise ValueError("contact_min_excess_mm 必须大于0")
    return profile


def offline_report(
    kin: Kinematics,
    approach_q: list[float] | None,
    standoff_q: list[float],
    descent_waypoints: list[tuple[str, list[float]]],
    grasp_q: list[float] | None,
    hover_only: bool,
    max_joint_delta_rad: float,
) -> None:
    route = [("READY", list(READY_Q))]
    if approach_q is not None:
        route.append(("approach", approach_q))
    route.append(("standoff", standoff_q))
    if not hover_only:
        assert grasp_q is not None
        route.extend(descent_waypoints)
        route.append(("grasp", grasp_q))

    for name, q in route:
        margins = []
        for index, (value, (lower, upper)) in enumerate(
            zip(q, S1_JOINT_LIMITS_RAD), start=1
        ):
            if not lower <= value <= upper:
                raise ValueError(
                    f"{name} 的J{index}={math.degrees(value):.2f}°超出硬限位 "
                    f"[{math.degrees(lower):.1f}, {math.degrees(upper):.1f}]°"
                )
            margins.append(min(value - lower, upper - value))
        xyz_mm = [round(v * 1000.0, 1) for v in kin.fk(q)[:3]]
        print(
            f"FK({name}) TCP mm = {xyz_mm}  "
            f"min_joint_margin={math.degrees(min(margins)):.2f}deg"
        )

    print("OFFLINE_ROUTE:")
    for (name_a, q_a), (name_b, q_b) in zip(route, route[1:]):
        delta = max_delta(q_a, q_b)
        state = "OK" if delta <= max_joint_delta_rad else "REJECT"
        print(f"  {name_a}->{name_b}: delta={delta:.3f}rad  {state}")
        if delta > max_joint_delta_rad:
            raise ValueError(
                f"{name_a}->{name_b} 关节增量 {delta:.3f}rad 超过 "
                f"{max_joint_delta_rad:.3f}rad；需要增加中间路点"
            )


def guarded_hold(arm: Arm, q: list[float], gap_mm: float, force_nm: float,
                 duration_s: float, label: str, grip: Gripper) -> None:
    """保持关节与夹爪，每拍运行安全闸；异常时抛出并交给 finally 失能。"""
    t0 = time.monotonic()
    settling = True
    while time.monotonic() - t0 < duration_s:
        arm._arm.joint_control_mit(list(q))
        grip.command_mm(gap_mm, force=force_nm)
        elapsed = time.monotonic() - t0
        bad = arm.guard(
            arm.get_pos(),
            list(arm._arm.get_vel()),
            list(arm._arm.get_temp()),
            q,
            settling=settling and elapsed < arm.limits.settle_seconds,
        )
        if bad:
            raise RuntimeError(f"{label}: {bad}")
        time.sleep(arm.dt)


def guarded_move(arm: Arm, q_from: list[float], q_to: list[float], label: str,
                 grip_fb: float, force_nm: float) -> None:
    abort = arm.move(
        q_from,
        q_to,
        label,
        grip_cmd=grip_fb,
        grip_force=force_nm,
    )
    print(("中止:" if abort else "到达:"), label, abort or "")
    if abort:
        raise RuntimeError(abort)


def merge_collinear_approach_route(
    route,
    tolerance_rad: float = _CONTINUOUS_TRANSIT_TOLERANCE_RAD,
):
    """Merge only a collinear ``...->approach->...`` transit pair.

    The merged joint-space line is geometrically identical to the two
    collision-checked source segments. Non-collinear or task waypoints keep
    their original stop-and-go behavior.
    """
    route = list(route)
    merged_route = []
    index = 0
    while index < len(route):
        if index + 1 >= len(route):
            merged_route.append(route[index])
            break

        first = route[index]
        second = route[index + 1]
        q_start, q_middle, first_label = first
        q_middle_again, q_end, second_label = second
        label_pair = (
            first_label.endswith("->approach")
            and second_label.startswith("approach->")
        )
        shared_point_ok = max_delta(q_middle, q_middle_again) <= tolerance_rad
        direct = [end - start for start, end in zip(q_start, q_end)]
        denominator = sum(value * value for value in direct)

        merged = None
        if label_pair and shared_point_ok and denominator > tolerance_rad ** 2:
            offset = [
                middle - start
                for start, middle in zip(q_start, q_middle)
            ]
            alpha = sum(
                value * direction
                for value, direction in zip(offset, direct)
            ) / denominator
            projection = [
                start + alpha * direction
                for start, direction in zip(q_start, direct)
            ]
            projection_error = max_delta(q_middle, projection)
            if 0.0 < alpha < 1.0 and projection_error <= tolerance_rad:
                destination = second_label.split("->", 1)[1]
                merged = (
                    list(q_start),
                    list(q_end),
                    f"{first_label}->{destination}",
                )

        if merged is None:
            merged_route.append(first)
            index += 1
        else:
            merged_route.append(merged)
            index += 2

    return merged_route


def guarded_move_route(
    arm: Arm,
    route,
    grip_fb: float,
    force_nm: float,
) -> None:
    """Execute a route, continuously crossing only verified transit points."""
    for q_from, q_to, label in merge_collinear_approach_route(route):
        if "->approach->" in label:
            print("CONTINUOUS_TRANSIT =", label)
        guarded_move(arm, q_from, q_to, label, grip_fb, force_nm)


def continuous_route_waypoints(
    route,
    tolerance_rad: float = _CONTINUOUS_TRANSIT_TOLERANCE_RAD,
):
    """Convert a contiguous checked route into one ordered waypoint path."""
    route = list(route)
    if not route:
        raise ValueError("连续路径不能为空")
    waypoints = [list(route[0][0])]
    names = [route[0][2].split("->", 1)[0]]
    previous_end = route[0][0]
    for index, (q_from, q_to, label) in enumerate(route):
        if max_delta(previous_end, q_from) > tolerance_rad:
            raise ValueError(f"连续路径第{index + 1}段与前一段不连通")
        waypoints.append(list(q_to))
        names.append(label.rsplit("->", 1)[-1])
        previous_end = q_to
    return waypoints, "->".join(names)


def guarded_move_continuous_route(
    arm: Arm,
    route,
    grip_fb: float,
    force_nm: float,
) -> None:
    """Traverse all checked route segments under one global motion profile."""
    waypoints, label = continuous_route_waypoints(route)
    print("CONTINUOUS_WAYPOINT_PATH =", label)
    abort = arm.move_waypoints(
        waypoints,
        label,
        grip_cmd=grip_fb,
        grip_force=force_nm,
    )
    print(("中止:" if abort else "到达:"), label, abort or "")
    if abort:
        raise RuntimeError(abort)


def safe_open_return(arm: Arm, grip: Gripper, grasp_q: list[float],
                     standoff_q: list[float], approach_q: list[float] | None,
                     start_q: list[float],
                     open_mm: float, force_nm: float,
                     label_prefix: str = "miss",
                     descent_waypoints: list[
                         tuple[str, list[float]]
                     ] | None = None) -> None:
    """不提升时使用：在grasp张开并按已预检路线撤回。"""
    open_fb = grip.mm_to_fb(open_mm)
    guarded_hold(
        arm, grasp_q, open_mm, force_nm, 1.0,
        f"{label_prefix}-open", grip,
    )
    ascent = ascent_route(
        standoff_q,
        descent_waypoints or [],
        grasp_q,
        label_prefix=label_prefix,
    )
    guarded_move_continuous_route(arm, ascent, open_fb, force_nm)
    guarded_move_route(
        arm,
        return_route(standoff_q, approach_q, start_q),
        open_fb,
        force_nm,
    )


def run_alignment_only(
    arm: Arm,
    grip: Gripper,
    grasp_q: list[float],
    standoff_q: list[float],
    approach_q: list[float] | None,
    start_q: list[float],
    open_mm: float,
    force_nm: float,
    hold_s: float,
    descent_waypoints: list[tuple[str, list[float]]] | None = None,
) -> None:
    """开爪保持并撤回；接口中没有close目标，避免误入闭合动作。"""
    print(
        ">>> ALIGNMENT_ONLY：保持开爪检查物块对准；"
        "本次禁止合爪和提升。"
    )
    guarded_hold(
        arm, grasp_q, open_mm, force_nm, hold_s,
        "alignment-hold", grip,
    )
    safe_open_return(
        arm, grip, grasp_q, standoff_q, approach_q, start_q,
        open_mm, force_nm, label_prefix="alignment",
        descent_waypoints=descent_waypoints,
    )


def outward_route(approach_q: list[float] | None, standoff_q: list[float]):
    """READY到standoff的路段；可插入离线规划给出的中间路点。"""
    if approach_q is None:
        return [(list(READY_Q), standoff_q, "ready->standoff")]
    return [
        (list(READY_Q), approach_q, "ready->approach"),
        (approach_q, standoff_q, "approach->standoff"),
    ]


def descent_route(
    standoff_q: list[float],
    descent_waypoints: list[tuple[str, list[float]]],
    grasp_q: list[float],
):
    """高位预对准后依次经过所有下降路点到grasp。"""
    points = [("standoff", standoff_q)] + list(descent_waypoints) + [
        ("grasp", grasp_q)
    ]
    return [
        (q_a, q_b, f"{name_a}->{name_b}")
        for (name_a, q_a), (name_b, q_b) in zip(points, points[1:])
    ]


def ascent_route(
    standoff_q: list[float],
    descent_waypoints: list[tuple[str, list[float]]],
    grasp_q: list[float],
    *,
    label_prefix: str | None = None,
):
    """按下降路径严格反向提升，避免抓取后跨路点直线返回。"""
    points = [("standoff", standoff_q)] + list(descent_waypoints) + [
        ("grasp", grasp_q)
    ]
    points.reverse()
    route = []
    for (name_a, q_a), (name_b, q_b) in zip(points, points[1:]):
        label = f"{name_a}->{name_b}"
        if label_prefix is not None and name_a == "grasp":
            label = f"{label_prefix}->{name_b}"
        route.append((q_a, q_b, label))
    return route


def return_route(standoff_q: list[float], approach_q: list[float] | None,
                 start_q: list[float]):
    """standoff经可选中间路点回READY，再回当次实测起点。"""
    if approach_q is None:
        route = [(standoff_q, list(READY_Q), "standoff->ready")]
    else:
        route = [
            (standoff_q, approach_q, "standoff->approach"),
            (approach_q, list(READY_Q), "approach->ready"),
        ]
    route.append((list(READY_Q), start_q, "ready->start"))
    return route


def load_adaptive_resources(config_path: str, baseline_path: str):
    """加载并绑定自适应参数和空载基线；不访问机械臂。"""
    resolved_config = _resolve_project_path(config_path)
    resolved_baseline = _resolve_project_path(baseline_path)
    parameters = load_probe_parameters(resolved_config)
    baseline = load_empty_baseline(resolved_baseline)
    baseline.assert_compatible(parameters)
    return resolved_config, resolved_baseline, parameters, baseline


def run_adaptive_acquisition(
    runner, parameters, baseline, secure: bool, *, minimum_secure_gap_mm: float | None = None
):
    """在当前抓取姿态探测接触，并按需施加相对预压。

    返回字典供状态机决定是否允许提升。探测失败时绝不执行预压；预压后
    若实际开口没有形成足够的阻挡量，则抛出异常并由上层禁止提升。
    """
    opened = runner.hold(
        parameters.start_gap_mm,
        parameters.secure_force_nm,
        parameters.open_hold_s,
        "adaptive_open",
    )
    open_shortfall_mm = parameters.start_gap_mm - opened.actual_gap_mm
    if open_shortfall_mm > parameters.empty_max_final_excess_mm:
        raise RuntimeError(
            "自适应抓取前夹爪未张开到起始区域: "
            f"actual={opened.actual_gap_mm:.2f}mm"
        )
    print(f"ADAPTIVE_OPEN_READY_GAP_MM = {opened.actual_gap_mm:.2f}")

    stable_samples = runner.probe_until_settled()
    stable_gap_mm = statistics.median(
        sample.actual_gap_mm for sample in stable_samples
    )
    stable_speed_mm_s = window_closing_speed_mm_s(stable_samples)
    stable_range_mm = (
        max(sample.actual_gap_mm for sample in stable_samples)
        - min(sample.actual_gap_mm for sample in stable_samples)
    )
    print(
        "ADAPTIVE_PROBE_SETTLED",
        f"gap={stable_gap_mm:.2f}mm",
        f"speed={stable_speed_mm_s:.3f}mm/s",
        f"range={stable_range_mm:.3f}mm",
    )

    detector = ContactDetector(parameters, baseline)
    decision = None
    for sample in stable_samples:
        decision = detector.update(sample)
    if decision is None or not decision.detected:
        print("ADAPTIVE_CONTACT_RESULT = MISS")
        return {
            "detected": False,
            "contact_gap_mm": None,
            "secure_gap_mm": None,
            "secure_actual_gap_mm": None,
            "secure_valid": False,
        }

    assert decision.contact_gap_mm is not None
    print(
        "ADAPTIVE_CONTACT_RESULT = DETECTED",
        f"gap={decision.contact_gap_mm:.2f}mm",
        f"excess={decision.tracking_excess_mm:.2f}mm",
        f"tau_delta={decision.torque_delta_nm:.6f}",
        f"closing_speed={decision.closing_speed_mm_s}",
    )
    result = {
        "detected": True,
        "contact_gap_mm": decision.contact_gap_mm,
        "secure_gap_mm": None,
        "secure_actual_gap_mm": None,
        "secure_valid": None,
    }
    if not secure:
        return result

    # The probe floor is calibrated with the empty baseline. A smaller object can
    # need a tighter secure command after the probe has already found contact.
    secure_floor_mm = (
        parameters.target_gap_mm
        if minimum_secure_gap_mm is None
        else float(minimum_secure_gap_mm)
    )
    secure_gap_mm = max(
        secure_floor_mm,
        decision.contact_gap_mm - parameters.secure_preload_command_mm,
    )
    secured = runner.hold(
        secure_gap_mm,
        parameters.secure_force_nm,
        parameters.secure_hold_s,
        "adaptive_secure_hold",
    )
    secure_excess_mm = secured.actual_gap_mm - secure_gap_mm
    minimum_secure_excess_mm = (
        baseline.tracking_excess_p99_mm
        + parameters.tracking_margin_over_empty_mm
    )
    secure_valid = secure_excess_mm >= minimum_secure_excess_mm
    print(
        "ADAPTIVE_SECURE_CHECK",
        f"command={secure_gap_mm:.2f}mm",
        f"actual={secured.actual_gap_mm:.2f}mm",
        f"excess={secure_excess_mm:.2f}mm",
        f"minimum={minimum_secure_excess_mm:.2f}mm",
        f"result={'HOLDING' if secure_valid else 'LOST'}",
    )
    result["secure_gap_mm"] = secure_gap_mm
    result["secure_actual_gap_mm"] = secured.actual_gap_mm
    result["secure_valid"] = secure_valid
    return result


def main() -> int:
    profiles = load_grasp_targets()
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev", default="/dev/ttyUSB0")
    ap.add_argument("--end", default="gripper")
    ap.add_argument("--target-profile", choices=sorted(profiles), default="cap31")
    ap.add_argument("--plan", help="规划JSON；自动读取ready/midpoint/hover/[grasp]")
    ap.add_argument(
        "--collision-report",
        default=_DEFAULT_COLLISION_REPORT,
        help="与规划SHA-256绑定的离线碰撞报告",
    )
    ap.add_argument("--approach-q", help="可选中间路点，6关节CSV")
    ap.add_argument("--standoff-q", help="预抓取/提升位姿，6关节CSV")
    ap.add_argument("--grasp-q", help="抓取位姿，6关节CSV；--hover-only 时可省略")
    ap.add_argument("--open-mm", type=float, help="覆盖目标档案的预张开量")
    ap.add_argument("--close-mm", type=float, help="覆盖目标档案的闭合目标")
    ap.add_argument("--grip-force-nm", type=float, help="覆盖目标档案的夹爪力矩")
    ap.add_argument("--contact-min-excess-mm", type=float,
                    help="覆盖实测开口相对闭合命令的最小超差")
    ap.add_argument(
        "--adaptive-grip",
        action="store_true",
        help="使用空载基线连续探测接触尺寸并相对预压；默认仍为固定闭合",
    )
    ap.add_argument(
        "--adaptive-config",
        default=_DEFAULT_ADAPTIVE_CONFIG,
        help="自适应夹爪参数YAML",
    )
    ap.add_argument(
        "--adaptive-baseline",
        default=_DEFAULT_ADAPTIVE_BASELINE,
        help="与自适应参数绑定的空载基线JSON",
    )
    ap.add_argument("--hover-only", action="store_true",
                    help="只到standoff保持后原路返回，不下降、不合爪")
    ap.add_argument(
        "--alignment-only",
        action="store_true",
        help="保持开爪到grasp停留后原路返回，不合爪、不提升",
    )
    ap.add_argument(
        "--contact-only",
        action="store_true",
        help="下降合爪并判定接触后立即张开撤回，绝不提升",
    )
    ap.add_argument("--hold-s", type=float, default=2.0)
    ap.add_argument(
        "--v-max-rad-s",
        type=float,
        default=None,
        help=(
            "最大关节速度rad/s；未指定时linear=0.05、"
            "s_curve=0.20，显式参数优先"
        ),
    )
    ap.add_argument(
        "--j6-v-max-rad-s",
        type=float,
        default=None,
        help=(
            "J6夹爪旋转的独立规划峰值rad/s；未指定时为0.10。"
            "若它比全局速度更严格，会等比例延长整条同步路径"
        ),
    )
    ap.add_argument(
        "--motion-profile",
        choices=("linear", "s_curve"),
        default="linear",
        help="关节插值曲线；linear保持旧行为，s_curve使用限峰值余弦加减速",
    )
    ap.add_argument("--max-joint-delta-rad", type=float, default=1.5)
    ap.add_argument(
        "--diagnostic-log",
        help="可选的小型JSON执行诊断；记录结果与异常，不保存图像或轨迹流",
    )
    ap.add_argument("--execute", action="store_true")
    args = ap.parse_args()

    args.v_max_rad_s = resolve_v_max_rad_s(
        args.motion_profile,
        args.v_max_rad_s,
    )
    args.j6_v_max_rad_s = resolve_j6_v_max_rad_s(
        args.j6_v_max_rad_s,
    )

    if args.hold_s < 0.0:
        raise ValueError("--hold-s 不能小于0")
    if args.max_joint_delta_rad <= 0.0:
        raise ValueError("--max-joint-delta-rad 必须大于0")
    if args.adaptive_grip and any(
        value is not None
        for value in (
            args.open_mm,
            args.close_mm,
            args.grip_force_nm,
            args.contact_min_excess_mm,
        )
    ):
        raise ValueError(
            "--adaptive-grip的开口、探测力矩和预压参数来自"
            "--adaptive-config，不能再用固定夹持覆盖参数"
        )

    q_arguments = (args.approach_q, args.standoff_q, args.grasp_q)
    if args.plan is not None and any(value is not None for value in q_arguments):
        raise ValueError(
            "--plan不能与--approach-q/--standoff-q/--grasp-q混用，"
            "避免计划与命令行路点产生歧义"
        )
    if args.execute and args.plan is None:
        raise ValueError(
            "实机执行必须使用--plan；手工关节角仅允许离线分析"
        )

    plan_path = None
    collision_report_path = None
    if args.plan is not None:
        (
            plan_path,
            approach_q,
            standoff_q,
            descent_waypoints,
            grasp_q,
            plan_names,
        ) = load_plan_route(args.plan)
        print(f"PLAN_FILE = {plan_path}")
        print(f"PLAN_ROUTE = {' -> '.join(plan_names)}")
        collision_report_path, collision_report = verify_collision_report(
            plan_path, args.collision_report
        )
        print(f"COLLISION_REPORT = {collision_report_path}")
        print(f"PLAN_SHA256 = {file_sha256(plan_path)}")
        print("COLLISION_REPORT_VERIFIED = True")
        required_min_z = float(
            collision_report["required_min_tcp_z_mm"]
        )
        if required_min_z < 0.0:
            print(
                "PROVISIONAL_BENCH_HEIGHT_LIMIT = "
                f"{_PROVISIONAL_BENCH_NAME} "
                f"min_tcp_z={required_min_z:.1f}mm"
            )
            print(
                "BENCH_CALIBRATION_INVALIDATES_ON_CHANGE："
                "台面/底座/夹爪/TCP任一变化后必须重标。"
            )
    else:
        approach_q = parse_q(args.approach_q, "approach-q", required=False)
        standoff_q = parse_q(args.standoff_q, "standoff-q")
        descent_waypoints = []
        grasp_q = parse_q(args.grasp_q, "grasp-q", required=False)

    validate_execution_mode(
        args.hover_only,
        args.contact_only,
        args.alignment_only,
        grasp_q is not None,
        adaptive_grip=args.adaptive_grip,
    )
    assert standoff_q is not None
    profile = resolve_parameters(args, profiles)

    adaptive_config_path = None
    adaptive_baseline_path = None
    adaptive_parameters = None
    adaptive_baseline = None
    if args.adaptive_grip:
        (
            adaptive_config_path,
            adaptive_baseline_path,
            adaptive_parameters,
            adaptive_baseline,
        ) = load_adaptive_resources(
            args.adaptive_config,
            args.adaptive_baseline,
        )

    print(f"TARGET_PROFILE = {args.target_profile}")
    print(f"TARGET_STATUS = {profile.get('status', 'unknown')}")
    print(f"NOMINAL_WIDTH_MM = {profile['nominal_width_mm']:.1f}")
    print(f"OPEN/CLOSE_MM = {profile['open_gap_mm']:.1f}/{profile['close_gap_mm']:.1f}")
    print(f"GRIP_FORCE_NM = {profile['grip_force_nm']:.2f}")
    print(f"CONTACT_MIN_EXCESS_MM = {profile['contact_min_excess_mm']:.1f}")
    print("GRIP_MODE =", "adaptive" if args.adaptive_grip else "fixed")
    print("MOTION_PROFILE =", args.motion_profile)
    print(f"V_MAX_RAD_S = {args.v_max_rad_s:.3f}")
    print(f"J6_V_MAX_RAD_S = {args.j6_v_max_rad_s:.3f}")
    if args.adaptive_grip:
        assert adaptive_parameters is not None
        assert adaptive_baseline is not None
        print("ADAPTIVE_CONFIG =", adaptive_config_path)
        print("ADAPTIVE_BASELINE =", adaptive_baseline_path)
        print(
            "ADAPTIVE_PROBE =",
            f"{adaptive_parameters.start_gap_mm:.1f}->"
            f"{adaptive_parameters.target_gap_mm:.1f}mm "
            f"force={adaptive_parameters.probe_force_nm:.2f}",
        )
        print(
            "ADAPTIVE_SECURE =",
            f"contact-{adaptive_parameters.secure_preload_command_mm:.1f}mm "
            f"force={adaptive_parameters.secure_force_nm:.2f}",
        )
    if profile.get("status") != "verified":
        print("PROVISIONAL_TARGET：这些参数只能用于低速、有人看护的首次试验。")

    kin = Kinematics(verbose=True)
    offline_report(
        kin,
        approach_q,
        standoff_q,
        descent_waypoints,
        grasp_q,
        args.hover_only,
        args.max_joint_delta_rad,
    )
    if not args.hover_only:
        assert grasp_q is not None
        if descent_waypoints:
            geometry = validate_multi_descent_geometry(
                kin, standoff_q, descent_waypoints, grasp_q
            )
            print(
                "MULTI_DESCENT_GEOMETRY_OK "
                f"total={geometry['total_descent_mm']:.1f}mm "
                f"max_step={geometry['maximum_step_mm']:.1f}mm "
                f"max_lateral={geometry['maximum_lateral_mm']:.1f}mm "
                f"max_joint_delta="
                f"{geometry['maximum_joint_delta_rad']:.3f}rad"
            )
        else:
            geometry = validate_first_grasp_geometry(
                kin, standoff_q, grasp_q
            )
            print(
                "FIRST_GRASP_GEOMETRY_OK "
                f"lift={geometry['lift_mm']:.1f}mm "
                f"lateral={geometry['lateral_mm']:.1f}mm "
                f"joint_delta={geometry['joint_delta_rad']:.3f}rad"
            )
    print("OFFLINE_PREFLIGHT_OK")
    if not args.execute:
        print("OFFLINE_ONLY：未构造Arm、未访问串口、不会改变电机使能状态。")
        return 0

    print("\n即将进入实机模式。必须满足：电机常红、机械臂有软支撑、路径清空，")
    print("且该关节路径已经通过独立的全路径碰撞检查。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("用户取消；尚未连接串口。")
        return 2

    assert plan_path is not None
    assert collision_report_path is not None
    arm = None
    result = "ABORTED"
    diagnostic = {
        "schema_version": 1,
        "started_unix_s": time.time(),
        "plan": str(plan_path),
        "collision_report": str(collision_report_path),
        "motion_profile": args.motion_profile,
        "v_max_rad_s": float(args.v_max_rad_s),
        "j6_v_max_rad_s": float(args.j6_v_max_rad_s),
        "adaptive_grip": bool(args.adaptive_grip),
        "result": result,
    }
    try:
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=SafetyLimits(
                v_max_rad_s=args.v_max_rad_s,
                j6_v_max_rad_s=args.j6_v_max_rad_s,
                motion_profile=args.motion_profile,
                max_joint_delta_rad=args.max_joint_delta_rad,
            ),
            check_collision=False,
        )
        grip = Gripper(arm)
        start = arm.read_joint_median()
        start_q = start[:6]
        diagnostic["start_q"] = [float(value) for value in start_q]
        print("START_Q =", [round(q, 6) for q in start_q])
        start_window_violations = start_pose_window_violations(start_q)
        start_safe = not start_window_violations
        print("START_SAFE_WINDOW_OK =", start_safe)
        for violation in start_window_violations:
            print("START_WINDOW_VIOLATION =", violation)
        print(f"START_GAP_MM = {grip.gap_from_fb(start[6]):.2f}")

        waypoints = [("ready", list(READY_Q))]
        if approach_q is not None:
            waypoints.append(("approach", approach_q))
        waypoints.append(("standoff", standoff_q))
        if not args.hover_only:
            assert grasp_q is not None
            waypoints.extend(descent_waypoints)
            waypoints.append(("grasp", grasp_q))
        arm.preflight(
            waypoints,
            start_q,
            collision_report_verified=True,
        )

        start_ready_delta = max_delta(start_q, list(READY_Q))
        print(f"START_TO_READY_DELTA_RAD = {start_ready_delta:.3f}")
        geometry_ok = (
            start_safe
            and start_ready_delta <= _MAX_START_READY_DELTA_RAD
        )
        print("LIVE_GEOMETRY_OK =", geometry_ok)

        print("开始3秒串口数值稳定性检查（不运行MuJoCo）。")
        readiness = serial_numeric_readiness(arm, start_q)
        diagnostic["serial_readiness"] = readiness
        print("SERIAL_SAMPLES =", readiness["samples"])
        print(
            "SERIAL_MAX_READ_MS =",
            round(readiness["max_read_ms"], 3),
        )
        print(
            "SERIAL_MAX_DRIFT_RAD =",
            round(readiness["max_drift_rad"], 6),
        )
        print("SERIAL_FINITE_OK =", readiness["finite_ok"])
        print("SERIAL_NUMERIC_READINESS_OK =", readiness["passed"])

        temperature = arm.get_temp()
        diagnostic["temperature_c"] = [float(value) for value in temperature]
        temperature_ok = temperature_is_safe(temperature)
        print("TEMPERATURE_C =", temperature)
        print("TEMPERATURE_OK =", temperature_ok)

        live_precheck_ok = (
            geometry_ok and readiness["passed"] and temperature_ok
        )
        print("LIVE_PRECHECK_OK =", live_precheck_ok)
        if not live_precheck_ok:
            result = "LIVE_PRECHECK_REJECTED"
            return 2

        print(
            "SDK未暴露底层timeout计数；若本次终端出现任何motor timeout，"
            "必须取消。"
        )
        confirmation = input(
            "确认路径清空、机械臂有软支撑，且本次连接后完全没有"
            "motor timeout，输入 no："
        ).strip()
        if confirmation != "no":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        open_mm = float(profile["open_gap_mm"])
        close_mm = float(profile["close_gap_mm"])
        force_nm = float(profile["grip_force_nm"])
        if args.adaptive_grip:
            assert adaptive_parameters is not None
            assert adaptive_baseline is not None
            route_open_mm = adaptive_parameters.start_gap_mm
            route_force_nm = adaptive_parameters.secure_force_nm
        else:
            route_open_mm = open_mm
            route_force_nm = force_nm
        open_fb = grip.mm_to_fb(route_open_mm)

        arm.enable()
        guarded_move(
            arm, start_q, list(READY_Q), "start->ready",
            open_fb, route_force_nm,
        )
        guarded_move_route(
            arm,
            outward_route(approach_q, standoff_q),
            open_fb,
            route_force_nm,
        )

        if args.hover_only:
            guarded_hold(
                arm, standoff_q, route_open_mm, route_force_nm,
                args.hold_s, "hover-hold", grip,
            )
            guarded_move_route(
                arm,
                return_route(standoff_q, approach_q, start_q),
                open_fb,
                route_force_nm,
            )
            result = "HOVER_ROUND_TRIP_DONE"
            return 0

        assert grasp_q is not None
        guarded_move_continuous_route(
            arm,
            descent_route(standoff_q, descent_waypoints, grasp_q),
            open_fb, route_force_nm,
        )
        if args.alignment_only:
            run_alignment_only(
                arm, grip, grasp_q, standoff_q, approach_q, start_q,
                open_mm, force_nm, args.hold_s,
                descent_waypoints=descent_waypoints,
            )
            result = "ALIGNMENT_ONLY_SAFE_RETURN"
            return 0

        if args.adaptive_grip:
            print(">>> ADAPTIVE_GRIP：低力矩探测连续接触尺寸。")
            adaptive_runner = BenchRunner(
                arm, grip, grasp_q, adaptive_parameters
            )
            acquisition = run_adaptive_acquisition(
                adaptive_runner,
                adaptive_parameters,
                adaptive_baseline,
                secure=not args.contact_only,
            )
            if not acquisition["detected"]:
                print(">>> 自适应判定夹空：禁止提升，张开并原路撤回。")
                safe_open_return(
                    arm, grip, grasp_q, standoff_q, approach_q, start_q,
                    route_open_mm, route_force_nm,
                    label_prefix="adaptive-miss",
                    descent_waypoints=descent_waypoints,
                )
                result = "ADAPTIVE_GRIP_MISS_SAFE_RETURN"
                return 3
            if args.contact_only:
                print(
                    ">>> ADAPTIVE_CONTACT_ONLY：确认接触但不预压、不提升；"
                    "立即张开撤回。"
                )
                safe_open_return(
                    arm, grip, grasp_q, standoff_q, approach_q, start_q,
                    route_open_mm, route_force_nm,
                    label_prefix="adaptive-contact",
                    descent_waypoints=descent_waypoints,
                )
                result = "ADAPTIVE_CONTACT_ONLY_SAFE_RETURN"
                return 0
            if not acquisition["secure_valid"]:
                print(
                    ">>> 自适应预压后未确认持续阻挡：禁止提升，"
                    "张开并原路撤回。"
                )
                safe_open_return(
                    arm, grip, grasp_q, standoff_q, approach_q, start_q,
                    route_open_mm, route_force_nm,
                    label_prefix="adaptive-secure-lost",
                    descent_waypoints=descent_waypoints,
                )
                result = "ADAPTIVE_SECURE_LOST_SAFE_RETURN"
                return 3
            assert acquisition["secure_gap_mm"] is not None
            lift_gap_mm = float(acquisition["secure_gap_mm"])
            lift_force_nm = adaptive_parameters.secure_force_nm
            success_result = "ADAPTIVE_GRASP_ROUND_TRIP_DONE"
        else:
            print(f">>> 低力矩合爪到 {close_mm:.1f} mm")
            guarded_hold(
                arm, grasp_q, close_mm, force_nm, 1.5, "close", grip
            )
            holding, excess_mm, actual_gap_mm = grip.is_holding_mm(
                close_mm, float(profile["contact_min_excess_mm"])
            )
            print(
                f"CONTACT_CHECK gap={actual_gap_mm:.1f}mm "
                f"excess={excess_mm:+.1f}mm "
                f"result={'HOLDING' if holding else 'MISS'}"
            )
            if not holding:
                print(">>> 判定夹空：不提升，张开并按原路撤回。")
                safe_open_return(
                    arm, grip, grasp_q, standoff_q, approach_q, start_q,
                    open_mm, force_nm,
                    descent_waypoints=descent_waypoints,
                )
                result = "GRIP_MISS_SAFE_RETURN"
                return 3
            if args.contact_only:
                print(
                    ">>> CONTACT_ONLY：确认接触，但本次禁止提升；"
                    "立即张开撤回。"
                )
                safe_open_return(
                    arm, grip, grasp_q, standoff_q, approach_q, start_q,
                    open_mm, force_nm, label_prefix="contact",
                    descent_waypoints=descent_waypoints,
                )
                result = "CONTACT_ONLY_HOLDING_SAFE_RETURN"
                return 0
            lift_gap_mm = close_mm
            lift_force_nm = force_nm
            success_result = "GRASP_ROUND_TRIP_DONE"

        lift_fb = grip.mm_to_fb(lift_gap_mm)
        guarded_move_continuous_route(
            arm,
            ascent_route(standoff_q, descent_waypoints, grasp_q),
            lift_fb, lift_force_nm,
        )
        guarded_hold(
            arm, standoff_q, lift_gap_mm, lift_force_nm,
            args.hold_s, "lift-hold", grip,
        )
        guarded_move_continuous_route(
            arm,
            descent_route(standoff_q, descent_waypoints, grasp_q),
            lift_fb, lift_force_nm,
        )
        guarded_hold(
            arm, grasp_q, route_open_mm, route_force_nm,
            1.0, "release", grip,
        )
        guarded_move_continuous_route(
            arm,
            ascent_route(standoff_q, descent_waypoints, grasp_q),
            open_fb, route_force_nm,
        )
        guarded_move_route(
            arm,
            return_route(standoff_q, approach_q, start_q),
            open_fb,
            route_force_nm,
        )
        result = success_result
        return 0
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        diagnostic["exception_type"] = type(exc).__name__
        diagnostic["exception_message"] = str(exc)
        print(result)
        return 1
    finally:
        if arm is not None:
            try:
                arm.close()
                print("DISABLED：电机应为常红；继续托稳直至机械臂落在软支撑上。")
            except Exception as exc:
                print(f"DISABLE_WARNING: {exc}")
        diagnostic["completed_unix_s"] = time.time()
        diagnostic["result"] = result
        if args.diagnostic_log:
            try:
                diagnostic_path = write_execution_diagnostic(
                    args.diagnostic_log, diagnostic
                )
                print("DIAGNOSTIC_LOG_SAVED =", diagnostic_path)
            except Exception as exc:
                print(f"DIAGNOSTIC_LOG_WARNING: {exc}")
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
