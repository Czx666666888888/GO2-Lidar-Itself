#!/usr/bin/env python3
"""Record D455 RGB continuously; share fresh aligned RGB-D with grasp workers.
No arm imports or arm commands. Use S1_RGBD_RECORD_SOCKET in the grasp shell.
"""
import argparse
from datetime import datetime,timezone
import io
import json
import math
from pathlib import Path
import queue
import signal
import socketserver
import struct
import sys
import threading
import time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from demo_grasp.capture_rgbd import fuse_depth_frames,interval_statistics,evaluate_capture_quality,_device_info,select_device


def make_capture(samples, options, info):
    minimum=options['min_depth_samples']
    if minimum is None:minimum=max(1,math.ceil(options['depth_frames']/2))
    depth=fuse_depth_frames([s['depth'] for s in samples],info['depth_scale'],minimum)
    metadata=dict(info['metadata'])
    ratios=[float((s['depth']>0).mean()) for s in samples]
    metadata.update(capture_utc=datetime.now(timezone.utc).isoformat(),
        warmup_frames=options['warmup_frames'],depth_frames=len(samples),min_depth_samples=minimum,
        valid_depth_ratio_frame_mean=float(np.mean(ratios)),valid_depth_ratio_frame_min=min(ratios),
        valid_depth_ratio_fused=float((depth>0).mean()),capture_source='shared_wrist_video_camera')
    metadata.update(interval_statistics(np.diff([s['time'] for s in samples])*1000))
    passed,reasons=evaluate_capture_quality(metadata,options['min_valid_depth_ratio'],options['max_frame_interval_ms'])
    metadata.update(quality_pass=passed,quality_reasons=reasons)
    return dict(rgb=samples[-1]['rgb'],depth_m=depth,K=info['K'],distortion_coeffs=info['distortion_coeffs'],metadata=metadata)


def encode_capture(capture):
    output=io.BytesIO()
    np.savez_compressed(output,**{k:v for k,v in capture.items() if k!='metadata'},metadata_json=np.array(json.dumps(capture['metadata'])))
    return output.getvalue()


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True)
    parser.add_argument('--socket',default='/tmp/s1-wrist-video.sock')
    parser.add_argument('--serial',default='231622302209')
    parser.add_argument('--width',type=int,default=640)
    parser.add_argument('--height',type=int,default=480)
    parser.add_argument('--fps',type=int,default=30)
    args=parser.parse_args(argv)
    import cv2
    import pyrealsense2 as rs
    output=Path(args.out).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists():raise FileExistsError(output)
    requests=queue.Queue();stop=threading.Event()
    class Handler(socketserver.StreamRequestHandler):
        def handle(self):
            try:
                options=json.loads(self.rfile.readline())
                for key in ('width','height','fps'):
                    if options[key]!=getattr(args,key):raise ValueError('shared camera profile mismatch: '+key)
                if options['serial'] not in (None,args.serial):raise ValueError('shared camera serial mismatch')
                job=dict(options=options,event=threading.Event(),samples=[],remaining=options['warmup_frames'])
                requests.put(job)
                if not job['event'].wait(30):raise RuntimeError('snapshot request timed out')
                if 'error' in job:raise RuntimeError(job['error'])
                body=encode_capture(make_capture(job['samples'],options,info));flag=1
            except Exception as exc:body=str(exc).encode();flag=0
            self.wfile.write(struct.pack('!BQ',flag,len(body))+body)
    class Server(socketserver.ThreadingUnixStreamServer):daemon_threads=True
    context=rs.context();device=select_device(context,rs,args.serial)
    pipeline=rs.pipeline(context);config=rs.config();config.enable_device(args.serial)
    config.enable_stream(rs.stream.color,args.width,args.height,rs.format.rgb8,args.fps)
    config.enable_stream(rs.stream.depth,args.width,args.height,rs.format.z16,args.fps)
    align=rs.align(rs.stream.color)
    writer=None;server=None;started=False;active=None;frames_written=0;source_frames=0;first=None;error=None
    signal.signal(signal.SIGTERM,lambda *_:stop.set());signal.signal(signal.SIGINT,lambda *_:stop.set())
    try:
        profile=pipeline.start(config);started=True;device=profile.get_device()
        depth_scale=float(device.first_depth_sensor().get_depth_scale())
        intr=profile.get_stream(rs.stream.color).as_video_stream_profile().get_intrinsics()
        info=dict(depth_scale=depth_scale,K=np.array([[intr.fx,0,intr.ppx],[0,intr.fy,intr.ppy],[0,0,1]]),distortion_coeffs=np.array(intr.coeffs),metadata=dict(
            schema_version=1,camera_name=_device_info(device,rs,rs.camera_info.name),serial=args.serial,
            firmware=_device_info(device,rs,rs.camera_info.firmware_version),usb_type=_device_info(device,rs,rs.camera_info.usb_type_descriptor),
            product_line=_device_info(device,rs,rs.camera_info.product_line),width=args.width,height=args.height,fps=args.fps,depth_scale=depth_scale,distortion_model=str(intr.model)))
        writer=cv2.VideoWriter(str(output),cv2.VideoWriter_fourcc(*'MJPG'),args.fps,(args.width,args.height))
        if not writer.isOpened():raise RuntimeError('cannot open MJPG video writer')
        server=Server(args.socket,Handler)
        threading.Thread(target=server.serve_forever,daemon=True).start()
        print('RECORDING_READY socket='+args.socket+' video='+str(output),flush=True)
        last_bgr=None
        while not stop.is_set():
            frames=pipeline.wait_for_frames(5000);now=time.monotonic()
            color=frames.get_color_frame()
            if not color:continue
            rgb=np.asanyarray(color.get_data()).copy();bgr=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
            if first is None:first=now
            target=int((now-first)*args.fps)+1
            # Duplicate only for missing timestamps so playback keeps wall-clock duration.
            while frames_written<target-1:
                writer.write(last_bgr if last_bgr is not None else bgr);frames_written+=1
            if frames_written<target:writer.write(bgr);frames_written+=1
            source_frames+=1;last_bgr=bgr
            if active is None:
                try:active=requests.get_nowait()
                except queue.Empty:continue
            if active['remaining']>0:active['remaining']-=1;continue
            aligned=align.process(frames);depth_frame=aligned.get_depth_frame();color_frame=aligned.get_color_frame()
            if not depth_frame or not color_frame:raise RuntimeError('aligned RGB/depth frame missing')
            active['samples'].append(dict(depth=np.asanyarray(depth_frame.get_data()).copy(),rgb=np.asanyarray(color_frame.get_data()).copy(),time=now))
            if len(active['samples'])>=active['options']['depth_frames']:
                active['event'].set();active=None
    except Exception as exc:
        error=str(exc);raise
    finally:
        if active is not None:active['error']=error or 'recording stopped';active['event'].set()
        if writer is not None:writer.release()
        if started:pipeline.stop()
        if server is not None:server.shutdown();server.server_close();Path(args.socket).unlink(missing_ok=True)
        summary=dict(video=str(output),frames_written=frames_written,source_frames=source_frames,fps=args.fps,duration_s=frames_written/args.fps,error=error,
            timing='wall-clock CFR; missing source frames duplicated',hardware_arm_commands_sent=False)
        output.with_suffix('.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
        print('RECORDING_SAVED '+json.dumps(summary),flush=True)

if __name__=='__main__':main()
