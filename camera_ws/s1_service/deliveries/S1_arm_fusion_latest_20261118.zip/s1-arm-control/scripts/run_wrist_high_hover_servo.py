#!/usr/bin/env python3
"""Supervised wrist-D455 high-hover support-tangent alignment validation.

The only commanded Cartesian change lies in the measured support-plane
tangent plane.  Support-normal height, TCP orientation and gripper state are
preserved.  This is deliberately not a grasping program.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
import multiprocessing
from pathlib import Path
import queue
import re
import statistics
import sys
import threading
import time

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
for import_path in (PROJECT_ROOT, SCRIPTS_DIR):
    if str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from demo_grasp.capture_rgbd import capture_aligned_rgbd, save_capture
from demo_grasp.detect_science_target_rgbd import (
    detect_capture,
    load_config as load_vision_config,
    save_preview,
    save_result,
)
from s1_control.arm import (
    Arm,
    J6_INDEX,
    SafetyLimits,
    motion_duration_s,
    motion_profile_progress,
)
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record
from s1_control.wrist_visual_servo import (
    camera_tilt_from_down_deg,
    dynamic_base_camera,
    evaluate_executed_tangent_correction,
    extract_single_surface_observation,
    file_sha256,
    joint_margin_details,
    load_wrist_servo_config,
    plan_high_hover_tangent_correction,
    validate_local_joint_step,
)


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "wrist_high_hover_servo.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "wrist_high_hover_runs"
RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
TEACH_GRAVITY_HZ = 200.0
TEACH_MONITOR_PERIOD_S = 0.10
TEACH_LOCK_SAMPLE_COUNT = 15
TEACH_LOCK_SAMPLE_PERIOD_S = 0.02
TEACH_LOCK_MAX_SPAN_RAD = 0.01
TEACH_PREVIEW_START_TIMEOUT_S = 15.0
TEACH_PREVIEW_FRAME_TIMEOUT_MS = 1000
TEACH_CAMERA_RELEASE_SETTLE_S = 1.0
STARTUP_FEEDBACK_TIMEOUT_S = 5.0
STARTUP_VALID_SAMPLE_COUNT = 10
STARTUP_SAMPLE_PERIOD_S = 0.05
MINIMUM_PLAUSIBLE_TEMPERATURE_C = 5.0
TEACHING_JOINT_LIMIT_TOLERANCE_RAD = 0.03
AB_SUPPORT_NORMAL_BLEND = 0.25
AB_ALLOWED_SUPPORT_NORMAL_BLENDS = (0.25, 0.50)
AB_MOTION_SUPPORT_NORMAL_BLEND = 0.50
AB_MOTION_TANGENT_STEP_MM = 4.0
AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD = 0.012
SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM = 3.0
J3_RESPONSE_INDEX = 2
J3_RESPONSE_OFFSETS_RAD = (0.004, 0.008, 0.012, 0.016, 0.020)
J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM = 2.0
J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD = 0.006
J3_RESPONSE_MINIMUM_FINAL_RATIO = 0.50
J3_RESPONSE_MAX_RETURN_ERROR_RAD = 0.006
J3_RESPONSE_TRACK_ERROR_RAD = 0.025
J3_RESPONSE_SETTLE_S = 0.40
J3_RESPONSE_SAMPLE_COUNT = 10
J3_CLOSED_LOOP_TOLERANCE_RAD = 0.004
J3_CLOSED_LOOP_BIAS_STEP_RAD = 0.004
J3_CLOSED_LOOP_MAX_BIAS_RAD = 0.040
J3_CLOSED_LOOP_BIAS_UPDATE_S = 0.20
J3_CLOSED_LOOP_MAX_BIAS_DWELL_S = 0.80
J3_CLOSED_LOOP_MAX_EXTRA_WALL_TIME_S = 12.0
J3_CLOSED_LOOP_COMPLETION_SAMPLES = 5
J3_CLOSED_LOOP_MAX_DOWNWARD_DRIFT_MM = 2.0
AB_BASELINE_SETTLE_S = 1.0
AB_ADAPTIVE_SETTLE_S = 1.5
AB_RESTORE_HOLD_S = 1.0
AB_SAMPLE_COUNT = 20
AB_MAX_INCREMENTAL_JOINT_DRIFT_RAD = 0.006
AB_MAX_TCP_DRIFT_MM = 2.0
AB_MAX_TARGET_ERROR_WORSENING_RAD = 0.003
RECOVERABLE_VISUAL_ERROR_MARKERS = (
    "Frame didn't arrive within",
    "RGB-D capture quality gate failed",
    "single-target detection failed:",
    "support-plane quality gate failed",
    "camera target depth",
    "normal clearance",
    "XY error",  # Historical base-XY logs remain recoverable on replay.
    "tangent error",
    "no local IK solution",
    "local IK joint",
    "local correction collision gate failed",
    "planned correction changed",
    "validated range",
    "cumulative tangent motion",
)


def teaching_camera_preview_process_main(
    camera_config,
    roi_normalized,
    maximum_tilt_deg,
    stop_event,
    ready_event,
    status_queue,
    tilt_value,
) -> None:
    """Own librealsense and Qt entirely inside a spawned child process."""
    camera = None
    window_name = "S1 D455 teach-lock preview"
    try:
        import cv2
        from capture_eye_in_hand import D455ColorSession

        camera = D455ColorSession(camera_config)
        camera.start()
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(window_name, 960, 720)
        status_queue.put(("ready", None))
        ready_event.set()
        consecutive_frame_timeouts = 0
        while not stop_event.is_set():
            try:
                frame_set = camera.pipeline.wait_for_frames(
                    TEACH_PREVIEW_FRAME_TIMEOUT_MS
                )
            except RuntimeError as exc:
                if "Frame didn't arrive within" not in str(exc):
                    raise
                consecutive_frame_timeouts += 1
                if consecutive_frame_timeouts <= 3:
                    continue
                raise RuntimeError(
                    "D455 teaching preview missed more than three frames"
                ) from exc
            consecutive_frame_timeouts = 0
            color_frame = frame_set.get_color_frame()
            if not color_frame:
                continue
            rgb = np.asanyarray(color_frame.get_data())
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            height, width = bgr.shape[:2]
            x0, y0, x1, y1 = roi_normalized
            roi_start = (
                int(round(x0 * (width - 1))),
                int(round(y0 * (height - 1))),
            )
            roi_end = (
                int(round(x1 * (width - 1))),
                int(round(y1 * (height - 1))),
            )
            cv2.rectangle(bgr, roi_start, roi_end, (255, 180, 0), 2)
            cv2.drawMarker(
                bgr,
                (width // 2, height // 2),
                (0, 255, 255),
                markerType=cv2.MARKER_CROSS,
                markerSize=26,
                thickness=2,
            )
            with tilt_value.get_lock():
                tilt_deg = float(tilt_value.value)
            if not math.isfinite(tilt_deg):
                tilt_text = "camera tilt: measuring..."
                tilt_ok = False
            else:
                tilt_ok = tilt_deg <= maximum_tilt_deg
                tilt_text = (
                    f"camera tilt from down: {tilt_deg:.1f} deg  "
                    f"limit: {maximum_tilt_deg:.1f}"
                )
            cv2.putText(
                bgr,
                tilt_text,
                (12, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 220, 0) if tilt_ok else (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                bgr,
                "Blue: detector ROI  Yellow: optical center",
                (12, height - 42),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )
            cv2.putText(
                bgr,
                "Use terminal: L+Enter lock, Q+Enter cancel",
                (12, height - 18),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )
            cv2.imshow(window_name, bgr)
            cv2.waitKey(1)
    except BaseException as exc:
        status_queue.put(("error", f"{type(exc).__name__}: {exc}"))
        ready_event.set()
    finally:
        if camera is not None:
            try:
                camera.stop()
            except Exception:
                pass
        try:
            import cv2

            cv2.destroyAllWindows()
            cv2.waitKey(1)
        except Exception:
            pass
        status_queue.put(("stopped", None))
        ready_event.set()


class TeachingCameraPreview:
    """Own D455 and Qt in a spawned process isolated from the S1 serial bus."""

    def __init__(self, servo_record: dict, vision_config: dict):
        capture = servo_record["capture"]
        self.camera_config = {
            "camera_serial": str(servo_record["camera_serial"]),
            "color_stream": {
                "width": int(capture["width"]),
                "height": int(capture["height"]),
                "fps": int(capture["fps"]),
                "warmup_frames": int(capture["warmup_frames"]),
            },
        }
        roi = vision_config.get("workspace_roi", {}).get("normalized_xyxy")
        if not isinstance(roi, list) or len(roi) != 4:
            raise ValueError("vision workspace ROI must contain normalized_xyxy")
        self.roi_normalized = tuple(float(value) for value in roi)
        self.maximum_tilt_deg = float(
            servo_record["safety"]["maximum_camera_tilt_from_down_deg"]
        )
        self._context = multiprocessing.get_context("spawn")
        self._stop = self._context.Event()
        self._ready = self._context.Event()
        self._status_queue = self._context.Queue()
        self._tilt_value = self._context.Value("d", float("nan"))
        self._process = None
        self._error = None

    @property
    def start_method(self) -> str:
        return self._context.get_start_method()

    def _poll_status(self) -> None:
        while True:
            try:
                event, payload = self._status_queue.get_nowait()
            except queue.Empty:
                break
            if event == "error":
                self._error = payload

    @property
    def ready(self) -> bool:
        self._poll_status()
        return self._ready.is_set() and self._error is None

    @property
    def alive(self) -> bool:
        self._poll_status()
        return self._process is not None and self._process.is_alive()

    @property
    def error(self):
        self._poll_status()
        return self._error

    def set_tilt(self, tilt_deg: float) -> None:
        with self._tilt_value.get_lock():
            self._tilt_value.value = float(tilt_deg)

    def start(self) -> None:
        if self._process is not None:
            raise RuntimeError("teaching preview can only be started once")
        self._process = self._context.Process(
            target=teaching_camera_preview_process_main,
            args=(
                self.camera_config,
                self.roi_normalized,
                self.maximum_tilt_deg,
                self._stop,
                self._ready,
                self._status_queue,
                self._tilt_value,
            ),
            name="teaching_d455_preview_process",
            daemon=True,
        )
        self._process.start()

    def request_stop(self) -> None:
        self._stop.set()

    def join(self, timeout: float = 0.0) -> None:
        if self._process is not None:
            self._process.join(timeout=timeout)
        self._poll_status()

def is_recoverable_visual_error(exc: BaseException) -> bool:
    if not isinstance(exc, (ValueError, RuntimeError)):
        return False
    message = str(exc)
    return any(marker in message for marker in RECOVERABLE_VISUAL_ERROR_MARKERS)


def resolve_project_path(raw: str | Path) -> Path:
    from s1_control.project_paths import project_path
    return project_path(raw, PROJECT_ROOT)


def write_json(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def make_run_id(raw: str | None) -> str:
    value = raw or time.strftime("wrist_hover_%Y%m%d-%H%M%S")
    if not RUN_ID_PATTERN.fullmatch(value):
        raise ValueError("--run-id只允许字母、数字、点、下划线和短横线，长度1~80")
    return value


def quaternion_error_deg(first, second) -> float:
    q1 = np.asarray(first, dtype=np.float64)
    q2 = np.asarray(second, dtype=np.float64)
    q1 /= np.linalg.norm(q1)
    q2 /= np.linalg.norm(q2)
    dot = min(1.0, max(-1.0, abs(float(q1 @ q2))))
    return math.degrees(2.0 * math.acos(dot))


def find_local_ik(kinematics, current_q, desired_pose, safety) -> tuple[list[float], dict]:
    seeds = [list(current_q)]
    for joint, amount in ((0, 0.03), (1, 0.03), (2, 0.03), (5, 0.02)):
        for sign in (-1.0, 1.0):
            seed = list(current_q)
            seed[joint] += sign * amount
            seeds.append(seed)

    candidates = []
    seen = set()
    for _ in range(3):
        for seed in seeds:
            solution = kinematics.ik(desired_pose[:3], desired_pose[3:], seed)
            if solution is None:
                continue
            key = tuple(round(value, 7) for value in solution)
            if key in seen:
                continue
            seen.add(key)
            try:
                joint_state = validate_local_joint_step(
                    current_q, solution, safety
                )
            except RuntimeError:
                continue
            fk = kinematics.fk(solution)
            position_error_mm = 1000.0 * float(
                np.linalg.norm(np.asarray(fk[:3]) - np.asarray(desired_pose[:3]))
            )
            orientation_error_deg = quaternion_error_deg(fk[3:], desired_pose[3:])
            if position_error_mm > float(safety["maximum_fk_position_error_mm"]):
                continue
            if orientation_error_deg > float(
                safety["maximum_fk_orientation_error_deg"]
            ):
                continue
            score = (
                joint_state["maximum_joint_delta_rad"],
                sum(abs(a - b) for a, b in zip(current_q, solution)),
                position_error_mm,
            )
            candidates.append(
                {
                    "q": list(solution),
                    "score": score,
                    "fk_position_error_mm": position_error_mm,
                    "fk_orientation_error_deg": orientation_error_deg,
                    **joint_state,
                }
            )
    if not candidates:
        raise RuntimeError("no local IK solution passed the high-hover safety gates")
    selected = min(candidates, key=lambda item: item["score"])
    return selected["q"], {
        key: value for key, value in selected.items() if key not in {"q", "score"}
    }


def check_collision_segment(checker, q_from, q_to, step_rad) -> dict:
    # Lazy import keeps --help, offline preflight and pure unit tests free of
    # MuJoCo/S1 runtime requirements.
    from check_cube_hover_path import collision_at, interpolate

    sample_count = 0
    excluded_count = 0
    for _, q in interpolate(q_from, q_to, step_rad):
        sample_count += 1
        active, excluded, floor = collision_at(checker, q)
        excluded_count += len(excluded)
        if active or floor:
            raise RuntimeError(
                "local correction collision gate failed: "
                f"active={sorted(active)} floor={sorted(floor)}"
            )
    return {
        "sample_count": sample_count,
        "excluded_contact_count": excluded_count,
        "active_collision_count": 0,
        "floor_contact_count": 0,
    }


def run_worker_while_holding(
    arm,
    q_hold,
    worker,
    *,
    timeout_s: float | None,
    label: str,
) -> tuple[object, list[float]]:
    """Run camera/CPU work in a daemon while the main thread holds at 50 Hz."""
    state = {"result": None, "error": None}

    def invoke():
        try:
            state["result"] = worker()
        except BaseException as exc:  # returned to the serial-owning main thread
            state["error"] = exc

    thread = threading.Thread(target=invoke, name=label, daemon=True)
    thread.start()
    started = time.monotonic()
    measured = []
    while thread.is_alive():
        cycle_started = time.monotonic()
        arm.command_position(q_hold)
        position = list(arm.get_pos())
        velocity = list(arm.get_vel())
        temperature = list(arm.get_temp())
        measured.append(position[:6])
        elapsed = time.monotonic() - started
        bad = arm.guard(
            position,
            velocity,
            temperature,
            list(q_hold),
            settling=elapsed < arm.limits.settle_seconds,
        )
        if bad:
            raise RuntimeError(f"{label}: {bad}")
        if timeout_s is not None and elapsed > timeout_s:
            raise TimeoutError(f"{label} exceeded {timeout_s:.1f}s")
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    thread.join(timeout=0.0)
    if state["error"] is not None:
        raise state["error"]
    if not measured:
        position = list(arm.get_pos())[:6]
        measured.append(position)
    median_q = [
        statistics.median(row[index] for row in measured)
        for index in range(6)
    ]
    return state["result"], median_q


def summarize_teach_lock_samples(samples) -> dict:
    """Validate teaching samples and summarize the candidate lock posture."""
    rows = []
    for index, raw in enumerate(samples):
        row = [float(value) for value in raw[:6]]
        if len(row) != 6 or not all(math.isfinite(value) for value in row):
            raise ValueError(
                f"teach lock sample {index + 1} must contain 6 finite joints"
            )
        rows.append(row)
    if not rows:
        raise ValueError("teach lock requires at least one joint sample")
    median_q = [
        statistics.median(row[joint] for row in rows)
        for joint in range(6)
    ]
    span_rad = [
        max(row[joint] for row in rows) - min(row[joint] for row in rows)
        for joint in range(6)
    ]
    limiting_joint = max(range(6), key=lambda joint: span_rad[joint])
    return {
        "sample_count": len(rows),
        "median_q_rad": median_q,
        "span_rad": span_rad,
        "maximum_span_rad": span_rad[limiting_joint],
        "maximum_span_joint": limiting_joint + 1,
    }


def _validated_feedback_state(position, temperature, maximum_temperature_c):
    q = [float(value) for value in position[:6]]
    temp = [float(value) for value in temperature]
    if len(q) != 6 or not all(math.isfinite(value) for value in q):
        raise RuntimeError("teaching returned a non-finite joint position")
    if len(temp) != 7 or not all(math.isfinite(value) for value in temp):
        raise RuntimeError("teaching returned a non-finite temperature")
    if max(temp) > maximum_temperature_c:
        raise RuntimeError(
            f"teaching temperature {max(temp):.1f}C exceeds "
            f"{maximum_temperature_c:.1f}C"
        )
    return q, temp


def _validated_live_state(
    position,
    temperature,
    maximum_temperature_c,
    *,
    joint_limit_tolerance_rad=TEACHING_JOINT_LIMIT_TOLERANCE_RAD,
):
    """Validate teaching feedback with bounded encoder-zero tolerance.

    The tolerance is only for gravity-teaching observation near a mechanical
    zero.  Lock acceptance still uses strict joint margins before any fixed
    hold or planned motion is commanded.
    """
    q, temp = _validated_feedback_state(
        position, temperature, maximum_temperature_c
    )
    tolerance = float(joint_limit_tolerance_rad)
    if not math.isfinite(tolerance) or tolerance < 0.0:
        raise ValueError("joint limit tolerance must be finite and nonnegative")
    outside = [
        item
        for item in joint_margin_details(q)
        if not (
            item["lower_rad"] - tolerance
            <= item["value_rad"]
            <= item["upper_rad"] + tolerance
        )
    ]
    if outside:
        joints = ", ".join(f"J{item['joint']}" for item in outside)
        raise RuntimeError(f"teaching crossed a hard joint limit: {joints}")
    return q, temp


def wait_for_valid_feedback(
    arm,
    maximum_temperature_c: float,
    *,
    timeout_s: float = STARTUP_FEEDBACK_TIMEOUT_S,
    required_consecutive: int = STARTUP_VALID_SAMPLE_COUNT,
    sample_period_s: float = STARTUP_SAMPLE_PERIOD_S,
):
    """Reject uninitialized SDK frames before any enable or teaching command.

    Joint positions may legitimately be near zero, but seven simultaneous
    0 degC motor readings are an SDK placeholder rather than physical state.
    Several consecutive plausible frames are required so a single stale frame
    cannot pass the gate.
    """
    if timeout_s <= 0.0 or required_consecutive <= 0 or sample_period_s < 0.0:
        raise ValueError("invalid startup feedback gate parameters")

    started = time.monotonic()
    valid_rows = []
    attempts = 0
    invalid_samples = 0
    last_invalid_reason = "no samples received"

    while True:
        cycle_started = time.monotonic()
        attempts += 1
        try:
            q, temperature = _validated_feedback_state(
                arm.get_pos(), arm.get_temp(), maximum_temperature_c
            )
            velocity = [float(value) for value in arm.get_vel()[:6]]
            if len(velocity) != 6 or not all(
                math.isfinite(value) for value in velocity
            ):
                raise RuntimeError("startup velocity feedback is not finite")
            if min(temperature) < MINIMUM_PLAUSIBLE_TEMPERATURE_C:
                raise ValueError(
                    "temperature feedback is not initialized "
                    f"(minimum={min(temperature):.1f}C)"
                )
        except (RuntimeError, ValueError, TypeError) as exc:
            if "exceeds" in str(exc) and "temperature" in str(exc):
                raise
            valid_rows.clear()
            invalid_samples += 1
            last_invalid_reason = str(exc)
        else:
            valid_rows.append(
                {
                    "position_rad": q,
                    "velocity_rad_s": velocity,
                    "temperature_c": temperature,
                }
            )
            if len(valid_rows) >= required_consecutive:
                break

        elapsed = time.monotonic() - started
        if elapsed >= timeout_s:
            raise RuntimeError(
                "startup feedback not ready after "
                f"{elapsed:.2f}s; last invalid sample: {last_invalid_reason}"
            )
        time.sleep(max(0.0, sample_period_s - (time.monotonic() - cycle_started)))

    positions = [row["position_rad"] for row in valid_rows]
    temperatures = [row["temperature_c"] for row in valid_rows]
    velocities = [row["velocity_rad_s"] for row in valid_rows]
    median_q = [
        statistics.median(row[joint] for row in positions)
        for joint in range(6)
    ]
    median_temperature = [
        statistics.median(row[motor] for row in temperatures)
        for motor in range(7)
    ]
    position_spans = [
        max(row[joint] for row in positions)
        - min(row[joint] for row in positions)
        for joint in range(6)
    ]
    summary = {
        "ready": True,
        "elapsed_s": time.monotonic() - started,
        "attempt_count": attempts,
        "invalid_sample_count": invalid_samples,
        "required_consecutive_samples": required_consecutive,
        "position_span_rad": position_spans,
        "maximum_abs_velocity_rad_s": max(
            abs(value) for row in velocities for value in row
        ),
        "temperature_min_c": min(
            value for row in temperatures for value in row
        ),
        "temperature_max_c": max(
            value for row in temperatures for value in row
        ),
    }
    return median_q, median_temperature, summary


def collect_teach_lock_samples(arm) -> tuple[dict, list[float]]:
    """Keep gravity compensation active while measuring a stationary pose."""
    samples = []
    latest_temperature = []
    for _ in range(TEACH_LOCK_SAMPLE_COUNT):
        cycle_started = time.monotonic()
        arm.gravity()
        position = list(arm.get_pos())
        latest_temperature = list(arm.get_temp())
        q, _ = _validated_live_state(
            position,
            latest_temperature,
            arm.limits.max_temp_c,
        )
        samples.append(q)
        time.sleep(
            max(
                0.0,
                TEACH_LOCK_SAMPLE_PERIOD_S
                - (time.monotonic() - cycle_started),
            )
        )
    return summarize_teach_lock_samples(samples), latest_temperature


def teaching_camera_tilt_deg(
    q,
    *,
    flange_kinematics,
    transform_flange_camera,
) -> float:
    flange_pose = flange_kinematics.fk(list(q))
    return camera_tilt_from_down_deg(flange_pose, transform_flange_camera)


def stop_preview_while_teaching(arm, preview) -> None:
    """Release D455 while gravity compensation stays continuously active."""
    if preview is None:
        return
    preview.request_stop()
    deadline = time.monotonic() + TEACH_PREVIEW_START_TIMEOUT_S
    while preview.alive:
        cycle_started = time.monotonic()
        arm.gravity()
        _validated_live_state(
            arm.get_pos(), arm.get_temp(), arm.limits.max_temp_c
        )
        if time.monotonic() > deadline:
            raise TimeoutError("D455 teaching preview did not release the camera")
        time.sleep(
            max(
                0.0,
                1.0 / TEACH_GRAVITY_HZ
                - (time.monotonic() - cycle_started),
            )
        )
    preview.join(timeout=0.0)
    if preview.error is not None:
        raise RuntimeError(f"D455 teaching preview failed: {preview.error}")
    settle_started = time.monotonic()
    while time.monotonic() - settle_started < TEACH_CAMERA_RELEASE_SETTLE_S:
        cycle_started = time.monotonic()
        arm.gravity()
        _validated_live_state(
            arm.get_pos(), arm.get_temp(), arm.limits.max_temp_c
        )
        time.sleep(
            max(
                0.0,
                1.0 / TEACH_GRAVITY_HZ
                - (time.monotonic() - cycle_started),
            )
        )
    print(
        "D455_PREVIEW_RELEASED = True "
        f"settle={TEACH_CAMERA_RELEASE_SETTLE_S:.1f}s"
    )


def teaching_until_locked(
    arm,
    *,
    collision_checker,
    collision_step_rad,
    minimum_joint_margin_deg,
) -> tuple[list[float] | None, dict | None]:
    """Run official gravity compensation until the user locks or quits."""
    print("TEACHING_ENABLED：缓慢摆位；未看到 LOCKED 前请继续扶住机械臂。")
    print("输入 l 后回车：采样并锁定当前姿态；输入 q 后回车：取消并失能。")
    while True:
        state = {"command": None, "error": None}

        def read_command():
            try:
                state["command"] = input("TEACH_COMMAND [l/q]：").strip().lower()
            except BaseException as exc:
                state["error"] = exc

        reader = threading.Thread(
            target=read_command,
            name="teach_command",
            daemon=True,
        )
        reader.start()
        next_monitor = time.monotonic()
        while reader.is_alive():
            cycle_started = time.monotonic()
            arm.gravity()
            now = time.monotonic()
            if now >= next_monitor:
                _validated_live_state(
                    arm.get_pos(),
                    arm.get_temp(),
                    arm.limits.max_temp_c,
                )
                next_monitor = now + TEACH_MONITOR_PERIOD_S
            time.sleep(
                max(
                    0.0,
                    1.0 / TEACH_GRAVITY_HZ
                    - (time.monotonic() - cycle_started),
                )
            )
        reader.join(timeout=0.0)
        if state["error"] is not None:
            raise state["error"]
        command = state["command"]
        if command == "q":
            return None, None
        if command != "l":
            print("仅接受 l（锁定）或 q（取消）；继续保持重力补偿。")
            continue

        summary, temperature = collect_teach_lock_samples(arm)
        if summary["maximum_span_rad"] > TEACH_LOCK_MAX_SPAN_RAD:
            print(
                "LOCK_REJECTED：姿态仍在移动，"
                f"J{summary['maximum_span_joint']}采样跨度="
                f"{summary['maximum_span_rad']:.5f}rad > "
                f"{TEACH_LOCK_MAX_SPAN_RAD:.5f}rad；继续扶稳后再输入 l。"
            )
            continue

        q_lock = list(summary["median_q_rad"])
        details = joint_margin_details(q_lock)
        margin = min(item["margin_deg"] for item in details)
        if margin < minimum_joint_margin_deg:
            limiting = min(details, key=lambda item: item["margin_deg"])
            print(
                "LOCK_REJECTED："
                f"J{limiting['joint']}余量={margin:.2f}deg < "
                f"{minimum_joint_margin_deg:.2f}deg；继续调整后再输入 l。"
            )
            continue
        try:
            collision = check_collision_segment(
                collision_checker,
                q_lock,
                q_lock,
                collision_step_rad,
            )
        except RuntimeError as exc:
            print(f"LOCK_REJECTED：{exc}；继续调整后再输入 l。")
            continue

        # Direct gravity -> MIT hold transition: there is deliberately no
        # disable/close between these commands.
        arm.command_position(q_lock)
        record = {
            **summary,
            "temperature_c": temperature,
            "joint_margin_deg": margin,
            "joint_margin_details": details,
            "collision": collision,
        }
        print("LOCKED_Q =", [round(value, 6) for value in q_lock])
        print("LOCK_SAMPLE_MAX_SPAN_RAD =", round(summary["maximum_span_rad"], 6))
        print("LOCK_JOINT_MARGIN_DEG =", round(margin, 3))
        print("LOCKED：已无缝切换到关节保持，可以松手观察是否稳定。")
        return q_lock, record


def teaching_until_locked_with_preview(
    arm,
    *,
    collision_checker,
    collision_step_rad,
    minimum_joint_margin_deg,
    maximum_camera_tilt_from_down_deg,
    flange_kinematics,
    transform_flange_camera,
    preview=None,
) -> tuple[list[float] | None, dict | None]:
    """Teach, supervise camera orientation, then hand off to a fixed hold."""
    print("TEACHING_ENABLED: keep supporting the arm until LOCKED is printed.")
    print("Terminal command: l + Enter locks; q + Enter cancels and disables.")
    print(
        "Camera gate: optical-axis tilt from vertical down must be <= "
        f"{maximum_camera_tilt_from_down_deg:.1f} deg."
    )
    if preview is not None:
        preview.start()
        deadline = time.monotonic() + TEACH_PREVIEW_START_TIMEOUT_S
        while not preview.ready:
            cycle_started = time.monotonic()
            arm.gravity()
            _validated_live_state(
                arm.get_pos(), arm.get_temp(), arm.limits.max_temp_c
            )
            if preview.error is not None:
                raise RuntimeError(
                    f"D455 teaching preview failed to start: {preview.error}"
                )
            if time.monotonic() > deadline:
                raise TimeoutError("D455 teaching preview startup timed out")
            time.sleep(
                max(
                    0.0,
                    1.0 / TEACH_GRAVITY_HZ
                    - (time.monotonic() - cycle_started),
                )
            )
        print("D455_TEACH_PREVIEW_READY = True")

    try:
        while True:
            state = {"command": None, "error": None}

            def read_command():
                try:
                    state["command"] = input(
                        "TEACH_COMMAND [l/q]: "
                    ).strip().lower()
                except BaseException as exc:
                    state["error"] = exc

            reader = threading.Thread(
                target=read_command,
                name="teach_command",
                daemon=True,
            )
            reader.start()
            next_monitor = time.monotonic()
            last_tilt_report = 0.0
            while reader.is_alive():
                cycle_started = time.monotonic()
                arm.gravity()
                now = time.monotonic()
                if now >= next_monitor:
                    q_live, _ = _validated_live_state(
                        arm.get_pos(),
                        arm.get_temp(),
                        arm.limits.max_temp_c,
                    )
                    tilt_deg = teaching_camera_tilt_deg(
                        q_live,
                        flange_kinematics=flange_kinematics,
                        transform_flange_camera=transform_flange_camera,
                    )
                    if preview is not None:
                        preview.set_tilt(tilt_deg)
                        if preview.error is not None:
                            raise RuntimeError(
                                f"D455 teaching preview failed: {preview.error}"
                            )
                    if now - last_tilt_report >= 1.0:
                        tilt_state = (
                            "OK"
                            if tilt_deg <= maximum_camera_tilt_from_down_deg
                            else "TOO_TILTED"
                        )
                        print(
                            f"TEACH_CAMERA_TILT_DEG = {tilt_deg:.2f} "
                            f"limit={maximum_camera_tilt_from_down_deg:.2f} "
                            f"state={tilt_state}"
                        )
                        last_tilt_report = now
                    next_monitor = now + TEACH_MONITOR_PERIOD_S
                time.sleep(
                    max(
                        0.0,
                        1.0 / TEACH_GRAVITY_HZ
                        - (time.monotonic() - cycle_started),
                    )
                )
            reader.join(timeout=0.0)
            if state["error"] is not None:
                raise state["error"]
            command = state["command"]
            if command == "q":
                stop_preview_while_teaching(arm, preview)
                return None, None
            if command != "l":
                print("Only l (lock) or q (cancel) is accepted; teaching continues.")
                continue

            summary, temperature = collect_teach_lock_samples(arm)
            if summary["maximum_span_rad"] > TEACH_LOCK_MAX_SPAN_RAD:
                print(
                    "LOCK_REJECTED: pose still moving; "
                    f"J{summary['maximum_span_joint']} span="
                    f"{summary['maximum_span_rad']:.5f}rad > "
                    f"{TEACH_LOCK_MAX_SPAN_RAD:.5f}rad. Teaching continues."
                )
                continue

            q_lock = list(summary["median_q_rad"])
            camera_tilt_deg = teaching_camera_tilt_deg(
                q_lock,
                flange_kinematics=flange_kinematics,
                transform_flange_camera=transform_flange_camera,
            )
            if camera_tilt_deg > maximum_camera_tilt_from_down_deg:
                print(
                    "LOCK_REJECTED: camera optical-axis tilt from down "
                    f"{camera_tilt_deg:.2f}deg > "
                    f"{maximum_camera_tilt_from_down_deg:.2f}deg. "
                    "Make the D455 more vertical; teaching continues."
                )
                continue

            details = joint_margin_details(q_lock)
            margin = min(item["margin_deg"] for item in details)
            if margin < minimum_joint_margin_deg:
                limiting = min(details, key=lambda item: item["margin_deg"])
                print(
                    "LOCK_REJECTED: "
                    f"J{limiting['joint']} margin={margin:.2f}deg < "
                    f"{minimum_joint_margin_deg:.2f}deg. Teaching continues."
                )
                continue
            try:
                collision = check_collision_segment(
                    collision_checker,
                    q_lock,
                    q_lock,
                    collision_step_rad,
                )
            except RuntimeError as exc:
                print(f"LOCK_REJECTED: {exc}. Teaching continues.")
                continue

            # The color preview must release D455 before RGB-D capture starts.
            # Gravity compensation remains active throughout this transition.
            stop_preview_while_teaching(arm, preview)
            arm.command_position(q_lock)
            record = {
                **summary,
                "temperature_c": temperature,
                "joint_margin_deg": margin,
                "joint_margin_details": details,
                "collision": collision,
                "camera_tilt_from_down_deg": camera_tilt_deg,
                "camera_tilt_limit_deg": maximum_camera_tilt_from_down_deg,
            }
            print("LOCKED_Q =", [round(value, 6) for value in q_lock])
            print(
                "LOCK_SAMPLE_MAX_SPAN_RAD =",
                round(summary["maximum_span_rad"], 6),
            )
            print("LOCK_JOINT_MARGIN_DEG =", round(margin, 3))
            print(
                "LOCK_CAMERA_TILT_FROM_DOWN_DEG =",
                round(camera_tilt_deg, 3),
            )
            print("LOCKED: gravity-to-position hold handoff completed.")
            return q_lock, record
    finally:
        if preview is not None and preview.alive:
            stop_preview_while_teaching(arm, preview)


def wait_for_q_while_holding(arm, q_hold) -> None:
    """Hold indefinitely until the supervised operator enters q."""
    print("FINAL_POSE_HOLDING：机械臂会持续保持当前对准姿态。")
    print("先托住机械臂或放好软支撑，再输入 q 后回车执行失能。")
    while True:
        command, _ = run_worker_while_holding(
            arm,
            q_hold,
            lambda: input("EXIT_COMMAND [q]：").strip().lower(),
            timeout_s=None,
            label="wait_for_operator_q",
        )
        if command == "q":
            print("Q_ACCEPTED：即将进入 finally 执行受控失能。")
            return
        print("仅接受 q；机械臂仍在保持当前姿态。")


def hold_for_duration(arm, q_hold, duration_s, label):
    started = time.monotonic()
    while time.monotonic() - started < duration_s:
        cycle_started = time.monotonic()
        arm.command_position(q_hold)
        elapsed = time.monotonic() - started
        bad = arm.guard(
            arm.get_pos(),
            arm.get_vel(),
            arm.get_temp(),
            list(q_hold),
            settling=elapsed < arm.limits.settle_seconds,
        )
        if bad:
            raise RuntimeError(f"{label}: {bad}")
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))


def sample_hold_joint_median(
    arm,
    q_hold,
    *,
    settle_s: float,
    sample_count: int,
    label: str,
    trace: list[dict] | None = None,
) -> list[float]:
    """Hold the commanded pose and record feedback until a settled median exists.

    ``trace`` is optional so existing callers keep the same return contract.  When
    supplied, it receives every control-cycle sample, including the settling
    interval.  The raw seven-motor feedback is retained to diagnose intermittent
    wrist/gripper wiring without changing any motion command or safety threshold.
    """
    if settle_s < 0.0:
        raise ValueError("settle_s cannot be negative")
    if sample_count < 1:
        raise ValueError("sample_count must be positive")
    started = time.monotonic()
    samples = []
    while len(samples) < sample_count:
        cycle_started = time.monotonic()
        arm.command_position(q_hold)
        position = [float(value) for value in arm.get_pos()]
        velocity = [float(value) for value in arm.get_vel()]
        temperature = [float(value) for value in arm.get_temp()]
        elapsed = time.monotonic() - started
        arm_q = position[:6]
        if trace is not None:
            trace.append(
                {
                    "sample_index": len(trace),
                    "elapsed_s": elapsed,
                    "phase": "settling" if elapsed < settle_s else "sampling",
                    "commanded_arm_q_rad": [float(value) for value in q_hold],
                    "measured_motor_position_rad": position,
                    "measured_motor_velocity_rad_s": velocity,
                    "measured_motor_temperature_c": temperature,
                    "arm_joint_error_command_minus_measured_rad": [
                        float(commanded - measured)
                        for commanded, measured in zip(q_hold, arm_q)
                    ],
                }
            )
        bad = arm.guard(
            position,
            velocity,
            temperature,
            list(q_hold),
            settling=elapsed < settle_s,
        )
        if bad:
            raise RuntimeError(f"{label}: {bad}")
        if elapsed >= settle_s:
            q = arm_q
            if len(q) != 6 or not all(math.isfinite(value) for value in q):
                raise RuntimeError(f"{label}: non-finite joint feedback")
            samples.append(q)
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    return [
        statistics.median(row[joint] for row in samples)
        for joint in range(6)
    ]


def evaluate_support_normal_ab(
    q_command,
    baseline_q,
    adaptive_q,
    baseline_tcp_pose,
    adaptive_tcp_pose,
    support_up_normal_base,
):
    """Compare two same-command holds without permitting planned motion."""
    q_command = np.asarray(q_command, dtype=float)
    baseline_q = np.asarray(baseline_q, dtype=float)
    adaptive_q = np.asarray(adaptive_q, dtype=float)
    baseline_tcp = np.asarray(baseline_tcp_pose[:3], dtype=float)
    adaptive_tcp = np.asarray(adaptive_tcp_pose[:3], dtype=float)
    support_up = np.asarray(support_up_normal_base, dtype=float)
    if (
        q_command.shape != (6,)
        or baseline_q.shape != (6,)
        or adaptive_q.shape != (6,)
        or baseline_tcp.shape != (3,)
        or adaptive_tcp.shape != (3,)
        or support_up.shape != (3,)
        or not all(
            np.all(np.isfinite(value))
            for value in (
                q_command,
                baseline_q,
                adaptive_q,
                baseline_tcp,
                adaptive_tcp,
                support_up,
            )
        )
    ):
        raise ValueError("support-normal A/B inputs must be finite vectors")
    support_norm = float(np.linalg.norm(support_up))
    if not 0.98 <= support_norm <= 1.02 or support_up[2] <= 0.0:
        raise ValueError("support normal must be unit length and point toward base +z")
    support_up = support_up / support_norm

    baseline_error = baseline_q - q_command
    adaptive_error = adaptive_q - q_command
    incremental_joint_drift = adaptive_q - baseline_q
    error_worsening = np.abs(adaptive_error) - np.abs(baseline_error)
    tcp_delta_mm = (adaptive_tcp - baseline_tcp) * 1000.0
    normal_drift_mm = float(np.dot(tcp_delta_mm, support_up))
    tangent_delta_mm = tcp_delta_mm - normal_drift_mm * support_up

    maximum_incremental_joint_drift = float(
        np.max(np.abs(incremental_joint_drift))
    )
    maximum_target_error_worsening = float(np.max(error_worsening))
    tcp_drift_norm_mm = float(np.linalg.norm(tcp_delta_mm))
    reasons = []
    if maximum_incremental_joint_drift > AB_MAX_INCREMENTAL_JOINT_DRIFT_RAD:
        reasons.append("incremental_joint_drift_too_large")
    if tcp_drift_norm_mm > AB_MAX_TCP_DRIFT_MM:
        reasons.append("tcp_drift_too_large")
    if maximum_target_error_worsening > AB_MAX_TARGET_ERROR_WORSENING_RAD:
        reasons.append("target_error_worsened")
    return {
        "passed": not reasons,
        "reasons": reasons,
        "baseline_target_error_rad": baseline_error.tolist(),
        "adaptive_target_error_rad": adaptive_error.tolist(),
        "incremental_joint_drift_rad": incremental_joint_drift.tolist(),
        "maximum_incremental_joint_drift_rad": (
            maximum_incremental_joint_drift
        ),
        "target_error_worsening_rad": error_worsening.tolist(),
        "maximum_target_error_worsening_rad": maximum_target_error_worsening,
        "tcp_delta_base_xyz_mm": tcp_delta_mm.tolist(),
        "tcp_drift_norm_mm": tcp_drift_norm_mm,
        "support_normal_drift_mm": normal_drift_mm,
        "support_tangent_drift_mm": tangent_delta_mm.tolist(),
        "support_tangent_drift_norm_mm": float(np.linalg.norm(tangent_delta_mm)),
        "limits": {
            "maximum_incremental_joint_drift_rad": (
                AB_MAX_INCREMENTAL_JOINT_DRIFT_RAD
            ),
            "maximum_tcp_drift_mm": AB_MAX_TCP_DRIFT_MM,
            "maximum_target_error_worsening_rad": (
                AB_MAX_TARGET_ERROR_WORSENING_RAD
            ),
        },
    }


def run_support_normal_ab(
    arm,
    tilt_commander,
    q_hold,
    support_up_normal_base,
    tcp_kinematics,
    record,
    *,
    support_normal_blend,
):
    """Hold one joint command while changing only the compensation normal."""
    record.update(
        {
            "planned_motion": False,
            "q_command_rad": [float(value) for value in q_hold],
            "support_normal_blend": float(support_normal_blend),
            "baseline_trace": [],
            "adaptive_trace": [],
            "restore_trace": [],
        }
    )
    baseline_q = sample_hold_joint_median(
        arm,
        q_hold,
        settle_s=AB_BASELINE_SETTLE_S,
        sample_count=AB_SAMPLE_COUNT,
        label="support_normal_ab_baseline",
        trace=record["baseline_trace"],
    )
    baseline_tcp = tcp_kinematics.fk(baseline_q)
    record["baseline"] = {
        "median_q_rad": baseline_q,
        "tcp_pose_xyz_xyzw": baseline_tcp,
        "commander_snapshot": tilt_commander.last_snapshot,
    }

    update = tilt_commander.set_support_up_normal(
        support_up_normal_base,
        source="validated_horizontal_support_plane:ab_diagnostic",
    )
    record["support_normal_update"] = update
    print("AB_SUPPORT_NORMAL_UPDATE =", update)
    restore_error = None
    try:
        adaptive_q = sample_hold_joint_median(
            arm,
            q_hold,
            settle_s=AB_ADAPTIVE_SETTLE_S,
            sample_count=AB_SAMPLE_COUNT,
            label="support_normal_ab_adaptive",
            trace=record["adaptive_trace"],
        )
        adaptive_tcp = tcp_kinematics.fk(adaptive_q)
        record["adaptive"] = {
            "median_q_rad": adaptive_q,
            "tcp_pose_xyz_xyzw": adaptive_tcp,
            "commander_snapshot": tilt_commander.last_snapshot,
        }
        record["evaluation"] = evaluate_support_normal_ab(
            q_hold,
            baseline_q,
            adaptive_q,
            baseline_tcp,
            adaptive_tcp,
            support_up_normal_base,
        )
    finally:
        restore = tilt_commander.set_support_up_normal(
            tilt_commander.nominal_support_up_normal_base,
            source="mount_record_pitch_only:ab_restore",
        )
        record["restore_support_normal_update"] = restore
        print("AB_RESTORE_SUPPORT_NORMAL =", restore)
        try:
            restored_q = sample_hold_joint_median(
                arm,
                q_hold,
                settle_s=AB_RESTORE_HOLD_S,
                sample_count=AB_SAMPLE_COUNT,
                label="support_normal_ab_restore",
                trace=record["restore_trace"],
            )
            record["restore"] = {
                "median_q_rad": restored_q,
                "tcp_pose_xyz_xyzw": tcp_kinematics.fk(restored_q),
                "commander_snapshot": tilt_commander.last_snapshot,
            }
        except BaseException as exc:
            restore_error = f"{type(exc).__name__}: {exc}"
            record["restore_error"] = restore_error
    if restore_error is not None:
        raise RuntimeError(f"nominal compensation restore failed: {restore_error}")
    return record["evaluation"]


def evaluate_support_normal_motion_ab(phases):
    """Require both legs of both same-target round trips to pass."""
    reasons = []
    for phase_name in ("mount_only", "support_normal"):
        phase = phases.get(phase_name)
        if not isinstance(phase, dict):
            reasons.append(f"{phase_name}_missing")
            continue
        for leg_name in ("outbound", "return"):
            leg = phase.get(leg_name)
            if not isinstance(leg, dict):
                reasons.append(f"{phase_name}_{leg_name}_missing")
                continue
            if not leg.get("passed", False):
                leg_reasons = leg.get("reasons") or ["rejected"]
                reasons.extend(
                    f"{phase_name}_{leg_name}_{reason}"
                    for reason in leg_reasons
                )
    return {"passed": not reasons, "reasons": reasons}


def validate_support_normal_motion_ab_target(q_start, q_target):
    """Reject commands too small to be observable on the physical S1."""
    start = np.asarray(q_start, dtype=float)
    target = np.asarray(q_target, dtype=float)
    if (
        start.shape != (6,)
        or target.shape != (6,)
        or not np.all(np.isfinite(start))
        or not np.all(np.isfinite(target))
    ):
        raise ValueError("motion A/B joint targets must be finite 6-vectors")
    delta = target - start
    maximum_delta = float(np.max(np.abs(delta)))
    if maximum_delta < AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD:
        raise RuntimeError(
            "motion A/B maximum joint target change "
            f"{maximum_delta:.6f}rad is below observable minimum "
            f"{AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD:.6f}rad"
        )
    return {
        "joint_delta_rad": delta.tolist(),
        "maximum_joint_delta_rad": maximum_delta,
        "minimum_required_maximum_joint_delta_rad": (
            AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD
        ),
    }


def support_normal_signed_displacement_mm(
    reference_tcp_pose,
    measured_tcp_pose,
    support_up_normal_base,
):
    """Return signed TCP displacement along measured support-plane up."""
    reference = np.asarray(reference_tcp_pose[:3], dtype=float)
    measured = np.asarray(measured_tcp_pose[:3], dtype=float)
    support_up = np.asarray(support_up_normal_base, dtype=float)
    if (
        reference.shape != (3,)
        or measured.shape != (3,)
        or support_up.shape != (3,)
        or not np.all(np.isfinite(reference))
        or not np.all(np.isfinite(measured))
        or not np.all(np.isfinite(support_up))
    ):
        raise ValueError("TCP poses and support normal must be finite 3-vectors")
    normal_norm = float(np.linalg.norm(support_up))
    if normal_norm <= 1e-9:
        raise ValueError("support normal cannot be zero")
    support_up = support_up / normal_norm
    return float(np.dot((measured - reference) * 1000.0, support_up))


def live_support_normal_guard_reason(
    signed_displacement_mm,
    *,
    maximum_downward_drift_mm=SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM,
):
    """Return a stable rejection code when the TCP descends too far."""
    signed = float(signed_displacement_mm)
    maximum = float(maximum_downward_drift_mm)
    if not math.isfinite(signed) or not math.isfinite(maximum) or maximum <= 0.0:
        raise ValueError("live support-normal guard inputs must be finite")
    if signed < -maximum:
        return "live_support_normal_downward_drift"
    return None


def live_other_joint_drift_guard_reason(
    measured_q,
    reference_q,
    *,
    allowed_joint_index,
    maximum_other_joint_drift_rad,
):
    """Reject drift on every joint except the explicitly tested axis."""
    measured = np.asarray(measured_q, dtype=float)
    reference = np.asarray(reference_q, dtype=float)
    maximum = float(maximum_other_joint_drift_rad)
    if (
        measured.shape != (6,)
        or reference.shape != (6,)
        or not np.all(np.isfinite(measured))
        or not np.all(np.isfinite(reference))
        or allowed_joint_index not in range(6)
        or not math.isfinite(maximum)
        or maximum <= 0.0
    ):
        raise ValueError("live other-joint drift guard inputs are invalid")
    drift = max(
        abs(float(measured[index] - reference[index]))
        for index in range(6)
        if index != allowed_joint_index
    )
    if drift > maximum:
        return "live_other_joint_drift", drift
    return None, drift


def _commander_snapshot_for_log(tilt_commander):
    snapshot = tilt_commander.last_snapshot
    if snapshot is None:
        return None
    return json.loads(json.dumps(snapshot, allow_nan=False))


def _append_guarded_motion_sample(
    trace,
    *,
    elapsed_s,
    phase,
    commanded_q,
    position,
    velocity,
    temperature,
    measured_tcp_pose,
    signed_normal_displacement_mm,
    tilt_commander,
):
    trace.append(
        {
            "sample_index": len(trace),
            "elapsed_s": float(elapsed_s),
            "phase": phase,
            "commanded_arm_q_rad": [float(value) for value in commanded_q],
            "measured_motor_position_rad": [float(value) for value in position],
            "measured_motor_velocity_rad_s": [float(value) for value in velocity],
            "measured_motor_temperature_c": [
                float(value) for value in temperature
            ],
            "arm_joint_error_command_minus_measured_rad": [
                float(commanded - measured)
                for commanded, measured in zip(commanded_q, position[:6])
            ],
            "measured_tcp_pose_xyz_xyzw": [
                float(value) for value in measured_tcp_pose
            ],
            "signed_support_normal_displacement_mm": float(
                signed_normal_displacement_mm
            ),
            "position_commander_snapshot": _commander_snapshot_for_log(
                tilt_commander
            ),
        }
    )


def run_guarded_support_normal_move(
    arm,
    q_from,
    q_to,
    *,
    label,
    tcp_reference,
    support_up_normal_base,
    tcp_kinematics,
    tilt_commander,
    trace,
    maximum_downward_drift_mm=SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM,
    joint_reference=None,
    allowed_moving_joint_index=None,
    maximum_other_joint_drift_rad=None,
):
    """Run one diagnostic-only ramp with a live 3 mm downward TCP guard."""
    limits = arm.limits
    delta = max(abs(a - b) for a, b in zip(q_from, q_to))
    ramp = max(
        motion_duration_s(
            delta,
            limits.v_max_rad_s,
            limits.motion_profile,
        ),
        motion_duration_s(
            abs(q_to[J6_INDEX] - q_from[J6_INDEX]),
            limits.j6_v_max_rad_s,
            limits.motion_profile,
            minimum_s=0.0,
        ),
    )
    trajectory_time = 0.0
    started = time.monotonic()
    while True:
        cycle_started = time.monotonic()
        u = min(1.0, trajectory_time / ramp)
        progress = motion_profile_progress(u, limits.motion_profile)
        target = [
            float(q_from[index] + progress * (q_to[index] - q_from[index]))
            for index in range(6)
        ]
        arm.command_position(target)
        position = [float(value) for value in arm.get_pos()]
        velocity = [float(value) for value in arm.get_vel()]
        temperature = [float(value) for value in arm.get_temp()]
        measured_tcp = tcp_kinematics.fk(position[:6])
        signed_normal = support_normal_signed_displacement_mm(
            tcp_reference,
            measured_tcp,
            support_up_normal_base,
        )
        _append_guarded_motion_sample(
            trace,
            elapsed_s=time.monotonic() - started,
            phase="ramp",
            commanded_q=target,
            position=position,
            velocity=velocity,
            temperature=temperature,
            measured_tcp_pose=measured_tcp,
            signed_normal_displacement_mm=signed_normal,
            tilt_commander=tilt_commander,
        )
        reason = live_support_normal_guard_reason(
            signed_normal,
            maximum_downward_drift_mm=maximum_downward_drift_mm,
        )
        if reason is not None:
            return {
                "code": reason,
                "message": (
                    f"{label}: signed support-normal displacement "
                    f"{signed_normal:.3f}mm exceeded downward limit "
                    f"{-maximum_downward_drift_mm:.3f}mm"
                ),
                "signed_support_normal_displacement_mm": signed_normal,
            }
        if joint_reference is not None:
            drift_reason, drift = live_other_joint_drift_guard_reason(
                position[:6],
                joint_reference,
                allowed_joint_index=allowed_moving_joint_index,
                maximum_other_joint_drift_rad=maximum_other_joint_drift_rad,
            )
            if drift_reason is not None:
                return {
                    "code": drift_reason,
                    "message": (
                        f"{label}: non-tested joint drift {drift:.6f}rad "
                        f"exceeded {maximum_other_joint_drift_rad:.6f}rad"
                    ),
                    "signed_support_normal_displacement_mm": signed_normal,
                    "maximum_other_joint_drift_rad": drift,
                }
        bad = arm.guard(
            position,
            velocity,
            temperature,
            target,
            settling=trajectory_time < limits.settle_seconds,
        )
        if bad:
            return {
                "code": "arm_guard_reject",
                "message": f"{label}: {bad}",
                "signed_support_normal_displacement_mm": signed_normal,
            }
        if u >= 1.0:
            return None
        trajectory_time = min(ramp, trajectory_time + arm.dt)
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))


def sample_guarded_support_normal_hold(
    arm,
    q_hold,
    *,
    settle_s,
    sample_count,
    label,
    tcp_reference,
    support_up_normal_base,
    tcp_kinematics,
    tilt_commander,
    trace,
    maximum_downward_drift_mm=SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM,
    joint_reference=None,
    allowed_moving_joint_index=None,
    maximum_other_joint_drift_rad=None,
):
    """Hold a diagnostic endpoint while continuously enforcing normal drift."""
    started = time.monotonic()
    samples = []
    while len(samples) < sample_count:
        cycle_started = time.monotonic()
        arm.command_position(q_hold)
        position = [float(value) for value in arm.get_pos()]
        velocity = [float(value) for value in arm.get_vel()]
        temperature = [float(value) for value in arm.get_temp()]
        elapsed = time.monotonic() - started
        measured_tcp = tcp_kinematics.fk(position[:6])
        signed_normal = support_normal_signed_displacement_mm(
            tcp_reference,
            measured_tcp,
            support_up_normal_base,
        )
        _append_guarded_motion_sample(
            trace,
            elapsed_s=elapsed,
            phase="settling" if elapsed < settle_s else "sampling",
            commanded_q=q_hold,
            position=position,
            velocity=velocity,
            temperature=temperature,
            measured_tcp_pose=measured_tcp,
            signed_normal_displacement_mm=signed_normal,
            tilt_commander=tilt_commander,
        )
        reason = live_support_normal_guard_reason(
            signed_normal,
            maximum_downward_drift_mm=maximum_downward_drift_mm,
        )
        if reason is not None:
            return None, {
                "code": reason,
                "message": (
                    f"{label}: signed support-normal displacement "
                    f"{signed_normal:.3f}mm exceeded downward limit "
                    f"{-maximum_downward_drift_mm:.3f}mm"
                ),
                "signed_support_normal_displacement_mm": signed_normal,
            }
        if joint_reference is not None:
            drift_reason, drift = live_other_joint_drift_guard_reason(
                position[:6],
                joint_reference,
                allowed_joint_index=allowed_moving_joint_index,
                maximum_other_joint_drift_rad=maximum_other_joint_drift_rad,
            )
            if drift_reason is not None:
                return None, {
                    "code": drift_reason,
                    "message": (
                        f"{label}: non-tested joint drift {drift:.6f}rad "
                        f"exceeded {maximum_other_joint_drift_rad:.6f}rad"
                    ),
                    "signed_support_normal_displacement_mm": signed_normal,
                    "maximum_other_joint_drift_rad": drift,
                }
        bad = arm.guard(
            position,
            velocity,
            temperature,
            list(q_hold),
            settling=elapsed < settle_s,
        )
        if bad:
            return None, {
                "code": "arm_guard_reject",
                "message": f"{label}: {bad}",
                "signed_support_normal_displacement_mm": signed_normal,
            }
        if elapsed >= settle_s:
            samples.append(position[:6])
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    median_q = [
        statistics.median(row[joint] for row in samples)
        for joint in range(6)
    ]
    return median_q, None


def _live_guard_leg_evaluation(q_command, trace, rejection):
    measured = trace[-1]["measured_motor_position_rad"][:6]
    error = [
        abs(float(commanded - actual))
        for commanded, actual in zip(q_command, measured)
    ]
    return {
        "passed": False,
        "reasons": [rejection["code"]],
        "abort_reason": rejection["message"],
        "commanded_q_rad": [float(value) for value in q_command],
        "measured_q_rad": measured,
        "joint_error_rad": error,
        "maximum_joint_error_rad": max(error),
        "maximum_joint_error_joint": int(np.argmax(error)) + 1,
        "signed_support_normal_displacement_mm": float(
            rejection["signed_support_normal_displacement_mm"]
        ),
        "support_normal_drift_mm": abs(
            float(rejection["signed_support_normal_displacement_mm"])
        ),
    }


def run_tangent_round_trip_phase(
    arm,
    *,
    phase_name,
    q_start,
    q_target,
    tcp_start,
    tcp_target,
    support_up_normal_base,
    tcp_kinematics,
    safety,
    phase_record,
):
    """Execute one guarded 4 mm out-and-back using fixed joint targets."""
    phase_record.update(
        {
            "phase": phase_name,
            "q_start_rad": [float(value) for value in q_start],
            "q_target_rad": [float(value) for value in q_target],
            "outbound_trace": [],
            "return_trace": [],
        }
    )
    abort = arm.move(q_start, q_target, f"{phase_name}_outbound")
    if abort:
        raise RuntimeError(f"{phase_name}_outbound: {abort}")
    measured_target_q = sample_hold_joint_median(
        arm,
        q_target,
        settle_s=float(safety["post_motion_settle_s"]),
        sample_count=int(safety["post_motion_sample_count"]),
        label=f"{phase_name}_outbound_hold",
        trace=phase_record["outbound_trace"],
    )
    outbound = evaluate_executed_tangent_correction(
        q_target,
        measured_target_q,
        tcp_start,
        tcp_target,
        tcp_kinematics.fk(measured_target_q),
        support_up_normal_base,
        safety,
    )
    phase_record["outbound"] = outbound
    if not outbound["passed"]:
        return False

    abort = arm.move(q_target, q_start, f"{phase_name}_return")
    if abort:
        raise RuntimeError(f"{phase_name}_return: {abort}")
    measured_return_q = sample_hold_joint_median(
        arm,
        q_start,
        settle_s=float(safety["post_motion_settle_s"]),
        sample_count=int(safety["post_motion_sample_count"]),
        label=f"{phase_name}_return_hold",
        trace=phase_record["return_trace"],
    )
    return_evaluation = evaluate_executed_tangent_correction(
        q_start,
        measured_return_q,
        tcp_target,
        tcp_start,
        tcp_kinematics.fk(measured_return_q),
        support_up_normal_base,
        safety,
    )
    phase_record["return"] = return_evaluation
    return bool(return_evaluation["passed"])


def run_support_normal_motion_ab(
    arm,
    tilt_commander,
    *,
    q_start,
    q_target,
    tcp_start,
    tcp_target,
    support_up_normal_base,
    tcp_kinematics,
    safety,
    record,
):
    """Compare identical guarded 4 mm round trips under two gravity normals."""
    record.update(
        {
            "planned_motion": True,
            "tangent_step_mm": AB_MOTION_TANGENT_STEP_MM,
            "support_normal_blend": AB_MOTION_SUPPORT_NORMAL_BLEND,
            "mount_only": {},
            "support_normal": {},
            "restore_trace": [],
        }
    )
    phases = {
        "mount_only": record["mount_only"],
        "support_normal": record["support_normal"],
    }
    restore_error = None
    try:
        mount_only_ok = run_tangent_round_trip_phase(
            arm,
            phase_name="mount_only",
            q_start=q_start,
            q_target=q_target,
            tcp_start=tcp_start,
            tcp_target=tcp_target,
            support_up_normal_base=support_up_normal_base,
            tcp_kinematics=tcp_kinematics,
            safety=safety,
            phase_record=record["mount_only"],
        )
        if not mount_only_ok:
            record["evaluation"] = evaluate_support_normal_motion_ab(phases)
            return record["evaluation"]

        update = tilt_commander.set_support_up_normal(
            support_up_normal_base,
            source="validated_horizontal_support_plane:motion_ab_diagnostic",
        )
        record["support_normal_update"] = update
        print("MOTION_AB_SUPPORT_NORMAL_UPDATE =", update)
        adaptive_ready_trace = []
        record["support_normal"]["ready_trace"] = adaptive_ready_trace
        sample_hold_joint_median(
            arm,
            q_start,
            settle_s=AB_ADAPTIVE_SETTLE_S,
            sample_count=AB_SAMPLE_COUNT,
            label="motion_ab_support_normal_ready",
            trace=adaptive_ready_trace,
        )
        run_tangent_round_trip_phase(
            arm,
            phase_name="support_normal",
            q_start=q_start,
            q_target=q_target,
            tcp_start=tcp_start,
            tcp_target=tcp_target,
            support_up_normal_base=support_up_normal_base,
            tcp_kinematics=tcp_kinematics,
            safety=safety,
            phase_record=record["support_normal"],
        )
        record["evaluation"] = evaluate_support_normal_motion_ab(phases)
        return record["evaluation"]
    finally:
        restore = tilt_commander.set_support_up_normal(
            tilt_commander.nominal_support_up_normal_base,
            source="mount_record_pitch_only:motion_ab_restore",
        )
        record["restore_support_normal_update"] = restore
        print("MOTION_AB_RESTORE_SUPPORT_NORMAL =", restore)
        if "evaluation" in record and record["evaluation"].get("passed"):
            try:
                restored_q = sample_hold_joint_median(
                    arm,
                    q_start,
                    settle_s=AB_RESTORE_HOLD_S,
                    sample_count=AB_SAMPLE_COUNT,
                    label="motion_ab_restore",
                    trace=record["restore_trace"],
                )
                record["restore"] = {
                    "median_q_rad": restored_q,
                    "tcp_pose_xyz_xyzw": tcp_kinematics.fk(restored_q),
                    "commander_snapshot": tilt_commander.last_snapshot,
                }
            except BaseException as exc:
                restore_error = f"{type(exc).__name__}: {exc}"
                record["restore_error"] = restore_error
        if restore_error is not None:
            raise RuntimeError(
                f"nominal compensation restore failed: {restore_error}"
            )


def run_guarded_support_normal_round_trip_phase(
    arm,
    tilt_commander,
    *,
    q_start,
    q_target,
    tcp_start,
    tcp_target,
    support_up_normal_base,
    tcp_kinematics,
    safety,
    phase_record,
):
    """Run one support-normal-only round trip with live downward guards."""
    phase_record.update(
        {
            "phase": "support_normal_only",
            "q_start_rad": [float(value) for value in q_start],
            "q_target_rad": [float(value) for value in q_target],
            "outbound_trace": [],
            "return_trace": [],
        }
    )
    rejection = run_guarded_support_normal_move(
        arm,
        q_start,
        q_target,
        label="support_normal_only_outbound",
        tcp_reference=tcp_start,
        support_up_normal_base=support_up_normal_base,
        tcp_kinematics=tcp_kinematics,
        tilt_commander=tilt_commander,
        trace=phase_record["outbound_trace"],
    )
    if rejection is not None:
        phase_record["outbound"] = _live_guard_leg_evaluation(
            q_target,
            phase_record["outbound_trace"],
            rejection,
        )
        return False
    measured_target_q, rejection = sample_guarded_support_normal_hold(
        arm,
        q_target,
        settle_s=float(safety["post_motion_settle_s"]),
        sample_count=int(safety["post_motion_sample_count"]),
        label="support_normal_only_outbound_hold",
        tcp_reference=tcp_start,
        support_up_normal_base=support_up_normal_base,
        tcp_kinematics=tcp_kinematics,
        tilt_commander=tilt_commander,
        trace=phase_record["outbound_trace"],
    )
    if rejection is not None:
        phase_record["outbound"] = _live_guard_leg_evaluation(
            q_target,
            phase_record["outbound_trace"],
            rejection,
        )
        return False
    outbound = evaluate_executed_tangent_correction(
        q_target,
        measured_target_q,
        tcp_start,
        tcp_target,
        tcp_kinematics.fk(measured_target_q),
        support_up_normal_base,
        safety,
    )
    phase_record["outbound"] = outbound
    if not outbound["passed"]:
        return False

    rejection = run_guarded_support_normal_move(
        arm,
        q_target,
        q_start,
        label="support_normal_only_return",
        tcp_reference=tcp_target,
        support_up_normal_base=support_up_normal_base,
        tcp_kinematics=tcp_kinematics,
        tilt_commander=tilt_commander,
        trace=phase_record["return_trace"],
    )
    if rejection is not None:
        phase_record["return"] = _live_guard_leg_evaluation(
            q_start,
            phase_record["return_trace"],
            rejection,
        )
        return False
    measured_return_q, rejection = sample_guarded_support_normal_hold(
        arm,
        q_start,
        settle_s=float(safety["post_motion_settle_s"]),
        sample_count=int(safety["post_motion_sample_count"]),
        label="support_normal_only_return_hold",
        tcp_reference=tcp_target,
        support_up_normal_base=support_up_normal_base,
        tcp_kinematics=tcp_kinematics,
        tilt_commander=tilt_commander,
        trace=phase_record["return_trace"],
    )
    if rejection is not None:
        phase_record["return"] = _live_guard_leg_evaluation(
            q_start,
            phase_record["return_trace"],
            rejection,
        )
        return False
    return_evaluation = evaluate_executed_tangent_correction(
        q_start,
        measured_return_q,
        tcp_target,
        tcp_start,
        tcp_kinematics.fk(measured_return_q),
        support_up_normal_base,
        safety,
    )
    phase_record["return"] = return_evaluation
    return bool(return_evaluation["passed"])


def evaluate_support_normal_only_motion(phase_record):
    reasons = []
    for leg_name in ("outbound", "return"):
        leg = phase_record.get(leg_name)
        if not isinstance(leg, dict):
            reasons.append(f"support_normal_{leg_name}_missing")
            continue
        if not leg.get("passed", False):
            reasons.extend(
                f"support_normal_{leg_name}_{reason}"
                for reason in (leg.get("reasons") or ["rejected"])
            )
    return {"passed": not reasons, "reasons": reasons}


def j3_bias_envelope_target(
    q_from,
    q_to,
    maximum_bias_rad=J3_CLOSED_LOOP_MAX_BIAS_RAD,
):
    """Return the furthest J3 command allowed by the closed-loop controller."""
    start = np.asarray(q_from, dtype=float)
    goal = np.asarray(q_to, dtype=float)
    if (
        start.shape != (6,)
        or goal.shape != (6,)
        or not np.all(np.isfinite(start))
        or not np.all(np.isfinite(goal))
        or not math.isfinite(maximum_bias_rad)
        or maximum_bias_rad <= 0.0
    ):
        raise ValueError("J3 bias envelope inputs are invalid")
    delta = float(goal[J3_RESPONSE_INDEX] - start[J3_RESPONSE_INDEX])
    if math.isclose(delta, 0.0, abs_tol=1e-12):
        return goal.tolist()
    envelope = goal.copy()
    envelope[J3_RESPONSE_INDEX] += math.copysign(maximum_bias_rad, delta)
    return envelope.tolist()


def next_j3_closed_loop_bias(
    current_bias_rad,
    desired_error_rad,
    motion_direction,
    *,
    tolerance_rad=J3_CLOSED_LOOP_TOLERANCE_RAD,
    step_rad=J3_CLOSED_LOOP_BIAS_STEP_RAD,
    maximum_bias_rad=J3_CLOSED_LOOP_MAX_BIAS_RAD,
):
    """Update a one-sided J3 command lead from physical target error."""
    values = (
        current_bias_rad,
        desired_error_rad,
        motion_direction,
        tolerance_rad,
        step_rad,
        maximum_bias_rad,
    )
    if not all(math.isfinite(float(value)) for value in values):
        raise ValueError("J3 closed-loop bias inputs must be finite")
    if motion_direction not in (-1.0, 1.0):
        raise ValueError("J3 motion direction must be -1 or +1")
    if not 0.0 < tolerance_rad <= step_rad <= maximum_bias_rad:
        raise ValueError("J3 closed-loop bias bounds are invalid")

    magnitude = max(
        0.0,
        min(maximum_bias_rad, motion_direction * current_bias_rad),
    )
    signed_lag = motion_direction * desired_error_rad
    if signed_lag > tolerance_rad:
        magnitude = min(maximum_bias_rad, magnitude + step_rad)
    elif signed_lag < -tolerance_rad:
        magnitude = max(0.0, magnitude - step_rad)
    return motion_direction * magnitude


def clear_position_bias_if_supported(arm) -> list[float] | None:
    commander = getattr(arm, "_position_commander", None)
    if commander is None or not hasattr(commander, "clear_position_bias"):
        return None
    return commander.clear_position_bias()


def run_j3_gated_tangent_move(
    arm,
    q_from,
    q_to,
    *,
    label,
    support_up_normal_base,
    tcp_kinematics,
    tilt_commander,
):
    """Run a tangent correction while pausing other joints for J3 lag."""
    start = np.asarray(q_from, dtype=float)
    goal = np.asarray(q_to, dtype=float)
    support_up = np.asarray(support_up_normal_base, dtype=float)
    if (
        start.shape != (6,)
        or goal.shape != (6,)
        or support_up.shape != (3,)
        or not np.all(np.isfinite(start))
        or not np.all(np.isfinite(goal))
        or not np.all(np.isfinite(support_up))
    ):
        raise ValueError("J3-gated tangent move inputs are invalid")
    support_norm = float(np.linalg.norm(support_up))
    if not 0.98 <= support_norm <= 1.02:
        raise ValueError("support normal must be a unit vector")
    support_up = support_up / support_norm
    if not hasattr(tilt_commander, "set_position_bias_rad"):
        raise RuntimeError("tilt commander does not support closed-loop bias")

    j3_delta = float(goal[J3_RESPONSE_INDEX] - start[J3_RESPONSE_INDEX])
    if math.isclose(j3_delta, 0.0, abs_tol=1e-6):
        abort = arm.move(start.tolist(), goal.tolist(), label)
        if abort:
            raise RuntimeError(abort)
        return {
            "mode": "direct_no_j3_delta",
            "j3_delta_rad": j3_delta,
            "final_bias_rad": float(
                tilt_commander.position_bias_rad[J3_RESPONSE_INDEX]
            ),
            "samples": [],
        }

    direction = math.copysign(1.0, j3_delta)
    existing_bias = np.asarray(tilt_commander.position_bias_rad, dtype=float)
    if existing_bias.shape != (6,) or not np.all(np.isfinite(existing_bias)):
        raise RuntimeError("tilt commander returned an invalid position bias")
    if np.max(np.abs(np.delete(existing_bias, J3_RESPONSE_INDEX))) > 1e-12:
        raise RuntimeError("only J3 may carry an outer-loop position bias")
    bias = float(existing_bias[J3_RESPONSE_INDEX])
    if direction * bias < 0.0:
        bias = 0.0
        tilt_commander.clear_position_bias()

    limits = arm.limits
    delta = max(abs(float(a - b)) for a, b in zip(start, goal))
    ramp = max(
        motion_duration_s(delta, limits.v_max_rad_s, limits.motion_profile),
        motion_duration_s(
            abs(float(goal[J6_INDEX] - start[J6_INDEX])),
            limits.j6_v_max_rad_s,
            limits.motion_profile,
            minimum_s=0.0,
        ),
    )
    initial_measured = [float(value) for value in arm.get_pos()[:6]]
    tcp_reference = tcp_kinematics.fk(initial_measured)
    trajectory_time = 0.0
    started = time.monotonic()
    last_bias_update = started - J3_CLOSED_LOOP_BIAS_UPDATE_S
    maximum_bias_started = None
    completion_samples = 0
    trace = []

    while True:
        cycle_started = time.monotonic()
        u = min(1.0, trajectory_time / ramp)
        progress = motion_profile_progress(u, limits.motion_profile)
        desired = start + progress * (goal - start)
        bias_vector = np.zeros(6, dtype=float)
        bias_vector[J3_RESPONSE_INDEX] = bias
        command_target = desired + bias_vector
        if not all(
            item["inside_hard_limit"]
            for item in joint_margin_details(command_target.tolist())
        ):
            raise RuntimeError("J3 closed-loop command exceeded a hard joint limit")
        tilt_commander.set_position_bias_rad(bias_vector.tolist())
        arm.command_position(desired.tolist())

        position = [float(value) for value in arm.get_pos()]
        velocity = [float(value) for value in arm.get_vel()]
        temperature = [float(value) for value in arm.get_temp()]
        measured_tcp = tcp_kinematics.fk(position[:6])
        signed_normal = support_normal_signed_displacement_mm(
            tcp_reference,
            measured_tcp,
            support_up,
        )
        desired_error = float(
            desired[J3_RESPONSE_INDEX] - position[J3_RESPONSE_INDEX]
        )
        signed_lag = direction * desired_error
        now = time.monotonic()
        if now - started > ramp + J3_CLOSED_LOOP_MAX_EXTRA_WALL_TIME_S:
            raise RuntimeError(
                f"{label}: J3 closed-loop move exceeded its wall-time limit"
            )
        trace.append(
            {
                "sample_index": len(trace),
                "elapsed_s": now - started,
                "trajectory_progress": float(progress),
                "trajectory_paused_for_j3": bool(
                    signed_lag > J3_CLOSED_LOOP_TOLERANCE_RAD
                ),
                "desired_q_rad": desired.tolist(),
                "position_bias_rad": bias_vector.tolist(),
                "command_target_q_rad": command_target.tolist(),
                "measured_q_rad": position[:6],
                "j3_desired_error_rad": desired_error,
                "signed_support_normal_displacement_mm": signed_normal,
                "position_commander_snapshot": _commander_snapshot_for_log(
                    tilt_commander
                ),
            }
        )

        normal_reason = live_support_normal_guard_reason(
            signed_normal,
            maximum_downward_drift_mm=(
                J3_CLOSED_LOOP_MAX_DOWNWARD_DRIFT_MM
            ),
        )
        if normal_reason is not None:
            raise RuntimeError(
                f"{label}: support-normal displacement {signed_normal:.3f}mm "
                f"crossed {-J3_CLOSED_LOOP_MAX_DOWNWARD_DRIFT_MM:.3f}mm"
            )
        guard_target = desired.tolist()
        guard_target[J3_RESPONSE_INDEX] = position[J3_RESPONSE_INDEX]
        bad = arm.guard(
            position,
            velocity,
            temperature,
            guard_target,
            settling=trajectory_time < limits.settle_seconds,
        )
        if bad:
            raise RuntimeError(f"{label}: {bad}")

        if now - last_bias_update >= J3_CLOSED_LOOP_BIAS_UPDATE_S:
            updated_bias = next_j3_closed_loop_bias(
                bias,
                desired_error,
                direction,
            )
            if not math.isclose(updated_bias, bias, abs_tol=1e-12):
                bias = updated_bias
                last_bias_update = now
                print(
                    "J3_CLOSED_LOOP_BIAS",
                    f"bias={bias:+.4f}rad",
                    f"desired_error={desired_error:+.4f}rad",
                )

        at_bias_limit = (
            direction * bias
            >= J3_CLOSED_LOOP_MAX_BIAS_RAD - 1e-12
        )
        if signed_lag > J3_CLOSED_LOOP_TOLERANCE_RAD and at_bias_limit:
            if maximum_bias_started is None:
                maximum_bias_started = now
            elif now - maximum_bias_started >= J3_CLOSED_LOOP_MAX_BIAS_DWELL_S:
                raise RuntimeError(
                    f"{label}: J3 remained unresponsive at the bounded "
                    f"{J3_CLOSED_LOOP_MAX_BIAS_RAD:.3f}rad command lead"
                )
        else:
            maximum_bias_started = None

        if u >= 1.0:
            if abs(desired_error) <= J3_CLOSED_LOOP_TOLERANCE_RAD:
                completion_samples += 1
            else:
                completion_samples = 0
            if completion_samples >= J3_CLOSED_LOOP_COMPLETION_SAMPLES:
                return {
                    "mode": "j3_closed_loop_gated",
                    "j3_delta_rad": j3_delta,
                    "final_bias_rad": bias,
                    "final_j3_desired_error_rad": desired_error,
                    "sample_count": len(trace),
                    "samples": trace,
                }

        # A lagging J3 freezes the synchronized path. Ahead-of-path J3 may be
        # caught by advancing the desired path while the bias is reduced.
        if signed_lag <= J3_CLOSED_LOOP_TOLERANCE_RAD:
            trajectory_time = min(ramp, trajectory_time + arm.dt)
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))


def build_j3_positive_targets(q_reference, offsets=J3_RESPONSE_OFFSETS_RAD):
    """Build diagnostic targets that change only J3 in the positive direction."""
    reference = np.asarray(q_reference, dtype=float)
    offset_values = np.asarray(offsets, dtype=float)
    if reference.shape != (6,) or not np.all(np.isfinite(reference)):
        raise ValueError("J3 response reference must be a finite 6-vector")
    if (
        offset_values.ndim != 1
        or offset_values.size == 0
        or not np.all(np.isfinite(offset_values))
        or np.any(offset_values <= 0.0)
        or np.any(np.diff(offset_values) <= 0.0)
    ):
        raise ValueError("J3 response offsets must be finite, positive, and increasing")
    targets = []
    for offset in offset_values:
        target = reference.copy()
        target[J3_RESPONSE_INDEX] += float(offset)
        targets.append(target.tolist())
    return targets


def evaluate_j3_response_stage(
    q_reference,
    q_command,
    q_measured,
    reference_tcp_pose,
    measured_tcp_pose,
    support_up_normal_base,
):
    """Summarize encoder response to one positive J3 command."""
    reference = np.asarray(q_reference, dtype=float)
    command = np.asarray(q_command, dtype=float)
    measured = np.asarray(q_measured, dtype=float)
    if any(
        vector.shape != (6,) or not np.all(np.isfinite(vector))
        for vector in (reference, command, measured)
    ):
        raise ValueError("J3 response vectors must contain six finite joints")
    commanded_delta = float(command[J3_RESPONSE_INDEX] - reference[J3_RESPONSE_INDEX])
    if commanded_delta <= 0.0:
        raise ValueError("J3 response command must be positive")
    measured_delta = float(measured[J3_RESPONSE_INDEX] - reference[J3_RESPONSE_INDEX])
    other_indices = [index for index in range(6) if index != J3_RESPONSE_INDEX]
    maximum_other_drift = max(
        abs(float(measured[index] - reference[index]))
        for index in other_indices
    )
    signed_normal = support_normal_signed_displacement_mm(
        reference_tcp_pose,
        measured_tcp_pose,
        support_up_normal_base,
    )
    return {
        "commanded_j3_delta_rad": commanded_delta,
        "measured_j3_delta_rad": measured_delta,
        "response_ratio": measured_delta / commanded_delta,
        "maximum_other_joint_drift_rad": maximum_other_drift,
        "signed_support_normal_displacement_mm": signed_normal,
        "q_command_rad": command.tolist(),
        "q_measured_rad": measured.tolist(),
    }


def evaluate_j3_positive_response(record):
    """Classify the one-shot J3 diagnostic without hiding partial response."""
    reasons = []
    stages = record.get("stages", [])
    if len(stages) != len(J3_RESPONSE_OFFSETS_RAD):
        reasons.append("j3_response_stage_sequence_incomplete")
    for stage in stages:
        if stage.get("rejection"):
            reasons.append(
                "j3_response_stage_"
                f"{stage['stage_index']}_{stage['rejection']['code']}"
            )
        if (
            stage.get("maximum_other_joint_drift_rad", float("inf"))
            > J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
        ):
            reasons.append(
                "j3_response_stage_"
                f"{stage['stage_index']}_other_joint_drift"
            )
    final_ratio = None
    if stages:
        final_ratio = stages[-1].get("response_ratio")
    if final_ratio is None or final_ratio < J3_RESPONSE_MINIMUM_FINAL_RATIO:
        reasons.append("j3_positive_response_ratio_too_small")
    return_error = record.get("return_maximum_joint_error_rad")
    if return_error is None:
        reasons.append("j3_response_return_missing")
    elif return_error > J3_RESPONSE_MAX_RETURN_ERROR_RAD:
        reasons.append("j3_response_return_error_too_large")
    return {
        "passed": not reasons,
        "reasons": reasons,
        "final_response_ratio": final_ratio,
        "classification": (
            "responsive" if not reasons else "unresponsive_or_rejected"
        ),
    }


def run_j3_positive_response(
    arm,
    tilt_commander,
    *,
    q_start,
    support_up_normal_base,
    tcp_kinematics,
    collision_checker,
    safety,
    record,
):
    """Run one bounded positive-J3 identification and return to its reference."""
    record.update(
        {
            "joint": 3,
            "offsets_rad": list(J3_RESPONSE_OFFSETS_RAD),
            "support_normal_blend": AB_MOTION_SUPPORT_NORMAL_BLEND,
            "maximum_live_downward_drift_mm": J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM,
            "maximum_other_joint_drift_rad": (
                J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
            ),
            "ready_trace": [],
            "stages": [],
            "return_trace": [],
        }
    )
    update = tilt_commander.set_support_up_normal(
        support_up_normal_base,
        source="validated_horizontal_support_plane:j3_response_diagnostic",
    )
    record["support_normal_update"] = update
    print("J3_RESPONSE_SUPPORT_NORMAL_UPDATE =", update)
    try:
        q_reference, rejection = sample_guarded_support_normal_hold(
            arm,
            q_start,
            settle_s=AB_ADAPTIVE_SETTLE_S,
            sample_count=AB_SAMPLE_COUNT,
            label="j3_response_ready",
            tcp_reference=tcp_kinematics.fk(q_start),
            support_up_normal_base=support_up_normal_base,
            tcp_kinematics=tcp_kinematics,
            tilt_commander=tilt_commander,
            trace=record["ready_trace"],
            maximum_downward_drift_mm=J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM,
        )
        if rejection is not None:
            record["ready_rejection"] = rejection
            record["evaluation"] = evaluate_j3_positive_response(record)
            return record["evaluation"]

        q_reference = [float(value) for value in q_reference]
        reference_tcp = tcp_kinematics.fk(q_reference)
        targets = build_j3_positive_targets(q_reference)
        record["q_reference_rad"] = q_reference
        record["reference_tcp_pose_xyz_xyzw"] = reference_tcp
        command_from = list(q_reference)
        completed = True
        for stage_index, (offset, target) in enumerate(
            zip(J3_RESPONSE_OFFSETS_RAD, targets), start=1
        ):
            validate_local_joint_step(q_reference, target, safety)
            collision = check_collision_segment(
                collision_checker,
                command_from,
                target,
                float(safety["collision_step_rad"]),
            )
            predicted_tcp = tcp_kinematics.fk(target)
            predicted_normal = support_normal_signed_displacement_mm(
                reference_tcp,
                predicted_tcp,
                support_up_normal_base,
            )
            predicted_displacement = float(
                np.linalg.norm(
                    (np.asarray(predicted_tcp[:3]) - np.asarray(reference_tcp[:3]))
                    * 1000.0
                )
            )
            if predicted_normal < -0.1:
                raise RuntimeError(
                    "positive J3 preview unexpectedly descends along the support normal"
                )
            if predicted_displacement > 10.0:
                raise RuntimeError(
                    "positive J3 preview exceeds the 10 mm diagnostic envelope"
                )
            stage = {
                "stage_index": stage_index,
                "requested_offset_rad": float(offset),
                "q_target_rad": [float(value) for value in target],
                "predicted_tcp_displacement_mm": predicted_displacement,
                "predicted_support_normal_displacement_mm": predicted_normal,
                "collision": collision,
                "trace": [],
            }
            record["stages"].append(stage)
            rejection = run_guarded_support_normal_move(
                arm,
                command_from,
                target,
                label=f"j3_response_stage_{stage_index}",
                tcp_reference=reference_tcp,
                support_up_normal_base=support_up_normal_base,
                tcp_kinematics=tcp_kinematics,
                tilt_commander=tilt_commander,
                trace=stage["trace"],
                maximum_downward_drift_mm=J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM,
                joint_reference=q_reference,
                allowed_moving_joint_index=J3_RESPONSE_INDEX,
                maximum_other_joint_drift_rad=(
                    J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
                ),
            )
            if rejection is not None:
                stage["rejection"] = rejection
                completed = False
                break
            q_measured, rejection = sample_guarded_support_normal_hold(
                arm,
                target,
                settle_s=J3_RESPONSE_SETTLE_S,
                sample_count=J3_RESPONSE_SAMPLE_COUNT,
                label=f"j3_response_stage_{stage_index}_hold",
                tcp_reference=reference_tcp,
                support_up_normal_base=support_up_normal_base,
                tcp_kinematics=tcp_kinematics,
                tilt_commander=tilt_commander,
                trace=stage["trace"],
                maximum_downward_drift_mm=J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM,
                joint_reference=q_reference,
                allowed_moving_joint_index=J3_RESPONSE_INDEX,
                maximum_other_joint_drift_rad=(
                    J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
                ),
            )
            if rejection is not None:
                stage["rejection"] = rejection
                completed = False
                break
            measured_tcp = tcp_kinematics.fk(q_measured)
            stage.update(
                evaluate_j3_response_stage(
                    q_reference,
                    target,
                    q_measured,
                    reference_tcp,
                    measured_tcp,
                    support_up_normal_base,
                )
            )
            print(
                "J3_RESPONSE_STAGE",
                f"offset={offset:+.3f}rad",
                f"measured={stage['measured_j3_delta_rad']:+.6f}rad",
                f"ratio={stage['response_ratio']:.3f}",
                f"other_drift={stage['maximum_other_joint_drift_rad']:.6f}rad",
                f"normal={stage['signed_support_normal_displacement_mm']:+.3f}mm",
            )
            if (
                stage["maximum_other_joint_drift_rad"]
                > J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
            ):
                stage["rejection"] = {
                    "code": "other_joint_drift",
                    "message": "non-J3 drift exceeded the diagnostic limit",
                }
                completed = False
                break
            command_from = list(target)

        if completed:
            rejection = run_guarded_support_normal_move(
                arm,
                command_from,
                q_reference,
                label="j3_response_return",
                tcp_reference=reference_tcp,
                support_up_normal_base=support_up_normal_base,
                tcp_kinematics=tcp_kinematics,
                tilt_commander=tilt_commander,
                trace=record["return_trace"],
                maximum_downward_drift_mm=J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM,
                joint_reference=q_reference,
                allowed_moving_joint_index=J3_RESPONSE_INDEX,
                maximum_other_joint_drift_rad=(
                    J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
                ),
            )
            if rejection is not None:
                record["return_rejection"] = rejection
            else:
                q_return, rejection = sample_guarded_support_normal_hold(
                    arm,
                    q_reference,
                    settle_s=J3_RESPONSE_SETTLE_S,
                    sample_count=J3_RESPONSE_SAMPLE_COUNT,
                    label="j3_response_return_hold",
                    tcp_reference=reference_tcp,
                    support_up_normal_base=support_up_normal_base,
                    tcp_kinematics=tcp_kinematics,
                    tilt_commander=tilt_commander,
                    trace=record["return_trace"],
                    maximum_downward_drift_mm=J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM,
                    joint_reference=q_reference,
                    allowed_moving_joint_index=J3_RESPONSE_INDEX,
                    maximum_other_joint_drift_rad=(
                        J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
                    ),
                )
                if rejection is not None:
                    record["return_rejection"] = rejection
                else:
                    record["q_return_rad"] = [float(value) for value in q_return]
                    record["return_maximum_joint_error_rad"] = max(
                        abs(float(actual - expected))
                        for actual, expected in zip(q_return, q_reference)
                    )
        record["evaluation"] = evaluate_j3_positive_response(record)
        return record["evaluation"]
    finally:
        restore = tilt_commander.set_support_up_normal(
            tilt_commander.nominal_support_up_normal_base,
            source="mount_record_pitch_only:j3_response_restore",
        )
        record["restore_support_normal_update"] = restore
        print("J3_RESPONSE_SUPPORT_NORMAL_RESTORE =", restore)


def run_support_normal_only_motion(
    arm,
    tilt_commander,
    *,
    q_start,
    q_target,
    tcp_start,
    tcp_target,
    support_up_normal_base,
    tcp_kinematics,
    safety,
    record,
):
    """Test only the statically-qualified 50% support-normal compensation."""
    record.update(
        {
            "planned_motion": True,
            "tangent_step_mm": AB_MOTION_TANGENT_STEP_MM,
            "support_normal_blend": AB_MOTION_SUPPORT_NORMAL_BLEND,
            "maximum_live_downward_drift_mm": (
                SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM
            ),
            "ready_trace": [],
            "support_normal": {},
        }
    )
    update = tilt_commander.set_support_up_normal(
        support_up_normal_base,
        source="validated_horizontal_support_plane:motion_only_diagnostic",
    )
    record["support_normal_update"] = update
    print("SUPPORT_NORMAL_MOTION_UPDATE =", update)
    try:
        _, rejection = sample_guarded_support_normal_hold(
            arm,
            q_start,
            settle_s=AB_ADAPTIVE_SETTLE_S,
            sample_count=AB_SAMPLE_COUNT,
            label="support_normal_only_ready",
            tcp_reference=tcp_start,
            support_up_normal_base=support_up_normal_base,
            tcp_kinematics=tcp_kinematics,
            tilt_commander=tilt_commander,
            trace=record["ready_trace"],
        )
        if rejection is not None:
            record["ready_rejection"] = rejection
            record["evaluation"] = {
                "passed": False,
                "reasons": [f"support_normal_ready_{rejection['code']}"],
            }
            return record["evaluation"]
        run_guarded_support_normal_round_trip_phase(
            arm,
            tilt_commander,
            q_start=q_start,
            q_target=q_target,
            tcp_start=tcp_start,
            tcp_target=tcp_target,
            support_up_normal_base=support_up_normal_base,
            tcp_kinematics=tcp_kinematics,
            safety=safety,
            phase_record=record["support_normal"],
        )
        record["evaluation"] = evaluate_support_normal_only_motion(
            record["support_normal"]
        )
        return record["evaluation"]
    finally:
        restore = tilt_commander.set_support_up_normal(
            tilt_commander.nominal_support_up_normal_base,
            source="mount_record_pitch_only:motion_only_restore",
        )
        record["restore_support_normal_update"] = restore
        print("SUPPORT_NORMAL_MOTION_RESTORE =", restore)


def finalize_run_log(log_path, log, *, status: str, result_name: str) -> None:
    """Persist a terminal run state before control leaves the guarded try block."""
    log["status"] = status
    log["result"] = result_name
    log["finished_at"] = datetime.now().astimezone().isoformat(
        timespec="seconds"
    )
    write_json(log_path, log)


def wait_for_visual_recovery_command(arm, q_hold, error_text: str) -> str:
    """Hold safely while the operator chooses retry, re-teach, or quit."""
    print("RECOVERABLE_VISUAL_REJECT =", error_text)
    print("The arm remains enabled at the current high-hover pose.")
    print("r: retry RGB-D here; t: support arm then return to teaching; q: disable.")
    while True:
        command, _ = run_worker_while_holding(
            arm,
            q_hold,
            lambda: input("RECOVERY_COMMAND [r/t/q]: ").strip().lower(),
            timeout_s=None,
            label="wait_for_visual_recovery_command",
        )
        if command in {"r", "t", "q"}:
            return command
        print("Only r, t, or q is accepted; high-hover hold continues.")


def recover_visual_failure(
    arm,
    q_hold,
    error_text,
    *,
    loaded,
    vision_config,
    collision_checker,
    flange_kinematics,
) -> tuple[str, list[float] | None, dict | None]:
    command = wait_for_visual_recovery_command(arm, q_hold, error_text)
    if command != "t":
        return command, None, None
    print("RETURNING_TO_TEACHING: keep supporting the arm while gravity mode starts.")
    clear_position_bias_if_supported(arm)
    arm.gravity()
    preview = TeachingCameraPreview(loaded.record, vision_config)
    new_q, record = teaching_until_locked_with_preview(
        arm,
        collision_checker=collision_checker,
        collision_step_rad=float(
            loaded.record["safety"]["collision_step_rad"]
        ),
        minimum_joint_margin_deg=float(
            loaded.record["safety"]["minimum_joint_margin_deg"]
        ),
        maximum_camera_tilt_from_down_deg=float(
            loaded.record["safety"]["maximum_camera_tilt_from_down_deg"]
        ),
        flange_kinematics=flange_kinematics,
        transform_flange_camera=loaded.transform_flange_camera,
        preview=preview,
    )
    if new_q is None:
        return "q", None, None
    return "t", list(new_q), record


def wait_for_motion_recovery_command(arm, q_hold, error_text: str) -> str:
    """Hold after an ineffective tangent move; only re-teach or disable is safe."""
    print("RECOVERABLE_MOTION_REJECT =", error_text)
    print("The arm remains enabled at the current high-hover command.")
    print("t: support arm then return to teaching; q: disable.")
    while True:
        command, _ = run_worker_while_holding(
            arm,
            q_hold,
            lambda: input("MOTION_RECOVERY_COMMAND [t/q]: ").strip().lower(),
            timeout_s=None,
            label="wait_for_motion_recovery_command",
        )
        if command in {"t", "q"}:
            return command
        print("Only t or q is accepted; high-hover hold continues.")


def recover_motion_failure(
    arm,
    q_hold,
    error_text,
    *,
    loaded,
    vision_config,
    collision_checker,
    flange_kinematics,
) -> tuple[str, list[float] | None, dict | None]:
    command = wait_for_motion_recovery_command(arm, q_hold, error_text)
    if command == "q":
        return "q", None, None
    print("RETURNING_TO_TEACHING: keep supporting the arm while gravity mode starts.")
    clear_position_bias_if_supported(arm)
    arm.gravity()
    preview = TeachingCameraPreview(loaded.record, vision_config)
    new_q, record = teaching_until_locked_with_preview(
        arm,
        collision_checker=collision_checker,
        collision_step_rad=float(
            loaded.record["safety"]["collision_step_rad"]
        ),
        minimum_joint_margin_deg=float(
            loaded.record["safety"]["minimum_joint_margin_deg"]
        ),
        maximum_camera_tilt_from_down_deg=float(
            loaded.record["safety"]["maximum_camera_tilt_from_down_deg"]
        ),
        flange_kinematics=flange_kinematics,
        transform_flange_camera=loaded.transform_flange_camera,
        preview=preview,
    )
    if new_q is None:
        return "q", None, None
    return "t", list(new_q), record


def bind_capture_path(capture, capture_path):
    """Adapt an in-memory live capture to the detector's saved-capture contract."""
    detection_capture = dict(capture)
    detection_capture["path"] = Path(capture_path)
    return detection_capture


def capture_detection_worker(loaded, vision_config, run_dir, iteration):
    capture_cfg = loaded.record["capture"]

    def capture_and_detect():
        capture = capture_aligned_rgbd(
            serial=loaded.record["camera_serial"],
            width=int(capture_cfg["width"]),
            height=int(capture_cfg["height"]),
            fps=int(capture_cfg["fps"]),
            warmup_frames=int(capture_cfg["warmup_frames"]),
            depth_frames=int(capture_cfg["depth_frames"]),
            timeout_ms=int(capture_cfg["timeout_ms"]),
            min_valid_depth_ratio=float(
                capture_cfg["minimum_valid_depth_ratio"]
            ),
            max_frame_interval_ms=float(
                capture_cfg["maximum_frame_interval_ms"]
            ),
        )
        capture_path = run_dir / f"iteration_{iteration:02d}_capture.npz"
        save_capture(capture, capture_path, write_preview=True)
        detection_capture = bind_capture_path(capture, capture_path)
        detection = detect_capture(detection_capture, vision_config)
        detection_path = run_dir / f"iteration_{iteration:02d}_detection.json"
        preview_path = run_dir / f"iteration_{iteration:02d}_detection.png"
        save_result(detection, detection_path)
        save_preview(capture["rgb"], detection, preview_path)
        return {
            "capture_metadata": capture["metadata"],
            "detection": detection,
            "capture_path": str(capture_path.relative_to(PROJECT_ROOT)),
            "detection_path": str(detection_path.relative_to(PROJECT_ROOT)),
            "preview_path": str(preview_path.relative_to(PROJECT_ROOT)),
        }

    def worker():
        try:
            return capture_and_detect()
        except BaseException as exc:
            if is_recoverable_visual_error(exc):
                return {
                    "recoverable_error": f"{type(exc).__name__}: {exc}",
                    "recoverable_stage": "capture_detection",
                }
            raise

    return worker


def build_planning_worker(
    *,
    capture_result,
    q_observed,
    q_hold,
    loaded,
    flange_kinematics,
    tcp_kinematics,
    collision_checker,
    cumulative_tangent_motion_mm,
    maximum_tangent_step_mm=None,
    joint_plan_required=True,
):
    safety = dict(loaded.record["safety"])
    if maximum_tangent_step_mm is not None:
        requested_step = float(maximum_tangent_step_mm)
        if (
            not math.isfinite(requested_step)
            or requested_step <= 0.0
            or requested_step > float(safety["maximum_xy_step_mm"])
        ):
            raise ValueError(
                "diagnostic tangent step must be positive and cannot exceed "
                "the configured maximum"
            )
        safety["maximum_xy_step_mm"] = requested_step

    def plan_and_check():
        flange_pose = flange_kinematics.fk(q_observed)
        transform_base_camera = dynamic_base_camera(
            flange_pose, loaded.transform_flange_camera
        )
        observation = extract_single_surface_observation(
            capture_result["detection"],
            capture_result["capture_metadata"],
            transform_base_camera,
            loaded.record["camera_serial"],
            safety,
        )
        tcp_pose = tcp_kinematics.fk(q_observed)
        correction = plan_high_hover_tangent_correction(
            tcp_pose,
            observation["surface_point_base_m"],
            observation["support_up_normal_base"],
            safety,
            loaded.record["validated_workspace"],
            cumulative_tangent_motion_mm=cumulative_tangent_motion_mm,
        )
        result = {
            "q_observed_rad": list(q_observed),
            "flange_pose_xyz_xyzw": flange_pose,
            "tcp_pose_before_xyz_xyzw": tcp_pose,
            "T_base_camera": transform_base_camera.tolist(),
            "observation": observation,
            "correction": correction,
            "next_q_rad": None,
            "ik": None,
            "collision": None,
        }
        if correction["converged"] or not joint_plan_required:
            return result
        next_q, ik = find_local_ik(
            tcp_kinematics,
            q_observed,
            correction["desired_tcp_pose_xyz_xyzw"],
            safety,
        )
        # Validate against the commanded hold point as well as measured pose.
        validate_local_joint_step(q_hold, next_q, safety)
        collision = check_collision_segment(
            collision_checker,
            q_hold,
            next_q,
            float(safety["collision_step_rad"]),
        )
        j3_bias_envelope = j3_bias_envelope_target(q_hold, next_q)
        validate_local_joint_step(q_hold, j3_bias_envelope, safety)
        j3_bias_collision_outbound = check_collision_segment(
            collision_checker,
            q_hold,
            j3_bias_envelope,
            float(safety["collision_step_rad"]),
        )
        j3_bias_collision_to_goal = check_collision_segment(
            collision_checker,
            j3_bias_envelope,
            next_q,
            float(safety["collision_step_rad"]),
        )
        after = tcp_kinematics.fk(next_q)
        support_up = np.asarray(
            observation["support_up_normal_base"], dtype=float
        )
        planned_normal_drift_mm = float(
            np.dot(np.asarray(after[:3]) - np.asarray(tcp_pose[:3]), support_up)
            * 1000.0
        )
        if abs(planned_normal_drift_mm) > float(
            safety["maximum_fk_position_error_mm"]
        ):
            raise RuntimeError(
                "planned correction changed support-normal clearance by "
                f"{planned_normal_drift_mm:.3f} mm"
            )
        if quaternion_error_deg(after[3:], tcp_pose[3:]) > float(
            safety["maximum_fk_orientation_error_deg"]
        ):
            raise RuntimeError("planned correction changed TCP orientation")
        envelope_tcp = tcp_kinematics.fk(j3_bias_envelope)
        envelope_normal_displacement_mm = float(
            np.dot(
                np.asarray(envelope_tcp[:3]) - np.asarray(tcp_pose[:3]),
                support_up,
            )
            * 1000.0
        )
        if (
            envelope_normal_displacement_mm
            < -J3_CLOSED_LOOP_MAX_DOWNWARD_DRIFT_MM
        ):
            raise RuntimeError(
                "J3 closed-loop bias envelope moves toward the support plane "
                f"by {envelope_normal_displacement_mm:.3f} mm"
            )
        result["next_q_rad"] = next_q
        result["tcp_pose_after_xyz_xyzw"] = after
        result["planned_support_normal_drift_mm"] = planned_normal_drift_mm
        result["ik"] = ik
        result["collision"] = collision
        result["j3_closed_loop_precheck"] = {
            "bias_envelope_q_rad": j3_bias_envelope,
            "bias_envelope_support_normal_displacement_mm": (
                envelope_normal_displacement_mm
            ),
            "collision_outbound": j3_bias_collision_outbound,
            "collision_to_goal": j3_bias_collision_to_goal,
        }
        return result

    def worker():
        try:
            return plan_and_check()
        except BaseException as exc:
            if is_recoverable_visual_error(exc):
                return {
                    "recoverable_error": f"{type(exc).__name__}: {exc}",
                    "recoverable_stage": "planning",
                }
            raise

    return worker


_capture_detection_worker_strict = capture_detection_worker
_build_planning_worker_strict = build_planning_worker


def capture_detection_worker(loaded, vision_config, run_dir, iteration):
    strict_worker = _capture_detection_worker_strict(
        loaded, vision_config, run_dir, iteration
    )

    def worker():
        try:
            return strict_worker()
        except BaseException as exc:
            if not is_recoverable_visual_error(exc):
                raise
            return {
                "recoverable_error": f"{type(exc).__name__}: {exc}",
                "recoverable_stage": "capture_detection",
            }

    return worker


def build_planning_worker(**kwargs):
    strict_worker = _build_planning_worker_strict(**kwargs)

    def worker():
        try:
            return strict_worker()
        except BaseException as exc:
            if not is_recoverable_visual_error(exc):
                raise
            return {
                "recoverable_error": f"{type(exc).__name__}: {exc}",
                "recoverable_stage": "planning",
            }

    return worker


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="腕载D455支撑平面切向高悬停闭环；禁止法向下降、合爪和提升"
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--run-id")
    parser.add_argument(
        "--teach-lock",
        action="store_true",
        help="同一进程内重力补偿示教、锁定、视觉对准，并保持到输入q",
    )
    parser.add_argument(
        "--compensation-ab-only",
        action="store_true",
        help=(
            "hold one locked joint command while comparing mount-only and "
            "a bounded support-normal compensation blend; no planned motion"
        ),
    )
    parser.add_argument(
        "--compensation-motion-ab-only",
        action="store_true",
        help=(
            "compare identical guarded 4 mm round trips under mount-only and "
            "50-percent support-normal compensation"
        ),
    )
    parser.add_argument(
        "--support-normal-motion-only",
        action="store_true",
        help=(
            "run only the statically-qualified 50-percent support-normal "
            "4 mm round trip with a live 3 mm downward-drift guard"
        ),
    )
    parser.add_argument(
        "--j3-response-only",
        action="store_true",
        help=(
            "run one positive-J3 response identification under the "
            "statically-qualified 50-percent support-normal compensation"
        ),
    )
    parser.add_argument(
        "--compensation-ab-blend",
        type=float,
        choices=AB_ALLOWED_SUPPORT_NORMAL_BLENDS,
        default=None,
        help=(
            "static A/B support-normal blend; only 0.25 or 0.50 is allowed, "
            "and it is valid only with --compensation-ab-only"
        ),
    )
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)

    selected_diagnostic_count = sum(
        bool(value)
        for value in (
            args.compensation_ab_only,
            args.compensation_motion_ab_only,
            args.support_normal_motion_only,
            args.j3_response_only,
        )
    )
    if selected_diagnostic_count > 1:
        parser.error(
            "compensation diagnostic modes are mutually exclusive"
        )
    motion_compensation_diagnostic = bool(
        args.compensation_motion_ab_only
        or args.support_normal_motion_only
        or args.j3_response_only
    )
    compensation_diagnostic = bool(
        args.compensation_ab_only or motion_compensation_diagnostic
    )
    if (
        args.compensation_ab_blend is not None
        and not compensation_diagnostic
    ):
        parser.error(
            "--compensation-ab-blend requires a compensation A/B mode"
        )
    ab_support_normal_blend = (
        AB_SUPPORT_NORMAL_BLEND
        if args.compensation_ab_blend is None
        else float(args.compensation_ab_blend)
    )
    if motion_compensation_diagnostic:
        if not args.teach_lock:
            parser.error(
                "motion compensation diagnostics require --teach-lock"
            )
        if not math.isclose(
            ab_support_normal_blend,
            AB_MOTION_SUPPORT_NORMAL_BLEND,
            rel_tol=0.0,
            abs_tol=1e-12,
        ):
            parser.error(
                "motion compensation diagnostics require "
                "--compensation-ab-blend 0.50"
            )

    loaded = load_wrist_servo_config(args.config)
    if loaded.record["mode"] != "high_hover_support_tangent_only":
        raise ValueError(
            "本实机入口只接受high_hover_support_tangent_only配置；"
            "旧base-XY配置仅可用于历史离线读取"
        )
    vision_config, _ = load_vision_config(loaded.vision_config_path)
    mount_record = json.loads(
        loaded.mount_config_path.read_text(encoding="utf-8")
    )
    tilt_config = loaded.record["tilt_compensation"]
    tilt_scale = float(tilt_config["scale"])
    maximum_support_tilt_deg = float(
        tilt_config["maximum_support_tilt_deg"]
    )
    maximum_support_normal_deviation_deg = float(
        tilt_config["maximum_support_normal_deviation_from_mount_deg"]
    )
    normal_transition_s = float(tilt_config["normal_transition_s"])
    configured_support_normal_blend = float(
        tilt_config["support_normal_blend"]
    )
    support_normal_blend = (
        ab_support_normal_blend
        if compensation_diagnostic
        else configured_support_normal_blend
    )
    rear_edge_lower_deg = float(
        mount_record["mount_measurement"]["rear_edge_lower_deg"]
    )
    print(
        "MODE =",
        (
            "SUPPORT_NORMAL_COMPENSATION_AB_HOLD_ONLY"
            if args.compensation_ab_only
            else (
                "SUPPORT_NORMAL_J3_POSITIVE_RESPONSE_ONLY"
                if args.j3_response_only
                else (
                    "SUPPORT_NORMAL_COMPENSATION_MOTION_ONLY_4MM"
                    if args.support_normal_motion_only
                    else (
                        "SUPPORT_NORMAL_COMPENSATION_MOTION_AB_4MM"
                        if args.compensation_motion_ab_only
                        else "HIGH_HOVER_SUPPORT_TANGENT_ONLY"
                    )
                )
            )
        ),
    )
    print("CONFIG =", loaded.path)
    print("EYE_IN_HAND_CANDIDATE =", loaded.candidate_path)
    print("CANDIDATE_SHA256 =", file_sha256(loaded.candidate_path))
    print("VISION_CONFIG =", loaded.vision_config_path)
    print("MOUNT_CONFIG =", loaded.mount_config_path)
    print(
        "TILT_COMPENSATED_POSITION_CONTROL =",
        {
            "required": True,
            "rear_edge_lower_deg": rear_edge_lower_deg,
            "scale": tilt_scale,
            "gravity_direction_source": tilt_config[
                "gravity_direction_source"
            ],
            "fallback_before_first_valid_plane": tilt_config[
                "fallback_before_first_valid_plane"
            ],
            "maximum_support_tilt_deg": maximum_support_tilt_deg,
            "maximum_support_normal_deviation_from_mount_deg": (
                maximum_support_normal_deviation_deg
            ),
            "normal_transition_s": normal_transition_s,
            "support_normal_blend": support_normal_blend,
            "scope": (
                "same locked joint command only; no planned motion"
                if args.compensation_ab_only
                else (
                    "positive J3 response sequence only"
                    if args.j3_response_only
                    else (
                        (
                            "one guarded 4 mm support-normal-only round trip"
                            if args.support_normal_motion_only
                            else "same guarded 4 mm round-trip target in two phases"
                        )
                        if motion_compensation_diagnostic
                        else "all locked position commands after a valid plane"
                    )
                )
            ),
        },
    )
    print("STATIC_VALIDATION_SUMMARY =", loaded.static_validation_summary_path)
    print("CAMERA_SERIAL =", loaded.record["camera_serial"])
    if args.compensation_ab_only:
        print("FORBIDDEN = joint-target-change, Cartesian-target-change, descent, gripper-close, lift")
        print(
            "AB_LIMITS =",
            {
                "support_normal_blend": ab_support_normal_blend,
                "maximum_incremental_joint_drift_rad": (
                    AB_MAX_INCREMENTAL_JOINT_DRIFT_RAD
                ),
                "maximum_tcp_drift_mm": AB_MAX_TCP_DRIFT_MM,
                "maximum_target_error_worsening_rad": (
                    AB_MAX_TARGET_ERROR_WORSENING_RAD
                ),
            },
        )
    elif args.j3_response_only:
        print(
            "FORBIDDEN = J1/J2/J4/J5/J6-target-change, descent, "
            "gripper-close, lift"
        )
        print(
            "J3_RESPONSE_LIMITS =",
            {
                "support_normal_blend": AB_MOTION_SUPPORT_NORMAL_BLEND,
                "positive_offsets_rad": list(J3_RESPONSE_OFFSETS_RAD),
                "live_downward_drift_limit_mm": (
                    J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM
                ),
                "maximum_other_joint_drift_rad": (
                    J3_RESPONSE_MAX_OTHER_JOINT_DRIFT_RAD
                ),
                "maximum_track_error_rad": J3_RESPONSE_TRACK_ERROR_RAD,
            },
        )
    elif motion_compensation_diagnostic:
        print(
            "FORBIDDEN = descent, orientation-change, gripper-close, lift, "
            "step-over-4mm"
        )
        print(
            "MOTION_AB_LIMITS =",
            {
                "support_normal_blend": AB_MOTION_SUPPORT_NORMAL_BLEND,
                "tangent_step_mm": AB_MOTION_TANGENT_STEP_MM,
                "minimum_maximum_joint_delta_rad": (
                    AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD
                ),
                "same_joint_target_for_both_phases": True,
                "mount_only_phase_enabled": bool(
                    args.compensation_motion_ab_only
                ),
                "mount_only_must_return_before_support_normal_phase": bool(
                    args.compensation_motion_ab_only
                ),
                "live_downward_drift_limit_mm": (
                    SUPPORT_NORMAL_MOTION_MAX_DOWNWARD_DRIFT_MM
                    if args.support_normal_motion_only
                    else None
                ),
            },
        )
    else:
        print(
            "FORBIDDEN = support-normal-change, orientation-change, descent, "
            "gripper-close, lift"
        )
    print(
        "MAX_TANGENT_STEP_MM =",
        (
            0.0
            if args.j3_response_only
            else AB_MOTION_TANGENT_STEP_MM
            if motion_compensation_diagnostic
            else loaded.record["safety"]["maximum_xy_step_mm"]
        ),
    )
    print(
        "MAX_CUMULATIVE_TANGENT_MOTION_MM =",
        loaded.record["safety"]["maximum_cumulative_tangent_motion_mm"],
    )
    print("VALIDATED_WORKSPACE =", loaded.record["validated_workspace"])
    print(
        "MAX_ITERATIONS =",
        1
        if motion_compensation_diagnostic
        else loaded.record["safety"]["maximum_iterations"],
    )
    print(
        "POST_MOTION_LIMITS =",
        {
            "joint_error_rad": loaded.record["safety"][
                "maximum_post_motion_joint_error_rad"
            ],
            "tangent_progress_ratio": [
                loaded.record["safety"][
                    "minimum_post_motion_xy_progress_ratio"
                ],
                loaded.record["safety"][
                    "maximum_post_motion_xy_progress_ratio"
                ],
            ],
            "direction_cosine": loaded.record["safety"][
                "minimum_post_motion_direction_cosine"
            ],
            "support_normal_drift_mm": loaded.record["safety"][
                "maximum_post_motion_tcp_z_drift_mm"
            ],
        },
    )
    print("START_MODE =", "teach-lock" if args.teach_lock else "fixed-red-pose")
    if not args.execute:
        print("OFFLINE_PREFLIGHT_OK：未访问相机、串口或机械臂。")
        return 0

    output_root = resolve_project_path(args.output_root)
    try:
        output_root.relative_to(PROJECT_ROOT)
    except ValueError as exc:
        raise ValueError("输出目录必须位于项目仓库内") from exc
    run_dir = output_root / make_run_id(args.run_id)
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    run_dir.mkdir(parents=True)
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": (
            "support_normal_compensation_ab_hold_only"
            if args.compensation_ab_only
            else (
                "support_normal_j3_positive_response_only"
                if args.j3_response_only
                else (
                    "support_normal_compensation_motion_only_4mm"
                    if args.support_normal_motion_only
                    else (
                        "support_normal_compensation_motion_ab_4mm"
                        if args.compensation_motion_ab_only
                        else (
                            "wrist_high_hover_support_tangent_teach_lock"
                            if args.teach_lock
                            else "wrist_high_hover_support_tangent_only"
                        )
                    )
                )
            )
        ),
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "initializing",
        "config": str(loaded.path.relative_to(PROJECT_ROOT)),
        "config_sha256": file_sha256(loaded.path),
        "candidate": str(loaded.candidate_path.relative_to(PROJECT_ROOT)),
        "candidate_sha256": file_sha256(loaded.candidate_path),
        "mount_config": str(loaded.mount_config_path.relative_to(PROJECT_ROOT)),
        "mount_config_sha256": file_sha256(loaded.mount_config_path),
        "static_validation_summary": str(
            loaded.static_validation_summary_path.relative_to(PROJECT_ROOT)
        ),
        "static_validation_summary_sha256": file_sha256(
            loaded.static_validation_summary_path
        ),
        "validated_workspace": loaded.record["validated_workspace"],
        "tilt_compensation": {
            "required_for_position_control": True,
            "rear_edge_lower_deg": rear_edge_lower_deg,
            "scale": tilt_scale,
            "gravity_direction_source": tilt_config[
                "gravity_direction_source"
            ],
            "fallback_before_first_valid_plane": tilt_config[
                "fallback_before_first_valid_plane"
            ],
            "maximum_support_tilt_deg": maximum_support_tilt_deg,
            "maximum_support_normal_deviation_from_mount_deg": (
                maximum_support_normal_deviation_deg
            ),
            "normal_transition_s": normal_transition_s,
            "support_normal_blend": support_normal_blend,
            "configured_support_normal_blend": (
                configured_support_normal_blend
            ),
            "correction_absolute_limits_nm": mount_record["diagnostic"][
                "correction_absolute_limits_nm"
            ],
        },
        "iterations": [],
        "recoverable_visual_rejections": [],
        "motion_verification_rejections": [],
        "teach_lock_history": [],
        "compensation_ab_only": bool(args.compensation_ab_only),
        "compensation_motion_ab_only": bool(
            args.compensation_motion_ab_only
        ),
        "support_normal_motion_only": bool(
            args.support_normal_motion_only
        ),
        "j3_response_only": bool(args.j3_response_only),
        "j3_closed_loop": {
            "enabled_for_normal_tangent_alignment": True,
            "joint_index_one_based": J3_RESPONSE_INDEX + 1,
            "physical_target_tolerance_rad": J3_CLOSED_LOOP_TOLERANCE_RAD,
            "bias_step_rad": J3_CLOSED_LOOP_BIAS_STEP_RAD,
            "maximum_bias_rad": J3_CLOSED_LOOP_MAX_BIAS_RAD,
            "bias_update_s": J3_CLOSED_LOOP_BIAS_UPDATE_S,
            "maximum_bias_dwell_s": J3_CLOSED_LOOP_MAX_BIAS_DWELL_S,
            "maximum_extra_wall_time_s": (
                J3_CLOSED_LOOP_MAX_EXTRA_WALL_TIME_S
            ),
            "maximum_downward_drift_mm": (
                J3_CLOSED_LOOP_MAX_DOWNWARD_DRIFT_MM
            ),
        },
    }
    write_json(log_path, log)

    safety = loaded.record["safety"]
    print("\n实机前提：机械臂常红并由软支撑托住；")
    if args.teach_lock:
        print("连接后由本程序开启重力补偿示教，再由你摆到无碰撞高悬停姿态；")
    else:
        print("人工摆在无碰撞高悬停姿态；")
    print("画面内只有一个科学目标，并让D455保持在已验证的远距深度工作区。")
    validated_clearance = loaded.record["validated_workspace"][
        "normal_clearance_mm"
    ]
    print(
        "程序硬门槛：目标光轴深度="
        f"{safety['minimum_camera_target_depth_mm']:.0f}–"
        f"{safety['maximum_camera_target_depth_mm']:.0f} mm；"
        "已验证支撑平面法向净空="
        f"{validated_clearance[0]:.0f}–"
        f"{validated_clearance[1]:.0f} mm。"
    )
    if input("确认满足后输入 e：").strip().lower() != "e":
        log["status"] = "cancelled_before_connection"
        write_json(log_path, log)
        print("CANCELLED：未连接机械臂。")
        return 2

    motion = loaded.record["motion"]
    configured_track_error_rad = float(motion["maximum_track_error_rad"])
    effective_track_error_rad = (
        max(configured_track_error_rad, J3_RESPONSE_TRACK_ERROR_RAD)
        if args.j3_response_only
        else configured_track_error_rad
    )
    limits = SafetyLimits(
        hz=float(motion["hz"]),
        v_max_rad_s=float(motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(motion["j6_v_max_rad_s"]),
        motion_profile=str(motion["profile"]),
        max_track_err_rad=effective_track_error_rad,
        max_speed_rad_s=float(motion["maximum_measured_speed_rad_s"]),
        max_temp_c=float(motion["maximum_temperature_c"]),
        max_joint_delta_rad=float(loaded.record["safety"]["maximum_joint_step_rad"]),
        settle_seconds=float(motion["settle_seconds"]),
    )

    # Load MuJoCo before opening the serial session.  Later checks run in the
    # worker thread while the main thread continues the 50 Hz hold loop.
    from S1_SDK.hardware.collision import CollisionChecker

    collision_checker = CollisionChecker("gripper")
    if collision_checker.model is None:
        collision_checker._load_model(gripper=True)
    if collision_checker.model is None or collision_checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")

    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())

    flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
    tcp_kinematics = Kinematics(verbose=True)
    arm = None
    q_hold = None
    q_history = []
    result_name = "ABORTED"
    try:
        arm = Arm(
            dev=args.dev,
            end_effector="gripper",
            limits=limits,
            check_collision=False,
        )
        tilt_commander = commander_from_mount_record(
            tilt_model,
            mount_record,
            tilt_scale,
            maximum_support_tilt_deg=maximum_support_tilt_deg,
            maximum_support_normal_deviation_deg=(
                maximum_support_normal_deviation_deg
            ),
            support_normal_blend=support_normal_blend,
            normal_transition_s=normal_transition_s,
        )
        arm.set_position_commander(tilt_commander)
        connected_q, connected_temp, startup_feedback = wait_for_valid_feedback(
            arm, limits.max_temp_c
        )
        log["startup_feedback"] = startup_feedback
        write_json(log_path, log)
        print("STARTUP_FEEDBACK_READY =", startup_feedback["ready"])
        print("STARTUP_FEEDBACK_ATTEMPTS =", startup_feedback["attempt_count"])
        print(
            "STARTUP_INVALID_SAMPLE_COUNT =",
            startup_feedback["invalid_sample_count"],
        )
        print("CONNECTED_Q =", [round(value, 6) for value in connected_q])
        print(
            "CONNECTED_TEMPERATURE_C =",
            [round(value, 1) for value in connected_temp],
        )
        if args.teach_lock:
            if input(
                "确认持续托稳、示教范围无碰撞，输入 e 开启重力补偿示教："
            ).strip().lower() != "e":
                log["status"] = "cancelled_before_teaching"
                result_name = "CANCELLED_BEFORE_TEACHING"
                write_json(log_path, log)
                print("CANCELLED：未开启示教。")
                return 2
            arm.enable()
            arm.gravity()
            teach_preview = TeachingCameraPreview(
                loaded.record, vision_config
            )
            start_q, teach_lock_record = teaching_until_locked_with_preview(
                arm,
                collision_checker=collision_checker,
                collision_step_rad=float(
                    loaded.record["safety"]["collision_step_rad"]
                ),
                minimum_joint_margin_deg=float(
                    loaded.record["safety"]["minimum_joint_margin_deg"]
                ),
                maximum_camera_tilt_from_down_deg=float(
                    loaded.record["safety"][
                        "maximum_camera_tilt_from_down_deg"
                    ]
                ),
                flange_kinematics=flange_kinematics,
                transform_flange_camera=loaded.transform_flange_camera,
                preview=teach_preview,
            )
            if start_q is None:
                log["status"] = "cancelled_during_teaching"
                result_name = "CANCELLED_DURING_TEACHING"
                write_json(log_path, log)
                print("CANCELLED：示教阶段收到 q。")
                return 2
            log["teach_lock"] = teach_lock_record
            log["teach_lock_history"].append(teach_lock_record)
            start = list(start_q) + [float(arm.get_pos()[6])]
        else:
            start = arm.read_joint_median(n=15, warmup_s=1.0)
            start_q = [float(value) for value in start[:6]]
        start_margin_details = joint_margin_details(start_q)
        start_margin = min(
            item["margin_deg"] for item in start_margin_details
        )
        start_tcp_pose = tcp_kinematics.fk(start_q)
        log.update(
            {
                "status": "live_start_pose_read",
                "start_q_rad": start_q,
                "start_tcp_pose_xyz_xyzw": start_tcp_pose,
                "start_joint_margin_deg": start_margin,
                "start_joint_margin_details": start_margin_details,
                "temperature_c": arm.get_temp(),
            }
        )
        write_json(log_path, log)
        print("START_Q =", [round(value, 6) for value in start_q])
        print("START_JOINT_MARGINS:")
        for item in start_margin_details:
            state = "OK" if item["inside_hard_limit"] else "OUT_OF_LIMIT"
            print(
                f"  J{item['joint']}: value={item['value_deg']:+.3f}deg "
                f"limit=[{item['lower_deg']:+.1f},{item['upper_deg']:+.1f}]deg "
                f"margin={item['margin_deg']:.3f}deg {state}"
            )
        if start_margin < float(
            loaded.record["safety"]["minimum_joint_margin_deg"]
        ):
            limiting = min(
                start_margin_details, key=lambda item: item["margin_deg"]
            )
            raise RuntimeError(
                f"start J{limiting['joint']} margin {start_margin:.2f} deg "
                "is insufficient"
            )
        start_collision = check_collision_segment(
            collision_checker,
            start_q,
            start_q,
            float(loaded.record["safety"]["collision_step_rad"]),
        )
        log.update(
            {
                "status": "live_precheck_passed",
                "start_collision": start_collision,
            }
        )
        write_json(log_path, log)
        print("START_JOINT_MARGIN_DEG =", round(start_margin, 3))
        print("TEMPERATURE_C =", log["temperature_c"])
        print("LIVE_PRECHECK_OK = True")
        if not args.teach_lock:
            if input("确认终端无motor timeout且支撑、净空仍正常，输入 e 使能：").strip().lower() != "e":
                log["status"] = "cancelled_before_enable"
                result_name = "CANCELLED_BEFORE_ENABLE"
                write_json(log_path, log)
                print("CANCELLED：未使能。")
                return 2
            arm.enable()
            print("ENABLED")
        else:
            print("ENABLED_AND_LOCKED：保持使能，开始腕部视觉支撑平面切向对准。")
        q_hold = start_q
        q_history = [list(start_q)]
        cumulative_tangent_motion_mm = 0.0
        converged = False
        successful_iterations = 0
        capture_attempt = 0
        while successful_iterations < int(
            loaded.record["safety"]["maximum_iterations"]
        ):
            iteration = successful_iterations + 1
            capture_attempt += 1
            print(f"\nITERATION {iteration}: 保持当前高度采集并检测")
            capture_result, q_observed = run_worker_while_holding(
                arm,
                q_hold,
                capture_detection_worker(
                    loaded, vision_config, run_dir, capture_attempt
                ),
                timeout_s=float(loaded.record["safety"]["worker_timeout_s"]),
                label=f"capture_attempt_{capture_attempt:02d}_detect",
            )
            if "recoverable_error" in capture_result:
                rejection = {
                    "iteration": iteration,
                    "capture_attempt": capture_attempt,
                    "stage": capture_result.get("recoverable_stage"),
                    "error": capture_result["recoverable_error"],
                }
                log["recoverable_visual_rejections"].append(rejection)
                write_json(log_path, log)
                command, new_q, teach_record = recover_visual_failure(
                    arm,
                    q_hold,
                    rejection["error"],
                    loaded=loaded,
                    vision_config=vision_config,
                    collision_checker=collision_checker,
                    flange_kinematics=flange_kinematics,
                )
                rejection["operator_command"] = command
                write_json(log_path, log)
                if command == "q":
                    result_name = "CANCELLED_AFTER_VISUAL_REJECT"
                    finalize_run_log(
                        log_path,
                        log,
                        status=result_name.lower(),
                        result_name=result_name,
                    )
                    return 2
                if command == "t":
                    q_hold = list(new_q)
                    q_history = [list(q_hold)]
                    cumulative_tangent_motion_mm = 0.0
                    log["teach_lock_history"].append(teach_record)
                continue
            planning_result, _ = run_worker_while_holding(
                arm,
                q_hold,
                build_planning_worker(
                    capture_result=capture_result,
                    q_observed=q_observed,
                    q_hold=q_hold,
                    loaded=loaded,
                    flange_kinematics=flange_kinematics,
                    tcp_kinematics=tcp_kinematics,
                    collision_checker=collision_checker,
                    cumulative_tangent_motion_mm=cumulative_tangent_motion_mm,
                    maximum_tangent_step_mm=(
                        AB_MOTION_TANGENT_STEP_MM
                        if motion_compensation_diagnostic
                        and not args.j3_response_only
                        else None
                    ),
                    joint_plan_required=not args.j3_response_only,
                ),
                timeout_s=float(loaded.record["safety"]["worker_timeout_s"]),
                label=f"iteration_{iteration:02d}_plan_check",
            )
            if "recoverable_error" in planning_result:
                rejection = {
                    "iteration": iteration,
                    "capture_attempt": capture_attempt,
                    "stage": planning_result.get("recoverable_stage"),
                    "error": planning_result["recoverable_error"],
                }
                log["recoverable_visual_rejections"].append(rejection)
                write_json(log_path, log)
                command, new_q, teach_record = recover_visual_failure(
                    arm,
                    q_hold,
                    rejection["error"],
                    loaded=loaded,
                    vision_config=vision_config,
                    collision_checker=collision_checker,
                    flange_kinematics=flange_kinematics,
                )
                rejection["operator_command"] = command
                write_json(log_path, log)
                if command == "q":
                    result_name = "CANCELLED_AFTER_VISUAL_REJECT"
                    finalize_run_log(
                        log_path,
                        log,
                        status=result_name.lower(),
                        result_name=result_name,
                    )
                    return 2
                if command == "t":
                    q_hold = list(new_q)
                    q_history = [list(q_hold)]
                    cumulative_tangent_motion_mm = 0.0
                    log["teach_lock_history"].append(teach_record)
                continue
            iteration_record = {
                "iteration": iteration,
                "capture_attempt": capture_attempt,
                **capture_result,
                **planning_result,
            }
            log["iterations"].append(iteration_record)
            write_json(log_path, log)
            correction = planning_result["correction"]
            print(
                "TANGENT_ERROR_BASE_XYZ_MM =",
                [
                    round(value, 3)
                    for value in correction["tangent_error_base_xyz_mm"]
                ],
                "NORM =",
                round(correction["tangent_error_norm_mm"], 3),
            )
            print(
                "SUPPORT_NORMAL_BASE =",
                [
                    round(value, 6)
                    for value in correction["support_up_normal_base"]
                ],
            )
            print(
                "NORMAL_CLEARANCE_MM =",
                round(correction["normal_clearance_mm"], 3),
            )
            if args.compensation_ab_only:
                ab_record = {}
                iteration_record["compensation_ab"] = ab_record
                write_json(log_path, log)
                evaluation = run_support_normal_ab(
                    arm,
                    tilt_commander,
                    q_hold,
                    planning_result["observation"][
                        "support_up_normal_base"
                    ],
                    tcp_kinematics,
                    ab_record,
                    support_normal_blend=ab_support_normal_blend,
                )
                write_json(log_path, log)
                print(
                    "AB_INCREMENTAL_JOINT_DRIFT_RAD =",
                    [
                        round(value, 6)
                        for value in evaluation[
                            "incremental_joint_drift_rad"
                        ]
                    ],
                )
                print(
                    "AB_TCP_DRIFT_BASE_XYZ_MM =",
                    [
                        round(value, 3)
                        for value in evaluation["tcp_delta_base_xyz_mm"]
                    ],
                    "NORM =",
                    round(evaluation["tcp_drift_norm_mm"], 3),
                )
                print(
                    "AB_TARGET_ERROR_WORSENING_RAD =",
                    [
                        round(value, 6)
                        for value in evaluation[
                            "target_error_worsening_rad"
                        ]
                    ],
                )
                print(
                    "AB_EVALUATION =",
                    "PASS" if evaluation["passed"] else "REJECT",
                    "reasons =",
                    evaluation["reasons"],
                )
                result_name = (
                    "SUPPORT_NORMAL_AB_HOLD_PASS"
                    if evaluation["passed"]
                    else "SUPPORT_NORMAL_AB_HOLD_REJECT"
                )
                finalize_run_log(
                    log_path,
                    log,
                    status=result_name.lower(),
                    result_name=result_name,
                )
                return 0 if evaluation["passed"] else 3
            if args.j3_response_only:
                j3_record = {}
                iteration_record["j3_positive_response"] = j3_record
                write_json(log_path, log)
                print(
                    "J3_RESPONSE_OFFSETS_RAD =",
                    list(J3_RESPONSE_OFFSETS_RAD),
                )
                print(
                    "J3_RESPONSE_PREDICTION = positive J3 must move TCP "
                    "away from the support plane; live downward limit is "
                    f"{J3_RESPONSE_MAX_DOWNWARD_DRIFT_MM:.1f} mm"
                )
                evaluation = run_j3_positive_response(
                    arm,
                    tilt_commander,
                    q_start=q_hold,
                    support_up_normal_base=planning_result["observation"][
                        "support_up_normal_base"
                    ],
                    tcp_kinematics=tcp_kinematics,
                    collision_checker=collision_checker,
                    safety=safety,
                    record=j3_record,
                )
                write_json(log_path, log)
                print(
                    "J3_RESPONSE_EVALUATION =",
                    "PASS" if evaluation["passed"] else "REJECT",
                    "classification =",
                    evaluation["classification"],
                    "final_ratio =",
                    evaluation["final_response_ratio"],
                    "reasons =",
                    evaluation["reasons"],
                )
                result_name = (
                    "J3_POSITIVE_RESPONSE_PASS"
                    if evaluation["passed"]
                    else "J3_POSITIVE_RESPONSE_REJECT"
                )
                finalize_run_log(
                    log_path,
                    log,
                    status=result_name.lower(),
                    result_name=result_name,
                )
                return 0 if evaluation["passed"] else 3
            if args.support_normal_motion_only:
                if correction["converged"]:
                    raise RuntimeError(
                        "support-normal motion diagnostic requires tangent "
                        "error above the configured convergence threshold"
                    )
                next_q = planning_result["next_q_rad"]
                if next_q is None:
                    raise RuntimeError(
                        "support-normal motion diagnostic has no checked "
                        "4 mm IK target"
                    )
                target_observability = validate_support_normal_motion_ab_target(
                    q_hold, next_q
                )
                motion_record = {}
                iteration_record["support_normal_motion"] = motion_record
                motion_record["target_observability"] = target_observability
                write_json(log_path, log)
                print(
                    "SUPPORT_NORMAL_MOTION_COMMAND_TANGENT_STEP_BASE_XYZ_MM =",
                    [
                        round(value, 3)
                        for value in correction["tangent_step_base_xyz_mm"]
                    ],
                )
                print(
                    "SUPPORT_NORMAL_MOTION_TARGET_Q =",
                    [round(value, 6) for value in next_q],
                )
                print(
                    "SUPPORT_NORMAL_MOTION_MAX_JOINT_DELTA_RAD =",
                    round(
                        target_observability["maximum_joint_delta_rad"],
                        6,
                    ),
                    "minimum =",
                    AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD,
                )
                evaluation = run_support_normal_only_motion(
                    arm,
                    tilt_commander,
                    q_start=q_hold,
                    q_target=next_q,
                    tcp_start=planning_result["tcp_pose_before_xyz_xyzw"],
                    tcp_target=planning_result["tcp_pose_after_xyz_xyzw"],
                    support_up_normal_base=planning_result["observation"][
                        "support_up_normal_base"
                    ],
                    tcp_kinematics=tcp_kinematics,
                    safety=safety,
                    record=motion_record,
                )
                write_json(log_path, log)
                phase = motion_record.get("support_normal", {})
                for leg_name in ("outbound", "return"):
                    leg = phase.get(leg_name)
                    if not isinstance(leg, dict):
                        continue
                    print(
                        "SUPPORT_NORMAL_MOTION_CHECK",
                        f"leg={leg_name}",
                        f"joint_error={leg['maximum_joint_error_rad']:.4f}rad",
                        (
                            "signed_normal="
                            f"{leg.get('signed_support_normal_displacement_mm', 0.0):.2f}mm"
                            if "abort_reason" in leg
                            else f"normal_drift={leg['support_normal_drift_mm']:.2f}mm"
                        ),
                        f"result={'PASS' if leg['passed'] else 'REJECT'}",
                    )
                    if "abort_reason" in leg:
                        print("LIVE_GUARD_ABORT =", leg["abort_reason"])
                print(
                    "SUPPORT_NORMAL_MOTION_EVALUATION =",
                    "PASS" if evaluation["passed"] else "REJECT",
                    "reasons =",
                    evaluation["reasons"],
                )
                result_name = (
                    "SUPPORT_NORMAL_MOTION_PASS"
                    if evaluation["passed"]
                    else "SUPPORT_NORMAL_MOTION_REJECT"
                )
                finalize_run_log(
                    log_path,
                    log,
                    status=result_name.lower(),
                    result_name=result_name,
                )
                return 0 if evaluation["passed"] else 3
            if args.compensation_motion_ab_only:
                if correction["converged"]:
                    raise RuntimeError(
                        "motion A/B requires tangent error above the configured "
                        "convergence threshold"
                    )
                next_q = planning_result["next_q_rad"]
                if next_q is None:
                    raise RuntimeError("motion A/B has no checked 4 mm IK target")
                target_observability = validate_support_normal_motion_ab_target(
                    q_hold, next_q
                )
                motion_ab_record = {}
                iteration_record["compensation_motion_ab"] = motion_ab_record
                motion_ab_record["target_observability"] = target_observability
                write_json(log_path, log)
                print(
                    "MOTION_AB_COMMAND_TANGENT_STEP_BASE_XYZ_MM =",
                    [
                        round(value, 3)
                        for value in correction["tangent_step_base_xyz_mm"]
                    ],
                )
                print(
                    "MOTION_AB_SHARED_TARGET_Q =",
                    [round(value, 6) for value in next_q],
                )
                print(
                    "MOTION_AB_MAX_JOINT_DELTA_RAD =",
                    round(
                        target_observability["maximum_joint_delta_rad"],
                        6,
                    ),
                    "minimum =",
                    AB_MOTION_MINIMUM_MAX_JOINT_DELTA_RAD,
                )
                evaluation = run_support_normal_motion_ab(
                    arm,
                    tilt_commander,
                    q_start=q_hold,
                    q_target=next_q,
                    tcp_start=planning_result["tcp_pose_before_xyz_xyzw"],
                    tcp_target=planning_result["tcp_pose_after_xyz_xyzw"],
                    support_up_normal_base=planning_result["observation"][
                        "support_up_normal_base"
                    ],
                    tcp_kinematics=tcp_kinematics,
                    safety=safety,
                    record=motion_ab_record,
                )
                write_json(log_path, log)
                for phase_name in ("mount_only", "support_normal"):
                    phase = motion_ab_record.get(phase_name, {})
                    for leg_name in ("outbound", "return"):
                        leg = phase.get(leg_name)
                        if not isinstance(leg, dict):
                            continue
                        print(
                            "MOTION_AB_CHECK",
                            f"phase={phase_name}",
                            f"leg={leg_name}",
                            f"joint_error={leg['maximum_joint_error_rad']:.4f}rad",
                            f"progress={leg['tangent_progress_ratio']:.3f}",
                            f"direction_cos={leg['tangent_direction_cosine']:.3f}",
                            f"normal_drift={leg['support_normal_drift_mm']:.2f}mm",
                            f"result={'PASS' if leg['passed'] else 'REJECT'}",
                        )
                print(
                    "MOTION_AB_EVALUATION =",
                    "PASS" if evaluation["passed"] else "REJECT",
                    "reasons =",
                    evaluation["reasons"],
                )
                result_name = (
                    "SUPPORT_NORMAL_MOTION_AB_PASS"
                    if evaluation["passed"]
                    else "SUPPORT_NORMAL_MOTION_AB_REJECT"
                )
                finalize_run_log(
                    log_path,
                    log,
                    status=result_name.lower(),
                    result_name=result_name,
                )
                return 0 if evaluation["passed"] else 3
            if correction["converged"]:
                converged = True
                result_name = "HIGH_HOVER_SUPPORT_TANGENT_CONVERGED"
                print("CONVERGED：不再移动。")
                break
            support_normal_state = tilt_commander.set_support_up_normal(
                planning_result["observation"]["support_up_normal_base"],
                source=(
                    "validated_horizontal_support_plane:"
                    f"capture_{capture_attempt:02d}"
                ),
            )
            iteration_record["tilt_compensation_support_normal_update"] = (
                support_normal_state
            )
            write_json(log_path, log)
            print("GRAVITY_SUPPORT_NORMAL_UPDATE =", support_normal_state)
            next_q = planning_result["next_q_rad"]
            print(
                "COMMAND_TANGENT_STEP_BASE_XYZ_MM =",
                [
                    round(value, 3)
                    for value in correction["tangent_step_base_xyz_mm"]
                ],
            )
            print(
                "CUMULATIVE_TANGENT_MOTION_MM =",
                round(correction["cumulative_tangent_motion_after_mm"], 3),
            )
            j3_closed_loop_motion = run_j3_gated_tangent_move(
                arm,
                q_hold,
                next_q,
                label=f"tangent_correction_{iteration:02d}",
                support_up_normal_base=planning_result["observation"][
                    "support_up_normal_base"
                ],
                tcp_kinematics=tcp_kinematics,
                tilt_commander=tilt_commander,
            )
            iteration_record["j3_closed_loop_motion"] = j3_closed_loop_motion
            write_json(log_path, log)
            print(
                "J3_CLOSED_LOOP_MOTION =",
                j3_closed_loop_motion["mode"],
                f"bias={j3_closed_loop_motion['final_bias_rad']:+.4f}rad",
                f"samples={j3_closed_loop_motion.get('sample_count', 0)}",
            )
            q_hold = list(next_q)
            post_motion_trace = []
            iteration_record["post_motion_hold_trace"] = {
                "command_rate_hz": float(motion["hz"]),
                "settle_s": float(safety["post_motion_settle_s"]),
                "settled_sample_count_requested": int(
                    safety["post_motion_sample_count"]
                ),
                "samples": post_motion_trace,
            }
            measured_q = sample_hold_joint_median(
                arm,
                q_hold,
                settle_s=float(safety["post_motion_settle_s"]),
                sample_count=int(safety["post_motion_sample_count"]),
                label=f"tangent_correction_{iteration:02d}_post_motion_hold",
                trace=post_motion_trace,
            )
            iteration_record["post_motion_hold_trace"][
                "sample_count_recorded"
            ] = len(post_motion_trace)
            if post_motion_trace:
                iteration_record["post_motion_hold_trace"][
                    "duration_s"
                ] = post_motion_trace[-1]["elapsed_s"]
            print(
                "POST_MOTION_TRACE_SAMPLES =",
                len(post_motion_trace),
                "duration_s =",
                round(post_motion_trace[-1]["elapsed_s"], 3)
                if post_motion_trace
                else 0.0,
            )
            measured_tcp = tcp_kinematics.fk(measured_q)
            verification = evaluate_executed_tangent_correction(
                q_hold,
                measured_q,
                planning_result["tcp_pose_before_xyz_xyzw"],
                planning_result["tcp_pose_after_xyz_xyzw"],
                measured_tcp,
                planning_result["observation"]["support_up_normal_base"],
                safety,
            )
            iteration_record["tilt_compensation_command_state"] = {
                "command_count": tilt_commander.command_count,
                "last_snapshot": tilt_commander.last_snapshot,
            }
            iteration_record["post_motion_verification"] = verification
            write_json(log_path, log)
            print(
                "POST_MOTION_CHECK",
                f"joint_error={verification['maximum_joint_error_rad']:.4f}rad",
                f"J{verification['maximum_joint_error_joint']}",
                f"progress={verification['tangent_progress_ratio']:.3f}",
                f"direction_cos={verification['tangent_direction_cosine']:.3f}",
                f"normal_drift={verification['support_normal_drift_mm']:.2f}mm",
                f"result={'PASS' if verification['passed'] else 'REJECT'}",
            )
            if not verification["passed"]:
                rejection = {
                    "iteration": iteration,
                    "capture_attempt": capture_attempt,
                    "stage": "post_motion_verification",
                    "error": (
                        "post-motion verification failed: "
                        + ",".join(verification["reasons"])
                    ),
                    "verification": verification,
                }
                log["motion_verification_rejections"].append(rejection)
                write_json(log_path, log)
                command, new_q, teach_record = recover_motion_failure(
                    arm,
                    q_hold,
                    rejection["error"],
                    loaded=loaded,
                    vision_config=vision_config,
                    collision_checker=collision_checker,
                    flange_kinematics=flange_kinematics,
                )
                rejection["operator_command"] = command
                write_json(log_path, log)
                if command == "q":
                    result_name = "CANCELLED_AFTER_MOTION_REJECT"
                    finalize_run_log(
                        log_path,
                        log,
                        status=result_name.lower(),
                        result_name=result_name,
                    )
                    return 2
                q_hold = list(new_q)
                q_history = [list(q_hold)]
                cumulative_tangent_motion_mm = 0.0
                log["teach_lock_history"].append(teach_record)
                continue
            cumulative_tangent_motion_mm = float(
                correction["cumulative_tangent_motion_after_mm"]
            )
            q_history.append(list(q_hold))
            successful_iterations += 1
            print("到达: high-hover support-tangent correction", iteration)

        if not converged:
            result_name = "HIGH_HOVER_SUPPORT_TANGENT_NOT_CONVERGED"
            print("NOT_CONVERGED：已达到最大迭代次数，不再继续校正。")
        if args.teach_lock:
            wait_for_q_while_holding(arm, q_hold)
            log["operator_exit_command"] = "q"
        else:
            hold_for_duration(
                arm,
                q_hold,
                float(loaded.record["safety"]["final_hold_s"]),
                "final_high_hover_hold",
            )
            clear_position_bias_if_supported(arm)
            for index, previous_q in enumerate(reversed(q_history[:-1]), start=1):
                abort = arm.move(q_hold, previous_q, f"safe_return_{index:02d}")
                if abort:
                    raise RuntimeError(abort)
                q_hold = list(previous_q)
                print("到达: safe return", index)
        finalize_run_log(
            log_path,
            log,
            status=result_name.lower(),
            result_name=result_name,
        )
        return 0 if converged else 3
    except BaseException as exc:
        result_name = f"ABORTED: {type(exc).__name__}: {exc}"
        log["error"] = result_name
        finalize_run_log(
            log_path,
            log,
            status="aborted",
            result_name=result_name,
        )
        print(result_name)
        return 1
    finally:
        if arm is not None:
            try:
                arm.disable()
            except Exception as disable_error:
                print("DISABLE_WARNING =", repr(disable_error))
            try:
                arm.close()
            except Exception:
                pass
            print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
        print("LOG_SAVED =", log_path)
        print("RESULT =", result_name)


if __name__ == "__main__":
    raise SystemExit(main())
