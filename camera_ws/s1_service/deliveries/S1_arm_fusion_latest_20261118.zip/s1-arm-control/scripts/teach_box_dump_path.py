#!/usr/bin/env python3
"""Record continuous, manually dragged approach and hinged tip trajectories.
Native gravity mode only; no automatic approach, tipping or return motion.
Output is a candidate in data/, not the active dump configuration.
"""
import argparse
from datetime import datetime
import fcntl
import json
from pathlib import Path
import queue
import sys
import threading
import time
ROOT=Path(__file__).resolve().parents[1]
for p in (ROOT,Path.home()/'thirdparty/S1_SDK_V2-official/src'):sys.path.insert(0,str(p))

class PathRecorder:
    def __init__(self):
        self.phase='idle';self.approach=[];self.tip=[];self.samples=[]
    def command(self,command,q):
        q=list(q[:6])
        if command=='a':
            self.approach=[[0.0]*6,q];self.tip=[];self.samples=[];self.phase='approach'
        elif command=='h' and self.phase=='approach':
            self.approach.append(q);self.phase='handle'
        elif command=='t' and self.phase=='handle':
            self.tip=[list(self.approach[-1]),q];self.phase='tip'
        elif command=='s' and self.phase=='tip':
            self.tip.append(q);self.phase='recorded'
        else:raise ValueError('current phase '+self.phase+' does not accept '+command)
    def sample(self,q,now):
        if self.phase in ('approach','tip'):
            point=list(q[:6])
            (self.approach if self.phase=='approach' else self.tip).append(point)
            self.samples.append(dict(time_s=now,phase=self.phase,q_rad=point))
    def plan(self,template,gap):
        if self.phase!='recorded':raise ValueError('tip trajectory is not finished')
        result=dict(template)
        result.update(approach_path_q_rad=self.approach,tip_path_q_rad=self.tip,
            handle_closed_gap_mm=gap,source='continuous_native_gravity_manual_teach',
            sampled_hz=20,installed_path_physical_validation='not_yet_replayed')
        return result


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dev',default='/dev/ttyUSB0')
    parser.add_argument('--out',default=str(ROOT/'data/box_dump_teach'/datetime.now().strftime('dump_candidate_%Y%m%d-%H%M%S.json')))
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args(argv)
    if not args.execute:
        print('OFFLINE. --execute starts gravity teaching; three Enter presses: handle, dump endpoint, restored box.')
        return 0
    from s1_control.arm import Arm,SafetyLimits
    from s1_control.gripper import Gripper
    from execute_go2_observe_deployment import wait_for_valid_feedback
    lock=open('/tmp/s1-arm-'+Path(args.dev).resolve().name+'.lock','a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    print('只使用空盒。全程手扶机械臂和盒子；本程序不会自动翻转、复位或回零。')
    print('请从零位附近开始。SDK原生重力补偿下仍可能下垂。退出失能前先将盒子复位并托稳机械臂。')
    arm=None;recorder=PathRecorder();commands=queue.Queue();gap=None;force=0.4
    grip_ready_at=None;release_done_at=None
    template=json.loads((ROOT/'config/go2_hinged_box_dump.json').read_text())
    def reader():
        while True:
            try:command=input().strip().lower()
            except (EOFError,KeyboardInterrupt):command='q'
            commands.put(command)
            if command=='q':return
    try:
        arm=Arm(dev=args.dev,end_effector='gripper',check_collision=False,limits=SafetyLimits(hz=50))
        wait_for_valid_feedback(arm,arm.limits.max_temp_c)
        grip=Gripper(arm)
        arm.enable();arm.gravity()
        gap=grip.max_gap_mm
        recorder.command('a',list(arm.get_pos()))
        threading.Thread(target=reader,daemon=True).start()
        print('正在重力示教并连续记录接近路径。',flush=True)
        print('第1次回车：到把手夹持位后回车，自动夹紧并开始记录翻转。',flush=True)
        print('第2次回车：翻到卸料终点后回车，保存路径。',flush=True)
        print('第3次回车：手动复位盒子并托稳机械臂后回车，松爪并失能退出。',flush=True)
        next_sample=0;next_temp=0
        while True:
            started=time.monotonic();arm.gravity();grip.command_mm(gap,force=force)
            q=list(arm.get_pos())
            if started>=next_sample:
                recorder.sample(q,started);next_sample=started+.05
            if started>=next_temp:
                if max(arm.get_temp())>arm.limits.max_temp_c:raise RuntimeError('existing temperature limit exceeded')
                next_temp=started+1
            try:command=commands.get_nowait()
            except queue.Empty:command=None
            if command=='q':break
            if release_done_at is not None and started>=release_done_at:break
            if grip_ready_at is not None and started>=grip_ready_at:
                recorder.command('t',q)
                grip_ready_at=None
                print('TIP_RECORDING：已开始连续记录，请手扶沿转轴翻转；到卸料终点回车。',flush=True)
            if command=='':
                if recorder.phase=='approach':
                    recorder.command('h',q)
                    gap=grip.min_gap_mm
                    grip_ready_at=started+template['grip_hold_s']
                    print('夹紧把手中，请短暂保持不动，看到TIP_RECORDING后开始翻转。',flush=True)
                elif recorder.phase=='tip':
                    recorder.command('s',q)
                    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
                    out.write_text(json.dumps(recorder.plan(template,gap),ensure_ascii=False,indent=2)+'\n')
                    out.with_suffix('.trace.json').write_text(json.dumps(recorder.samples,ensure_ascii=False)+'\n')
                    print('DUMP_CANDIDATE_SAVED =',out,flush=True)
                    print('继续手扶，手动将盒子复位；托稳机械臂后再回车，松爪并退出。',flush=True)
                elif recorder.phase=='recorded' and release_done_at is None:
                    gap=grip.max_gap_mm
                    release_done_at=started+template['release_hold_s']
                    print('正在松爪，随后失能，请继续托稳。',flush=True)
            time.sleep(max(0,.02-(time.monotonic()-started)))
    except KeyboardInterrupt:print('CANCELLED: 托住机械臂和盒子。')
    finally:
        if arm is not None:
            try:arm.disable()
            finally:arm.close()
            print('DISABLED：请保持支撑。',flush=True)
        lock.close()
    return 0
if __name__=='__main__':raise SystemExit(main())
