#!/usr/bin/env python3
"""Inspect taught dump plan and sequence offline; never opens the arm."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from s1_control.box_dump import load_dump_plan,dump_steps

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',default=str(Path(__file__).resolve().parents[1]/'config/go2_hinged_box_dump.json'))
    args=parser.parse_args()
    try:plan=load_dump_plan(args.plan)
    except ValueError as exc:
        print('DUMP_NOT_TAUGHT =',exc)
        return 2
    for step in dump_steps(plan):print(step['name'],step['kind'],'gripped='+str(step['closed']))
    print('OFFLINE_SEQUENCE_ONLY; collision, pivot tracking and physical unload not verified')
    return 0
if __name__=='__main__':raise SystemExit(main())
