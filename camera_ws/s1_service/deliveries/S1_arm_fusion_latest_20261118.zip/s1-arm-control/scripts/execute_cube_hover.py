#!/usr/bin/env python3
import argparse
import json
import math
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from S1_SDK.hardware.collision import CollisionChecker
from s1_control.arm import Arm, SafetyLimits
from s1_control.gripper import Gripper
from s1_control.kinematics import Kinematics
from scripts.check_cube_hover_path import (
    collision_at,
    interpolate,
)


JOINT_LIMITS = [
    (math.radians(-170), math.radians(170)),
    (math.radians(0), math.radians(180)),
    (math.radians(0), math.radians(170)),
    (math.radians(-90), math.radians(87)),
    (math.radians(-90), math.radians(90)),
    (math.radians(-90), math.radians(90)),
]


def resolve_path(raw):
    path = Path(raw)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path


def make_collision_checker():
    checker = CollisionChecker("gripper")

    if checker.model is None:
        checker._load_model(gripper=True)

    if checker.model is None or checker.data is None:
        raise RuntimeError("MuJoCo碰撞模型加载失败")

    return checker


def sample_complete_route(route, step_rad, min_tcp_z_mm):
    checker = make_collision_checker()
    kinematics = Kinematics(verbose=True)

    sample_count = 0
    hard_limit_ok = True
    minimum_margin_deg = float("inf")
    minimum_tcp_z_mm = float("inf")
    collision_first = {}
    floor_contact_samples = 0

    # 实测零位允许很小的编码器偏差。
    hard_limit_tolerance_rad = 0.02

    for segment_index, (previous, current) in enumerate(
        zip(route, route[1:])
    ):
        segment_name = (
            f"{previous['name']}->{current['name']}"
        )

        for local_index, (alpha, q) in enumerate(
            interpolate(
                previous["q"],
                current["q"],
                step_rad,
            )
        ):
            if segment_index > 0 and local_index == 0:
                continue

            sample_count += 1

            margins_deg = []

            for value, (lower, upper) in zip(
                q,
                JOINT_LIMITS,
            ):
                if (
                    value < lower - hard_limit_tolerance_rad
                    or value > upper + hard_limit_tolerance_rad
                ):
                    hard_limit_ok = False

                margin = min(
                    value - lower,
                    upper - value,
                )
                margins_deg.append(math.degrees(margin))

            minimum_margin_deg = min(
                minimum_margin_deg,
                min(margins_deg),
            )

            tcp = kinematics.fk(q)
            tcp_mm = [1000.0 * value for value in tcp[:3]]
            minimum_tcp_z_mm = min(
                minimum_tcp_z_mm,
                tcp_mm[2],
            )

            active, _, floor = collision_at(checker, q)

            if floor:
                floor_contact_samples += 1

            for pair in active:
                key = " <-> ".join(pair)

                if key not in collision_first:
                    collision_first[key] = {
                        "segment": segment_name,
                        "alpha": alpha,
                        "pair": pair,
                        "q": q,
                        "tcp_mm": tcp_mm,
                    }

    height_ok = minimum_tcp_z_mm >= min_tcp_z_mm
    collision_ok = not collision_first

    passed = (
        hard_limit_ok
        and height_ok
        and collision_ok
    )

    return {
        "passed": passed,
        "sample_count": sample_count,
        "hard_limit_ok": hard_limit_ok,
        "minimum_margin_deg": minimum_margin_deg,
        "minimum_tcp_z_mm": minimum_tcp_z_mm,
        "height_ok": height_ok,
        "collision_ok": collision_ok,
        "collisions": list(collision_first.values()),
        "floor_contact_samples": floor_contact_samples,
    }


def hold_open(arm, gripper, q, open_mm, duration_s):
    deadline = time.monotonic() + duration_s
    next_tick = time.monotonic()

    while time.monotonic() < deadline:
        arm._arm.joint_control_mit(list(q))
        gripper.command_mm(open_mm)

        measured = list(arm.get_pos())
        velocity = list(arm._arm.get_vel())
        temperature = list(arm._arm.get_temp())

        fault = arm.guard(
            measured,
            velocity,
            temperature,
            q,
            settling=False,
        )

        if fault:
            return fault

        next_tick += arm.dt
        delay = next_tick - time.monotonic()

        if delay > 0:
            time.sleep(delay)
        else:
            next_tick = time.monotonic()

    return None


def main():
    parser = argparse.ArgumentParser(
        description="S1方块悬停分级实机验证"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--end", default="gripper")
    parser.add_argument(
        "--plan",
        default="data/plans/cube50_hover_plan.json",
    )
    parser.add_argument(
        "--report",
        default=(
            "data/plans/"
            "cube50_hover_collision_report.json"
        ),
    )
    parser.add_argument(
        "--target",
        choices=["midpoint", "hover"],
        default="midpoint",
    )
    parser.add_argument("--step-rad", type=float, default=0.02)
    parser.add_argument(
        "--min-tcp-z-mm",
        type=float,
        default=60.0,
    )
    parser.add_argument(
        "--max-segment-delta-rad",
        type=float,
        default=1.0,
    )
    parser.add_argument("--open-mm", type=float, default=65.0)
    parser.add_argument(
        "--v-max-rad-s",
        type=float,
        default=0.05,
    )
    parser.add_argument("--hold-s", type=float, default=2.0)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    plan_path = resolve_path(args.plan)
    report_path = resolve_path(args.report)

    plan = json.loads(
        plan_path.read_text(encoding="utf-8")
    )
    report = json.loads(
        report_path.read_text(encoding="utf-8")
    )

    if report.get("status") != "OFFLINE_MODEL_PASS":
        raise RuntimeError(
            "离线碰撞报告不是OFFLINE_MODEL_PASS"
        )

    plan_waypoints = plan["joint_path"]
    target_indices = [
        index
        for index, waypoint in enumerate(plan_waypoints)
        if waypoint["name"] == args.target
    ]

    if not target_indices:
        raise ValueError(
            f"规划中找不到目标路点 {args.target}"
        )

    planned_route = plan_waypoints[
        :target_indices[0] + 1
    ]

    print("即将连接串口读取当前位置。")
    print("默认不会使能；检查结束会明确发送失能命令。")
    print("机械臂必须已经常红，并处于可靠支撑状态。")

    arm = Arm(
        dev=args.dev,
        end_effector=args.end,
        limits=SafetyLimits(
            hz=50.0,
            v_max_rad_s=args.v_max_rad_s,
            max_joint_delta_rad=(
                args.max_segment_delta_rad
            ),
        ),
    )

    # 禁用S1_arm内部有数值不稳定风险的碰撞器；
    # 本脚本使用独立、重置状态的离线检查器。
    arm._arm.collision_checker = None

    gripper = Gripper(arm)

    start = arm.read_joint_median()
    start_q = [float(value) for value in start[:6]]

    route = [
        {
            "name": "start",
            "q": start_q,
        },
        *planned_route,
    ]

    print(
        "START_Q =",
        [round(value, 6) for value in start_q],
    )
    print(
        "START_GAP_MM =",
        round(gripper.gap_from_fb(start[6]), 2),
    )
    print("ROUTE:")

    segment_delta_ok = True

    for previous, current in zip(route, route[1:]):
        delta = max(
            abs(a - b)
            for a, b in zip(
                previous["q"],
                current["q"],
            )
        )

        print(
            f"  {previous['name']}->{current['name']}: "
            f"delta={delta:.3f}rad"
        )

        if delta > args.max_segment_delta_rad:
            segment_delta_ok = False

    route_check = sample_complete_route(
        route,
        args.step_rad,
        args.min_tcp_z_mm,
    )

    print(
        "LIVE_ROUTE_SAMPLE_COUNT =",
        route_check["sample_count"],
    )
    print(
        "LIVE_ROUTE_HARD_LIMIT_OK =",
        route_check["hard_limit_ok"],
    )
    print(
        "LIVE_ROUTE_MIN_MARGIN_DEG =",
        round(route_check["minimum_margin_deg"], 3),
    )
    print(
        "LIVE_ROUTE_MIN_TCP_Z_MM =",
        round(route_check["minimum_tcp_z_mm"], 3),
    )
    print(
        "LIVE_ROUTE_COLLISION_OK =",
        route_check["collision_ok"],
    )
    print(
        "LIVE_ROUTE_FLOOR_CONTACT_SAMPLES =",
        route_check["floor_contact_samples"],
    )
    print(
        "SEGMENT_DELTA_OK =",
        segment_delta_ok,
    )

    for collision in route_check["collisions"]:
        print(
            "COLLISION:",
            collision["segment"],
            f"alpha={collision['alpha']:.3f}",
            collision["pair"],
        )

    precheck_ok = (
        segment_delta_ok
        and route_check["passed"]
    )

    print("PRECHECK_OK =", precheck_ok)

    if not precheck_ok:
        try:
            arm.disable()
        finally:
            print("检查未通过，已发送失能命令。")
        return 2

    if not args.execute:
        try:
            arm.disable()
        finally:
            print(
                "未指定 --execute；"
                "未使能、未运动，已明确发送失能命令。"
            )
        return 0

    confirmation = input(
        f"将低速运动到 {args.target} 并原路返回；"
        "确认工作区清空且有人托护后输入 EXECUTE："
    ).strip()

    if confirmation != "EXECUTE":
        try:
            arm.disable()
        finally:
            print("未确认执行，已发送失能命令。")
        return 1

    open_fb = gripper.mm_to_fb(args.open_mm)
    enable_attempted = False
    completed = False

    try:
        enable_attempted = True
        arm.enable()
        print("ENABLED")

        for previous, current in zip(route, route[1:]):
            label = (
                f"{previous['name']}"
                f"->{current['name']}"
            )

            fault = arm.move(
                previous["q"],
                current["q"],
                label,
                grip_cmd=open_fb,
                grip_force=gripper.force,
            )

            print(
                "到达:" if not fault else "中止:",
                label,
                fault or "",
            )

            if fault:
                raise RuntimeError(fault)

        target_q = route[-1]["q"]
        fault = hold_open(
            arm,
            gripper,
            target_q,
            args.open_mm,
            args.hold_s,
        )

        if fault:
            raise RuntimeError(
                f"target_hold: {fault}"
            )

        print(
            f"目标保持 {args.hold_s:.1f}s 完成，"
            "开始原路返回。"
        )

        for index in range(
            len(route) - 1,
            0,
            -1,
        ):
            previous = route[index]
            current = route[index - 1]
            label = (
                f"{previous['name']}"
                f"->{current['name']}"
            )

            fault = arm.move(
                previous["q"],
                current["q"],
                label,
                grip_cmd=open_fb,
                grip_force=gripper.force,
            )

            print(
                "到达:" if not fault else "中止:",
                label,
                fault or "",
            )

            if fault:
                raise RuntimeError(fault)

        completed = True
        print("MIDPOINT_TEST_DONE" if args.target == "midpoint"
              else "HOVER_TEST_DONE")

    except Exception as exc:
        print("EXECUTION_ABORT:", repr(exc))

    finally:
        if enable_attempted:
            try:
                arm.disable()
                print("DISABLED")
            except Exception as exc:
                print(
                    "DISABLE_FAILED:",
                    repr(exc),
                )

    return 0 if completed else 2


if __name__ == "__main__":
    raise SystemExit(main())