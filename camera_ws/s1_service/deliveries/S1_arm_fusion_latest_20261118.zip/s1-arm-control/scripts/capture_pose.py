#!/usr/bin/env python3
import argparse
import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.arm import Arm, SafetyLimits
from s1_control.gripper import Gripper
from s1_control.kinematics import Kinematics


# 来自当前S1代码采用的关节范围
JOINT_LIMITS_DEG = [
    (-170.0, 170.0),
    (0.0, 180.0),
    (0.0, 170.0),
    (-90.0, 87.0),
    (-90.0, 90.0),
    (-90.0, 90.0),
]

RECOMMENDED_MARGIN_DEG = 10.0


def main():
    parser = argparse.ArgumentParser(
        description="安全采集S1当前关节姿态和TCP位姿"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--end", default="gripper")
    parser.add_argument("--name", required=True)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.name):
        raise ValueError("--name 只能包含字母、数字、下划线和连字符")

    pose_dir = PROJECT_ROOT / "data" / "captured_poses"
    output_path = pose_dir / f"{args.name}.json"

    if output_path.exists() and not args.overwrite:
        raise FileExistsError(
            f"{output_path} 已存在；如确需覆盖，请添加 --overwrite"
        )

    print("警告：本脚本退出时会明确执行失能，电机将由绿变红。")
    print("运行期间必须一直托住机械臂，或在连杆下放置可靠软支撑。")
    print("不要依靠电机保持力矩防止下落。")

    confirmation = input("确认已经托稳后，输入 y：").strip()
    if confirmation != "y":
        print("未确认，取消采集。")
        return 1

    arm = None

    try:
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=SafetyLimits(hz=50.0, v_max_rad_s=0.05),
        )
        gripper = Gripper(arm)
        kinematics = Kinematics(verbose=True)

        state = [float(v) for v in arm.read_joint_median()]
        q = state[:6]
        q_deg = [math.degrees(v) for v in q]
        tcp = [float(v) for v in kinematics.fk(q)]
        tcp_mm = [1000.0 * v for v in tcp[:3]]

        hard_limit_ok = True
        margin_ok = True
        joint_report = []

        print("\n关节检查：")

        for index, (value, limits) in enumerate(
            zip(q_deg, JOINT_LIMITS_DEG), start=1
        ):
            lower, upper = limits
            inside = lower <= value <= upper
            margin = min(value - lower, upper - value)

            if not inside:
                hard_limit_ok = False
                status = "越界"
            elif margin < RECOMMENDED_MARGIN_DEG:
                margin_ok = False
                status = "余量不足"
            else:
                status = "正常"

            joint_report.append(
                {
                    "joint": index,
                    "angle_deg": value,
                    "lower_deg": lower,
                    "upper_deg": upper,
                    "nearest_margin_deg": margin,
                    "status": status,
                }
            )

            print(
                f"J{index}: {value:+8.3f}°  "
                f"范围=[{lower:+.1f}, {upper:+.1f}]°  "
                f"最近余量={margin:.3f}°  {status}"
            )

        quaternion_w = max(-1.0, min(1.0, abs(tcp[6])))
        model_rotation_deg = math.degrees(
            2.0 * math.acos(quaternion_w)
        )

        replay_recommended = hard_limit_ok and margin_ok

        print("\nCAPTURED_Q_RAD =", [round(v, 6) for v in q])
        print("CAPTURED_Q_DEG =", [round(v, 3) for v in q_deg])
        print("TCP_MM =", [round(v, 3) for v in tcp_mm])
        print("TCP_QUAT_XYZW =", [round(v, 6) for v in tcp[3:]])
        print(
            "MODEL_ROTATION_FROM_ZERO_DEG =",
            round(model_rotation_deg, 3),
        )
        print(
            "GRIPPER_GAP_MM =",
            round(gripper.gap_from_fb(state[6]), 3),
        )
        print("HARD_LIMIT_OK =", hard_limit_ok)
        print("RECOMMENDED_MARGIN_OK =", margin_ok)
        print("REPLAY_RECOMMENDED =", replay_recommended)

        pose_dir.mkdir(parents=True, exist_ok=True)

        record = {
            "name": args.name,
            "captured_at": datetime.now().astimezone().isoformat(
                timespec="seconds"
            ),
            "joint_rad": q,
            "joint_deg": q_deg,
            "gripper_feedback": state[6],
            "gripper_gap_mm": gripper.gap_from_fb(state[6]),
            "tcp_xyz_quat_xyzw": tcp,
            "tcp_xyz_mm": tcp_mm,
            "joint_report": joint_report,
            "hard_limit_ok": hard_limit_ok,
            "recommended_margin_ok": margin_ok,
            "replay_recommended": replay_recommended,
        }

        with output_path.open("w", encoding="utf-8") as file:
            json.dump(record, file, ensure_ascii=False, indent=2)

        print("POSE_SAVED =", output_path)
        input("\n继续托稳机械臂，按回车执行受控失能：")

    finally:
        if arm is not None:
            try:
                arm.disable()
                print("DISABLED：现在电机应为常红。")
            except Exception as exc:
                print("DISABLE_FAILED:", repr(exc))


if __name__ == "__main__":
    raise SystemExit(main())