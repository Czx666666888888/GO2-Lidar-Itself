#!/usr/bin/env python3
"""Supervised first commissioning of zero-to-right-observation deployment."""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import statistics
import sys
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from s1_control.arm import Arm, SafetyLimits
from s1_control.go2_deployment import (
    file_sha256,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)
from s1_control.tilt_gravity import UrdfGravityModel, locate_official_gripper_urdf
from s1_control.tilt_motion import commander_from_mount_record


DEFAULT_PLAN = PROJECT_ROOT / "data" / "plans" / "go2_crouch_right_observe_deployment_v1.json"
DEFAULT_REPORT = PROJECT_ROOT / "data" / "plans" / "go2_crouch_right_observe_collision_report_v1.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "go2_observe_deployment_runs"


def resolve_project_path(raw: str | Path) -> Path:
    from s1_control.project_paths import project_path
    return project_path(raw, PROJECT_ROOT)


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporary.replace(path)


def wait_for_valid_feedback(
    arm,
    maximum_temperature_c: float,
    timeout_s: float = 5.0,
    required_consecutive: int = 10,
):
    started = time.monotonic()
    valid = []
    invalid_count = 0
    last_reason = "no samples"
    while time.monotonic() - started < timeout_s:
        cycle = time.monotonic()
        try:
            position = [float(value) for value in arm.get_pos()]
            velocity = [float(value) for value in arm.get_vel()]
            temperature = [float(value) for value in arm.get_temp()]
            if len(position) < 7 or len(velocity) < 6 or len(temperature) < 7:
                raise ValueError("feedback vector length is invalid")
            if not all(math.isfinite(value) for value in position + velocity + temperature):
                raise ValueError("feedback contains non-finite values")
            if min(temperature) < 5.0:
                raise ValueError("temperature feedback is not initialized")
            if max(temperature) > maximum_temperature_c:
                raise RuntimeError(f"temperature exceeds {maximum_temperature_c:.1f}C")
        except (RuntimeError, ValueError) as exc:
            if "temperature exceeds" in str(exc):
                raise
            valid.clear()
            invalid_count += 1
            last_reason = str(exc)
        else:
            valid.append({
                "position": position[:6],
                "velocity": velocity[:6],
                "temperature": temperature[:7],
            })
            if len(valid) >= required_consecutive:
                break
        time.sleep(max(0.0, 0.05 - (time.monotonic() - cycle)))
    if len(valid) < required_consecutive:
        raise RuntimeError(
            f"startup feedback not ready after {time.monotonic() - started:.2f}s: {last_reason}"
        )
    q = [statistics.median(row["position"][index] for row in valid) for index in range(6)]
    temp = [statistics.median(row["temperature"][index] for row in valid) for index in range(7)]
    spans = [
        max(row["position"][index] for row in valid)
        - min(row["position"][index] for row in valid)
        for index in range(6)
    ]
    return q, temp, {
        "ready": True,
        "invalid_sample_count": invalid_count,
        "sample_count": len(valid),
        "position_span_rad": spans,
        "maximum_abs_velocity_rad_s": max(
            abs(value) for row in valid for value in row["velocity"]
        ),
    }


def guarded_hold(
    arm,
    target_q,
    duration_s: float,
    label: str,
    *,
    gripper=None,
    grip_gap_mm: float | None = None,
    grip_force: float | None = None,
) -> None:
    if (gripper is None) != (grip_gap_mm is None):
        raise ValueError(f"{label}: gripper and grip_gap_mm must be provided together")
    deadline = time.monotonic() + duration_s
    next_tick = time.monotonic()
    while time.monotonic() < deadline:
        arm.command_position(target_q)
        if gripper is not None:
            gripper.command_mm(grip_gap_mm, force=grip_force)
        fault = arm.guard(
            arm.get_pos(), arm.get_vel(), arm.get_temp(), target_q, settling=False
        )
        if fault:
            raise RuntimeError(f"{label}: {fault}")
        next_tick += arm.dt
        time.sleep(max(0.0, next_tick - time.monotonic()))


def ramp_compensation_scale(
    arm,
    commander,
    target_q,
    *,
    start_scale: float,
    end_scale: float,
    duration_s: float,
    label: str,
    gripper=None,
    grip_gap_mm: float | None = None,
    grip_force: float | None = None,
):
    """Change compensation smoothly while holding a fixed, verified pose."""
    start_scale = float(start_scale)
    end_scale = float(end_scale)
    duration_s = float(duration_s)
    if not all(math.isfinite(value) for value in (start_scale, end_scale, duration_s)):
        raise ValueError(f"{label}: scale transition contains non-finite values")
    if not 0.0 < start_scale <= 1.0 or not 0.0 < end_scale <= 1.0:
        raise ValueError(f"{label}: compensation scales must be in (0, 1]")
    if duration_s <= 0.0:
        raise ValueError(f"{label}: transition duration must be positive")
    if (gripper is None) != (grip_gap_mm is None):
        raise ValueError(f"{label}: gripper and grip_gap_mm must be provided together")
    if not math.isclose(commander.compensation_scale, start_scale, abs_tol=1e-9):
        raise RuntimeError(
            f"{label}: current compensation scale {commander.compensation_scale:.3f} "
            f"does not match expected {start_scale:.3f}"
        )

    started = time.monotonic()
    next_tick = started
    sample_count = 0
    maximum_track_error = 0.0
    while True:
        elapsed = time.monotonic() - started
        u = min(1.0, max(0.0, elapsed / duration_s))
        smooth = u * u * (3.0 - 2.0 * u)
        scale = start_scale + (end_scale - start_scale) * smooth
        commander.set_compensation_scale(scale)
        arm.command_position(target_q)
        if gripper is not None:
            gripper.command_mm(grip_gap_mm, force=grip_force)
        measured_q = [float(value) for value in arm.get_pos()[:6]]
        maximum_track_error = max(
            maximum_track_error,
            max(abs(actual - target) for actual, target in zip(measured_q, target_q)),
        )
        fault = arm.guard(
            measured_q,
            arm.get_vel(),
            arm.get_temp(),
            target_q,
            settling=False,
        )
        if fault:
            raise RuntimeError(f"{label}: {fault}")
        sample_count += 1
        if u >= 1.0:
            break
        next_tick += arm.dt
        time.sleep(max(0.0, next_tick - time.monotonic()))

    commander.set_compensation_scale(end_scale)
    return {
        "label": label,
        "start_scale": start_scale,
        "end_scale": end_scale,
        "requested_duration_s": duration_s,
        "actual_duration_s": time.monotonic() - started,
        "sample_count": sample_count,
        "maximum_track_error_rad": maximum_track_error,
        "final_commander_snapshot": commander.last_snapshot,
    }


def planned_phases(start_q, waypoints, target_name: str):
    side = "left" if target_name.startswith("left_") else "right"
    by_name = {item["name"]: [float(value) for value in item["q"]] for item in waypoints}
    phases = [("vertical_escape", [list(start_q), by_name["rear_ready"]])]
    if target_name in {f"{side}_ready", f"{side}_observe"}:
        phases.append((
            "high_turn",
            [by_name["rear_ready"], by_name["high_turn_mid"], by_name[f"{side}_ready"]],
        ))
    if target_name == f"{side}_observe":
        phases.append((
            "side_deploy",
            [by_name[f"{side}_ready"], by_name[f"{side}_observe_mid"], by_name[f"{side}_observe"]],
        ))
    return phases


def main() -> int:
    parser = argparse.ArgumentParser(description="Go2趴下构型：S1零位自动部署到右侧观察位并原路返回")
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--plan", default=str(DEFAULT_PLAN))
    parser.add_argument("--collision-report", default=str(DEFAULT_REPORT))
    parser.add_argument(
        "--target",
        choices=["rear_ready", "right_ready", "right_observe"],
        default="right_observe",
    )
    parser.add_argument("--run-id")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    plan_path = resolve_project_path(args.plan)
    report_path = resolve_project_path(args.collision_report)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    mount_path = resolve_project_path(plan["mount_config"])
    mount_record = json.loads(mount_path.read_text(encoding="utf-8"))
    report = verify_bound_report(plan_path, report_path, mount_path)
    waypoints = plan["joint_path"]
    names = [str(item["name"]) for item in waypoints]
    if args.target not in names:
        raise ValueError(f"target {args.target} not found in plan")
    target_index = names.index(args.target)
    selected = waypoints[: target_index + 1]
    motion = plan["motion"]
    tilt_config = motion["tilt_compensation"]
    vertical_escape_scale = float(tilt_config["vertical_escape_scale"])
    high_turn_scale = float(tilt_config["high_turn_scale"])
    side_deploy_scale = float(tilt_config["side_deploy_scale"])
    transition_s = float(tilt_config["scale_transition_s"])
    transition_pose = str(tilt_config["transition_pose"])
    if transition_pose != "right_ready":
        raise ValueError("tilt compensation transition pose must be right_ready")
    if not math.isclose(vertical_escape_scale, high_turn_scale, abs_tol=1e-9):
        raise ValueError(
            "vertical_escape and high_turn scales must match because no "
            "intermediate transition pose is defined"
        )

    print("MODE = GO2_RIGHT_OBSERVE_DEPLOYMENT_ROUND_TRIP")
    print("PLAN_FILE =", plan_path)
    print("PLAN_SHA256 =", file_sha256(plan_path))
    print("COLLISION_REPORT =", report_path)
    print("COLLISION_REPORT_VERIFIED = True")
    print("MOUNT_CONFIG =", mount_path)
    print(
        "TILT_COMPENSATION_SCHEDULE =",
        f"vertical_escape={vertical_escape_scale:.2f}",
        f"high_turn={high_turn_scale:.2f}",
        f"side_deploy={side_deploy_scale:.2f}",
        f"transition={transition_pose}/{transition_s:.2f}s",
    )
    print("TARGET =", args.target)
    print("ROUTE =", " -> ".join(item["name"] for item in selected))
    print("UNMODELLED_EXTERNAL_OBSTACLES =", report["unmodelled_external_obstacles"])
    print("FORBIDDEN = camera-servo, descent, gripper-close, lift, box-place")

    if not args.execute:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("RESULT = OFFLINE_PREFLIGHT_OK")
        return 0

    print("\n首次实机仅验证自动部署往返，不启动D455、不下降、不合爪。")
    print("必须满足：Go2趴下且静止；机械臂从常红机械零位开始；全路径有软支撑但不阻挡运动。")
    print("配重、收纳盒、D455线束和人员均不得进入右侧部署路径。")
    if input("确认上述条件后输入 e：").strip().lower() != "e":
        print("RESULT = CANCELLED_BEFORE_CONNECTION")
        return 2

    run_id = args.run_id or datetime.now().strftime("deployment_%Y%m%d-%H%M%S")
    run_dir = DEFAULT_OUTPUT_ROOT / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": "go2_right_observe_deployment_round_trip",
        "status": "started",
        "plan": str(plan_path),
        "plan_sha256": file_sha256(plan_path),
        "report": str(report_path),
        "target": args.target,
    }
    write_json(log_path, log)

    limits = SafetyLimits(
        hz=float(motion["hz"]),
        v_max_rad_s=float(motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(motion["j6_v_max_rad_s"]),
        motion_profile=str(motion["profile"]),
        max_track_err_rad=float(motion["maximum_track_error_rad"]),
        max_speed_rad_s=float(motion["maximum_measured_speed_rad_s"]),
        max_temp_c=float(motion["maximum_temperature_c"]),
        max_joint_delta_rad=0.9,
        settle_seconds=float(motion["settle_seconds"]),
    )
    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    arm = None
    result = "ABORTED"
    try:
        arm = Arm(
            dev=args.dev,
            end_effector="gripper",
            limits=limits,
            check_collision=False,
        )
        commander = commander_from_mount_record(
            tilt_model,
            mount_record,
            vertical_escape_scale,
        )
        arm.set_position_commander(commander)
        start_q, temperature, readiness = wait_for_valid_feedback(
            arm, limits.max_temp_c
        )
        print("STARTUP_FEEDBACK_READY =", readiness["ready"])
        print("START_Q =", [round(value, 6) for value in start_q])
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        violations = start_window_violations(
            start_q, plan["start_safe_windows_rad"]
        )
        print("START_SAFE_WINDOW_OK =", not violations)
        for violation in violations:
            print("START_WINDOW_VIOLATION =", violation)
        rear_ready = [float(value) for value in waypoints[1]["q"]]
        start_delta = max_joint_delta(start_q, rear_ready)
        print("START_TO_REAR_READY_DELTA_RAD =", round(start_delta, 6))
        live_precheck_ok = not violations and start_delta <= limits.max_joint_delta_rad
        print("LIVE_PRECHECK_OK =", live_precheck_ok)
        log.update({
            "start_q": start_q,
            "temperature_c": temperature,
            "startup_readiness": readiness,
            "start_window_violations": violations,
            "start_to_rear_ready_delta_rad": start_delta,
        })
        write_json(log_path, log)
        if not live_precheck_ok:
            result = "LIVE_PRECHECK_REJECTED"
            return 2

        arm.preflight(
            [(item["name"], item["q"]) for item in selected[1:]],
            start_q,
            collision_report_verified=True,
        )
        print("本次连接后若出现持续motor timeout、线束绷紧或Go2姿态变化，禁止继续。")
        if input("确认实际净空仍满足，输入 d：").strip() != "d":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        phases = planned_phases(start_q, waypoints, args.target)
        log["phases"] = [name for name, _ in phases]
        log["tilt_compensation_schedule"] = tilt_config
        log["compensation_transitions"] = []
        arm.enable()
        print(
            "ENABLED_WITH_TILT_COMPENSATION scale =",
            f"{commander.compensation_scale:.2f}",
        )
        guarded_hold(arm, start_q, 0.5, "initial_hold")
        for name, points in phases:
            if name == "side_deploy":
                print(
                    "TILT_SCALE_TRANSITION =",
                    f"{vertical_escape_scale:.2f}->{side_deploy_scale:.2f}",
                    "at right_ready",
                )
                transition = ramp_compensation_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=vertical_escape_scale,
                    end_scale=side_deploy_scale,
                    duration_s=transition_s,
                    label="right_ready_scale_up",
                )
                log["compensation_transitions"].append(transition)
                write_json(log_path, log)
            print("DEPLOY_PHASE =", name)
            fault = arm.move_waypoints(points, name)
            if fault:
                raise RuntimeError(fault)
            print("到达:", name)
        final_q = phases[-1][1][-1]
        guarded_hold(
            arm,
            final_q,
            float(motion["observation_hold_s"]),
            "observation_hold",
        )
        print("OBSERVATION_POSE_REACHED = True")
        print("D455_CAPTURE_EXECUTED = False")
        for name, points in reversed(phases):
            return_name = f"{name}_return"
            print("RETURN_PHASE =", return_name)
            fault = arm.move_waypoints(list(reversed(points)), return_name)
            if fault:
                raise RuntimeError(fault)
            print("到达:", return_name)
            if name == "side_deploy":
                print(
                    "TILT_SCALE_TRANSITION =",
                    f"{side_deploy_scale:.2f}->{high_turn_scale:.2f}",
                    "at right_ready",
                )
                transition = ramp_compensation_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=side_deploy_scale,
                    end_scale=high_turn_scale,
                    duration_s=transition_s,
                    label="right_ready_scale_down",
                )
                log["compensation_transitions"].append(transition)
                write_json(log_path, log)
        result = "DEPLOYMENT_ROUND_TRIP_DONE"
        return 0
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        print(result)
        return 1
    finally:
        if arm is not None:
            try:
                arm.disable()
            except Exception as exc:
                print("DISABLE_WARNING =", repr(exc))
        log["status"] = result
        write_json(log_path, log)
        print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
        print("LOG_SAVED =", log_path)
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
