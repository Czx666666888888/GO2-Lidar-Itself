#!/usr/bin/env python3
"""Run the guarded 4 mm support-normal compensation motion A/B diagnostic."""
from __future__ import annotations

import sys

from run_wrist_high_hover_servo import main as run_high_hover_main


def main(argv=None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--compensation-motion-ab-only" not in args:
        args.append("--compensation-motion-ab-only")
    if not any(
        arg == "--compensation-ab-blend"
        or arg.startswith("--compensation-ab-blend=")
        for arg in args
    ):
        args.extend(["--compensation-ab-blend", "0.50"])
    return run_high_hover_main(args)


if __name__ == "__main__":
    raise SystemExit(main())
