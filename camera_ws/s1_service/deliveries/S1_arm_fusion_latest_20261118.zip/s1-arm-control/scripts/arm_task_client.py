#!/usr/bin/env python3
"""Local JSON socket client for the persistent arm integration service."""
import argparse
import json
import socket

DEFAULT_SOCKET = "/tmp/s1-arm-integration.sock"

def request(command, socket_path=DEFAULT_SOCKET):
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(socket_path)
        client.sendall((json.dumps({"command": command})+"\n").encode())
        with client.makefile("rb") as stream:
            return json.loads(stream.readline())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["status", "grasp", "dump"])
    parser.add_argument("--socket", default=DEFAULT_SOCKET)
    args = parser.parse_args()
    print(json.dumps(request(args.command, args.socket), ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
