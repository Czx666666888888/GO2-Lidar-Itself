#!/usr/bin/env python3
"""Persistent zero-hold service. No hardware is opened without --execute."""
from __future__ import annotations
import argparse
import fcntl
import json
from pathlib import Path
import queue
import signal
import socketserver
import sys
import threading

ROOT = Path(__file__).resolve().parents[1]
for path in (ROOT, ROOT / "scripts", Path.home()/"thirdparty/S1_SDK_V2-official/src"):
    sys.path.insert(0, str(path))
from s1_control.integration import ArmIntegrationSession, ZERO_Q

DEFAULT_SOCKET = "/tmp/s1-arm-integration.sock"

def flow_arguments(args, *, execute):
    values = ["--dev", args.dev, "--config", args.config,
              "--search-plan", *args.search_plan,
              "--flexible-approach", "--all-joint-speed-rad-s", str(args.speed),
              "--descent-speed-rad-s", str(args.descent_speed),
              "--descent-acceleration-rad-s2", str(args.descent_acceleration_rad_s2),
              "--deployment-acceleration-rad-s2", str(args.deployment_acceleration_rad_s2)]
    if getattr(args, "payload_mass_g", None) is not None:
        values.extend(["--payload-mass-g", str(args.payload_mass_g)])
    if args.acceleration_rad_s2 is not None:
        values.extend(["--acceleration-rad-s2", str(args.acceleration_rad_s2)])
    if args.non_interactive:
        values.append("--non-interactive")
    else:
        values.append("--manual-confirmations")
    if execute:
        values.append("--execute")
    return values

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--socket", default=DEFAULT_SOCKET)
    parser.add_argument("--config", default="config/go2_dual_white_light_full_flow_size_adaptive_v1.json")
    parser.add_argument("--search-plan", nargs=2, default=[
        "data/plans/go2_right_grasp_search_20261107_v1.json",
        "data/plans/go2_right_grasp_search_20261107_v1_report.json"])
    parser.add_argument("--deployment-acceleration-rad-s2", type=float, default=0.25)
    parser.add_argument("--descent-acceleration-rad-s2", type=float, default=0.25)
    parser.add_argument("--acceleration-rad-s2", type=float, default=None)
    parser.add_argument("--speed", type=float, default=1.5)
    parser.add_argument("--descent-speed", type=float, default=0.75)
    parser.add_argument("--manual-confirmations", dest="non_interactive", action="store_false",
                        help="optional development mode requiring e/d confirmations")
    parser.add_argument("--non-interactive", action="store_true", default=True,
                        help="skip manual confirmations (default for fusion integration)")
    parser.add_argument("--payload-mass-g", type=float, help="actual object mass in grams; overrides configuration")
    parser.add_argument("--dump-plan", default="config/go2_hinged_box_dump.json")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)
    import run_go2_visual_alignment as flow
    # Run the complete existing preflight before opening the arm.
    code = flow.main(flow_arguments(args, execute=False))
    if code or not args.execute:
        return code
    from s1_control.arm import Arm, SafetyLimits
    from execute_go2_observe_deployment import wait_for_valid_feedback
    _, config = flow.load_alignment_config(args.config)
    plan = json.loads(flow.resolve_project_path(config["deployment_plan"]).read_text())
    # One service owns the device across idle hold and every grasp.
    device_lock = open("/tmp/s1-arm-" + Path(args.dev).resolve().name + ".lock", "a")
    fcntl.flock(device_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    socket_path = Path(args.socket)
    if socket_path.is_socket():
        socket_path.unlink()
    arm = Arm(dev=args.dev, end_effector="gripper", check_collision=False,
              limits=SafetyLimits(v_max_rad_s=args.speed, j6_v_max_rad_s=args.speed,
                                  max_acceleration_rad_s2=args.acceleration_rad_s2,
                                  max_speed_rad_s=1.2*args.speed, motion_profile="s_curve",
                                  pause_on_tracking_lag=True, elapsed_cycle_progress=True))
    session = ArmIntegrationSession(arm)
    stop = threading.Event()
    server = None
    server_running = False
    def stop_requested(signum, frame):
        # Finish an active grasp before stopping the service.
        stop.set()
    signal.signal(signal.SIGTERM, stop_requested)
    signal.signal(signal.SIGINT, stop_requested)
    class Handler(socketserver.StreamRequestHandler):
        def handle(self):
            try:
                request = json.loads(self.rfile.readline(4096))
                if request.get("command") == "status":
                    response = session.snapshot()
                elif request.get("command") == "grasp":
                    response = session.request_grasp()
                elif request.get("command") == "dump":
                    from s1_control.box_dump import load_dump_plan
                    try:
                        dump_plan = load_dump_plan(flow.resolve_project_path(args.dump_plan))
                        response = session.request_task("dump", dump_plan)
                    except (ValueError, OSError, KeyError) as exc:
                        response = {"accepted": False, "reason": str(exc)}
                else:
                    response = {"accepted": False, "reason": "unknown command"}
            except (ValueError, TypeError) as exc:
                response = {"accepted": False, "reason": str(exc)}
            self.wfile.write((json.dumps(response, ensure_ascii=False)+"\n").encode())
    class Server(socketserver.ThreadingUnixStreamServer):
        daemon_threads = True
    try:
        q, _, _ = wait_for_valid_feedback(arm, arm.limits.max_temp_c)
        print("STARTUP_ZERO_START_Q =", q[:6], flush=True)
        print("STARTUP_ZERO_SPEED_RAD_S =", args.speed, flush=True)
        print("STARTUP_ZERO_ROUTE = direct_position_return", flush=True)
        # Bind before enabling so a second service cannot take serial control.
        server = Server(args.socket, Handler)
        Path(args.socket).chmod(0o660)
        arm.enable()
        fault = arm.move(q[:6], ZERO_Q, "startup_zero")
        if fault:
            raise RuntimeError(fault)
        session.start_hold()
        session.ready()
        threading.Thread(target=server.serve_forever, name="s1-task-api", daemon=True).start()
        server_running = True
        print("INTEGRATION_READY = ZERO_HOLD socket="+args.socket, flush=True)
        while not stop.is_set():
            try:
                job = session.jobs.get(timeout=0.2)
            except queue.Empty:
                continue
            if isinstance(job, tuple) and job[0] == "dump":
                from s1_control.box_dump import run_dump
                session.run_task(lambda active: run_dump(active, job[1],
                    log_root=ROOT/"data/go2_box_dump_runs"), task="dump")
            else:
                session.run_task(lambda active: flow.main(flow_arguments(args, execute=True),
                                                         arm_session=active))
        return 0
    finally:
        if server is not None:
            if server_running:
                server.shutdown()
            server.server_close()
            Path(args.socket).unlink(missing_ok=True)
        session.close()

if __name__ == "__main__":
    raise SystemExit(main())
