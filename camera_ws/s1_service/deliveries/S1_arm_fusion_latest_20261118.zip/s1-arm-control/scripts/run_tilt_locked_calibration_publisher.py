#!/usr/bin/env python3
"""Publish synchronized S1 joint states during supervised tilt-locked calibration.

This process is the sole owner of the S1 serial bus.  It never opens a camera,
never moves to a planned pose, and never commands the gripper.  The operator
uses gravity teaching to place each calibration view, presses ``l`` to lock the
unchanged joint pose, captures one or more images in the separate camera
process, then presses ``t`` to return to teaching.  ``q`` ramps the differential
tilt feed-forward down and disables the arm.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
import json
import math
from pathlib import Path
import re
import sys
import threading
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
for path in (PROJECT_ROOT, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from diagnose_small_joint_motion import summarize_lock_rows
from diagnose_tilt_compensation import (
    correction_snapshot,
    load_configuration,
    send_compensated_position,
)
from diagnose_wrist_hold_tracking import finite_vector, wait_for_valid_feedback
from s1_control.arm import Arm, SafetyLimits
from s1_control.tilt_gravity import UrdfGravityModel, locate_official_gripper_urdf
from s1_control.wrist_visual_servo import joint_margin_details


DEFAULT_MOUNT_CONFIG = PROJECT_ROOT / "config" / "go2_crouch_mount.json"
DEFAULT_POSE_SOURCE_ROOT = (
    PROJECT_ROOT / "data" / "eye_in_hand_calibration" / "pose_sources"
)
SESSION_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
POSE_SOURCE_STATES = {"teaching", "locking", "locked", "unlocking"}
LOCK_MAXIMUM_SPAN_RAD = 0.01
LOCK_SETTLE_SECONDS = 0.5


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="S1倾角补偿标定姿态发布器（独占串口，不访问D455）"
    )
    parser.add_argument("--session", required=True)
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--end", default="gripper")
    parser.add_argument("--mount-config", type=Path, default=DEFAULT_MOUNT_CONFIG)
    parser.add_argument("--pose-csv", type=Path)
    parser.add_argument("--compensation-scale", type=float, default=1.0)
    parser.add_argument("--teach-hz", type=float, default=50.0)
    parser.add_argument("--publish-hz", type=float, default=20.0)
    parser.add_argument("--lock-sample-hz", type=float, default=10.0)
    parser.add_argument("--lock-sample-count", type=int, default=15)
    parser.add_argument("--min-joint-margin-deg", type=float, default=15.0)
    parser.add_argument("--max-temp-c", type=float, default=55.0)
    parser.add_argument("--execute", action="store_true")
    return parser


def validate_args(args) -> None:
    if not SESSION_PATTERN.fullmatch(args.session):
        raise ValueError("--session contains unsupported characters")
    for name, value in {
        "--teach-hz": args.teach_hz,
        "--publish-hz": args.publish_hz,
        "--lock-sample-hz": args.lock_sample_hz,
        "--max-temp-c": args.max_temp_c,
    }.items():
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be positive and finite")
    if args.publish_hz > args.teach_hz:
        raise ValueError("--publish-hz cannot exceed --teach-hz")
    if args.lock_sample_hz > args.teach_hz:
        raise ValueError("--lock-sample-hz cannot exceed --teach-hz")
    if args.lock_sample_count < 10:
        raise ValueError("--lock-sample-count must be at least 10")
    if (
        not math.isfinite(args.min_joint_margin_deg)
        or args.min_joint_margin_deg < 10.0
    ):
        raise ValueError("--min-joint-margin-deg must be at least 10 degrees")


def resolve_pose_csv(args) -> Path:
    if args.pose_csv is not None:
        return args.pose_csv.expanduser().resolve()
    return (DEFAULT_POSE_SOURCE_ROOT / f"{args.session}.csv").resolve()


def pose_csv_row(timestamp_s: float, state7, source_state: str) -> list:
    timestamp = float(timestamp_s)
    state = finite_vector(state7, 7, "joint state")
    if not math.isfinite(timestamp):
        raise ValueError("pose timestamp must be finite")
    if source_state not in POSE_SOURCE_STATES:
        raise ValueError(f"unsupported pose source state: {source_state}")
    return [f"{timestamp:.9f}", *[f"{value:.9f}" for value in state], source_state]


class PoseCsvPublisher:
    def __init__(self, path: Path):
        self.path = path.expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._stream = self.path.open("x", encoding="utf-8", newline="")
        self._writer = csv.writer(self._stream)
        self._writer.writerow(
            ["time", "q1", "q2", "q3", "q4", "q5", "q6", "gripper", "source_state"]
        )
        self._stream.flush()

    def publish(self, state7, source_state: str, timestamp_s: float | None = None):
        timestamp = time.time() if timestamp_s is None else float(timestamp_s)
        self._writer.writerow(pose_csv_row(timestamp, state7, source_state))
        self._stream.flush()

    def close(self):
        if not self._stream.closed:
            self._stream.flush()
            self._stream.close()


def start_command_reader(prompt: str, name: str):
    state = {"command": None, "error": None}

    def read_command():
        try:
            state["command"] = input(prompt).strip().lower()
        except BaseException as exc:  # surfaced in the control thread
            state["error"] = exc

    thread = threading.Thread(target=read_command, name=name, daemon=True)
    thread.start()
    return state, thread


def publish_if_due(publisher, state7, source_state, now, next_publish, period):
    if now >= next_publish:
        publisher.publish(state7, source_state)
        return now + period
    return next_publish


def collect_lock_sample(
    arm,
    args,
    publisher,
):
    control_period = 1.0 / args.teach_hz
    sample_period = 1.0 / args.lock_sample_hz
    publish_period = 1.0 / args.publish_hz
    next_sample = time.monotonic()
    next_publish = next_sample
    rows = []
    while len(rows) < args.lock_sample_count:
        cycle_started = time.monotonic()
        arm.gravity()
        state7 = finite_vector(arm.get_pos(), 7, "position")
        now = time.monotonic()
        next_publish = publish_if_due(
            publisher,
            state7,
            "locking",
            now,
            next_publish,
            publish_period,
        )
        if now >= next_sample:
            rows.append(state7[:6])
            next_sample = now + sample_period
        time.sleep(max(0.0, control_period - (time.monotonic() - cycle_started)))
    temperature = finite_vector(arm.get_temp(), 7, "temperature")
    return summarize_lock_rows(rows), temperature


def teach_until_locked(arm, args, publisher):
    print("TEACHING_ENABLED：持续托住机械臂；只允许人工摆姿，不运行规划运动。")
    print("棋盘完整可见且机械臂静止后输入 l；输入 q 结束并失能。")
    publish_period = 1.0 / args.publish_hz
    while True:
        command_state, reader = start_command_reader(
            "TEACH_COMMAND [l/q]: ",
            "tilt_calibration_teach_command",
        )
        next_temperature_check = time.monotonic()
        next_publish = next_temperature_check
        while reader.is_alive():
            cycle_started = time.monotonic()
            arm.gravity()
            state7 = finite_vector(arm.get_pos(), 7, "position")
            now = time.monotonic()
            next_publish = publish_if_due(
                publisher,
                state7,
                "teaching",
                now,
                next_publish,
                publish_period,
            )
            if now >= next_temperature_check:
                temperature = finite_vector(arm.get_temp(), 7, "temperature")
                if max(temperature) > args.max_temp_c:
                    raise RuntimeError("motor temperature exceeds configured limit")
                next_temperature_check = now + 1.0
            time.sleep(
                max(0.0, 1.0 / args.teach_hz - (time.monotonic() - cycle_started))
            )
        if command_state["error"] is not None:
            raise command_state["error"]
        if command_state["command"] == "q":
            return None, None
        if command_state["command"] != "l":
            print("只接受 l 或 q；继续重力示教。")
            continue

        summary, temperature = collect_lock_sample(arm, args, publisher)
        if summary["maximum_span_rad"] > LOCK_MAXIMUM_SPAN_RAD:
            print(
                "LOCK_REJECTED：姿态仍在移动；"
                f"J{summary['maximum_span_joint']} span="
                f"{summary['maximum_span_rad']:.6f}rad。继续示教。"
            )
            continue
        q_lock = list(summary["median_q_rad"])
        margins = joint_margin_details(q_lock)
        minimum_margin = min(item["margin_deg"] for item in margins)
        if minimum_margin < args.min_joint_margin_deg:
            limiting = min(margins, key=lambda item: item["margin_deg"])
            print(
                f"LOCK_REJECTED：J{limiting['joint']} margin="
                f"{minimum_margin:.2f}deg < {args.min_joint_margin_deg:.2f}deg。"
            )
            continue
        arm._arm.joint_control_mit(q_lock)
        return q_lock, {
            **summary,
            "temperature_c": temperature,
            "joint_margin_deg": minimum_margin,
            "joint_margin_details": margins,
        }


def ramp_down_compensation(
    arm,
    model,
    q_lock,
    rear_down_deg,
    scale,
    limits_nm,
    ramp_s,
    publisher,
    args,
):
    started = time.monotonic()
    next_publish = started
    publish_period = 1.0 / args.publish_hz
    while True:
        cycle_started = time.monotonic()
        elapsed = cycle_started - started
        progress = min(1.0, elapsed / ramp_s)
        effective_scale = scale * (1.0 - progress)
        state7 = finite_vector(arm.get_pos(), 7, "position")
        command = send_compensated_position(
            arm,
            model,
            q_lock,
            state7[:6],
            rear_down_deg,
            effective_scale,
            limits_nm,
        )
        if command["clipped"]:
            raise RuntimeError("tilt correction reached a hard cap during unlock")
        now = time.monotonic()
        next_publish = publish_if_due(
            publisher,
            state7,
            "unlocking",
            now,
            next_publish,
            publish_period,
        )
        if progress >= 1.0:
            break
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    arm.gravity()


def hold_until_command(
    arm,
    model,
    q_lock,
    rear_down_deg,
    scale,
    limits_nm,
    ramp_s,
    publisher,
    args,
):
    command_state, reader = start_command_reader(
        "LOCKED_COMMAND [t=返回示教/q=失能退出]: ",
        "tilt_calibration_locked_command",
    )
    started = time.monotonic()
    next_publish = started
    next_temperature_check = started
    publish_period = 1.0 / args.publish_hz
    cached_temperature = finite_vector(arm.get_temp(), 7, "temperature")
    ready_printed = False
    while True:
        cycle_started = time.monotonic()
        elapsed = cycle_started - started
        effective_scale = scale * min(1.0, elapsed / ramp_s)
        state7 = finite_vector(arm.get_pos(), 7, "position")
        command = send_compensated_position(
            arm,
            model,
            q_lock,
            state7[:6],
            rear_down_deg,
            effective_scale,
            limits_nm,
        )
        velocity = finite_vector(arm.get_vel(), 7, "velocity")
        now = time.monotonic()
        if now >= next_temperature_check:
            cached_temperature = finite_vector(arm.get_temp(), 7, "temperature")
            next_temperature_check = now + 0.5
        source_state = (
            "locked" if elapsed >= ramp_s + LOCK_SETTLE_SECONDS else "locking"
        )
        next_publish = publish_if_due(
            publisher,
            state7,
            source_state,
            now,
            next_publish,
            publish_period,
        )
        bad = arm.guard(
            state7[:6],
            velocity[:6],
            cached_temperature,
            q_lock,
            settling=source_state != "locked",
        )
        if bad:
            raise RuntimeError(f"tilt-locked hold: {bad}")
        if command["clipped"]:
            raise RuntimeError("tilt correction reached a hard cap")
        if source_state == "locked" and not ready_printed:
            print("LOCKED_Q =", [round(value, 6) for value in q_lock])
            print("LOCKED_READY_FOR_CAPTURE = True")
            print("切换到D455采集窗口；样本被接受后回本终端输入 t。")
            ready_printed = True

        if not reader.is_alive():
            if command_state["error"] is not None:
                raise command_state["error"]
            command_text = command_state["command"]
            if command_text in {"t", "q"}:
                ramp_down_compensation(
                    arm,
                    model,
                    q_lock,
                    rear_down_deg,
                    scale,
                    limits_nm,
                    ramp_s,
                    publisher,
                    args,
                )
                return command_text
            print("只接受 t 或 q；继续倾角补偿锁定。")
            command_state, reader = start_command_reader(
                "LOCKED_COMMAND [t/q]: ",
                "tilt_calibration_locked_command_retry",
            )
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))


def write_json(path: Path, record: dict):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    validate_args(args)
    pose_csv_path = resolve_pose_csv(args)
    log_path = pose_csv_path.with_suffix(".publisher.json")
    config_path = args.mount_config.expanduser().resolve()
    config = load_configuration(config_path)
    diagnostic = config["diagnostic"]
    allowed_scales = [float(value) for value in diagnostic["allowed_scale_steps"]]
    if not any(
        math.isclose(args.compensation_scale, value, abs_tol=1e-9)
        for value in allowed_scales
    ):
        raise ValueError(
            f"--compensation-scale must be one of {allowed_scales}"
        )
    rear_down_deg = float(config["mount_measurement"]["rear_edge_lower_deg"])
    correction_limits_nm = [
        float(value) for value in diagnostic["correction_absolute_limits_nm"]
    ]
    ramp_s = float(diagnostic["ramp_seconds"])

    print("MODE = tilt-locked-eye-in-hand-pose-publisher")
    print("CAMERA_ACCESS = False")
    print("PLANNED_MOTION = False")
    print("GRIPPER_COMMANDS = False")
    print("SESSION =", args.session)
    print("POSE_CSV =", pose_csv_path)
    print("MOUNT_CONFIG =", config_path)
    print("REAR_EDGE_LOWER_DEG =", rear_down_deg)
    print("COMPENSATION_SCALE =", args.compensation_scale)
    print("POSE_FLOW = teaching -> locking -> locked -> unlocking -> teaching")
    print("PAYLOAD_NOT_MODELLED = D455 and printed bracket")
    if not args.execute:
        print("OFFLINE_ONLY：未构造Arm、未访问串口、未使能机械臂。")
        return 0
    if pose_csv_path.exists() or log_path.exists():
        raise FileExistsError(
            "pose source already exists; use a new session name instead of overwriting"
        )

    print("实机条件：Go2趴下并固定，机械臂常红、持续人工托住且有软支撑。")
    print("棋盘和Go2在整个训练会话中都不得移动；D455线束无干涉。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("CANCELLED_BEFORE_ARM_ACCESS")
        return 1

    urdf_path = locate_official_gripper_urdf()
    model = UrdfGravityModel.from_file(urdf_path)
    publisher = PoseCsvPublisher(pose_csv_path)
    record = {
        "schema_version": 1,
        "mode": "tilt-locked-eye-in-hand-pose-publisher",
        "session": args.session,
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "pose_csv": str(pose_csv_path),
        "mount_config": str(config_path),
        "rear_edge_lower_deg": rear_down_deg,
        "compensation_scale": args.compensation_scale,
        "urdf": str(urdf_path),
        "urdf_total_mass_kg": model.total_mass_kg,
        "lock_events": [],
        "result": "STARTED",
    }
    arm = None
    return_code = 1
    try:
        limits = SafetyLimits(
            hz=float(diagnostic["control_hz"]),
            v_max_rad_s=0.05,
            j6_v_max_rad_s=0.05,
            motion_profile="s_curve",
            max_track_err_rad=float(diagnostic["maximum_track_error_rad"]),
            max_speed_rad_s=float(diagnostic["maximum_speed_rad_s"]),
            max_temp_c=min(args.max_temp_c, float(diagnostic["maximum_temperature_c"])),
            max_joint_delta_rad=0.05,
            settle_seconds=ramp_s + LOCK_SETTLE_SECONDS,
        )
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=limits,
            check_collision=False,
        )
        connected_q, connected_temperature, startup = wait_for_valid_feedback(
            arm, limits.max_temp_c
        )
        print("STARTUP_FEEDBACK_READY =", startup["ready"])
        print("CONNECTED_Q =", [round(value, 6) for value in connected_q])
        print(
            "CONNECTED_TEMPERATURE_C =",
            [round(value, 1) for value in connected_temperature],
        )
        if input("确认继续托稳且示教范围无碰撞，输入 e：").strip().lower() != "e":
            record["result"] = "CANCELLED_BEFORE_TEACHING"
            return 1

        arm.enable()
        arm.gravity()
        while True:
            q_lock, lock_record = teach_until_locked(arm, args, publisher)
            if q_lock is None:
                record["result"] = "COMPLETED_BY_OPERATOR"
                return_code = 0
                break
            snapshot = correction_snapshot(
                model,
                q_lock,
                rear_down_deg,
                args.compensation_scale,
                correction_limits_nm,
            )
            lock_record["locked_at"] = datetime.now().astimezone().isoformat(
                timespec="milliseconds"
            )
            lock_record["q_lock_rad"] = q_lock
            lock_record["correction"] = snapshot
            record["lock_events"].append(lock_record)
            if snapshot["clipped"]:
                raise RuntimeError("locked-pose correction exceeds a hard cap")
            command = hold_until_command(
                arm,
                model,
                q_lock,
                rear_down_deg,
                args.compensation_scale,
                correction_limits_nm,
                ramp_s,
                publisher,
                args,
            )
            if command == "q":
                record["result"] = "COMPLETED_BY_OPERATOR"
                return_code = 0
                break
            print("RETURNED_TO_TEACHING = True")
            print("持续托住机械臂，摆放下一个标定姿态。")
    except KeyboardInterrupt:
        record["result"] = "CANCELLED"
        print("CANCELLED")
    except Exception as exc:
        record["result"] = f"ABORTED: {type(exc).__name__}: {exc}"
        record["error"] = repr(exc)
        print(record["result"])
    finally:
        if arm is not None:
            try:
                arm.disable()
                print("DISABLED：继续托稳直到机械臂落在软支撑上。")
            except Exception as exc:
                record["disable_error"] = repr(exc)
                print("DISABLE_FAILED:", repr(exc))
        publisher.close()
        record["finished_at"] = datetime.now().astimezone().isoformat(
            timespec="seconds"
        )
        write_json(log_path, record)
        print("PUBLISHER_LOG_SAVED =", log_path)
        print("RESULT =", record["result"])
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
