#!/usr/bin/env python3
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import mujoco

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from S1_SDK.hardware.collision import CollisionChecker
from s1_control.kinematics import Kinematics


JOINT_LIMITS = [
    (math.radians(-170), math.radians(170)),
    (math.radians(0), math.radians(180)),
    (math.radians(0), math.radians(170)),
    (math.radians(-90), math.radians(87)),
    (math.radians(-90), math.radians(90)),
    (math.radians(-90), math.radians(90)),
]


def resolve_path(raw):
    path = Path(raw)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path


def interpolate(q_from, q_to, max_step_rad):
    delta = max(
        abs(a - b) for a, b in zip(q_from, q_to)
    )
    steps = max(1, math.ceil(delta / max_step_rad))

    for index in range(steps + 1):
        alpha = index / steps
        yield alpha, [
            a + alpha * (b - a)
            for a, b in zip(q_from, q_to)
        ]


def joint_status(q):
    hard_ok = True
    margins_deg = []

    for value, (lower, upper) in zip(q, JOINT_LIMITS):
        if not lower <= value <= upper:
            hard_ok = False

        margin = min(value - lower, upper - value)
        margins_deg.append(math.degrees(margin))

    return hard_ok, margins_deg


def collision_at(checker, q):
    model = checker.model
    data = checker.data

    mujoco.mj_resetData(model, data)

    # 保留SDK模型使用的第四关节+0.01rad偏置，
    # 但不修改原始关节数组。
    model_q = list(q[:6])
    model_q[3] += 0.01

    for index, value in enumerate(model_q):
        joint_id = checker.joint_indices[index]
        qpos_address = model.jnt_qposadr[joint_id]
        data.qpos[qpos_address] = value

    mujoco.mj_forward(model, data)

    exclusions = {
        tuple(sorted(pair))
        for pair in checker.exclude_pairs
    }

    q3 = model_q[2]
    q4 = model_q[3]
    dynamic_pair = tuple(sorted(("geom1", "geom5")))

    if not (0.0 <= q3 <= 0.02) or q4 < -0.02:
        exclusions.add(dynamic_pair)
    else:
        exclusions.discard(dynamic_pair)

    active_pairs = set()
    excluded_pairs = set()
    floor_pairs = set()

    for index in range(data.ncon):
        contact = data.contact[index]

        geom1_id = contact.geom1
        geom2_id = contact.geom2

        geom1 = model.geom(geom1_id).name or f"geom{geom1_id}"
        geom2 = model.geom(geom2_id).name or f"geom{geom2_id}"

        body1 = (
            model.body(model.geom_bodyid[geom1_id]).name
            or f"body{model.geom_bodyid[geom1_id]}"
        )
        body2 = (
            model.body(model.geom_bodyid[geom2_id]).name
            or f"body{model.geom_bodyid[geom2_id]}"
        )

        geom_pair = tuple(sorted((geom1, geom2)))
        full_pair = tuple(sorted((
            f"{geom1} (link={body1})",
            f"{geom2} (link={body2})",
        )))

        if geom1 == "floor" or geom2 == "floor":
            floor_pairs.add(full_pair)
        elif geom_pair in exclusions:
            excluded_pairs.add(full_pair)
        else:
            # 不复用SDK中不对称的广泛忽略条件，
            # 未经确认的接触一律保守报告。
            active_pairs.add(full_pair)

    return active_pairs, excluded_pairs, floor_pairs


def main():
    parser = argparse.ArgumentParser(
        description="纯离线逐点检查方块悬停关节路径"
    )
    parser.add_argument(
        "--plan",
        default="data/plans/cube50_hover_plan.json",
    )
    parser.add_argument("--step-rad", type=float, default=0.02)
    parser.add_argument(
        "--min-joint-margin-deg",
        type=float,
        default=10.0,
    )
    parser.add_argument(
        "--min-tcp-z-mm",
        type=float,
        default=60.0,
    )
    parser.add_argument(
        "--max-descent-lateral-mm",
        type=float,
        default=3.0,
        help="hover/descent/grasp下降段相对目标XY的最大允许横向偏差",
    )
    parser.add_argument(
        "--output",
        default="data/plans/cube50_hover_collision_report.json",
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if args.step_rad <= 0.0:
        raise ValueError("--step-rad 必须大于0")
    if args.max_descent_lateral_mm <= 0.0:
        raise ValueError("--max-descent-lateral-mm必须大于0")

    plan_path = resolve_path(args.plan)
    output_path = resolve_path(args.output)

    if output_path.exists() and not args.overwrite:
        raise FileExistsError(
            f"{output_path} 已存在；如需覆盖请添加 --overwrite"
        )

    plan_bytes = plan_path.read_bytes()
    plan_sha256 = hashlib.sha256(plan_bytes).hexdigest()
    plan = json.loads(plan_bytes.decode("utf-8"))
    joint_path = plan["joint_path"]
    target_xyz_mm = plan.get("target_xyz_mm")
    if not isinstance(target_xyz_mm, list) or len(target_xyz_mm) != 3:
        raise ValueError("计划缺少3维target_xyz_mm")
    target_xy_mm = [float(target_xyz_mm[0]), float(target_xyz_mm[1])]

    if len(joint_path) < 2:
        raise ValueError("规划文件至少需要两个关节路点")

    checker = CollisionChecker("gripper")

    # 兼容S1 SDK CollisionChecker构造函数将model覆盖为None的问题。
    if checker.model is None:
        checker._load_model(gripper=True)

    if checker.model is None or checker.data is None:
        raise RuntimeError("MuJoCo碰撞模型加载失败")

    kinematics = Kinematics(verbose=True)
    sample_count = 0
    hard_limit_ok = True
    minimum_margin_deg = float("inf")

    tcp_min = [float("inf")] * 3
    tcp_max = [float("-inf")] * 3

    active_first_occurrence = {}
    excluded_contact_samples = 0
    floor_contact_samples = 0
    joint_violations = []
    maximum_descent_lateral_mm = 0.0
    descent_lateral_first_violation = None

    for segment_index, (previous, current) in enumerate(
        zip(joint_path, joint_path[1:])
    ):
        segment_name = (
            f"{previous['name']}->{current['name']}"
        )
        previous_name = str(previous["name"]).lower()
        current_name = str(current["name"]).lower()
        is_descent_segment = (
            previous_name in {"hover", "standoff"}
            or previous_name.startswith("descent_")
        ) and (
            current_name == "grasp"
            or current_name.startswith("descent_")
        )

        for local_index, (alpha, q) in enumerate(
            interpolate(
                previous["q"],
                current["q"],
                args.step_rad,
            )
        ):
            # 避免相邻两段重复计算中间路点。
            if segment_index > 0 and local_index == 0:
                continue

            sample_count += 1

            point_hard_ok, margins_deg = joint_status(q)
            point_minimum_margin = min(margins_deg)

            minimum_margin_deg = min(
                minimum_margin_deg,
                point_minimum_margin,
            )

            if not point_hard_ok:
                hard_limit_ok = False
                joint_violations.append({
                    "segment": segment_name,
                    "alpha": alpha,
                    "q": q,
                    "margins_deg": margins_deg,
                })

            tcp = kinematics.fk(q)
            tcp_mm = [1000.0 * value for value in tcp[:3]]

            for axis in range(3):
                tcp_min[axis] = min(tcp_min[axis], tcp_mm[axis])
                tcp_max[axis] = max(tcp_max[axis], tcp_mm[axis])

            if is_descent_segment:
                lateral_mm = math.hypot(
                    tcp_mm[0] - target_xy_mm[0],
                    tcp_mm[1] - target_xy_mm[1],
                )
                maximum_descent_lateral_mm = max(
                    maximum_descent_lateral_mm, lateral_mm
                )
                if (
                    lateral_mm > args.max_descent_lateral_mm
                    and descent_lateral_first_violation is None
                ):
                    descent_lateral_first_violation = {
                        "segment": segment_name,
                        "alpha": alpha,
                        "tcp_mm": tcp_mm,
                        "lateral_mm": lateral_mm,
                    }

            active, excluded, floor = collision_at(checker, q)

            if excluded:
                excluded_contact_samples += 1
            if floor:
                floor_contact_samples += 1

            for pair in active:
                key = " <-> ".join(pair)

                if key not in active_first_occurrence:
                    active_first_occurrence[key] = {
                        "pair": list(pair),
                        "segment": segment_name,
                        "alpha": alpha,
                        "q": q,
                        "tcp_mm": tcp_mm,
                    }

    margin_ok = (
        minimum_margin_deg >= args.min_joint_margin_deg
    )
    height_ok = tcp_min[2] >= args.min_tcp_z_mm
    self_collision_ok = not active_first_occurrence
    descent_lateral_ok = descent_lateral_first_violation is None

    passed = (
        hard_limit_ok
        and margin_ok
        and height_ok
        and self_collision_ok
        and descent_lateral_ok
    )

    report = {
        "schema_version": 2,
        "status": (
            "OFFLINE_MODEL_PASS"
            if passed
            else "OFFLINE_MODEL_FAIL"
        ),
        "warning": (
            "仅检查SDK自碰撞模型；不包含真实桌面、物块、"
            "线缆、夹具和人员。"
        ),
        "source_plan": str(plan_path),
        "source_plan_sha256": plan_sha256,
        "sample_step_rad": args.step_rad,
        "sample_count": sample_count,
        "hard_limit_ok": hard_limit_ok,
        "minimum_joint_margin_deg": minimum_margin_deg,
        "required_joint_margin_deg": (
            args.min_joint_margin_deg
        ),
        "tcp_min_mm": tcp_min,
        "tcp_max_mm": tcp_max,
        "required_min_tcp_z_mm": args.min_tcp_z_mm,
        "height_ok": height_ok,
        "self_collision_ok": self_collision_ok,
        "descent_target_xy_mm": target_xy_mm,
        "maximum_descent_lateral_mm": maximum_descent_lateral_mm,
        "required_max_descent_lateral_mm": args.max_descent_lateral_mm,
        "descent_lateral_ok": descent_lateral_ok,
        "descent_lateral_first_violation": descent_lateral_first_violation,
        "active_collisions": list(
            active_first_occurrence.values()
        ),
        "excluded_contact_samples": excluded_contact_samples,
        "floor_contact_samples": floor_contact_samples,
        "joint_violations": joint_violations,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("OFFLINE_MODEL_ONLY：未访问串口、未控制机械臂。")
    print("SAMPLE_COUNT =", sample_count)
    print("HARD_LIMIT_OK =", hard_limit_ok)
    print(
        "MINIMUM_JOINT_MARGIN_DEG =",
        round(minimum_margin_deg, 3),
    )
    print(
        "TCP_X_RANGE_MM =",
        [round(tcp_min[0], 2), round(tcp_max[0], 2)],
    )
    print(
        "TCP_Y_RANGE_MM =",
        [round(tcp_min[1], 2), round(tcp_max[1], 2)],
    )
    print(
        "TCP_Z_RANGE_MM =",
        [round(tcp_min[2], 2), round(tcp_max[2], 2)],
    )
    print(
        "ACTIVE_COLLISION_PAIR_COUNT =",
        len(active_first_occurrence),
    )
    print(
        "EXCLUDED_CONTACT_SAMPLE_COUNT =",
        excluded_contact_samples,
    )
    print(
        "FLOOR_CONTACT_SAMPLE_COUNT =",
        floor_contact_samples,
    )
    print(
        "MAXIMUM_DESCENT_LATERAL_MM =",
        round(maximum_descent_lateral_mm, 3),
    )
    print("DESCENT_LATERAL_OK =", descent_lateral_ok)

    for collision in active_first_occurrence.values():
        print(
            "COLLISION:",
            collision["segment"],
            f"alpha={collision['alpha']:.3f}",
            collision["pair"],
        )

    print("CHECK_RESULT =", report["status"])
    print("SOURCE_PLAN_SHA256 =", plan_sha256)
    print("REPORT_SAVED =", output_path)
    print(
        "EXTERNAL_ENVIRONMENT_NOT_CHECKED："
        "即使PASS也禁止直接高速执行。"
    )

    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
