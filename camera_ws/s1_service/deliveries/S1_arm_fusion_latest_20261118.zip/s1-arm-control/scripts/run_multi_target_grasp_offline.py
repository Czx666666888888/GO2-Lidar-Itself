#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline-only multi-target RGB-D detection, planning, and target ranking."""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.arm import joint_path_motion_duration_s  # noqa: E402
from s1_control.visual_target import (  # noqa: E402
    derive_visual_grasp_targets,
    file_sha256,
    load_visual_grasp_calibration,
)
from scripts.run_visual_adaptive_grasp import (  # noqa: E402
    DEFAULT_CALIBRATION,
    DEFAULT_J6_V_MAX_RAD_S,
    DEFAULT_V_MAX_RAD_S,
    build_planning_commands,
    resolve_output_root,
    resolve_project_path,
    run_stage,
    validated_run_id,
    write_json,
)


DEFAULT_OUTPUT_ROOT = "data/multi_target_grasp_runs"


def estimate_outbound_plan_cost(
    plan: dict,
    *,
    v_max_rad_s: float,
    j6_v_max_rad_s: float,
    motion_profile: str,
) -> dict:
    """Estimate the same two continuous outbound motions used by execution."""
    joint_path = plan.get("joint_path")
    if not isinstance(joint_path, list) or len(joint_path) < 3:
        raise ValueError("plan joint_path must contain ready, hover and grasp")
    names = [str(waypoint.get("name")) for waypoint in joint_path]
    if names[0] != "ready" or "hover" not in names or names[-1] != "grasp":
        raise ValueError("plan route must be ready -> ... -> hover -> ... -> grasp")
    q_path = []
    for name, waypoint in zip(names, joint_path):
        q = [float(value) for value in waypoint.get("q", [])]
        if len(q) != 6 or not all(math.isfinite(value) for value in q):
            raise ValueError(f"waypoint {name} must contain 6 finite joints")
        q_path.append(q)

    hover_index = names.index("hover")
    transit_path = q_path[: hover_index + 1]
    descent_path = q_path[hover_index:]
    transit_duration_s = joint_path_motion_duration_s(
        transit_path,
        v_max_rad_s,
        j6_v_max_rad_s,
        motion_profile,
    )
    descent_duration_s = joint_path_motion_duration_s(
        descent_path,
        v_max_rad_s,
        j6_v_max_rad_s,
        motion_profile,
    )
    total_j6_travel_rad = sum(
        abs(after[5] - before[5])
        for before, after in zip(q_path, q_path[1:])
    )
    return {
        "estimated_outbound_duration_s": (
            float(transit_duration_s + descent_duration_s)
        ),
        "estimated_transit_duration_s": float(transit_duration_s),
        "estimated_descent_duration_s": float(descent_duration_s),
        "total_j6_travel_rad": float(total_j6_travel_rad),
    }


def target_selection_key(candidate: dict) -> tuple:
    return (
        float(candidate["estimated_outbound_duration_s"]),
        float(candidate["total_j6_travel_rad"]),
        -float(candidate["confidence_score"]),
        str(candidate["target_id"]),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "多目标RGB-D离线评估：逐目标绑定属性、转换基座坐标、"
            "规划与碰撞检查后排序；绝不连接S1串口"
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--live-capture", action="store_true")
    source.add_argument("--replay-npz")
    parser.add_argument("--run-id")
    parser.add_argument("--output-root", default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--calibration", default=DEFAULT_CALIBRATION)
    parser.add_argument(
        "--v-max-rad-s", type=float, default=DEFAULT_V_MAX_RAD_S
    )
    parser.add_argument(
        "--j6-v-max-rad-s", type=float, default=DEFAULT_J6_V_MAX_RAD_S
    )
    parser.add_argument("--no-preview", action="store_true")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    for name, value in (
        ("v-max-rad-s", args.v_max_rad_s),
        ("j6-v-max-rad-s", args.j6_v_max_rad_s),
    ):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"--{name}必须是大于0的有限数")

    calibration = load_visual_grasp_calibration(
        args.calibration,
        root=PROJECT_ROOT,
        verify_bindings=True,
        verbose=True,
    )
    calibration_record = calibration.record
    raw_run_id = args.run_id or time.strftime("multi_target_%Y%m%d-%H%M%S")
    run_id = validated_run_id(raw_run_id)
    run_dir = resolve_output_root(args.output_root) / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    manifest_path = run_dir / "manifest.json"
    capture_path = run_dir / "capture.npz"
    detection_path = run_dir / "detection.json"
    preview_path = run_dir / "detection.png"
    targets_path = run_dir / "targets_base.json"
    selection_path = run_dir / "target_selection.json"
    manifest = {
        "schema_version": 1,
        "run_id": run_id,
        "status": "STARTED",
        "mode": "LIVE_CAPTURE" if args.live_capture else "OFFLINE_REPLAY",
        "hardware_execution_allowed": False,
        "v_max_rad_s": float(args.v_max_rad_s),
        "j6_v_max_rad_s": float(args.j6_v_max_rad_s),
        "calibration": str(calibration.path),
        "calibration_sha256": file_sha256(calibration.path),
        "targets": [],
    }
    write_json(manifest_path, manifest)

    try:
        from demo_grasp.capture_rgbd import capture_aligned_rgbd, save_capture
        from demo_grasp.detect_science_target_rgbd import (
            detect_capture,
            load_capture,
            load_config,
            save_preview,
            save_result,
        )

        if args.live_capture:
            capture_settings = calibration_record["capture"]
            capture = capture_aligned_rgbd(
                serial=str(calibration_record["camera_serial"]),
                width=int(capture_settings["width"]),
                height=int(capture_settings["height"]),
                fps=int(capture_settings["fps"]),
                warmup_frames=int(capture_settings["warmup_frames"]),
                depth_frames=int(capture_settings["depth_frames"]),
                timeout_ms=int(capture_settings["timeout_ms"]),
                min_valid_depth_ratio=float(
                    capture_settings["minimum_valid_depth_ratio"]
                ),
                max_frame_interval_ms=float(
                    capture_settings["maximum_frame_interval_ms"]
                ),
            )
            save_capture(
                capture,
                capture_path,
                write_preview=not args.no_preview,
            )
            if capture["metadata"].get("quality_pass") is not True:
                raise RuntimeError("RGB-D采集质量门控未通过")
        else:
            capture_path = resolve_project_path(args.replay_npz)
            if not capture_path.is_file():
                raise FileNotFoundError(f"重放RGB-D不存在: {capture_path}")

        replay = load_capture(capture_path)
        if replay["metadata"].get("quality_pass") is not True:
            raise RuntimeError("RGB-D源数据质量门控未通过")
        vision_config, vision_config_path = load_config(
            calibration.binding_paths["vision_config"]
        )
        detection = detect_capture(replay, vision_config)
        detection["config_path"] = str(vision_config_path)
        save_result(detection, detection_path)
        if not args.no_preview:
            save_preview(replay["rgb"], detection, preview_path)
        if int(detection.get("accepted_candidate_count", 0)) < 1:
            raise RuntimeError(f"没有可用目标: {detection.get('status')}")

        targets_record = derive_visual_grasp_targets(
            detection,
            calibration,
            replay["metadata"],
            source_detection=detection_path,
            source_capture=capture_path,
        )
        write_json(targets_path, targets_record)
        if not targets_record["targets"]:
            raise RuntimeError("所有视觉目标均未通过基座工作空间与标定门控")

        motion_profile = str(
            calibration_record["execution"]["motion_profile"]
        )
        feasible = []
        evaluations = []
        for target_record in targets_record["targets"]:
            target_id = str(target_record["source_target_id"])
            target_dir = run_dir / "targets" / target_id
            target_dir.mkdir(parents=True, exist_ok=False)
            target_path = target_dir / "target_base.json"
            hover_plan_path = target_dir / "hover_plan.json"
            grasp_plan_path = target_dir / "grasp_plan.json"
            collision_report_path = target_dir / "collision_report.json"
            write_json(target_path, target_record)

            evaluation = {
                "target_id": target_id,
                "component_id": int(target_record["source_component_id"]),
                "confidence_score": float(
                    target_record["visual_target"]["confidence_score"]
                ),
                "target_base_xy_mm": target_record["visual_target"][
                    "corrected_target_base_xy_mm"
                ],
                "status": "PLANNING",
                "stages": [],
            }
            commands = build_planning_commands(
                sys.executable,
                target_path,
                hover_plan_path,
                grasp_plan_path,
                collision_report_path,
                target_record,
                calibration_record,
                v_max_rad_s=args.v_max_rad_s,
                j6_v_max_rad_s=args.j6_v_max_rad_s,
            )
            failed = False
            for stage, command in commands:
                scoped_stage = f"{target_id}/{stage}"
                return_code = run_stage(scoped_stage, command)
                evaluation["stages"].append({
                    "name": stage,
                    "return_code": return_code,
                })
                if return_code != 0:
                    evaluation["status"] = "PLAN_OR_COLLISION_REJECTED"
                    failed = True
                    break
            if failed:
                evaluations.append(evaluation)
                continue

            plan = json.loads(grasp_plan_path.read_text(encoding="utf-8"))
            collision = json.loads(
                collision_report_path.read_text(encoding="utf-8")
            )
            if collision.get("status") != "OFFLINE_MODEL_PASS":
                evaluation["status"] = "COLLISION_REPORT_NOT_PASS"
                evaluations.append(evaluation)
                continue
            cost = estimate_outbound_plan_cost(
                plan,
                v_max_rad_s=args.v_max_rad_s,
                j6_v_max_rad_s=args.j6_v_max_rad_s,
                motion_profile=motion_profile,
            )
            evaluation.update(cost)
            evaluation.update({
                "status": "FEASIBLE",
                "minimum_joint_margin_deg": float(
                    collision["minimum_joint_margin_deg"]
                ),
                "target_record": str(target_path),
                "grasp_plan": str(grasp_plan_path),
                "collision_report": str(collision_report_path),
                "grasp_plan_sha256": file_sha256(grasp_plan_path),
                "collision_report_sha256": file_sha256(
                    collision_report_path
                ),
            })
            feasible.append(evaluation)
            evaluations.append(evaluation)

        if not feasible:
            raise RuntimeError("没有目标同时通过IK规划和离线碰撞检查")
        feasible.sort(key=target_selection_key)
        selected = feasible[0]
        selection = {
            "schema_version": 1,
            "status": "OFFLINE_TARGET_SELECTED",
            "hardware_execution_allowed": False,
            "selection_order": [
                "estimated_outbound_duration_s",
                "total_j6_travel_rad",
                "negative_confidence_score",
                "target_id",
            ],
            "selected_target_id": selected["target_id"],
            "selected_target": selected,
            "evaluations": evaluations,
        }
        write_json(selection_path, selection)
        manifest["status"] = "OFFLINE_TARGET_SELECTED"
        manifest["detection_status"] = detection["status"]
        manifest["detected_target_count"] = int(
            detection["accepted_candidate_count"]
        )
        manifest["base_frame_target_count"] = int(
            targets_record["base_frame_target_count"]
        )
        manifest["selected_target_id"] = selected["target_id"]
        manifest["targets"] = evaluations
        manifest["artifacts"] = {
            "capture": str(capture_path),
            "detection": str(detection_path),
            "targets_base": str(targets_path),
            "selection": str(selection_path),
        }
        write_json(manifest_path, manifest)

        print("MULTI_TARGET_COUNT =", len(evaluations))
        for evaluation in sorted(
            feasible, key=target_selection_key
        ):
            print(
                "TARGET_EVALUATION =",
                evaluation["target_id"],
                f"xy={evaluation['target_base_xy_mm']}",
                f"duration={evaluation['estimated_outbound_duration_s']:.3f}s",
                f"j6_travel={evaluation['total_j6_travel_rad']:.3f}rad",
                f"confidence={evaluation['confidence_score']:.3f}",
            )
        print("SELECTED_TARGET_ID =", selected["target_id"])
        print("MULTI_TARGET_OFFLINE_READY =", run_dir)
        print("OFFLINE_ONLY：未访问S1串口，禁止直接执行所选计划。")
        return 0
    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["error"] = f"{type(exc).__name__}: {exc}"
        write_json(manifest_path, manifest)
        print("MULTI_TARGET_PIPELINE_FAILED =", manifest["error"])
        print("MANIFEST =", manifest_path)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
