#!/usr/bin/env python3
"""Offline solver for S1 wrist-mounted D455 eye-in-hand calibration."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.hand_eye import (
    fixed_target_residuals,
    invert_transform,
    refine_hand_eye,
    rotation_angle_deg,
    sample_motion_diversity,
    solve_hand_eye,
    validate_transform,
)


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "eye_in_hand_calibration.json"
DEFAULT_OUTPUT = PROJECT_ROOT / "calibration" / "eye_in_hand_camera_candidate.json"
EXPECTED_PNP_PROJECTION_MODEL = "librealsense_deprojected_normalized_rays"


def resolve_path(value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporary.replace(path)


def load_samples(session_dir: Path, config_path: Path, config: dict) -> list[dict]:
    manifest_path = session_dir / "session_manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"missing session manifest: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    config_hash = file_sha256(config_path)
    if manifest.get("config_sha256") != config_hash:
        raise RuntimeError("session manifest does not match the current configuration")

    samples = []
    expected_serial = str(config["camera_serial"])
    reference_K = None
    for path in sorted(session_dir.glob("sample_*.json")):
        record = json.loads(path.read_text(encoding="utf-8"))
        if record.get("mode") != "eye_in_hand_sample":
            raise ValueError(f"unexpected sample mode in {path}")
        if record.get("config_sha256") != config_hash:
            raise RuntimeError(f"configuration hash mismatch in {path}")
        camera = record["camera"]
        if str(camera.get("serial")) != expected_serial:
            raise RuntimeError(f"camera serial mismatch in {path}")
        K = np.asarray(camera["K"], dtype=np.float64)
        if K.shape != (3, 3) or not np.isfinite(K).all():
            raise ValueError(f"invalid camera matrix in {path}")
        if reference_K is None:
            reference_K = K
        elif not np.allclose(K, reference_K, atol=1e-9):
            raise RuntimeError(f"camera intrinsics changed within session at {path}")

        base_flange = validate_transform(
            record["T_base_flange"], f"{path.name}.T_base_flange"
        )
        camera_target = validate_transform(
            record["observation"]["T_camera_target"],
            f"{path.name}.T_camera_target",
        )
        projection_model = record["observation"]["metrics"].get(
            "pnp_projection_model"
        )
        expected_projection_model = config.get("pnp_projection_model")
        if expected_projection_model != EXPECTED_PNP_PROJECTION_MODEL:
            raise RuntimeError(
                "configuration does not require the validated RealSense projection model"
            )
        if projection_model != expected_projection_model:
            raise RuntimeError(
                f"PnP projection model mismatch in {path}: {projection_model!r}"
            )
        reprojection = float(
            record["observation"]["metrics"]["reprojection_rms_px"]
        )
        if not math.isfinite(reprojection):
            raise ValueError(f"non-finite reprojection error in {path}")
        samples.append(
            {
                "path": path,
                "record": record,
                "T_base_flange": base_flange,
                "T_camera_target": camera_target,
                "reprojection_rms_px": reprojection,
            }
        )
    return samples


def load_training_samples(
    session_dirs: list[Path], config_path: Path, config: dict
) -> list[dict]:
    """Load one or more capture sessions with duplicate/intrinsic guards."""
    if not session_dirs:
        raise ValueError("at least one training session is required")

    samples = []
    seen_paths = set()
    seen_hashes = {}
    reference_K = None
    for session_dir in session_dirs:
        resolved_session = session_dir.resolve()
        if resolved_session in seen_paths:
            raise ValueError(f"duplicate training session: {resolved_session}")
        seen_paths.add(resolved_session)
        for sample in load_samples(resolved_session, config_path, config):
            digest = file_sha256(sample["path"])
            if digest in seen_hashes:
                raise RuntimeError(
                    "duplicate calibration sample content: "
                    f"{sample['path']} matches {seen_hashes[digest]}"
                )
            seen_hashes[digest] = sample["path"]
            K = np.asarray(sample["record"]["camera"]["K"], dtype=np.float64)
            if reference_K is None:
                reference_K = K
            elif not np.allclose(K, reference_K, atol=1e-9):
                raise RuntimeError(
                    f"camera intrinsics changed across sessions at {sample['path']}"
                )
            sample["session"] = resolved_session
            sample["sha256"] = digest
            samples.append(sample)
    return samples


def quality_failures(
    config: dict,
    samples: list[dict],
    diversity: dict,
    best: dict | None,
) -> list[str]:
    quality = config["solve_quality"]
    reasons = []
    if len(samples) < int(quality["minimum_samples"]):
        reasons.append(
            f"sample_count={len(samples)} < minimum={quality['minimum_samples']}"
        )
    if diversity["maximum_pairwise_rotation_deg"] < float(
        quality["minimum_max_pairwise_rotation_deg"]
    ):
        reasons.append(
            "maximum_pairwise_rotation_deg="
            f"{diversity['maximum_pairwise_rotation_deg']:.3f} is insufficient"
        )
    if diversity["maximum_pairwise_translation_mm"] < float(
        quality["minimum_max_pairwise_translation_mm"]
    ):
        reasons.append(
            "maximum_pairwise_translation_mm="
            f"{diversity['maximum_pairwise_translation_mm']:.3f} is insufficient"
        )
    if diversity["informative_rotation_pair_count"] < int(
        quality["minimum_informative_rotation_pairs"]
    ):
        reasons.append(
            "informative_rotation_pair_count="
            f"{diversity['informative_rotation_pair_count']} is insufficient"
        )
    if best is None:
        reasons.append("all OpenCV hand-eye methods failed")
        return reasons

    summary = best["summary"]
    comparisons = (
        ("translation_rms_mm", "maximum_translation_rms_mm"),
        ("translation_max_mm", "maximum_translation_max_mm"),
        ("rotation_rms_deg", "maximum_rotation_rms_deg"),
        ("rotation_max_deg", "maximum_rotation_max_deg"),
    )
    for metric_name, limit_name in comparisons:
        value = float(summary[metric_name])
        limit = float(quality[limit_name])
        if value > limit:
            reasons.append(f"{metric_name}={value:.4f} > {limit_name}={limit:.4f}")

    maximum_offset = float(quality["maximum_flange_camera_translation_m"])
    offset = float(np.linalg.norm(np.asarray(best["T_flange_camera"])[:3, 3]))
    if offset > maximum_offset:
        reasons.append(
            f"flange_camera_translation_m={offset:.4f} exceeds plausible {maximum_offset:.4f}"
        )
    return reasons


def method_consensus(method_results: list[dict], selected: dict) -> list[dict]:
    selected_transform = np.asarray(selected["T_flange_camera"], dtype=np.float64)
    comparisons = []
    for result in method_results:
        transform = np.asarray(result["T_flange_camera"], dtype=np.float64)
        delta = invert_transform(selected_transform) @ transform
        comparisons.append(
            {
                "method": result["method"],
                "translation_difference_mm": 1000.0
                * float(np.linalg.norm(delta[:3, 3])),
                "rotation_difference_deg": rotation_angle_deg(delta[:3, :3]),
            }
        )
    return comparisons


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="离线求解S1腕部D455的T_flange_camera；不会访问任何硬件"
    )
    parser.add_argument(
        "--session",
        action="append",
        required=True,
        help="采集会话目录；可重复传入以联合求解，顺序会写入来源记录",
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument(
        "--report",
        help="求解报告路径；多会话时建议显式指定，默认写入首个会话",
    )
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--refinement-rotation-weight-m-per-rad", type=float, default=0.5
    )
    parser.add_argument("--refinement-max-iterations", type=int, default=60)
    parser.add_argument("--refinement-max-delta-mm", type=float, default=50.0)
    parser.add_argument("--refinement-max-delta-deg", type=float, default=5.0)
    args = parser.parse_args(argv)

    if (
        not math.isfinite(args.refinement_rotation_weight_m_per_rad)
        or args.refinement_rotation_weight_m_per_rad <= 0.0
    ):
        raise ValueError("refinement rotation weight must be positive and finite")
    if args.refinement_max_iterations < 1:
        raise ValueError("refinement max iterations must be positive")
    if (
        not math.isfinite(args.refinement_max_delta_mm)
        or args.refinement_max_delta_mm <= 0.0
    ):
        raise ValueError("refinement max delta mm must be positive and finite")
    if (
        not math.isfinite(args.refinement_max_delta_deg)
        or args.refinement_max_delta_deg <= 0.0
    ):
        raise ValueError("refinement max delta deg must be positive and finite")

    import cv2

    if not hasattr(cv2, "calibrateHandEye"):
        raise RuntimeError(
            "当前OpenCV没有calibrateHandEye；请先 conda activate S1-calib"
        )

    config_path = resolve_path(args.config)
    session_dirs = [resolve_path(value) for value in args.session]
    output_path = resolve_path(args.output)
    report_path = (
        resolve_path(args.report)
        if args.report
        else session_dirs[0] / "solve_report.json"
    )
    if output_path.exists() and not args.overwrite:
        raise FileExistsError(f"{output_path} already exists; pass --overwrite to replace")

    config = json.loads(config_path.read_text(encoding="utf-8"))
    samples = load_training_samples(session_dirs, config_path, config)
    base_flange = [sample["T_base_flange"] for sample in samples]
    camera_target = [sample["T_camera_target"] for sample in samples]
    diversity = sample_motion_diversity(base_flange)

    print("OFFLINE_ONLY = True")
    print("OPENCV =", cv2.__version__)
    print("SESSIONS =", [str(path) for path in session_dirs])
    print("SAMPLE_COUNT =", len(samples))
    print("MOTION_DIVERSITY =", diversity)
    if samples:
        print(
            "REPROJECTION_RMS_PX max/median =",
            round(max(item["reprojection_rms_px"] for item in samples), 4),
            round(float(np.median([item["reprojection_rms_px"] for item in samples])), 4),
        )

    method_results = []
    method_failures = []
    for method in config["candidate_methods"]:
        try:
            closed_form_flange_camera = solve_hand_eye(
                base_flange, camera_target, method_name=method
            )
            closed_form_base_target, closed_form_details, closed_form_summary = (
                fixed_target_residuals(
                    base_flange, camera_target, closed_form_flange_camera
                )
            )
            flange_camera = closed_form_flange_camera
            base_target = closed_form_base_target
            details = closed_form_details
            summary = closed_form_summary
            refinement = {
                "accepted": False,
                "rejection_reasons": [],
            }
            try:
                (
                    refined_flange_camera,
                    optimizer_base_target,
                    refinement_diagnostics,
                ) = refine_hand_eye(
                    base_flange,
                    camera_target,
                    closed_form_flange_camera,
                    rotation_weight_m_per_rad=(
                        args.refinement_rotation_weight_m_per_rad
                    ),
                    maximum_iterations=args.refinement_max_iterations,
                )
                (
                    refined_base_target,
                    refined_details,
                    refined_summary,
                ) = fixed_target_residuals(
                    base_flange, camera_target, refined_flange_camera
                )
                refinement_delta = (
                    invert_transform(closed_form_flange_camera)
                    @ refined_flange_camera
                )
                delta_translation_mm = 1000.0 * float(
                    np.linalg.norm(refinement_delta[:3, 3])
                )
                delta_rotation_deg = rotation_angle_deg(
                    refinement_delta[:3, :3]
                )
                rejection_reasons = []
                if not refinement_diagnostics["converged"]:
                    rejection_reasons.append("optimizer_not_converged")
                if refinement_diagnostics["objective_improvement_m2"] <= 0.0:
                    rejection_reasons.append("objective_not_improved")
                if refined_summary.score >= closed_form_summary.score:
                    rejection_reasons.append("quality_score_not_improved")
                if delta_translation_mm > args.refinement_max_delta_mm:
                    rejection_reasons.append("translation_delta_exceeds_guard")
                if delta_rotation_deg > args.refinement_max_delta_deg:
                    rejection_reasons.append("rotation_delta_exceeds_guard")
                refinement = {
                    **refinement_diagnostics,
                    "accepted": not rejection_reasons,
                    "rejection_reasons": rejection_reasons,
                    "delta_from_closed_form_translation_mm": delta_translation_mm,
                    "delta_from_closed_form_rotation_deg": delta_rotation_deg,
                    "optimizer_T_base_target": optimizer_base_target.tolist(),
                    "evaluated_summary": refined_summary.to_dict(),
                }
                if refinement["accepted"]:
                    flange_camera = refined_flange_camera
                    base_target = refined_base_target
                    details = refined_details
                    summary = refined_summary
            except Exception as refinement_error:
                refinement = {
                    "accepted": False,
                    "rejection_reasons": ["optimizer_exception"],
                    "error": repr(refinement_error),
                }
            result = {
                "method": method,
                "solution_stage": (
                    "joint_nonlinear_refinement"
                    if refinement["accepted"]
                    else "closed_form"
                ),
                "T_flange_camera": flange_camera.tolist(),
                "T_base_target_estimate": base_target.tolist(),
                "summary": summary.to_dict(),
                "closed_form": {
                    "T_flange_camera": closed_form_flange_camera.tolist(),
                    "T_base_target_estimate": closed_form_base_target.tolist(),
                    "summary": closed_form_summary.to_dict(),
                },
                "refinement": refinement,
                "per_sample_residuals": [
                    {
                        "sample": str(
                            samples[item["sample_index"]]["path"].relative_to(
                                PROJECT_ROOT
                            )
                        ),
                        **item,
                    }
                    for item in details
                ],
            }
            method_results.append(result)
            print(
                f"METHOD {method}: "
                f"closed={closed_form_summary.translation_rms_mm:.3f}mm/"
                f"{closed_form_summary.rotation_rms_deg:.3f}deg "
                f"final={summary.translation_rms_mm:.3f}mm/"
                f"{summary.rotation_rms_deg:.3f}deg "
                f"stage={result['solution_stage']}"
            )
        except Exception as exc:
            method_failures.append({"method": method, "error": repr(exc)})
            print(f"METHOD {method}: FAILED {exc!r}")

    method_results.sort(key=lambda item: float(item["summary"]["score"]))
    selection_score_tolerance = 1.0e-6
    selected = None
    if method_results:
        best_final_score = float(method_results[0]["summary"]["score"])
        numerically_tied = [
            item
            for item in method_results
            if float(item["summary"]["score"])
            <= best_final_score + selection_score_tolerance
        ]
        method_order = {
            name: index for index, name in enumerate(config["candidate_methods"])
        }
        selected = min(
            numerically_tied,
            key=lambda item: (
                float(item["closed_form"]["summary"]["score"]),
                method_order[item["method"]],
            ),
        )
    failures = quality_failures(config, samples, diversity, selected)
    consensus = method_consensus(method_results, selected) if selected else []
    report = {
        "schema_version": 1,
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "pass" if not failures else "fail",
        "opencv_version": cv2.__version__,
        "session": str(session_dirs[0].relative_to(PROJECT_ROOT)),
        "sessions": [
            str(path.relative_to(PROJECT_ROOT)) for path in session_dirs
        ],
        "config": str(config_path.relative_to(PROJECT_ROOT)),
        "config_sha256": file_sha256(config_path),
        "sample_count": len(samples),
        "samples": [
            {
                "path": str(item["path"].relative_to(PROJECT_ROOT)),
                "sha256": item["sha256"],
                "reprojection_rms_px": item["reprojection_rms_px"],
            }
            for item in samples
        ],
        "motion_diversity": diversity,
        "method_results": method_results,
        "method_failures": method_failures,
        "selected_method": selected["method"] if selected else None,
        "selection_policy": {
            "final_score_tolerance": selection_score_tolerance,
            "tie_breaker": "lowest_closed_form_score_then_configured_method_order",
        },
        "method_consensus_to_selected": consensus,
        "refinement_settings": {
            "rotation_weight_m_per_rad": (
                args.refinement_rotation_weight_m_per_rad
            ),
            "maximum_iterations": args.refinement_max_iterations,
            "maximum_delta_mm": args.refinement_max_delta_mm,
            "maximum_delta_deg": args.refinement_max_delta_deg,
        },
        "quality_failures": failures,
    }
    write_json(report_path, report)
    print("REPORT_SAVED =", report_path)
    if failures:
        for reason in failures:
            print("QUALITY_REJECT =", reason)
        print("CALIBRATION_RESULT = REJECTED")
        return 2

    candidate = {
        "_README": (
            "Eye-in-hand candidate only; runtime use is forbidden until physical "
            "validation. T_parent_child maps child coordinates into parent."
        ),
        "schema_version": 1,
        "name": output_path.stem,
        "quantity": "T_flange_camera",
        "description": "camera coordinates -> S1 zero-offset flange coordinates",
        "value_T_flange_camera": selected["T_flange_camera"],
        "runtime_formula": "T_base_camera(q)=T_base_flange(q)@T_flange_camera",
        "unit": "meter",
        "status": "candidate_pending_physical_validation",
        "runtime_approved": False,
        "valid_only_if": (
            "D455, wrist bracket, gripper body and fasteners remain rigidly unchanged"
        ),
        "recalibrate_when": (
            "camera/bracket/gripper is moved, loosened, disassembled, impacted or replaced"
        ),
        "provenance": {
            "generated_at": report["generated_at"],
            "method": selected["method"],
            "selection_policy": report["selection_policy"],
            "solution_stage": selected["solution_stage"],
            "closed_form": selected["closed_form"],
            "refinement": selected["refinement"],
            "opencv_version": cv2.__version__,
            "camera_serial": str(config["camera_serial"]),
            "checkerboard": config["checkerboard"],
            "session": report["session"],
            "sessions": report["sessions"],
            "samples": report["samples"],
            "config_sha256": report["config_sha256"],
            "sample_count": len(samples),
            "motion_diversity": diversity,
            "fixed_target_residual_summary": selected["summary"],
            "T_base_target_estimate": selected["T_base_target_estimate"],
            "method_consensus_to_selected": consensus,
        },
    }
    write_json(output_path, candidate)
    print("SELECTED_METHOD =", selected["method"])
    print("SELECTED_STAGE =", selected["solution_stage"])
    print("SELECTED_RESIDUAL_SUMMARY =", selected["summary"])
    print("T_FLANGE_CAMERA =", selected["T_flange_camera"])
    print("CANDIDATE_SAVED =", output_path)
    print("CALIBRATION_RESULT = CANDIDATE_PENDING_PHYSICAL_VALIDATION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
