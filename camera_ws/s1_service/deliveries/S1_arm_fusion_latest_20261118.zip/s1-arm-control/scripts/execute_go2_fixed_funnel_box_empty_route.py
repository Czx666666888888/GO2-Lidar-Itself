#!/usr/bin/env python3
"""Supervised empty-gripper commissioning of the fixed funnel-box route."""
from __future__ import annotations

import argparse
import copy
from datetime import datetime
import json
import math
from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from s1_control.arm import Arm, SafetyLimits  # noqa: E402
from s1_control.go2_deployment import (  # noqa: E402
    file_sha256,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)
from s1_control.tilt_gravity import (  # noqa: E402
    UrdfGravityModel,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record  # noqa: E402
from scripts.execute_go2_observe_deployment import (  # noqa: E402
    guarded_hold,
    wait_for_valid_feedback,
    write_json,
)


DEFAULT_PLAN = PROJECT_ROOT / "data" / "plans" / "go2_fixed_funnel_box_place_plan_v1.json"
DEFAULT_REPORT = PROJECT_ROOT / "data" / "plans" / "go2_fixed_funnel_box_place_collision_report_v1.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "go2_box_empty_route_runs"


def resolve_project_path(raw: str | Path) -> Path:
    from s1_control.project_paths import project_path
    return project_path(raw, PROJECT_ROOT)


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def verify_box_artifacts(plan_path: Path, report_path: Path) -> tuple[dict, dict, dict, dict]:
    plan = load_json(plan_path)
    report = load_json(report_path)
    if plan.get("mode") != "go2_fixed_funnel_box_place":
        raise ValueError("box plan mode is incompatible")
    if plan.get("status") != "candidate_pending_empty_route_physical_validation":
        raise ValueError("box plan is not awaiting empty-route physical validation")
    if report.get("status") != "OFFLINE_BOX_ROUTE_PASS":
        raise ValueError("box collision report did not pass")
    if report.get("source_plan_sha256") != file_sha256(plan_path):
        raise ValueError("box collision report is not bound to the current plan")
    required_report_flags = (
        "self_collision_ok",
        "floor_contact_ok",
        "box_payload_envelope_ok",
        "tilt_torque_cap_ok",
    )
    failed_flags = [name for name in required_report_flags if report.get(name) is not True]
    if failed_flags:
        raise ValueError(f"box report safety flags failed: {failed_flags}")
    payload_model = report.get("payload_gravity_model", {})
    if not math.isclose(float(payload_model.get("mass_kg", -1.0)), 0.3, abs_tol=1e-9):
        raise ValueError("box report is not based on the 300g rated payload")
    if not math.isclose(
        float(payload_model.get("dynamic_design_factor", -1.0)), 2.0, abs_tol=1e-9
    ):
        raise ValueError("box report is not based on the 2.0 dynamic design factor")
    if payload_model.get("passed") is not True:
        raise ValueError("payload design envelope did not pass")

    bindings = plan.get("bindings", {})
    bound_paths = {}
    for name in (
        "box_calibration",
        "deployment_plan",
        "deployment_collision_report",
        "mount_config",
    ):
        path = resolve_project_path(bindings[name])
        expected = str(bindings[f"{name}_sha256"])
        if file_sha256(path) != expected:
            raise ValueError(f"bound artifact hash mismatch: {name}")
        bound_paths[name] = path

    box_calibration = load_json(bound_paths["box_calibration"])
    if float(box_calibration["payload"]["maximum_target_mass_g"]) != 300.0:
        raise ValueError("box calibration payload is not 300g")
    deployment_plan = load_json(bound_paths["deployment_plan"])
    mount_record = load_json(bound_paths["mount_config"])
    verify_bound_report(
        bound_paths["deployment_plan"],
        bound_paths["deployment_collision_report"],
        bound_paths["mount_config"],
    )
    return plan, report, deployment_plan, mount_record


def route_names(route: list[dict]) -> list[str]:
    return [str(item["name"]) for item in route]


def validate_route_shape(route: list[dict]) -> None:
    expected = [
        "rear_ready",
        "box_transport_reference_01",
        "box_transport_reference_02",
        "box_transport_reference",
        "box_opening_hover",
        "box_release",
    ]
    if route_names(route) != expected:
        raise ValueError("box route does not match the commissioned route shape")
    for item in route:
        q = item.get("q")
        if not isinstance(q, list) or len(q) != 6:
            raise ValueError(f"invalid route waypoint: {item.get('name')}")
        if not all(math.isfinite(float(value)) for value in q):
            raise ValueError(f"non-finite route waypoint: {item.get('name')}")


def mount_record_with_lower_route_scale(
    mount_record: dict,
    route_scale: float,
) -> tuple[dict, dict | None]:
    """Authorize a lower-torque route-local working threshold without mutating mount data."""
    scale = float(route_scale)
    approved = sorted(
        float(value)
        for value in mount_record.get("diagnostic", {}).get(
            "allowed_scale_steps", []
        )
    )
    if not approved:
        raise ValueError("mount record has no approved compensation scale steps")
    if any(math.isclose(scale, value, abs_tol=1e-9) for value in approved):
        return copy.deepcopy(mount_record), None
    if not 0.0 < scale < approved[0]:
        raise ValueError(
            "route-specific compensation scale must be lower than the minimum "
            "mount-approved step"
        )
    scoped = copy.deepcopy(mount_record)
    scoped["diagnostic"]["allowed_scale_steps"] = [scale, *approved]
    override = {
        "scope": "go2_fixed_funnel_box_route_only",
        "value": scale,
        "source_mount_minimum_approved_step": approved[0],
        "torque_direction": "reduced_only",
        "global_mount_record_modified": False,
    }
    return scoped, override


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Empty-gripper Go2 fixed funnel-box route commissioning"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--plan", default=str(DEFAULT_PLAN))
    parser.add_argument("--collision-report", default=str(DEFAULT_REPORT))
    parser.add_argument("--run-id")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)

    plan_path = resolve_project_path(args.plan)
    report_path = resolve_project_path(args.collision_report)
    plan, report, deployment_plan, mount_record = verify_box_artifacts(
        plan_path, report_path
    )
    route = plan["route"]
    validate_route_shape(route)
    deployment_motion = deployment_plan["motion"]
    box_motion = plan["motion"]
    rear_ready_q = [float(value) for value in route[0]["q"]]
    zero_reference_q = [
        float(value) for value in deployment_plan["joint_path"][0]["q"]
    ]
    tilt_scale = float(box_motion["tilt_compensation_scale"])
    if not math.isclose(tilt_scale, 0.20, abs_tol=1e-9):
        raise ValueError("first empty route requires the commissioned 0.20 tilt scale")
    commander_mount_record, route_scale_override = mount_record_with_lower_route_scale(
        mount_record, tilt_scale
    )
    expected_override = box_motion.get(
        "tilt_compensation_working_threshold_override"
    )
    if route_scale_override is not None and not isinstance(expected_override, dict):
        raise ValueError("plan does not declare its route-specific tilt-scale override")

    print("MODE = GO2_FIXED_FUNNEL_BOX_EMPTY_ROUTE_ROUND_TRIP")
    print("PLAN_FILE =", plan_path)
    print("PLAN_SHA256 =", file_sha256(plan_path))
    print("COLLISION_REPORT =", report_path)
    print("COLLISION_REPORT_VERIFIED = True")
    print("RATED_PAYLOAD_MASS_G =", plan["payload"]["maximum_mass_g"])
    print("DYNAMIC_DESIGN_EQUIVALENT_MASS_G =", plan["payload"]["dynamic_design_equivalent_mass_g"])
    print("TILT_COMPENSATION_SCALE =", tilt_scale)
    print("TILT_SCALE_ROUTE_OVERRIDE =", route_scale_override)
    print("ROUTE = zero_reference ->", " -> ".join(route_names(route)), "-> zero_reference")
    print("FORBIDDEN = D455, gripper-close, gripper-open, payload, autonomous-release")

    if not args.execute:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("RESULT = OFFLINE_PREFLIGHT_OK")
        return 0

    print("\n首次实机只验证空夹爪运动路径，不启动D455、不控制夹爪、不得携带物体。")
    print("必须满足：Go2保持最终趴下构型；机械臂从常红机械零位开始；盒体已固定。")
    print("全路径有软支撑但不阻挡运动；人员、线束和临时物品均在路径外。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("RESULT = CANCELLED_BEFORE_CONNECTION")
        return 2

    run_id = args.run_id or datetime.now().strftime("box_empty_%Y%m%d-%H%M%S")
    run_dir = DEFAULT_OUTPUT_ROOT / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": "go2_fixed_funnel_box_empty_route_round_trip",
        "status": "started",
        "plan": str(plan_path),
        "plan_sha256": file_sha256(plan_path),
        "collision_report": str(report_path),
        "collision_report_sha256": file_sha256(report_path),
        "rated_payload_mass_g": 300.0,
        "actual_payload_mass_g": 0.0,
        "tilt_scale_route_override": route_scale_override,
    }
    write_json(log_path, log)

    limits = SafetyLimits(
        hz=float(deployment_motion["hz"]),
        v_max_rad_s=float(box_motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(box_motion["j6_v_max_rad_s"]),
        motion_profile=str(box_motion["profile"]),
        max_track_err_rad=float(deployment_motion["maximum_track_error_rad"]),
        max_speed_rad_s=float(deployment_motion["maximum_measured_speed_rad_s"]),
        max_temp_c=float(deployment_motion["maximum_temperature_c"]),
        max_joint_delta_rad=float(box_motion["maximum_waypoint_delta_rad"]),
        settle_seconds=float(deployment_motion["settle_seconds"]),
    )
    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    arm = None
    result = "ABORTED"
    try:
        arm = Arm(
            dev=args.dev,
            end_effector="gripper",
            limits=limits,
            check_collision=False,
        )
        commander = commander_from_mount_record(
            tilt_model, commander_mount_record, tilt_scale
        )
        arm.set_position_commander(commander)
        start_q, temperature, readiness = wait_for_valid_feedback(
            arm, limits.max_temp_c
        )
        print("STARTUP_FEEDBACK_READY =", readiness["ready"])
        print("START_Q =", [round(value, 6) for value in start_q])
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        violations = start_window_violations(
            start_q, deployment_plan["start_safe_windows_rad"]
        )
        print("START_SAFE_WINDOW_OK =", not violations)
        for violation in violations:
            print("START_WINDOW_VIOLATION =", violation)
        start_delta = max_joint_delta(start_q, rear_ready_q)
        print("START_TO_REAR_READY_DELTA_RAD =", round(start_delta, 6))
        live_precheck_ok = not violations and start_delta <= limits.max_joint_delta_rad
        print("LIVE_PRECHECK_OK =", live_precheck_ok)
        log.update({
            "start_q": start_q,
            "temperature_c": temperature,
            "startup_readiness": readiness,
            "start_window_violations": violations,
            "start_to_rear_ready_delta_rad": start_delta,
        })
        write_json(log_path, log)
        if not live_precheck_ok:
            result = "LIVE_PRECHECK_REJECTED"
            return 2

        forward_waypoints = [(item["name"], item["q"]) for item in route]
        arm.preflight(forward_waypoints, start_q, collision_report_verified=True)
        print("300g/2倍动态载荷报告只用于离线设计；本次夹爪必须为空。")
        print("若连接后出现持续motor timeout、Go2姿态变化或线束绷紧，禁止继续。")
        if input("再次确认空夹爪且实际净空满足，输入 d：").strip().lower() != "d":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        arm.enable()
        print("ENABLED_WITH_TILT_COMPENSATION scale =", f"{tilt_scale:.2f}")
        guarded_hold(arm, start_q, 0.5, "initial_hold")

        print("BOX_ROUTE_PHASE = zero_to_rear_ready")
        fault = arm.move_waypoints([start_q, rear_ready_q], "zero_to_rear_ready")
        if fault:
            raise RuntimeError(fault)
        print("到达: rear_ready")

        print("BOX_ROUTE_PHASE = rear_ready_to_transport")
        fault = arm.move_waypoints(
            [[float(v) for v in item["q"]] for item in route[:4]],
            "rear_ready_to_transport",
        )
        if fault:
            raise RuntimeError(fault)
        print("到达: box_transport_reference")

        print("BOX_ROUTE_PHASE = transport_to_opening_hover")
        fault = arm.move_waypoints(
            [[float(v) for v in item["q"]] for item in route[3:5]],
            "transport_to_opening_hover",
        )
        if fault:
            raise RuntimeError(fault)
        print("到达: box_opening_hover")

        print("BOX_ROUTE_PHASE = opening_hover_to_release")
        fault = arm.move_waypoints(
            [[float(v) for v in item["q"]] for item in route[4:6]],
            "opening_hover_to_release",
        )
        if fault:
            raise RuntimeError(fault)
        print("到达: box_release")
        print("GRIPPER_COMMAND_EXECUTED = False")
        guarded_hold(arm, route[-1]["q"], 1.0, "empty_release_hold")

        print("BOX_ROUTE_PHASE = release_to_rear_ready")
        reverse_q = [[float(v) for v in item["q"]] for item in reversed(route)]
        fault = arm.move_waypoints(reverse_q, "release_to_rear_ready")
        if fault:
            raise RuntimeError(fault)
        print("到达: rear_ready")

        print("BOX_ROUTE_PHASE = rear_ready_to_zero")
        fault = arm.move_waypoints([rear_ready_q, start_q], "rear_ready_to_zero")
        if fault:
            raise RuntimeError(fault)
        print("到达: start")
        result = "EMPTY_BOX_ROUTE_ROUND_TRIP_DONE"
        return 0
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        print(result)
        return 1
    finally:
        if arm is not None:
            try:
                arm.disable()
            except Exception as exc:
                print("DISABLE_WARNING =", repr(exc))
        log["status"] = result
        write_json(log_path, log)
        print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
        print("LOG_SAVED =", log_path)
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
