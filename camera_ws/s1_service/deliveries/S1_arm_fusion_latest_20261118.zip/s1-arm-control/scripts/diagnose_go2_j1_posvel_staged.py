#!/usr/bin/env python3
"""Fast supervised J1 response test through the vendor position-velocity path.

The checked sequence is rear_ready -> +5deg -> +15deg -> +30deg and back.
Each larger excursion is authorized only after the preceding endpoint passes.
No camera, gripper command, descent, lift, or box motion is permitted.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import statistics
import sys
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SCRIPT_DIR, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from execute_go2_observe_deployment import (
    guarded_hold,
    resolve_project_path,
    wait_for_valid_feedback,
    write_json,
)
from S1_SDK.hardware.collision import CollisionChecker
from s1_control.arm import Arm, SafetyLimits, motion_duration_s, motion_profile_progress
from s1_control.go2_deployment import (
    file_sha256,
    interpolate_segment,
    joint_hard_limit_violations,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import UrdfGravityModel, locate_official_gripper_urdf
from s1_control.tilt_motion import commander_from_mount_record


DEFAULT_PLAN = (
    PROJECT_ROOT
    / "data/plans/go2_crouch_right_observe_deployment_nocw_metalbracket_highturn050_v2.json"
)
DEFAULT_REPORT = (
    PROJECT_ROOT
    / "data/plans/go2_crouch_right_observe_collision_report_nocw_metalbracket_highturn050_v2.json"
)
DEFAULT_COMMANDER_MOUNT = (
    PROJECT_ROOT
    / "config/go2_crouch_mount_nocw_metalbracket_dual_white_light_v2.json"
)
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data/go2_j1_posvel_diagnostics"
J1_INDEX = 0
STAGE_DEGREES = (5.0, 15.0, 30.0)


class StageResponseError(RuntimeError):
    """Expected bounded position response was not observed."""


class StageSafetyError(RuntimeError):
    """A direction, drift, speed, temperature, or envelope guard fired."""


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="Go2趴下构型：J1官方位置速度通道5/15/30度分级响应诊断"
    )
    ap.add_argument("--dev", default="/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0")
    ap.add_argument("--plan", default=str(DEFAULT_PLAN))
    ap.add_argument("--collision-report", default=str(DEFAULT_REPORT))
    ap.add_argument("--commander-mount", default=str(DEFAULT_COMMANDER_MOUNT))
    ap.add_argument("--trajectory-speed-rad-s", type=float, default=0.10)
    ap.add_argument("--endpoint-tolerance-rad", type=float, default=0.015)
    ap.add_argument("--other-joint-drift-rad", type=float, default=0.025)
    ap.add_argument("--run-id")
    ap.add_argument("--execute", action="store_true")
    return ap


def validate_args(args) -> None:
    if not 0.04 <= args.trajectory_speed_rad_s <= 0.12:
        raise ValueError("trajectory speed must be within [0.04, 0.12]rad/s")
    if not 0.005 <= args.endpoint_tolerance_rad <= 0.02:
        raise ValueError("endpoint tolerance must be within [0.005, 0.02]rad")
    if not 0.01 <= args.other_joint_drift_rad <= 0.03:
        raise ValueError("other-joint drift limit must be within [0.01, 0.03]rad")


def official_posvel_commander(arm, target_q):
    """Use the official SDK path; its internal velocity vector is vendor-default 10."""
    return arm._arm.joint_control([float(value) for value in target_q])


def stage_targets(rear_ready) -> list[tuple[str, list[float]]]:
    base = [float(value) for value in rear_ready]
    result = []
    for degrees in STAGE_DEGREES:
        target = list(base)
        target[J1_INDEX] += math.radians(degrees)
        result.append((f"outbound_{degrees:g}deg", target))
    for degrees in reversed(STAGE_DEGREES[:-1]):
        target = list(base)
        target[J1_INDEX] += math.radians(degrees)
        result.append((f"return_{degrees:g}deg", target))
    result.append(("return_rear_ready", list(base)))
    return result


def check_j1_sweep_collision(rear_ready, maximum_step_rad: float = 0.01) -> int:
    final_q = list(rear_ready)
    final_q[J1_INDEX] += math.radians(STAGE_DEGREES[-1])
    checker = CollisionChecker("gripper")
    sample_count = 0
    for _, q in interpolate_segment(rear_ready, final_q, maximum_step_rad):
        sample_count += 1
        if checker.check_collision(list(q), gripper=True):
            raise RuntimeError(
                f"J1 sweep self-collision at sample {sample_count}, q={q}"
            )
    return sample_count


def predicted_tcp_arc(rear_ready) -> dict:
    final_q = list(rear_ready)
    final_q[J1_INDEX] += math.radians(STAGE_DEGREES[-1])
    kinematics = Kinematics(verbose=False)
    start = kinematics.fk(rear_ready)
    final = kinematics.fk(final_q)
    delta_mm = [1000.0 * (final[index] - start[index]) for index in range(3)]
    return {
        "start_tcp_m": start,
        "final_tcp_m": final,
        "delta_mm": delta_mm,
        "displacement_mm": math.sqrt(sum(value * value for value in delta_mm)),
    }


def _median_tail(samples, count: int = 8) -> list[float]:
    rows = [row["position_q_rad"] for row in samples[-count:]]
    return [statistics.median(row[index] for row in rows) for index in range(6)]


def run_scurve_stage(
    arm,
    q_from,
    q_to,
    rear_ready,
    *,
    label: str,
    speed_rad_s: float,
    endpoint_tolerance_rad: float,
    other_joint_drift_rad: float,
    maximum_temperature_c: float,
) -> dict:
    delta = max(abs(a - b) for a, b in zip(q_from, q_to))
    duration = motion_duration_s(delta, speed_rad_s, "s_curve", minimum_s=0.6)
    samples = []
    started = time.monotonic()
    trajectory_time = 0.0
    temperature = [float(value) for value in arm.get_temp()]
    speed_strikes = 0
    direction = 1.0 if q_to[J1_INDEX] >= q_from[J1_INDEX] else -1.0
    while True:
        cycle_started = time.monotonic()
        u = min(1.0, trajectory_time / duration)
        progress = motion_profile_progress(u, "s_curve")
        target = [
            q_from[index] + progress * (q_to[index] - q_from[index])
            for index in range(6)
        ]
        arm.command_position(target)
        position = [float(value) for value in arm.get_pos()[:6]]
        velocity = [float(value) for value in arm.get_vel()[:6]]
        if len(samples) % 10 == 0:
            temperature = [float(value) for value in arm.get_temp()]
        elapsed = time.monotonic() - started
        row = {
            "elapsed_s": elapsed,
            "trajectory_time_s": trajectory_time,
            "progress": progress,
            "target_q_rad": target,
            "position_q_rad": position,
            "velocity_rad_s": velocity,
            "error_rad": [position[i] - target[i] for i in range(6)],
        }
        samples.append(row)

        peak_speed = max(abs(value) for value in velocity)
        speed_strikes = speed_strikes + 1 if peak_speed > 0.5 else 0
        if speed_strikes >= 3:
            raise StageSafetyError(f"{label}: measured speed >0.5rad/s for 3 samples")
        if max(temperature) > maximum_temperature_c:
            raise StageSafetyError(f"{label}: motor temperature exceeded limit")
        other_drift = max(
            abs(position[index] - rear_ready[index]) for index in range(1, 6)
        )
        if other_drift > other_joint_drift_rad:
            raise StageSafetyError(
                f"{label}: non-J1 drift {other_drift:.5f}rad exceeds limit"
            )
        directed_from_start = direction * (position[J1_INDEX] - q_from[J1_INDEX])
        if directed_from_start < -0.012:
            raise StageSafetyError(f"{label}: J1 moved in the wrong direction")
        lower = min(rear_ready[J1_INDEX], q_to[J1_INDEX]) - 0.02
        upper = max(rear_ready[J1_INDEX], q_to[J1_INDEX]) + 0.02
        if not lower <= position[J1_INDEX] <= upper:
            raise StageSafetyError(f"{label}: J1 left the checked motion envelope")

        if u >= 1.0:
            break
        trajectory_time = min(duration, trajectory_time + arm.dt)
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))

    # Hold the exact endpoint briefly so encoder quantization and stiction do
    # not turn one lucky sample into a pass.
    hold_started = time.monotonic()
    while time.monotonic() - hold_started < 0.35:
        cycle_started = time.monotonic()
        arm.command_position(q_to)
        position = [float(value) for value in arm.get_pos()[:6]]
        velocity = [float(value) for value in arm.get_vel()[:6]]
        samples.append(
            {
                "elapsed_s": time.monotonic() - started,
                "trajectory_time_s": duration,
                "progress": 1.0,
                "target_q_rad": list(q_to),
                "position_q_rad": position,
                "velocity_rad_s": velocity,
                "error_rad": [position[i] - q_to[i] for i in range(6)],
            }
        )
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))

    median_q = _median_tail(samples)
    j1_error = abs(median_q[J1_INDEX] - q_to[J1_INDEX])
    other_drift = max(
        abs(median_q[index] - rear_ready[index]) for index in range(1, 6)
    )
    observed = median_q[J1_INDEX] - rear_ready[J1_INDEX]
    requested = q_to[J1_INDEX] - rear_ready[J1_INDEX]
    ratio = 1.0 if abs(requested) < 1e-9 else observed / requested
    summary = {
        "label": label,
        "planned_duration_s": duration,
        "sample_count": len(samples),
        "target_q_rad": list(q_to),
        "median_q_rad": median_q,
        "j1_endpoint_error_rad": j1_error,
        "other_joint_drift_rad": other_drift,
        "cumulative_j1_response_ratio": ratio,
        "maximum_abs_velocity_rad_s": max(
            abs(value) for sample in samples for value in sample["velocity_rad_s"]
        ),
        "samples": samples,
    }
    if j1_error > endpoint_tolerance_rad:
        raise StageResponseError(
            f"{label}: J1 endpoint error {j1_error:.5f}rad exceeds "
            f"{endpoint_tolerance_rad:.5f}rad"
        )
    if other_drift > other_joint_drift_rad:
        raise StageSafetyError(f"{label}: other-joint endpoint drift is too large")
    return summary


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    validate_args(args)
    plan_path = resolve_project_path(args.plan)
    report_path = resolve_project_path(args.collision_report)
    commander_mount_path = resolve_project_path(args.commander_mount)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    report_mount_path = resolve_project_path(plan["mount_config"])
    report = verify_bound_report(plan_path, report_path, report_mount_path)
    commander_mount = json.loads(commander_mount_path.read_text(encoding="utf-8"))
    waypoints = plan["joint_path"]
    rear_ready = next(
        [float(value) for value in item["q"]]
        for item in waypoints
        if item["name"] == "rear_ready"
    )
    stages = stage_targets(rear_ready)
    for label, target in stages:
        violations = joint_hard_limit_violations(target)
        if violations:
            raise ValueError(f"{label}: " + "; ".join(violations))
    collision_samples = check_j1_sweep_collision(rear_ready)
    arc = predicted_tcp_arc(rear_ready)

    print("MODE = GO2_J1_OFFICIAL_POSVEL_STAGED_RESPONSE")
    print("CAMERA_ACCESS = False")
    print("GRIPPER_COMMANDS = False")
    print("PLAN_FILE =", plan_path)
    print("PLAN_SHA256 =", file_sha256(plan_path))
    print("COLLISION_REPORT =", report_path)
    print("COLLISION_REPORT_VERIFIED = True")
    print("COMMANDER_MOUNT =", commander_mount_path)
    print("COMMANDER_MOUNT_SHA256 =", file_sha256(commander_mount_path))
    print("POSITION_VELOCITY_API = vendor joint_control -> control_pos_vel")
    print("TRAJECTORY_SPEED_RAD_S =", args.trajectory_speed_rad_s)
    print("STAGES_DEG =", list(STAGE_DEGREES))
    print("J1_SWEEP_COLLISION_SAMPLES =", collision_samples)
    print("J1_SWEEP_SELF_COLLISION_OK = True")
    print("PREDICTED_30DEG_TCP_DELTA_MM =", [round(v, 3) for v in arc["delta_mm"]])
    print("PREDICTED_30DEG_TCP_DISPLACEMENT_MM =", round(arc["displacement_mm"], 3))
    print("FORBIDDEN = D455, J6-orientation, descent, gripper, lift, box-place")
    if not args.execute:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("RESULT = OFFLINE_PREFLIGHT_OK")
        return 0

    print("\n本测试自动到rear_ready后，只让J1沿已检查圆弧依次到5°、15°、30°并返回。")
    print("必须满足：Go2趴下且静止；机械臂从常红机械零位开始；全路径有软支撑。")
    print("J1正向圆弧（从零位逆时针朝Go2前侧）至少保留预测位移外加50mm净空。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("RESULT = CANCELLED_BEFORE_CONNECTION")
        return 2

    run_id = args.run_id or datetime.now().strftime("j1_posvel_%Y%m%d-%H%M%S")
    run_dir = DEFAULT_OUTPUT_ROOT / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": "go2_j1_official_posvel_staged_response",
        "status": "STARTED",
        "parameters": {
            "trajectory_speed_rad_s": args.trajectory_speed_rad_s,
            "endpoint_tolerance_rad": args.endpoint_tolerance_rad,
            "other_joint_drift_rad": args.other_joint_drift_rad,
            "stages_deg": list(STAGE_DEGREES),
        },
        "plan": str(plan_path),
        "plan_sha256": file_sha256(plan_path),
        "collision_report": str(report_path),
        "commander_mount": str(commander_mount_path),
        "commander_mount_sha256": file_sha256(commander_mount_path),
        "collision_samples": collision_samples,
        "predicted_tcp_arc": arc,
        "stage_results": [],
    }
    write_json(log_path, log)

    motion = plan["motion"]
    limits = SafetyLimits(
        hz=50.0,
        v_max_rad_s=float(motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(motion["j6_v_max_rad_s"]),
        motion_profile="s_curve",
        max_track_err_rad=float(motion["maximum_track_error_rad"]),
        max_speed_rad_s=0.5,
        max_temp_c=float(motion["maximum_temperature_c"]),
        max_joint_delta_rad=0.9,
        settle_seconds=float(motion["settle_seconds"]),
    )
    arm = None
    result = "ABORTED"
    posvel_started = False
    current_target = None
    try:
        arm = Arm(
            dev=args.dev,
            end_effector="gripper",
            limits=limits,
            check_collision=False,
        )
        tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
        tilt_commander = commander_from_mount_record(
            tilt_model, commander_mount, 0.25
        )
        arm.set_position_commander(tilt_commander)
        start_q, temperature, readiness = wait_for_valid_feedback(
            arm, limits.max_temp_c
        )
        print("STARTUP_FEEDBACK_READY =", readiness["ready"])
        print("START_Q =", [round(value, 6) for value in start_q])
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        violations = start_window_violations(start_q, plan["start_safe_windows_rad"])
        start_delta = max_joint_delta(start_q, rear_ready)
        print("START_SAFE_WINDOW_OK =", not violations)
        for violation in violations:
            print("START_WINDOW_VIOLATION =", violation)
        print("START_TO_REAR_READY_DELTA_RAD =", round(start_delta, 6))
        if violations or start_delta > limits.max_joint_delta_rad:
            result = "LIVE_PRECHECK_REJECTED"
            return 2
        arm.preflight(
            [("rear_ready", rear_ready)],
            start_q,
            collision_report_verified=True,
        )
        print("确认J1圆弧净空、软支撑不阻挡且线束有余量，输入 d：")
        if input().strip().lower() != "d":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        arm.enable()
        print("ENABLED_WITH_TILT_COMPENSATION scale = 0.25")
        guarded_hold(arm, start_q, 0.35, "initial_hold")
        fault = arm.move(start_q, rear_ready, "zero_to_rear_ready")
        if fault:
            raise RuntimeError(fault)
        guarded_hold(arm, rear_ready, 0.35, "rear_ready_hold")
        print("REAR_READY_REACHED = True")

        arm.set_position_commander(official_posvel_commander)
        posvel_started = True
        print("CONTROL_MODE_SWITCH = official_position_velocity")
        q_from = list(rear_ready)
        for label, q_to in stages:
            current_target = list(q_to)
            print("J1_STAGE_START =", label)
            stage = run_scurve_stage(
                arm,
                q_from,
                q_to,
                rear_ready,
                label=label,
                speed_rad_s=args.trajectory_speed_rad_s,
                endpoint_tolerance_rad=args.endpoint_tolerance_rad,
                other_joint_drift_rad=args.other_joint_drift_rad,
                maximum_temperature_c=limits.max_temp_c,
            )
            log["stage_results"].append(stage)
            write_json(log_path, log)
            print(
                "J1_STAGE_PASS =",
                label,
                f"endpoint_error={stage['j1_endpoint_error_rad']:.5f}rad",
                f"other_drift={stage['other_joint_drift_rad']:.5f}rad",
            )
            q_from = list(q_to)

        posvel_started = False
        arm.set_position_commander(tilt_commander)
        guarded_hold(arm, rear_ready, 0.35, "tilt_mode_restore_hold")
        print("CONTROL_MODE_RESTORE = tilt_compensated_position")
        fault = arm.move(rear_ready, start_q, "rear_ready_to_zero")
        if fault:
            raise RuntimeError(fault)
        print("RETURN_TO_START_DONE = True")
        result = "J1_POSVEL_STAGED_ROUND_TRIP_DONE"
        return 0
    except StageResponseError as exc:
        result = f"RESPONSE_REJECTED: {exc}"
        print(result)
        # A response rejection is not a runaway. Restore the proven tilted
        # hold at the measured pose, then disable; do not attempt a new path.
        if arm is not None:
            measured = [float(value) for value in arm.get_pos()[:6]]
            arm.set_position_commander(tilt_commander)
            posvel_started = False
            guarded_hold(arm, measured, 0.25, "response_reject_hold")
        return 1
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        print(result)
        return 1
    finally:
        log["status"] = result
        log["posvel_active_at_exit"] = posvel_started
        log["last_commanded_target_q_rad"] = current_target
        if arm is not None:
            try:
                arm.disable()
            except Exception as exc:
                log["disable_error"] = repr(exc)
                print("DISABLE_WARNING =", repr(exc))
        write_json(log_path, log)
        print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
        print("LOG_SAVED =", log_path)
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
