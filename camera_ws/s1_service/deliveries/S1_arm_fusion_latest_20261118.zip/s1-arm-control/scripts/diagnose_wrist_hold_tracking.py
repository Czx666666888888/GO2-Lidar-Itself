#!/usr/bin/env python3
"""Supervised, camera-free S1 hold test for the added wrist payload.

The test captures the current supported pose as its target and repeatedly sends
that exact same target.  It does not plan or command Cartesian/joint motion.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import re
import statistics
import sys
import threading
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.arm import Arm, SafetyLimits
from s1_control.hold_diagnostic import summarize_hold_samples
from s1_control.kinematics import Kinematics
from s1_control.wrist_visual_servo import joint_margin_details


DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "wrist_hold_diagnostics"
RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
DEFAULT_TEACH_GRAVITY_HZ = 50.0
TEACH_MONITOR_PERIOD_S = 0.1
TEACH_LOCK_SAMPLE_COUNT = 15
TEACH_LOCK_SAMPLE_PERIOD_S = 0.02
TEACH_LOCK_MAX_SPAN_RAD = 0.01
STARTUP_FEEDBACK_TIMEOUT_S = 5.0
STARTUP_VALID_SAMPLE_COUNT = 10
STARTUP_SAMPLE_PERIOD_S = 0.05
MINIMUM_PLAUSIBLE_TEMPERATURE_C = 5.0


def finite_vector(values, length: int, label: str) -> list[float]:
    result = [float(value) for value in values]
    if len(result) != length or not all(math.isfinite(value) for value in result):
        raise RuntimeError(f"{label} must contain {length} finite values")
    return result


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="无相机、无轨迹运动的S1腕部载荷同姿态保持诊断"
    )
    ap.add_argument("--dev", default="/dev/ttyUSB0")
    ap.add_argument("--end", default="gripper")
    ap.add_argument("--duration-s", type=float, default=5.0)
    ap.add_argument("--hz", type=float, default=50.0)
    ap.add_argument("--teach-hz", type=float, default=DEFAULT_TEACH_GRAVITY_HZ)
    ap.add_argument("--final-window-s", type=float, default=1.0)
    ap.add_argument("--min-joint-margin-deg", type=float, default=10.0)
    ap.add_argument("--tracking-tolerance-rad", type=float, default=0.01)
    ap.add_argument("--max-track-error-rad", type=float, default=0.05)
    ap.add_argument("--max-temp-c", type=float, default=55.0)
    ap.add_argument("--run-id")
    ap.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    ap.add_argument("--execute", action="store_true")
    return ap


def validate_args(args) -> None:
    positive = {
        "--duration-s": args.duration_s,
        "--hz": args.hz,
        "--teach-hz": args.teach_hz,
        "--final-window-s": args.final_window_s,
        "--tracking-tolerance-rad": args.tracking_tolerance_rad,
        "--max-track-error-rad": args.max_track_error_rad,
        "--max-temp-c": args.max_temp_c,
    }
    for name, value in positive.items():
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be positive and finite")
    if args.duration_s < args.final_window_s:
        raise ValueError("--duration-s must be >= --final-window-s")
    if args.max_track_error_rad <= args.tracking_tolerance_rad:
        raise ValueError(
            "--max-track-error-rad must exceed --tracking-tolerance-rad"
        )
    if not math.isfinite(args.min_joint_margin_deg) or args.min_joint_margin_deg < 0:
        raise ValueError("--min-joint-margin-deg must be finite and non-negative")
    if args.run_id is not None and not RUN_ID_PATTERN.fullmatch(args.run_id):
        raise ValueError("--run-id contains unsupported characters")


def print_plan(args) -> None:
    print("MODE = same-pose-hold-diagnostic")
    print("CAMERA_ACCESS = False")
    print("PLANNED_JOINT_OR_CARTESIAN_MOTION = False")
    print("HOLD_DURATION_S =", args.duration_s)
    print("CONTROL_HZ =", args.hz)
    print("TEACH_GRAVITY_HZ =", args.teach_hz)
    print("MAX_TRACK_ERROR_RAD =", args.max_track_error_rad)
    print("START_MODE = camera-free gravity teaching -> unchanged joint hold")


def validated_live_state(arm, maximum_temperature_c: float):
    position = finite_vector(arm.get_pos(), 7, "position")
    temperature = finite_vector(arm.get_temp(), 7, "temperature")
    if max(temperature) > maximum_temperature_c:
        raise RuntimeError("motor temperature exceeds configured limit")
    return position[:6], temperature


def wait_for_valid_feedback(
    arm,
    maximum_temperature_c: float,
    *,
    timeout_s: float = STARTUP_FEEDBACK_TIMEOUT_S,
    required_consecutive: int = STARTUP_VALID_SAMPLE_COUNT,
    sample_period_s: float = STARTUP_SAMPLE_PERIOD_S,
):
    """Wait until live feedback is initialized and stable enough to trust.

    The SDK can briefly return finite all-zero temperature frames immediately
    after opening the bus.  Joint positions may legitimately be zero, so a
    plausible temperature range is used as the initialization signal.  Several
    consecutive frames are required so one stale frame cannot pass the gate.
    """
    if timeout_s <= 0.0 or required_consecutive <= 0 or sample_period_s < 0.0:
        raise ValueError("invalid startup feedback gate parameters")

    started = time.monotonic()
    valid_rows = []
    attempts = 0
    invalid_samples = 0
    last_invalid_reason = "no samples received"

    while True:
        cycle_started = time.monotonic()
        attempts += 1
        try:
            position = finite_vector(arm.get_pos(), 7, "position")
            velocity = finite_vector(arm.get_vel(), 7, "velocity")
            temperature = finite_vector(arm.get_temp(), 7, "temperature")
            if max(temperature) > maximum_temperature_c:
                raise RuntimeError("motor temperature exceeds configured limit")
            if min(temperature) < MINIMUM_PLAUSIBLE_TEMPERATURE_C:
                raise ValueError(
                    "temperature feedback is not initialized "
                    f"(minimum={min(temperature):.1f}C)"
                )
        except (RuntimeError, ValueError, TypeError) as exc:
            if "exceeds configured limit" in str(exc):
                raise
            valid_rows.clear()
            invalid_samples += 1
            last_invalid_reason = str(exc)
        else:
            valid_rows.append(
                {
                    "position_rad": position[:6],
                    "velocity_rad_s": velocity[:6],
                    "temperature_c": temperature,
                }
            )
            if len(valid_rows) >= required_consecutive:
                break

        elapsed = time.monotonic() - started
        if elapsed >= timeout_s:
            raise RuntimeError(
                "startup feedback not ready after "
                f"{elapsed:.2f}s; last invalid sample: {last_invalid_reason}"
            )
        time.sleep(max(0.0, sample_period_s - (time.monotonic() - cycle_started)))

    position_rows = [row["position_rad"] for row in valid_rows]
    temperature_rows = [row["temperature_c"] for row in valid_rows]
    velocity_rows = [row["velocity_rad_s"] for row in valid_rows]
    median_q = [
        statistics.median(row[joint] for row in position_rows)
        for joint in range(6)
    ]
    median_temperature = [
        statistics.median(row[motor] for row in temperature_rows)
        for motor in range(7)
    ]
    position_spans = [
        max(row[joint] for row in position_rows)
        - min(row[joint] for row in position_rows)
        for joint in range(6)
    ]
    summary = {
        "ready": True,
        "elapsed_s": time.monotonic() - started,
        "attempt_count": attempts,
        "invalid_sample_count": invalid_samples,
        "required_consecutive_samples": required_consecutive,
        "position_span_rad": position_spans,
        "maximum_abs_velocity_rad_s": max(
            abs(value) for row in velocity_rows for value in row
        ),
        "temperature_min_c": min(value for row in temperature_rows for value in row),
        "temperature_max_c": max(value for row in temperature_rows for value in row),
    }
    return median_q, median_temperature, summary


def collect_teach_lock_samples(arm):
    rows = []
    temperature = None
    for _ in range(TEACH_LOCK_SAMPLE_COUNT):
        cycle_started = time.monotonic()
        arm.gravity()
        q, temperature = validated_live_state(arm, arm.limits.max_temp_c)
        rows.append(q)
        time.sleep(
            max(
                0.0,
                TEACH_LOCK_SAMPLE_PERIOD_S - (time.monotonic() - cycle_started),
            )
        )
    median_q = [
        statistics.median(row[joint] for row in rows) for joint in range(6)
    ]
    ranges = [
        max(row[joint] for row in rows) - min(row[joint] for row in rows)
        for joint in range(6)
    ]
    return {
        "median_q_rad": median_q,
        "joint_span_rad": ranges,
        "maximum_span_rad": max(ranges),
        "maximum_span_joint": 1 + max(range(6), key=lambda index: ranges[index]),
        "sample_count": len(rows),
    }, temperature


def teaching_until_locked(
    arm, minimum_joint_margin_deg: float, teach_gravity_hz: float
):
    """Run camera-free gravity teaching and directly hand off to position hold."""
    print("TEACHING_ENABLED：持续托住机械臂；此诊断不启动D455。")
    print("摆到无碰撞高悬停并静止后输入 l；输入 q 取消并失能。")
    while True:
        state = {"command": None, "error": None}

        def read_command():
            try:
                state["command"] = input("TEACH_COMMAND [l/q]: ").strip().lower()
            except BaseException as exc:
                state["error"] = exc

        reader = threading.Thread(
            target=read_command, name="hold_diagnostic_teach_command", daemon=True
        )
        reader.start()
        next_monitor = time.monotonic()
        while reader.is_alive():
            cycle_started = time.monotonic()
            arm.gravity()
            now = time.monotonic()
            if now >= next_monitor:
                validated_live_state(arm, arm.limits.max_temp_c)
                next_monitor = now + TEACH_MONITOR_PERIOD_S
            time.sleep(
                max(
                    0.0,
                    1.0 / teach_gravity_hz - (time.monotonic() - cycle_started),
                )
            )
        reader.join(timeout=0.0)
        if state["error"] is not None:
            raise state["error"]
        if state["command"] == "q":
            return None, None
        if state["command"] != "l":
            print("仅接受 l 或 q；继续重力补偿示教。")
            continue

        summary, temperature = collect_teach_lock_samples(arm)
        if summary["maximum_span_rad"] > TEACH_LOCK_MAX_SPAN_RAD:
            print(
                "LOCK_REJECTED：姿态仍在移动；"
                f"J{summary['maximum_span_joint']} span="
                f"{summary['maximum_span_rad']:.5f}rad > "
                f"{TEACH_LOCK_MAX_SPAN_RAD:.5f}rad。继续示教。"
            )
            continue
        q_lock = list(summary["median_q_rad"])
        margins = joint_margin_details(q_lock)
        minimum_margin = min(item["margin_deg"] for item in margins)
        if minimum_margin < minimum_joint_margin_deg:
            limiting = min(margins, key=lambda item: item["margin_deg"])
            print(
                f"LOCK_REJECTED：J{limiting['joint']} margin="
                f"{minimum_margin:.2f}deg < {minimum_joint_margin_deg:.2f}deg。"
                "继续示教。"
            )
            continue

        # The target is exactly the just-observed pose; no trajectory is made.
        arm._arm.joint_control_mit(list(q_lock))
        record = {
            **summary,
            "temperature_c": temperature,
            "joint_margin_deg": minimum_margin,
            "joint_margin_details": margins,
        }
        print("LOCKED_Q =", [round(value, 6) for value in q_lock])
        print("LOCK_SAMPLE_MAX_SPAN_RAD =", round(summary["maximum_span_rad"], 6))
        print("LOCK_JOINT_MARGIN_DEG =", round(minimum_margin, 3))
        print("LOCKED：已从重力补偿无缝切换到同姿态关节保持。")
        return q_lock, record


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    validate_args(args)
    print_plan(args)
    if not args.execute:
        print("OFFLINE_ONLY：未构造Arm、未访问串口、未使能机械臂。")
        return 0

    print("\n实机条件：机械臂常红，Go2保持趴下且静止；")
    print("示教和锁定期间必须持续人工托住，周围有可靠软支撑。")
    print(
        f"本测试示教锁定后保持同一关节角{args.duration_s:.1f}秒，"
        "不使用D455、不规划任何位移。"
    )
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("CANCELLED_BEFORE_ARM_ACCESS")
        return 1

    run_id = args.run_id or datetime.now().strftime("wrist_hold_%Y%m%d-%H%M%S")
    run_dir = args.output_root.expanduser().resolve() / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    run_dir.mkdir(parents=True)
    output_path = run_dir / "run.json"

    arm = None
    samples = []
    record = {
        "schema_version": 1,
        "mode": "same-pose-hold-diagnostic",
        "run_id": run_id,
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "camera_access": False,
        "planned_motion": False,
        "parameters": vars(args) | {"output_root": str(args.output_root)},
        "result": "STARTED",
    }
    return_code = 1

    try:
        limits = SafetyLimits(
            hz=args.hz,
            v_max_rad_s=0.05,
            max_track_err_rad=args.max_track_error_rad,
            max_speed_rad_s=0.5,
            max_temp_c=args.max_temp_c,
            settle_seconds=0.5,
        )
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=limits,
            check_collision=False,
        )
        connected_q, connected_temperature, startup_feedback = wait_for_valid_feedback(
            arm, args.max_temp_c
        )
        record["startup_feedback"] = startup_feedback
        print("STARTUP_FEEDBACK_READY =", startup_feedback["ready"])
        print("STARTUP_FEEDBACK_ATTEMPTS =", startup_feedback["attempt_count"])
        print(
            "STARTUP_INVALID_SAMPLE_COUNT =",
            startup_feedback["invalid_sample_count"],
        )
        print("CONNECTED_Q =", [round(value, 6) for value in connected_q])
        print(
            "CONNECTED_TEMPERATURE_C =",
            [round(value, 1) for value in connected_temperature],
        )
        if input(
            "确认持续托稳且示教范围无碰撞，输入 e 开启重力补偿示教："
        ).strip().lower() != "e":
            record["result"] = "CANCELLED_BEFORE_TEACHING"
            raise KeyboardInterrupt
        arm.enable()
        arm.gravity()
        q_reference, teach_lock = teaching_until_locked(
            arm, args.min_joint_margin_deg, args.teach_hz
        )
        if q_reference is None:
            record["result"] = "CANCELLED_DURING_TEACHING"
            raise KeyboardInterrupt

        kinematics = Kinematics(verbose=True)
        reference_tcp = finite_vector(kinematics.fk(q_reference), 7, "reference_tcp")
        margins = teach_lock["joint_margin_details"]
        minimum_margin = teach_lock["joint_margin_deg"]
        temperature = finite_vector(arm.get_temp(), 7, "temperature")
        nominal_gravity_reference = finite_vector(
            arm._arm.gravity(return_tau=True), 6, "nominal_gravity_reference"
        )
        record.update(
            {
                "reference_q_rad": q_reference,
                "reference_tcp_xyz_xyzw": reference_tcp,
                "joint_margin_details": margins,
                "minimum_joint_margin_deg": minimum_margin,
                "initial_temperature_c": temperature,
                "nominal_gravity_reference_nm": nominal_gravity_reference,
                "teach_lock": teach_lock,
            }
        )
        print("REFERENCE_Q =", [round(value, 6) for value in q_reference])
        print("REFERENCE_TCP_MM =", [round(1000.0 * value, 3) for value in reference_tcp[:3]])
        print("MINIMUM_JOINT_MARGIN_DEG =", round(minimum_margin, 3))
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        if minimum_margin < args.min_joint_margin_deg:
            raise RuntimeError(
                f"joint margin {minimum_margin:.2f}deg is below "
                f"{args.min_joint_margin_deg:.2f}deg"
            )
        if max(temperature) > args.max_temp_c:
            raise RuntimeError("motor temperature exceeds configured limit")

        print("ENABLED_AND_LOCKED：立即开始同姿态保持诊断；仍需保持软支撑。")
        started = time.monotonic()
        cycle_index = 0
        cached_torque = [math.nan] * 6
        cached_temperature = temperature
        while True:
            cycle_started = time.monotonic()
            elapsed = cycle_started - started
            arm._arm.joint_control_mit(list(q_reference))
            position = finite_vector(arm.get_pos(), 7, "position")[:6]
            velocity = finite_vector(arm.get_vel(), 7, "velocity")[:6]
            torque_fresh = cycle_index % 5 == 0
            if torque_fresh:
                cached_torque = finite_vector(arm.get_tau(), 7, "torque")[:6]
                cached_temperature = finite_vector(
                    arm.get_temp(), 7, "temperature"
                )
            sample = {
                "elapsed_s": elapsed,
                "position_rad": position,
                "velocity_rad_s": velocity,
                "torque_nm": list(cached_torque),
                "torque_fresh": torque_fresh,
                "temperature_c": list(cached_temperature),
            }
            samples.append(sample)
            bad = arm.guard(
                position,
                velocity,
                cached_temperature,
                q_reference,
                settling=elapsed < limits.settle_seconds,
            )
            if bad:
                raise RuntimeError(f"hold guard rejected: {bad}")
            if elapsed >= args.duration_s:
                break
            cycle_index += 1
            time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))

        nominal_gravity_final = finite_vector(
            arm._arm.gravity(return_tau=True), 6, "nominal_gravity_final"
        )
        summary = summarize_hold_samples(
            q_reference,
            reference_tcp,
            samples,
            kinematics.fk,
            final_window_s=args.final_window_s,
            tracking_tolerance_rad=args.tracking_tolerance_rad,
        )
        summary["nominal_gravity_reference_nm"] = nominal_gravity_reference
        summary["nominal_gravity_final_nm"] = nominal_gravity_final
        feedback = summary["feedback_torque_median_nm"]
        summary["feedback_minus_nominal_gravity_nm"] = (
            [value - gravity for value, gravity in zip(feedback, nominal_gravity_final)]
            if feedback is not None
            else None
        )
        record["samples"] = samples
        record["summary"] = summary
        record["result"] = "HOLD_DIAGNOSTIC_DONE"
        print("FINAL_ERROR_RAD =", [round(value, 6) for value in summary["final_error_rad"]])
        print("FINAL_ERROR_DEG =", [round(value, 3) for value in summary["final_error_deg"]])
        print("TCP_DELTA_MM =", [round(value, 3) for value in summary["tcp_delta_mm"]])
        print("FINAL_WINDOW_RANGE_RAD =", [round(value, 6) for value in summary["final_window_range_rad"]])
        print("FINAL_WINDOW_SLOPE_RAD_S =", [round(value, 6) for value in summary["final_window_slope_rad_s"]])
        print("DIAGNOSTIC_STATUS =", summary["status"])
        if summary["status"] == "STEADY_OFFSET_DETECTED":
            print("INTERPRETATION：检测到稳定偏差；这支持载荷/控制偏差假设，但尚不能单独证明原因。")
        elif summary["status"] == "NOT_SETTLED":
            print("INTERPRETATION：5秒末仍未稳定，需检查慢响应或通信/控制波动。")
        else:
            print("INTERPRETATION：同姿态保持满足当前误差门槛。")
        return_code = 0
    except KeyboardInterrupt:
        if record["result"] == "STARTED":
            record["result"] = "CANCELLED"
        print("CANCELLED")
    except Exception as exc:
        record["result"] = f"ABORTED: {type(exc).__name__}: {exc}"
        record["error"] = repr(exc)
        record["samples"] = samples
        print(record["result"])
    finally:
        if arm is not None:
            try:
                arm.disable()
                print("DISABLED：电机应为常红；继续托稳直到机械臂落在支撑上。")
            except Exception as exc:
                record["disable_error"] = repr(exc)
                print("DISABLE_FAILED:", repr(exc))
        record["finished_at"] = datetime.now().astimezone().isoformat(
            timespec="seconds"
        )
        output_path.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print("LOG_SAVED =", output_path)
        print("RESULT =", record["result"])
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
