#!/usr/bin/env python3
"""Capture checkerboard observations for an S1 wrist-mounted D455.

The capture process never imports or opens the S1 arm interface.  During
gravity-compensated teaching, the vendor ``teaching.py`` process is the sole
owner of the serial bus and continuously appends joint states to a CSV file.
This process reads recent, timestamped CSV rows around each image burst and
rejects stale, stopped, or non-static pose data.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import time

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.hand_eye import pose_xyz_quat_to_transform


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "eye_in_hand_calibration.json"
DATA_ROOT = PROJECT_ROOT / "data" / "eye_in_hand_calibration"
DEFAULT_TEACHING_CSV = (
    Path.home()
    / "thirdparty"
    / "S1_SDK_V2-official"
    / "examples"
    / "python"
    / "data.csv"
)
EXPECTED_PNP_PROJECTION_MODEL = "librealsense_deprojected_normalized_rays"
POSE_SOURCE_TYPES = (
    "official-teaching-csv",
    "tilt-locked-csv",
)
POSE_SOURCE_STATES = {"teaching", "locking", "locked", "unlocking"}


def resolve_path(value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def read_config(path: Path) -> dict:
    record = json.loads(path.read_text(encoding="utf-8"))
    if record.get("calibration_mode") != "eye_in_hand":
        raise ValueError("configuration calibration_mode must be eye_in_hand")
    board = record["checkerboard"]
    if int(board["inner_corners_columns"]) < 3 or int(board["inner_corners_rows"]) < 3:
        raise ValueError("checkerboard needs at least 3x3 inner corners")
    if not math.isfinite(float(board["square_size_m"])) or float(board["square_size_m"]) <= 0:
        raise ValueError("checkerboard square_size_m must be positive")
    if record.get("pnp_projection_model") != EXPECTED_PNP_PROJECTION_MODEL:
        raise ValueError(
            "configuration must use librealsense-deprojected normalized rays"
        )
    return record


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    temporary.replace(path)


def checkerboard_object_points(board: dict) -> np.ndarray:
    columns = int(board["inner_corners_columns"])
    rows = int(board["inner_corners_rows"])
    square = float(board["square_size_m"])
    points = np.zeros((columns * rows, 3), dtype=np.float64)
    grid = np.mgrid[0:columns, 0:rows].T.reshape(-1, 2)
    points[:, :2] = grid * square
    return points


class D455ColorSession:
    def __init__(self, config: dict):
        self.config = config
        self.pipeline = None
        self.rs = None
        self.profile = None
        self.camera_info = None
        self.K = None
        self.distortion = None
        self.intrinsics = None

    def start(self) -> None:
        import pyrealsense2 as rs

        requested_serial = str(self.config["camera_serial"])
        context = rs.context()
        devices = list(context.query_devices())
        matching = [
            device
            for device in devices
            if device.get_info(rs.camera_info.serial_number) == requested_serial
        ]
        if len(matching) != 1:
            available = [
                device.get_info(rs.camera_info.serial_number) for device in devices
            ]
            raise RuntimeError(
                f"D455 serial {requested_serial} not uniquely available; available={available}"
            )

        stream = self.config["color_stream"]
        pipeline = rs.pipeline(context)
        rs_config = rs.config()
        rs_config.enable_device(requested_serial)
        rs_config.enable_stream(
            rs.stream.color,
            int(stream["width"]),
            int(stream["height"]),
            rs.format.rgb8,
            int(stream["fps"]),
        )
        try:
            profile = pipeline.start(rs_config)
        except Exception as exc:
            raise RuntimeError(
                "failed to start D455; close realsense-viewer and check VMware USB passthrough"
            ) from exc

        self.pipeline = pipeline
        self.rs = rs
        self.profile = profile
        device = profile.get_device()
        color_profile = profile.get_stream(rs.stream.color).as_video_stream_profile()
        intrinsics = color_profile.get_intrinsics()
        self.K = np.array(
            [
                [intrinsics.fx, 0.0, intrinsics.ppx],
                [0.0, intrinsics.fy, intrinsics.ppy],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float64,
        )
        self.distortion = np.asarray(intrinsics.coeffs, dtype=np.float64)
        self.intrinsics = intrinsics
        self.camera_info = {
            "name": device.get_info(rs.camera_info.name),
            "serial": device.get_info(rs.camera_info.serial_number),
            "firmware": device.get_info(rs.camera_info.firmware_version),
            "usb_type": device.get_info(rs.camera_info.usb_type_descriptor),
            "distortion_model": str(intrinsics.model),
            "K": self.K.tolist(),
            "distortion_coefficients": self.distortion.tolist(),
        }
        for _ in range(int(stream["warmup_frames"])):
            pipeline.wait_for_frames(5000)

    def capture_candidates(self) -> list[dict]:
        if self.pipeline is None or self.rs is None:
            raise RuntimeError("camera session has not started")
        stream = self.config["color_stream"]
        quality = self.config["capture_quality"]
        fresh = int(stream["fresh_frames_before_capture"])
        for _ in range(fresh):
            self.pipeline.wait_for_frames(5000)

        frames = []
        for _ in range(int(quality["frames_to_search"])):
            frame_set = self.pipeline.wait_for_frames(5000)
            color_frame = frame_set.get_color_frame()
            if not color_frame:
                continue
            frames.append(
                {
                    "rgb": np.asanyarray(color_frame.get_data()).copy(),
                    "frame_timestamp_ms": float(color_frame.get_timestamp()),
                    "host_monotonic_s": time.monotonic(),
                }
            )
        if not frames:
            raise RuntimeError("D455 returned no color frames")
        return frames

    def stop(self) -> None:
        if self.pipeline is not None:
            self.pipeline.stop()
            self.pipeline = None

    def normalize_pixels(self, pixel_points: np.ndarray) -> np.ndarray:
        """Use librealsense's inverse model to turn pixels into camera rays."""
        if self.rs is None or self.intrinsics is None:
            raise RuntimeError("camera intrinsics are unavailable")
        normalized = []
        for u, v in np.asarray(pixel_points, dtype=np.float64).reshape(-1, 2):
            ray = self.rs.rs2_deproject_pixel_to_point(
                self.intrinsics, [float(u), float(v)], 1.0
            )
            if len(ray) != 3 or not np.isfinite(ray).all() or abs(ray[2]) < 1e-12:
                raise RuntimeError(f"invalid RealSense deprojected ray: {ray}")
            normalized.append([float(ray[0] / ray[2]), float(ray[1] / ray[2])])
        return np.asarray(normalized, dtype=np.float64)


def detect_checkerboard(
    rgb: np.ndarray,
    K: np.ndarray,
    distortion: np.ndarray,
    config: dict,
    normalize_pixels=None,
) -> dict:
    import cv2

    board = config["checkerboard"]
    quality = config["capture_quality"]
    columns = int(board["inner_corners_columns"])
    rows = int(board["inner_corners_rows"])
    pattern_size = (columns, rows)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    flags = 0
    for name in (
        "CALIB_CB_NORMALIZE_IMAGE",
        "CALIB_CB_EXHAUSTIVE",
        "CALIB_CB_ACCURACY",
    ):
        flags |= int(getattr(cv2, name, 0))
    found, corners = cv2.findChessboardCornersSB(gray, pattern_size, flags=flags)
    annotated = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    if not found or corners is None:
        return {
            "detected": False,
            "accepted": False,
            "reasons": [f"checkerboard {columns}x{rows} inner corners not detected"],
            "annotated_bgr": annotated,
        }

    corners = np.asarray(corners, dtype=np.float64).reshape(-1, 1, 2)
    # OpenCV 4.12's drawing helper requires CV_32FC2 even though solvePnP
    # accepts (and benefits from retaining) float64 corner coordinates.
    cv2.drawChessboardCorners(
        annotated, pattern_size, corners.astype(np.float32), True
    )
    object_points = checkerboard_object_points(board)
    if normalize_pixels is not None:
        image_points = normalize_pixels(corners.reshape(-1, 2)).reshape(-1, 1, 2)
        pnp_K = np.eye(3, dtype=np.float64)
        pnp_distortion = None
        pnp_model = str(config["pnp_projection_model"])
    else:
        image_points = corners
        pnp_K = K
        pnp_distortion = distortion
        pnp_model = "opencv_pixel_distortion"
    success, rvec, tvec = cv2.solvePnP(
        object_points,
        image_points,
        pnp_K,
        pnp_distortion,
        flags=cv2.SOLVEPNP_ITERATIVE,
    )
    if not success:
        return {
            "detected": True,
            "accepted": False,
            "reasons": ["solvePnP failed"],
            "annotated_bgr": annotated,
        }

    rotation, _ = cv2.Rodrigues(rvec)
    camera_target = np.eye(4, dtype=np.float64)
    camera_target[:3, :3] = rotation
    camera_target[:3, 3] = np.asarray(tvec).reshape(3)
    if normalize_pixels is not None:
        camera_points = (
            rotation @ object_points.T + np.asarray(tvec, dtype=np.float64).reshape(3, 1)
        ).T
        if np.any(camera_points[:, 2] <= 0.0):
            raise RuntimeError("PnP produced checkerboard points behind the camera")
        projected_normalized = camera_points[:, :2] / camera_points[:, 2:3]
        observed_normalized = image_points.reshape(-1, 2)
        residual = (projected_normalized - observed_normalized) * np.array(
            [K[0, 0], K[1, 1]], dtype=np.float64
        )
    else:
        projected, _ = cv2.projectPoints(
            object_points, rvec, tvec, K, distortion
        )
        residual = projected.reshape(-1, 2) - corners.reshape(-1, 2)
    reprojection_rms = float(np.sqrt(np.mean(np.sum(residual**2, axis=1))))

    points_2d = corners.reshape(-1, 2).astype(np.float32)
    hull = cv2.convexHull(points_2d)
    height, width = gray.shape
    area_ratio = float(cv2.contourArea(hull) / float(width * height))
    border = float(
        min(
            np.min(points_2d[:, 0]),
            np.min(points_2d[:, 1]),
            np.min((width - 1) - points_2d[:, 0]),
            np.min((height - 1) - points_2d[:, 1]),
        )
    )
    laplacian_variance = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    target_distance = float(camera_target[2, 3])
    board_normal_z = float(camera_target[2, 2])

    reasons = []
    checks = (
        (
            reprojection_rms <= float(quality["maximum_reprojection_rms_px"]),
            f"reprojection_rms_px={reprojection_rms:.3f} exceeds limit",
        ),
        (
            area_ratio >= float(quality["minimum_board_area_ratio"]),
            f"board_area_ratio={area_ratio:.4f} too small",
        ),
        (
            area_ratio <= float(quality["maximum_board_area_ratio"]),
            f"board_area_ratio={area_ratio:.4f} too large",
        ),
        (
            border >= float(quality["minimum_border_px"]),
            f"minimum_border_px={border:.1f} too small",
        ),
        (
            laplacian_variance >= float(quality["minimum_laplacian_variance"]),
            f"laplacian_variance={laplacian_variance:.1f} indicates blur",
        ),
        (
            target_distance >= float(quality["minimum_target_distance_m"]),
            f"target_distance_m={target_distance:.3f} too near",
        ),
        (
            target_distance <= float(quality["maximum_target_distance_m"]),
            f"target_distance_m={target_distance:.3f} too far",
        ),
        (
            board_normal_z >= float(quality["minimum_board_normal_z"]),
            f"board_normal_z={board_normal_z:.3f} suggests an orientation flip",
        ),
    )
    for passed, reason in checks:
        if not passed:
            reasons.append(reason)

    metrics = {
        "reprojection_rms_px": reprojection_rms,
        "board_area_ratio": area_ratio,
        "minimum_border_px": border,
        "laplacian_variance": laplacian_variance,
        "target_distance_m": target_distance,
        "board_normal_z": board_normal_z,
        "pnp_projection_model": pnp_model,
    }
    color = (0, 180, 0) if not reasons else (0, 0, 255)
    label = (
        f"{'ACCEPT' if not reasons else 'REJECT'} "
        f"rms={reprojection_rms:.3f}px area={area_ratio:.3f} z={target_distance:.3f}m"
    )
    cv2.putText(
        annotated,
        label,
        (12, 28),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        color,
        2,
        cv2.LINE_AA,
    )
    return {
        "detected": True,
        "accepted": not reasons,
        "reasons": reasons,
        "metrics": metrics,
        "corners_px": corners.reshape(-1, 2).tolist(),
        "T_camera_target": camera_target.tolist(),
        "annotated_bgr": annotated,
    }


def choose_best_observation(frames: list[dict], camera: D455ColorSession, config: dict) -> dict:
    detected = []
    for frame in frames:
        result = detect_checkerboard(
            frame["rgb"],
            camera.K,
            camera.distortion,
            config,
            normalize_pixels=camera.normalize_pixels,
        )
        result.update(frame)
        if result["detected"]:
            detected.append(result)
    if detected:
        return min(
            detected,
            key=lambda item: item.get("metrics", {}).get(
                "reprojection_rms_px", float("inf")
            ),
        )
    fallback = detect_checkerboard(
        frames[-1]["rgb"],
        camera.K,
        camera.distortion,
        config,
        normalize_pixels=camera.normalize_pixels,
    )
    fallback.update(frames[-1])
    return fallback


def live_preview_command(
    camera: D455ColorSession,
    config: dict,
    sample_index: int,
    max_samples: int,
    last_result: str = "",
) -> str:
    """Show a responsive preview and return ``capture`` or ``quit``.

    The fast checkerboard result is a framing aid only.  Saved samples still go
    through ``findChessboardCornersSB`` and every configured quality gate.
    """
    import cv2

    if camera.pipeline is None:
        raise RuntimeError("camera session has not started")
    board = config["checkerboard"]
    pattern_size = (
        int(board["inner_corners_columns"]),
        int(board["inner_corners_rows"]),
    )
    window_name = "S1 D455 eye-in-hand collection"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window_name, 960, 720)
    fast_found = False
    fast_corners = None
    frame_index = 0
    while True:
        frame_set = camera.pipeline.wait_for_frames(5000)
        color_frame = frame_set.get_color_frame()
        if not color_frame:
            continue
        rgb = np.asanyarray(color_frame.get_data()).copy()
        bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        height, width = bgr.shape[:2]

        if frame_index % 10 == 0:
            gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
            flags = (
                int(getattr(cv2, "CALIB_CB_ADAPTIVE_THRESH", 0))
                | int(getattr(cv2, "CALIB_CB_NORMALIZE_IMAGE", 0))
                | int(getattr(cv2, "CALIB_CB_FAST_CHECK", 0))
            )
            fast_found, fast_corners = cv2.findChessboardCorners(
                gray, pattern_size, flags=flags
            )
        frame_index += 1

        if fast_found and fast_corners is not None:
            cv2.drawChessboardCorners(
                bgr,
                pattern_size,
                np.asarray(fast_corners, dtype=np.float32),
                True,
            )
        margin = 20
        cv2.rectangle(
            bgr,
            (margin, margin),
            (width - 1 - margin, height - 1 - margin),
            (255, 180, 0),
            1,
        )
        cv2.drawMarker(
            bgr,
            (width // 2, height // 2),
            (0, 255, 255),
            markerType=cv2.MARKER_CROSS,
            markerSize=24,
            thickness=1,
        )
        status_color = (0, 220, 0) if fast_found else (0, 180, 255)
        cv2.putText(
            bgr,
            f"sample {sample_index}/{max_samples}  fast-board={'YES' if fast_found else 'NO'}",
            (12, 28),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            status_color,
            2,
            cv2.LINE_AA,
        )
        cv2.putText(
            bgr,
            "SPACE/C/ENTER: capture   Q/ESC: finish",
            (12, height - 18),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        if last_result:
            cv2.putText(
                bgr,
                last_result[:80],
                (12, 54),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )
        cv2.imshow(window_name, bgr)
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            return "quit"
        if key in (ord("c"), ord(" "), 13, 10):
            return "capture"


def save_images(directory: Path, stem: str, observation: dict) -> dict:
    import cv2

    directory.mkdir(parents=True, exist_ok=True)
    raw_path = directory / f"{stem}_rgb.png"
    annotated_path = directory / f"{stem}_annotated.png"
    raw_bgr = cv2.cvtColor(observation["rgb"], cv2.COLOR_RGB2BGR)
    if not cv2.imwrite(str(raw_path), raw_bgr):
        raise RuntimeError(f"failed to save {raw_path}")
    if not cv2.imwrite(str(annotated_path), observation["annotated_bgr"]):
        raise RuntimeError(f"failed to save {annotated_path}")
    return {
        "raw_rgb_path": str(raw_path.relative_to(PROJECT_ROOT)),
        "annotated_path": str(annotated_path.relative_to(PROJECT_ROOT)),
        "raw_rgb_sha256": file_sha256(raw_path),
    }


def serializable_observation(observation: dict) -> dict:
    return {
        key: value
        for key, value in observation.items()
        if key not in {"rgb", "annotated_bgr"}
    }


def read_teaching_csv_tail(path: Path, count: int) -> list[dict]:
    """Read the newest complete vendor-teaching CSV rows without opening S1.

    The official recorder writes ``time,q1..q7,...`` and closes the file after
    every row.  Reading a bounded tail keeps this inexpensive even during a
    long calibration session.  A partial first/last line is ignored safely.
    """
    if count < 1:
        raise ValueError("teaching CSV row count must be positive")
    if not path.is_file():
        raise RuntimeError(f"官方示教CSV不存在：{path}")

    maximum_bytes = max(65536, count * 2048)
    with path.open("rb") as stream:
        stream.seek(0, 2)
        end = stream.tell()
        start = max(0, end - maximum_bytes)
        stream.seek(start)
        payload = stream.read()

    lines = payload.decode("utf-8", errors="replace").splitlines()
    if start > 0 and lines:
        lines = lines[1:]
    if payload and not payload.endswith((b"\n", b"\r")) and lines:
        lines = lines[:-1]

    records = []
    for row in csv.reader(lines):
        if len(row) < 7:
            continue
        try:
            timestamp_s = float(row[0])
            joint_rad = [float(value) for value in row[1:7]]
            gripper_feedback = float(row[7]) if len(row) >= 8 else 0.0
        except (TypeError, ValueError):
            continue
        values = [timestamp_s, *joint_rad, gripper_feedback]
        if not np.isfinite(values).all():
            continue
        source_state = None
        if len(row) >= 9:
            candidate_state = row[8].strip().lower()
            if candidate_state in POSE_SOURCE_STATES:
                source_state = candidate_state
        records.append(
            {
                "timestamp_s": timestamp_s,
                "state": [*joint_rad, gripper_feedback],
                "source_state": source_state,
            }
        )
    if len(records) < count:
        raise RuntimeError(
            f"官方示教CSV有效数据不足：需要{count}行，实际{len(records)}行"
        )
    return records[-count:]


def wait_for_teaching_csv(
    path: Path,
    count: int,
    *,
    newer_than_s: float | None = None,
    timeout_s: float = 1.0,
) -> list[dict]:
    """Wait until the official recorder supplies a fresh, advancing block."""
    deadline = time.monotonic() + timeout_s
    last_error = None
    while time.monotonic() < deadline:
        try:
            records = read_teaching_csv_tail(path, count)
            if newer_than_s is None or records[-1]["timestamp_s"] > newer_than_s:
                return records
            last_error = RuntimeError("官方示教CSV时间戳没有继续更新")
        except RuntimeError as exc:
            last_error = exc
        time.sleep(0.02)
    raise RuntimeError(
        f"等待官方示教CSV更新超时：{last_error or '无有效数据'}；"
        "确认teaching.py仍在运行"
    )


def validate_teaching_csv_freshness(
    records: list[dict], *, now_s: float, maximum_age_s: float
) -> dict:
    newest = float(records[-1]["timestamp_s"])
    oldest = float(records[0]["timestamp_s"])
    age = now_s - newest
    if age < -0.25:
        raise RuntimeError(f"官方示教CSV时间戳超前系统时间：{age:.3f}s")
    if age > maximum_age_s:
        raise RuntimeError(
            f"官方示教CSV已停止或过旧：最新数据距今{age:.3f}s，"
            f"上限{maximum_age_s:.3f}s"
        )
    if newest <= oldest:
        raise RuntimeError("官方示教CSV时间戳未递增")
    return {
        "oldest_timestamp_s": oldest,
        "newest_timestamp_s": newest,
        "newest_age_s": age,
    }


def summarize_joint_reads(reads: list[list[float]] | list[dict]) -> dict:
    states = [row["state"] if isinstance(row, dict) else row for row in reads]
    values = np.asarray(states, dtype=np.float64)
    joint_values = values[:, :6]
    median = np.median(joint_values, axis=0)
    span = np.ptp(joint_values, axis=0)
    return {
        "joint_rad": median.tolist(),
        "joint_span_rad": span.tolist(),
        "maximum_joint_span_rad": float(np.max(span)),
        "gripper_feedback_median": float(np.median(values[:, 6])),
    }


def pose_source_state_reasons(records: list[dict], pose_source_type: str) -> list[str]:
    """Reject a tilt-lock capture unless every bracketing row is locked.

    The legacy official teaching CSV has no state column and remains fully
    backward compatible.  The tilt-aware publisher appends a ninth field so
    the camera process can prove the arm stayed locked for the whole exposure
    burst instead of trusting operator timing alone.
    """
    if pose_source_type == "official-teaching-csv":
        return []
    if pose_source_type != "tilt-locked-csv":
        raise ValueError(f"unsupported pose source type: {pose_source_type}")
    states = [record.get("source_state") for record in records]
    if not states or any(state != "locked" for state in states):
        observed = sorted({str(state) for state in states})
        return [
            "tilt-locked pose source was not locked throughout capture: "
            f"states={observed}"
        ]
    return []


def next_sample_index(session_dir: Path) -> int:
    indices = []
    for path in session_dir.glob("sample_*.json"):
        match = re.fullmatch(r"sample_(\d+)\.json", path.name)
        if match:
            indices.append(int(match.group(1)))
    return max(indices, default=0) + 1


def create_or_validate_manifest(
    session_dir: Path,
    config_path: Path,
    config: dict,
    pose_csv_path: Path,
    pose_source_type: str = "official-teaching-csv",
) -> dict:
    manifest_path = session_dir / "session_manifest.json"
    config_hash = file_sha256(config_path)
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("config_sha256") != config_hash:
            raise RuntimeError("session configuration hash differs; use a new session name")
        if manifest.get("pose_source_path") != str(pose_csv_path):
            raise RuntimeError("session pose CSV differs; use a new session name")
        existing_type = manifest.get(
            "pose_source_type", "official-teaching-csv"
        )
        if existing_type != pose_source_type:
            raise RuntimeError("session pose source type differs; use a new session name")
        return manifest
    if pose_source_type == "tilt-locked-csv":
        pose_source = "S1 tilt-compensated locked-pose timestamped CSV"
        serial_owner_rule = (
            "only run_tilt_locked_calibration_publisher.py may open /dev/ttyUSB0"
        )
    else:
        pose_source = "official S1 SDK teaching.py append-only CSV"
        serial_owner_rule = "only the vendor teaching.py process may open /dev/ttyUSB0"
    manifest = {
        "schema_version": 1,
        "mode": "eye_in_hand",
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "config_path": str(config_path.relative_to(PROJECT_ROOT)),
        "config_sha256": config_hash,
        "camera_serial": str(config["camera_serial"]),
        "checkerboard": dict(config["checkerboard"]),
        "fixed_target_rule": "checkerboard must remain rigidly fixed for the whole session",
        "robot_rule": "capture process never imports or opens the S1 interface",
        "pose_source": pose_source,
        "pose_source_type": pose_source_type,
        "pose_source_path": str(pose_csv_path),
        "serial_owner_rule": serial_owner_rule,
    }
    write_json(manifest_path, manifest)
    return manifest


def camera_check(args, config_path: Path, config: dict) -> int:
    print("MODE = camera-check")
    print("NO_ARM_ACCESS = True")
    if not args.execute:
        print("未指定 --execute；不会打开D455。")
        return 0

    output_dir = (
        resolve_path(args.output_dir)
        if args.output_dir
        else DATA_ROOT / f"precheck_{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    )
    camera = D455ColorSession(config)
    try:
        camera.start()
        frames = camera.capture_candidates()
        observation = choose_best_observation(frames, camera, config)
        paths = save_images(output_dir, "board_precheck", observation)
        record = {
            "schema_version": 1,
            "mode": "eye_in_hand_camera_check",
            "captured_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            "config_sha256": file_sha256(config_path),
            "camera": camera.camera_info,
            "checkerboard": config["checkerboard"],
            "observation": serializable_observation(observation),
            **paths,
        }
        write_json(output_dir / "board_precheck.json", record)
        print("CAMERA =", camera.camera_info)
        print("BOARD_DETECTED =", observation["detected"])
        print("BOARD_ACCEPTED =", observation["accepted"])
        if observation.get("metrics"):
            print("BOARD_METRICS =", observation["metrics"])
        for reason in observation["reasons"]:
            print("BOARD_REJECT =", reason)
        print("PRECHECK_DIR =", output_dir)
        return 0 if observation["accepted"] else 2
    finally:
        camera.stop()


def collect(args, config_path: Path, config: dict) -> int:
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.session):
        raise ValueError("--session may contain only letters, digits, _ and -")
    print("MODE = collect")
    print("NO_ARM_ACCESS = True")
    print("ROBOT_MOTION_COMMANDS = disabled-by-design")
    print("CAMERA_SERIAL =", config["camera_serial"])
    print("SESSION =", args.session)
    pose_csv_path = Path(args.pose_csv).expanduser().resolve()
    print("POSE_SOURCE =", args.pose_source_type)
    print("POSE_CSV =", pose_csv_path)
    if not args.execute:
        print("未指定 --execute；不会打开D455，也不会访问机械臂串口。")
        return 0

    if args.pose_source_type == "tilt-locked-csv":
        print("倾角补偿发布器必须已在另一终端运行并独占/dev/ttyUSB0。")
        print("只有发布器显示LOCKED_READY_FOR_CAPTURE后才允许采集。")
    else:
        print("官方teaching.py必须已在另一终端运行并独占/dev/ttyUSB0。")
    print("本进程只读取CSV，不导入S1控制类、不连接串口、不发送失能。")
    print("标定板必须全程固定；改变姿态后静止，再按键采集。")
    print("若示教终端退出或机械臂异常，立即托稳并停止本采集窗口。")
    confirmation = input("确认上述条件后输入 y：").strip().lower()
    if confirmation != "y":
        print("未确认，取消采集。")
        return 1

    from s1_control.kinematics import Kinematics

    session_dir = DATA_ROOT / args.session
    session_dir.mkdir(parents=True, exist_ok=True)
    create_or_validate_manifest(
        session_dir,
        config_path,
        config,
        pose_csv_path,
        args.pose_source_type,
    )
    camera = D455ColorSession(config)
    quality = config["capture_quality"]
    per_block = max(2, int(quality["joint_read_count"]) // 2)
    maximum_age_s = float(args.pose_csv_max_age_s)
    try:
        initial_records = wait_for_teaching_csv(
            pose_csv_path,
            per_block,
            timeout_s=float(args.pose_csv_wait_s),
        )
        initial_freshness = validate_teaching_csv_freshness(
            initial_records,
            now_s=time.time(),
            maximum_age_s=maximum_age_s,
        )
        print(
            "POSE_CSV_LIVE = True",
            f"age={initial_freshness['newest_age_s']:.3f}s",
        )
        camera.start()
        flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
        if args.pose_source_type == "tilt-locked-csv":
            print("READY：在发布器中摆姿并锁定；出现LOCKED_READY_FOR_CAPTURE后采集。")
        else:
            print("READY：在官方重力补偿下摆姿；停止并稳定后再采集。")

        last_preview_result = ""
        while next_sample_index(session_dir) <= args.max_samples:
            sample_index = next_sample_index(session_dir)
            if args.live_preview:
                command = live_preview_command(
                    camera,
                    config,
                    sample_index,
                    args.max_samples,
                    last_preview_result,
                )
                print(
                    f"LIVE_PREVIEW_COMMAND sample={sample_index} action={command}"
                )
            else:
                command = input(
                    f"[{sample_index}/{args.max_samples}] 回车采集，输入 q 结束："
                ).strip().lower()
            if command in {"q", "quit"}:
                break
            if command not in {"", "c", "capture"}:
                print("未知输入；回车/c=采集，q=结束。")
                continue

            before = wait_for_teaching_csv(
                pose_csv_path,
                per_block,
                timeout_s=float(args.pose_csv_wait_s),
            )
            before_freshness = validate_teaching_csv_freshness(
                before,
                now_s=time.time(),
                maximum_age_s=maximum_age_s,
            )
            capture_started_s = time.time()
            frames = camera.capture_candidates()
            capture_finished_s = time.time()
            after = wait_for_teaching_csv(
                pose_csv_path,
                per_block,
                newer_than_s=max(
                    float(before[-1]["timestamp_s"]), capture_finished_s
                ),
                timeout_s=float(args.pose_csv_wait_s),
            )
            after_freshness = validate_teaching_csv_freshness(
                after,
                now_s=time.time(),
                maximum_age_s=maximum_age_s,
            )
            joint = summarize_joint_reads(before + after)
            observation = choose_best_observation(frames, camera, config)
            reasons = list(observation["reasons"])
            reasons.extend(
                pose_source_state_reasons(
                    before + after,
                    args.pose_source_type,
                )
            )
            if joint["maximum_joint_span_rad"] > float(
                quality["maximum_joint_span_rad"]
            ):
                reasons.append(
                    "maximum_joint_span_rad="
                    f"{joint['maximum_joint_span_rad']:.6f} exceeds static limit"
                )

            accepted = bool(observation["accepted"] and not reasons)
            if not accepted:
                reject_dir = session_dir / "rejected"
                stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
                paths = save_images(reject_dir, f"rejected_{stamp}", observation)
                print("SAMPLE_REJECTED =", reasons)
                print("REJECTED_PREVIEW =", paths["annotated_path"])
                last_preview_result = "REJECTED: " + "; ".join(reasons)
                continue

            q = joint["joint_rad"]
            flange_pose = flange_kinematics.fk(q)
            base_flange = pose_xyz_quat_to_transform(flange_pose)
            stem = f"sample_{sample_index:03d}"
            paths = save_images(session_dir, stem, observation)
            record = {
                "schema_version": 1,
                "mode": "eye_in_hand_sample",
                "sample_index": sample_index,
                "captured_at": datetime.now().astimezone().isoformat(
                    timespec="milliseconds"
                ),
                "config_sha256": file_sha256(config_path),
                "camera": camera.camera_info,
                "checkerboard": config["checkerboard"],
                "observation": serializable_observation(observation),
                "joint_observation": joint,
                "pose_source_observation": {
                    "type": args.pose_source_type,
                    "path": str(pose_csv_path),
                    "before_source_states": sorted(
                        {
                            str(record.get("source_state"))
                            for record in before
                        }
                    ),
                    "after_source_states": sorted(
                        {
                            str(record.get("source_state"))
                            for record in after
                        }
                    ),
                    "capture_started_epoch_s": capture_started_s,
                    "capture_finished_epoch_s": capture_finished_s,
                    "before": before_freshness,
                    "after": after_freshness,
                    "source_brackets_capture": bool(
                        before[-1]["timestamp_s"] <= capture_started_s
                        and after[-1]["timestamp_s"] > capture_finished_s
                    ),
                },
                "flange_fk_definition": "S1_solver end_offset=[0,0,0]",
                "flange_pose_xyz_quat_xyzw": flange_pose,
                "T_base_flange": base_flange.tolist(),
                **paths,
            }
            write_json(session_dir / f"{stem}.json", record)
            print(
                f"SAMPLE_ACCEPTED = {sample_index} "
                f"rms={observation['metrics']['reprojection_rms_px']:.3f}px "
                f"z={observation['metrics']['target_distance_m']:.3f}m "
                f"joint_span={joint['maximum_joint_span_rad']:.6f}rad"
            )
            last_preview_result = (
                f"ACCEPTED {sample_index}: "
                f"rms={observation['metrics']['reprojection_rms_px']:.3f}px"
            )
            print("接下来改变位置及至少一个姿态角；标定板不能移动。")

        count = next_sample_index(session_dir) - 1
        print("SESSION_SAMPLE_COUNT =", count)
        print("SESSION_DIR =", session_dir)
        print("建议至少采集", config["solve_quality"]["recommended_samples"], "个有效姿态。")
        print("CAMERA_COLLECTION_DONE：官方示教进程仍在运行，未发送失能。")
        return 0
    finally:
        if args.live_preview:
            try:
                import cv2

                cv2.destroyAllWindows()
            except Exception:
                pass
        camera.stop()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="S1腕部D455眼在手采集（相机进程不访问机械臂串口）"
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    subparsers = parser.add_subparsers(dest="mode", required=True)

    camera_parser = subparsers.add_parser(
        "camera-check", help="只开D455采集一组棋盘格预检图"
    )
    camera_parser.add_argument("--output-dir", default=None)
    camera_parser.add_argument("--execute", action="store_true")

    collect_parser = subparsers.add_parser(
        "collect", help="采集RGB并同步读取官方teaching.py关节CSV"
    )
    collect_parser.add_argument("--session", required=True)
    collect_parser.add_argument(
        "--pose-source-type",
        choices=POSE_SOURCE_TYPES,
        default="official-teaching-csv",
        help="关节CSV来源；倾角锁定发布器使用tilt-locked-csv",
    )
    collect_parser.add_argument(
        "--pose-csv",
        default=str(DEFAULT_TEACHING_CSV),
        help="官方S1 teaching.py持续写入的data.csv",
    )
    collect_parser.add_argument(
        "--pose-csv-max-age-s",
        type=float,
        default=0.25,
        help="允许CSV最新关节数据距当前时间的最大秒数",
    )
    collect_parser.add_argument(
        "--pose-csv-wait-s",
        type=float,
        default=1.0,
        help="等待示教CSV继续更新的超时秒数",
    )
    collect_parser.add_argument("--max-samples", type=int, default=20)
    collect_parser.add_argument(
        "--live-preview",
        action="store_true",
        help="显示D455实时画面；SPACE/C/回车采集，Q/ESC结束",
    )
    collect_parser.add_argument("--execute", action="store_true")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    config_path = resolve_path(args.config)
    config = read_config(config_path)
    board = config["checkerboard"]
    print("CONFIG =", config_path)
    print(
        "CHECKERBOARD =",
        f"{board['inner_corners_columns']}x{board['inner_corners_rows']} inner corners,",
        f"square={1000.0 * float(board['square_size_m']):.1f}mm",
    )
    if args.mode == "camera-check":
        return camera_check(args, config_path, config)
    if args.max_samples < 1:
        raise ValueError("--max-samples must be positive")
    if args.pose_csv_max_age_s <= 0.0:
        raise ValueError("--pose-csv-max-age-s must be positive")
    if args.pose_csv_wait_s <= 0.0:
        raise ValueError("--pose-csv-wait-s must be positive")
    return collect(args, config_path, config)


if __name__ == "__main__":
    raise SystemExit(main())
