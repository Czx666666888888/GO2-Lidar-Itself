#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Supervised one-target RGB-D -> plan -> adaptive grasp pipeline."""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.visual_target import (  # noqa: E402
    derive_visual_grasp_target,
    file_sha256,
    load_visual_grasp_calibration,
)


DEFAULT_CALIBRATION = "calibration/temp_bench_visual_grasp.json"
DEFAULT_OUTPUT_ROOT = "data/visual_grasp_runs"
DEFAULT_V_MAX_RAD_S = 0.20
DEFAULT_J6_V_MAX_RAD_S = 0.10
RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


def resolve_project_path(raw_path: str | Path) -> Path:
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def resolve_output_root(raw_path: str | Path) -> Path:
    path = resolve_project_path(raw_path)
    try:
        path.relative_to(PROJECT_ROOT.resolve())
    except ValueError as exc:
        raise ValueError("输出目录必须位于项目仓库内") from exc
    return path


def validated_run_id(raw_run_id: str | None) -> str:
    run_id = (
        raw_run_id
        if raw_run_id is not None
        else time.strftime("visual_grasp_%Y%m%d-%H%M%S")
    )
    if not RUN_ID_PATTERN.fullmatch(run_id):
        raise ValueError(
            "--run-id只允许字母、数字、下划线、点和短横线，长度1~80"
        )
    return run_id


def build_descent_z_waypoints(
    hover_z_mm: float,
    grasp_z_mm: float,
    maximum_step_mm: float,
) -> list[tuple[str, float]]:
    """Split a vertical descent into equal positive steps no larger than max."""
    values = (hover_z_mm, grasp_z_mm, maximum_step_mm)
    if not all(math.isfinite(value) for value in values):
        raise ValueError("下降高度和最大步长必须是有限数")
    total_descent_mm = hover_z_mm - grasp_z_mm
    if total_descent_mm <= 0.0:
        raise ValueError("hover必须严格高于grasp")
    if maximum_step_mm <= 0.0:
        raise ValueError("maximum_step_mm必须大于0")

    segment_count = max(1, math.ceil(total_descent_mm / maximum_step_mm))
    waypoints = []
    for index in range(1, segment_count + 1):
        name = (
            "grasp" if index == segment_count else f"descent_{index:02d}"
        )
        z_mm = hover_z_mm - total_descent_mm * index / segment_count
        waypoints.append((name, z_mm))
    return waypoints


def build_planning_commands(
    python_executable: str,
    target_path: Path,
    hover_plan_path: Path,
    grasp_plan_path: Path,
    collision_report_path: Path,
    target_record: dict,
    calibration_record: dict,
    *,
    v_max_rad_s: float = DEFAULT_V_MAX_RAD_S,
    j6_v_max_rad_s: float = DEFAULT_J6_V_MAX_RAD_S,
) -> list[tuple[str, list[str]]]:
    visual_target = target_record["visual_target"]
    hover_z_mm = float(visual_target["hover_tcp_mm"][2])
    grasp_z_mm = float(visual_target["grasp_tcp_mm"][2])
    minimum_tcp_z_mm = float(
        calibration_record["geometry"]["minimum_tcp_z_mm"]
    )
    maximum_step_mm = float(
        calibration_record["geometry"]["maximum_cartesian_descent_step_mm"]
    )
    maximum_lateral_mm = float(
        calibration_record["geometry"]["maximum_descent_lateral_deviation_mm"]
    )
    motion_profile = str(calibration_record["execution"]["motion_profile"])
    planning_motion_arguments = [
        "--motion-profile",
        motion_profile,
        "--v-max-rad-s",
        f"{v_max_rad_s:.9g}",
        "--j6-v-max-rad-s",
        f"{j6_v_max_rad_s:.9g}",
    ]
    commands = [
        (
            "plan_hover",
            [
                python_executable,
                "-B",
                str(PROJECT_ROOT / "scripts/plan_cube_hover.py"),
                "--pose-file",
                str(target_path),
                "--target-z-mm",
                f"{hover_z_mm:.9f}",
                *planning_motion_arguments,
                "--output",
                str(hover_plan_path),
            ],
        ),
    ]
    previous_plan_path = hover_plan_path
    for waypoint_name, waypoint_z_mm in build_descent_z_waypoints(
        hover_z_mm, grasp_z_mm, maximum_step_mm
    ):
        output_path = (
            grasp_plan_path
            if waypoint_name == "grasp"
            else grasp_plan_path.with_name(f"{waypoint_name}_plan.json")
        )
        commands.append((
            f"plan_{waypoint_name}",
            [
                python_executable,
                "-B",
                str(PROJECT_ROOT / "scripts/plan_cube_hover.py"),
                "--pose-file",
                str(target_path),
                "--base-plan",
                str(previous_plan_path),
                "--waypoint-name",
                waypoint_name,
                "--max-descent-step-mm",
                f"{maximum_step_mm:.9f}",
                "--target-z-mm",
                f"{waypoint_z_mm:.9f}",
                *planning_motion_arguments,
                "--output",
                str(output_path),
            ],
        ))
        previous_plan_path = output_path

    commands.append((
            "check_collision",
            [
                python_executable,
                "-B",
                str(PROJECT_ROOT / "scripts/check_cube_hover_path.py"),
                "--plan",
                str(grasp_plan_path),
                "--step-rad",
                "0.02",
                "--min-joint-margin-deg",
                "10",
                "--min-tcp-z-mm",
                f"{minimum_tcp_z_mm:.9f}",
                "--max-descent-lateral-mm",
                f"{maximum_lateral_mm:.9f}",
                "--output",
                str(collision_report_path),
            ],
        ))
    return commands


def build_execution_command(
    python_executable: str,
    dev: str,
    grasp_plan_path: Path,
    collision_report_path: Path,
    calibration_record: dict,
    *,
    alignment_only: bool = False,
    v_max_rad_s: float = DEFAULT_V_MAX_RAD_S,
    j6_v_max_rad_s: float = DEFAULT_J6_V_MAX_RAD_S,
    diagnostic_log_path: Path | None = None,
) -> list[str]:
    execution = calibration_record["execution"]
    command = [
        python_executable,
        "-B",
        str(PROJECT_ROOT / "scripts/grip_lift_place.py"),
        "--dev",
        dev,
        "--target-profile",
        str(execution["target_profile"]),
        "--plan",
        str(grasp_plan_path),
        "--collision-report",
        str(collision_report_path),
    ]
    if alignment_only:
        command.append("--hover-only")
    elif execution.get("adaptive_grip") is True:
        command.append("--adaptive-grip")
    command.extend([
        "--motion-profile",
        str(execution["motion_profile"]),
        "--v-max-rad-s",
        f"{v_max_rad_s:.9g}",
        "--j6-v-max-rad-s",
        f"{j6_v_max_rad_s:.9g}",
    ])
    if diagnostic_log_path is not None:
        command.extend(["--diagnostic-log", str(diagnostic_log_path)])
    command.append("--execute")
    return command


def write_json(path: Path, record: dict) -> None:
    path.write_text(
        json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )


def run_stage(stage: str, command: list[str]) -> int:
    print(f"\n===== STAGE: {stage} =====", flush=True)
    print("COMMAND =", shlex.join(command), flush=True)
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        env=environment,
        check=False,
    )
    print(f"STAGE_RESULT {stage} = {completed.returncode}", flush=True)
    return int(completed.returncode)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "当前临时台架的单目标视觉自适应抓取；默认完成离线规划后停止"
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--live-capture",
        action="store_true",
        help="访问当前绑定的D455采集新RGB-D数据",
    )
    source.add_argument(
        "--replay-npz",
        help="离线重放已有capture_rgbd.py输出；禁止与--execute组合",
    )
    parser.add_argument("--run-id")
    parser.add_argument("--output-root", default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--calibration", default=DEFAULT_CALIBRATION)
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument(
        "--v-max-rad-s",
        type=float,
        default=DEFAULT_V_MAX_RAD_S,
        help="规划器与执行器共用的全局规划峰值rad/s；默认0.20",
    )
    parser.add_argument(
        "--j6-v-max-rad-s",
        type=float,
        default=DEFAULT_J6_V_MAX_RAD_S,
        help=(
            "转发给机械臂执行器的J6独立规划峰值rad/s；"
            "默认0.10，本参数不改变J1-J5全局速度"
        ),
    )
    parser.add_argument("--no-preview", action="store_true")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="仅新鲜实拍允许进入现有有人确认的机械臂执行器",
    )
    parser.add_argument(
        "--alignment-only",
        action="store_true",
        help="与--execute配合：完成本轮实拍、规划和碰撞检查后仅开爪对准，不合爪或提升",
    )
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.execute and not args.live_capture:
        raise ValueError("实机执行必须使用本轮--live-capture，禁止重放旧画面")
    if args.alignment_only and not args.execute:
        raise ValueError("--alignment-only必须与--execute同时使用")
    for name, value in (
        ("v-max-rad-s", args.v_max_rad_s),
        ("j6-v-max-rad-s", args.j6_v_max_rad_s),
    ):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"--{name}必须是大于0的有限数")

    calibration = load_visual_grasp_calibration(
        args.calibration,
        root=PROJECT_ROOT,
        verify_bindings=True,
        verbose=True,
    )
    record = calibration.record
    run_id = validated_run_id(args.run_id)
    output_root = resolve_output_root(args.output_root)
    run_dir = output_root / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    manifest_path = run_dir / "manifest.json"
    detection_path = run_dir / "detection.json"
    detection_preview_path = run_dir / "detection.png"
    target_path = run_dir / "target_base.json"
    hover_plan_path = run_dir / "hover_plan.json"
    grasp_plan_path = run_dir / "grasp_plan.json"
    collision_report_path = run_dir / "collision_report.json"
    execution_diagnostic_path = run_dir / "execution_diagnostic.json"
    capture_path = run_dir / "capture.npz"

    manifest = {
        "schema_version": 1,
        "run_id": run_id,
        "status": "STARTED",
        "mode": "LIVE_CAPTURE" if args.live_capture else "OFFLINE_REPLAY",
        "execute_requested": bool(args.execute),
        "execution_mode": "ALIGNMENT_ONLY" if args.alignment_only else "ADAPTIVE_GRASP",
        "v_max_rad_s": float(args.v_max_rad_s),
        "j6_v_max_rad_s": float(args.j6_v_max_rad_s),
        "calibration": str(calibration.path),
        "calibration_sha256": file_sha256(calibration.path),
        "stages": [],
        "artifacts": {},
    }
    write_json(manifest_path, manifest)

    try:
        from demo_grasp.capture_rgbd import capture_aligned_rgbd, save_capture
        from demo_grasp.detect_science_target_rgbd import (
            detect_capture,
            load_capture,
            load_config,
            save_preview,
            save_result,
        )

        if args.live_capture:
            capture_settings = record["capture"]
            print("\n===== STAGE: live_capture =====")
            capture = capture_aligned_rgbd(
                serial=str(record["camera_serial"]),
                width=int(capture_settings["width"]),
                height=int(capture_settings["height"]),
                fps=int(capture_settings["fps"]),
                warmup_frames=int(capture_settings["warmup_frames"]),
                depth_frames=int(capture_settings["depth_frames"]),
                timeout_ms=int(capture_settings["timeout_ms"]),
                min_valid_depth_ratio=float(
                    capture_settings["minimum_valid_depth_ratio"]
                ),
                max_frame_interval_ms=float(
                    capture_settings["maximum_frame_interval_ms"]
                ),
            )
            save_capture(
                capture,
                capture_path,
                write_preview=not args.no_preview,
            )
            manifest["stages"].append({
                "name": "live_capture",
                "status": "PASS" if capture["metadata"]["quality_pass"] else "FAIL",
                "metadata": capture["metadata"],
            })
            if capture["metadata"]["quality_pass"] is not True:
                raise RuntimeError("RGB-D采集质量门控未通过")
        else:
            capture_path = resolve_project_path(args.replay_npz)
            if not capture_path.is_file():
                raise FileNotFoundError(f"重放RGB-D不存在: {capture_path}")

        replay = load_capture(capture_path)
        if replay["metadata"].get("quality_pass") is not True:
            raise RuntimeError("RGB-D源数据质量门控未通过")

        vision_config, vision_config_path = load_config(
            calibration.binding_paths["vision_config"]
        )
        detection = detect_capture(replay, vision_config)
        detection["config_path"] = str(vision_config_path)
        save_result(detection, detection_path)
        if not args.no_preview:
            save_preview(replay["rgb"], detection, detection_preview_path)
        manifest["stages"].append({
            "name": "detect_target",
            "status": detection["status"],
            "accepted_candidate_count": detection.get(
                "accepted_candidate_count", 0
            ),
        })
        if detection.get("selected") is None:
            raise RuntimeError(f"目标检测未通过: {detection['status']}")

        target_record = derive_visual_grasp_target(
            detection,
            calibration,
            replay["metadata"],
            source_detection=detection_path,
            source_capture=capture_path,
        )
        write_json(target_path, target_record)
        target = target_record["visual_target"]
        print("RAW_TARGET_BASE_XY_MM =", [
            round(v, 3) for v in target["raw_target_base_xy_mm"]
        ])
        print("EMPIRICAL_BIAS_BASE_XY_MM =", [
            round(v, 3)
            for v in target["empirical_target_center_bias_base_mm"][:2]
        ])
        print("TARGET_BASE_XY_MM =", [
            round(target["grasp_tcp_mm"][0], 3),
            round(target["grasp_tcp_mm"][1], 3),
        ])
        print("TARGET_HEIGHT_MM =", round(
            target["height_along_table_normal_mm"], 3
        ))
        print("HOVER_TCP_MM =", [round(v, 3) for v in target["hover_tcp_mm"]])
        print("GRASP_TCP_MM =", [round(v, 3) for v in target["grasp_tcp_mm"]])
        target_edge_axis_base = target["target_edge_axis_base"]
        target_edge_angle_mod90_deg = (
            math.degrees(
                math.atan2(
                    float(target_edge_axis_base[1]),
                    float(target_edge_axis_base[0]),
                )
            )
            % 90.0
        )
        print("TARGET_EDGE_AXIS_BASE =", [
            round(v, 6) for v in target_edge_axis_base
        ])
        print(
            "TARGET_EDGE_ANGLE_BASE_MOD90_DEG =",
            round(target_edge_angle_mod90_deg, 3),
        )
        print(
            "TARGET_ORIENTATION_CONFIDENCE =",
            round(target["orientation_confidence_score"], 3),
        )
        print(
            "TARGET_ORIENTATION_P90_DEVIATION_DEG =",
            round(target["orientation_p90_deviation_deg"], 3),
        )
        print("SIZE_CONTROL = adaptive_continuous_contact_feedback")
        manifest["stages"].append({
            "name": "camera_to_base",
            "status": "PASS",
            "raw_target_base_xy_mm": target["raw_target_base_xy_mm"],
            "empirical_target_center_bias_base_mm": target[
                "empirical_target_center_bias_base_mm"
            ],
            "target_base_xy_mm": target["grasp_tcp_mm"][:2],
            "target_height_mm": target["height_along_table_normal_mm"],
            "target_edge_axis_base": target_edge_axis_base,
            "target_edge_angle_base_mod90_deg": (
                target_edge_angle_mod90_deg
            ),
            "orientation_confidence_score": target[
                "orientation_confidence_score"
            ],
            "orientation_p90_deviation_deg": target[
                "orientation_p90_deviation_deg"
            ],
        })

        planning_commands = build_planning_commands(
            sys.executable,
            target_path,
            hover_plan_path,
            grasp_plan_path,
            collision_report_path,
            target_record,
            record,
            v_max_rad_s=args.v_max_rad_s,
            j6_v_max_rad_s=args.j6_v_max_rad_s,
        )
        for stage, command in planning_commands:
            return_code = run_stage(stage, command)
            manifest["stages"].append({
                "name": stage,
                "status": "PASS" if return_code == 0 else "FAIL",
                "return_code": return_code,
            })
            write_json(manifest_path, manifest)
            if return_code != 0:
                raise RuntimeError(f"{stage}失败，返回码{return_code}")

        manifest["artifacts"] = {
            "capture": str(capture_path),
            "detection": str(detection_path),
            "target": str(target_path),
            "hover_plan": str(hover_plan_path),
            "descent_plans": [
                command[command.index("--output") + 1]
                for stage, command in planning_commands
                if stage.startswith("plan_descent_")
            ],
            "grasp_plan": str(grasp_plan_path),
            "collision_report": str(collision_report_path),
            "execution_diagnostic": str(execution_diagnostic_path),
            "grasp_plan_sha256": file_sha256(grasp_plan_path),
            "collision_report_sha256": file_sha256(collision_report_path),
        }
        manifest["status"] = "OFFLINE_READY"
        write_json(manifest_path, manifest)
        print("PIPELINE_OFFLINE_READY =", run_dir)

        if not args.execute:
            print("OFFLINE_ONLY：未访问S1串口、未使能机械臂。")
            return 0

        command = build_execution_command(
            sys.executable,
            args.dev,
            grasp_plan_path,
            collision_report_path,
            record,
            alignment_only=args.alignment_only,
            v_max_rad_s=args.v_max_rad_s,
            j6_v_max_rad_s=args.j6_v_max_rad_s,
            diagnostic_log_path=execution_diagnostic_path,
        )
        execute_stage = (
            "execute_alignment_only"
            if args.alignment_only
            else "execute_adaptive_grasp"
        )
        return_code = run_stage(execute_stage, command)
        manifest["stages"].append({
            "name": execute_stage,
            "status": "PASS" if return_code == 0 else "FAIL",
            "return_code": return_code,
        })
        manifest["status"] = (
            "EXECUTION_COMPLETE" if return_code == 0 else "EXECUTION_FAILED"
        )
        write_json(manifest_path, manifest)
        if return_code != 0:
            return return_code
        result_name = (
            "VISUAL_ALIGNMENT_PIPELINE_DONE"
            if args.alignment_only
            else "VISUAL_ADAPTIVE_GRASP_PIPELINE_DONE"
        )
        print(result_name, "=", run_dir)
        return 0
    except Exception as exc:
        manifest["status"] = "FAILED_BEFORE_OR_DURING_EXECUTION"
        manifest["error"] = f"{type(exc).__name__}: {exc}"
        write_json(manifest_path, manifest)
        print("PIPELINE_FAILED =", manifest["error"])
        print("MANIFEST =", manifest_path)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
