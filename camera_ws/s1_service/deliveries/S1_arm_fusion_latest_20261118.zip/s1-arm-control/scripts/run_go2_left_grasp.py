#!/usr/bin/env python3
"""Left-side automatic full grasp with persistent zero hold."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_arm_integration import main

if __name__ == "__main__":
    raise SystemExit(main([
        "--config", "config/go2_left_full_flow_size_adaptive_20261112_v1.json",
        "--search-plan", "data/plans/go2_left_grasp_search_20261112_v1.json",
        "data/plans/go2_left_grasp_search_20261112_v1_report.json",
        *sys.argv[1:],
    ]))
