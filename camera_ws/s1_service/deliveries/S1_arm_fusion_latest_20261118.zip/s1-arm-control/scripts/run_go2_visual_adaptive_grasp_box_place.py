#!/usr/bin/env python3
"""Run the supervised 50mm/40g visual grasp and fixed-box placement loop."""
from pathlib import Path
import sys

from run_go2_visual_alignment import main


DEFAULT_CONFIG = (
    Path(__file__).resolve().parents[1]
    / "config"
    / "go2_crouch_right_visual_adaptive_grasp_box_place_nocw_metalbracket_v1.json"
)


if __name__ == "__main__":
    argv = list(sys.argv[1:])
    if "--config" not in argv:
        argv = ["--config", str(DEFAULT_CONFIG), *argv]
    raise SystemExit(main(argv))
