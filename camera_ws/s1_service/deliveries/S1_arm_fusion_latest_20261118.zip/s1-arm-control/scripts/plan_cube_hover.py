#!/usr/bin/env python3
import argparse
import contextlib
import json
import math
import os
import re
import sys
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.calib import load_tcp
from s1_control.arm import MOTION_PROFILES, motion_duration_s
from s1_control.kinematics import (
    GRASP_REGION_SEED_Q,
    READY_Q,
)


JOINT_LIMITS = [
    (math.radians(-170), math.radians(170)),
    (math.radians(0), math.radians(180)),
    (math.radians(0), math.radians(170)),
    (math.radians(-90), math.radians(87)),
    (math.radians(-90), math.radians(90)),
    (math.radians(-90), math.radians(90)),
]

MIN_MARGIN_DEG = 10.0
MAX_READY_DELTA_RAD = 1.5
MAX_STANDOFF_GRASP_DELTA_RAD = 0.5
DEFAULT_MAX_DESCENT_STEP_MM = 30.0
MAX_POSITION_ERROR_MM = 3.0
MAX_ORIENTATION_ERROR_DEG = 5.0
DEFAULT_MOTION_PROFILE = "s_curve"
DEFAULT_V_MAX_RAD_S = 0.20
DEFAULT_J6_V_MAX_RAD_S = 0.10

# 列向量依次为 X_tool、Y_tool、Z_tool：
# X_tool向下接近物体，Y_tool沿基座Y方向水平闭合。
TOPDOWN_R = np.array([
    [0.0, 0.0, 1.0],
    [0.0, 1.0, 0.0],
    [-1.0, 0.0, 0.0],
])


def validate_topdown_rotation(rotation):
    """Validate a base-vertical top-down tool rotation matrix."""
    matrix = np.asarray(rotation, dtype=float)
    if matrix.shape != (3, 3) or not np.all(np.isfinite(matrix)):
        raise ValueError("top-down抓取旋转矩阵必须是有限3x3")
    if not np.allclose(matrix.T @ matrix, np.eye(3), atol=1e-6):
        raise ValueError("top-down抓取旋转矩阵不是正交矩阵")
    if not math.isclose(float(np.linalg.det(matrix)), 1.0, abs_tol=1e-6):
        raise ValueError("top-down抓取旋转矩阵行列式必须为+1")
    if not np.allclose(matrix[:, 0], [0.0, 0.0, -1.0], atol=1e-6):
        raise ValueError("top-down抓取的X_tool必须沿base -Z")
    if abs(float(matrix[2, 1])) > 1e-6:
        raise ValueError("top-down抓取的夹爪闭合轴必须位于base XY平面")
    return matrix


def topdown_orientations_for_square_axis(edge_axis_base):
    """Return four equivalent tool rotations for a square edge axis.

    A square supplies two orthogonal face-normal choices. A parallel gripper
    is additionally symmetric under a 180-degree rotation about its approach
    axis, yielding four IK candidates with identical grasp geometry.
    """
    edge = np.asarray(edge_axis_base, dtype=float)
    if edge.shape != (3,) or not np.all(np.isfinite(edge)):
        raise ValueError("target_edge_axis_base必须是3维有限向量")
    edge = np.array([edge[0], edge[1], 0.0], dtype=float)
    norm = float(np.linalg.norm(edge))
    if norm < 1e-9:
        raise ValueError("target_edge_axis_base在base XY平面投影退化")
    edge /= norm
    perpendicular = np.array([-edge[1], edge[0], 0.0], dtype=float)
    approach = np.array([0.0, 0.0, -1.0], dtype=float)
    roll180 = np.diag([1.0, -1.0, -1.0])
    orientations = []
    for axis_name, closing_axis in (
        ("edge", edge),
        ("edge90", perpendicular),
    ):
        tool_z = np.cross(approach, closing_axis)
        base_rotation = validate_topdown_rotation(
            np.column_stack((approach, closing_axis, tool_z))
        )
        orientations.append((axis_name, base_rotation))
        orientations.append((
            f"{axis_name}_roll180",
            validate_topdown_rotation(base_rotation @ roll180),
        ))
    return orientations


def orientation_candidates_from_pose(record):
    visual_target = record.get("visual_target")
    if isinstance(visual_target, dict) and (
        "target_edge_axis_base" in visual_target
    ):
        if (
            visual_target.get("grasp_orientation_mode")
            != "dynamic_topdown_square_edge_mod90"
        ):
            raise ValueError("动态目标方向模式不受支持")
        if float(
            visual_target.get("orientation_symmetry_period_deg", 0.0)
        ) != 90.0:
            raise ValueError("动态方块方向必须采用90度对称周期")
        return topdown_orientations_for_square_axis(
            visual_target["target_edge_axis_base"]
        )
    return [
        ("as-is", TOPDOWN_R),
        ("roll180", TOPDOWN_R @ np.diag([1.0, -1.0, -1.0])),
    ]


@contextlib.contextmanager
def hush_sdk():
    saved_stdout = os.dup(1)
    saved_stderr = os.dup(2)
    devnull = os.open(os.devnull, os.O_WRONLY)

    os.dup2(devnull, 1)
    os.dup2(devnull, 2)

    try:
        yield
    finally:
        os.dup2(saved_stdout, 1)
        os.dup2(saved_stderr, 2)
        os.close(devnull)
        os.close(saved_stdout)
        os.close(saved_stderr)


def rotation_to_quaternion(matrix):
    trace = np.trace(matrix)

    if trace > 0:
        scale = math.sqrt(trace + 1.0) * 2.0
        w = 0.25 * scale
        x = (matrix[2, 1] - matrix[1, 2]) / scale
        y = (matrix[0, 2] - matrix[2, 0]) / scale
        z = (matrix[1, 0] - matrix[0, 1]) / scale
    elif matrix[0, 0] > matrix[1, 1] and matrix[0, 0] > matrix[2, 2]:
        scale = math.sqrt(
            1.0 + matrix[0, 0] - matrix[1, 1] - matrix[2, 2]
        ) * 2.0
        w = (matrix[2, 1] - matrix[1, 2]) / scale
        x = 0.25 * scale
        y = (matrix[0, 1] + matrix[1, 0]) / scale
        z = (matrix[0, 2] + matrix[2, 0]) / scale
    elif matrix[1, 1] > matrix[2, 2]:
        scale = math.sqrt(
            1.0 + matrix[1, 1] - matrix[0, 0] - matrix[2, 2]
        ) * 2.0
        w = (matrix[0, 2] - matrix[2, 0]) / scale
        x = (matrix[0, 1] + matrix[1, 0]) / scale
        y = 0.25 * scale
        z = (matrix[1, 2] + matrix[2, 1]) / scale
    else:
        scale = math.sqrt(
            1.0 + matrix[2, 2] - matrix[0, 0] - matrix[1, 1]
        ) * 2.0
        w = (matrix[1, 0] - matrix[0, 1]) / scale
        x = (matrix[0, 2] + matrix[2, 0]) / scale
        y = (matrix[1, 2] + matrix[2, 1]) / scale
        z = 0.25 * scale

    quaternion = np.array([x, y, z, w], dtype=float)
    return quaternion / np.linalg.norm(quaternion)


def quaternion_to_rotation(quaternion):
    x, y, z, w = quaternion / np.linalg.norm(quaternion)

    return np.array([
        [
            1 - 2 * (y * y + z * z),
            2 * (x * y - z * w),
            2 * (x * z + y * w),
        ],
        [
            2 * (x * y + z * w),
            1 - 2 * (x * x + z * z),
            2 * (y * z - x * w),
        ],
        [
            2 * (x * z - y * w),
            2 * (y * z + x * w),
            1 - 2 * (x * x + y * y),
        ],
    ])


def joint_report(q):
    hard_ok = True
    margins_deg = []

    for value, (lower, upper) in zip(q, JOINT_LIMITS):
        if not lower <= value <= upper:
            hard_ok = False

        margin = min(value - lower, upper - value)
        margins_deg.append(math.degrees(margin))

    return hard_ok, min(margins_deg), margins_deg


def estimate_candidate_motion_metrics(
    q,
    reference_q,
    v_max_rad_s: float,
    j6_v_max_rad_s: float,
    motion_profile: str,
) -> dict:
    """Estimate synchronized move time using the executor's speed limits."""
    global_delta = max(abs(a - b) for a, b in zip(q, reference_q))
    j6_delta = abs(float(q[5]) - float(reference_q[5]))
    global_duration = motion_duration_s(
        global_delta,
        v_max_rad_s,
        motion_profile,
    )
    j6_duration = motion_duration_s(
        j6_delta,
        j6_v_max_rad_s,
        motion_profile,
        minimum_s=0.0,
    )
    return {
        "j6_delta_from_reference_rad": j6_delta,
        "estimated_motion_duration_s": max(
            global_duration,
            j6_duration,
        ),
    }


def candidate_selection_key(candidate: dict) -> tuple:
    """Prefer the fastest valid synchronized route, then less wrist travel."""
    return (
        candidate["estimated_motion_duration_s"],
        candidate["j6_delta_from_reference_rad"],
        candidate["max_delta_from_reference_rad"],
        -candidate["minimum_joint_margin_deg"],
        candidate["position_error_mm"],
        candidate["orientation_error_deg"],
    )


def evaluate_fixed_candidate(
    q,
    solver,
    target_xyz,
    target_z_mm,
    target_rotation,
    orientation_name,
    reference_q,
    reference_name,
):
    """按与IK候选相同的规则验证一个精确示教关节姿态。"""
    fk = [float(value) for value in solver.forward_quat(q)]
    fk_rotation = quaternion_to_rotation(np.array(fk[3:], dtype=float))
    position_error_mm = (
        np.linalg.norm(np.array(fk[:3]) - target_xyz) * 1000.0
    )
    target_height_clearance_mm = fk[2] * 1000.0 - target_z_mm
    orientation_error_deg = math.degrees(
        math.acos(
            np.clip(
                (np.trace(fk_rotation.T @ target_rotation) - 1.0) / 2.0,
                -1.0,
                1.0,
            )
        )
    )
    hard_ok, minimum_margin_deg, margins_deg = joint_report(q)
    ready_delta = max(abs(a - b) for a, b in zip(q, READY_Q))
    reference_delta = max(abs(a - b) for a, b in zip(q, reference_q))
    valid = (
        hard_ok
        and minimum_margin_deg >= MIN_MARGIN_DEG
        and position_error_mm <= MAX_POSITION_ERROR_MM
        and orientation_error_deg <= MAX_ORIENTATION_ERROR_DEG
        and target_height_clearance_mm >= -0.001
        and reference_delta <= MAX_STANDOFF_GRASP_DELTA_RAD
    )
    return {
        "q": list(q),
        "orientation": orientation_name,
        "source": "captured_joint_rad",
        "fk_xyz_mm": [1000.0 * value for value in fk[:3]],
        "position_error_mm": position_error_mm,
        "target_height_clearance_mm": target_height_clearance_mm,
        "orientation_error_deg": orientation_error_deg,
        "joint_margins_deg": margins_deg,
        "minimum_joint_margin_deg": minimum_margin_deg,
        "max_delta_from_ready_rad": ready_delta,
        "reference_waypoint": reference_name,
        "max_delta_from_reference_rad": reference_delta,
        "direct_ready_segment_ok": ready_delta <= MAX_READY_DELTA_RAD,
        "valid": valid,
    }


def resolve_project_path(raw_path):
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def load_base_hover_plan(raw_path):
    """加载hover/分段下降计划，供追加下一个下降路点。"""
    path = resolve_project_path(raw_path)
    if not path.is_file():
        raise FileNotFoundError(f"基础悬停计划不存在: {path}")

    plan = json.loads(path.read_text(encoding="utf-8"))
    raw_joint_path = plan.get("joint_path")
    if not isinstance(raw_joint_path, list):
        raise ValueError("基础悬停计划缺少joint_path")

    names = [str(item.get("name", "")).lower() for item in raw_joint_path]
    if not names or names[0] != "ready":
        raise ValueError(f"基础计划必须从ready开始: {names}")
    hover_indices = [
        index for index, name in enumerate(names)
        if name in {"hover", "standoff"}
    ]
    if len(hover_indices) != 1:
        raise ValueError("基础计划必须且只能包含一个hover或standoff")
    hover_index = hover_indices[0]
    before_hover = names[1:hover_index]
    if len(before_hover) > 1 or (
        before_hover and before_hover[0] not in {"midpoint", "approach"}
    ):
        raise ValueError(
            f"hover前最多允许一个midpoint/approach路点: {names}"
        )
    tail = names[hover_index + 1:]
    expected_tail = [
        f"descent_{index:02d}" for index in range(1, len(tail) + 1)
    ]
    if tail != expected_tail:
        raise ValueError(
            "基础计划hover后的路点必须为连续编号的"
            f"descent_01...，实际为: {tail}"
        )

    cleaned_path = []
    for name, item in zip(names, raw_joint_path):
        raw_q = item.get("q")
        if not isinstance(raw_q, list) or len(raw_q) != 6:
            raise ValueError(f"基础计划路点{name}的q必须为6维数组")
        q = [float(value) for value in raw_q]
        if not all(math.isfinite(value) for value in q):
            raise ValueError(f"基础计划路点{name}包含NaN或Inf")
        cleaned_path.append({"name": name, "q": q})

    if max(
        abs(a - b) for a, b in zip(cleaned_path[0]["q"], READY_Q)
    ) > 1e-5:
        raise ValueError("基础计划的ready与项目READY_Q不一致")

    target_xyz_mm = plan.get("target_xyz_mm")
    if not isinstance(target_xyz_mm, list) or len(target_xyz_mm) != 3:
        raise ValueError("基础悬停计划缺少3维target_xyz_mm")
    target_xyz_mm = [float(value) for value in target_xyz_mm]
    if not all(math.isfinite(value) for value in target_xyz_mm):
        raise ValueError("基础悬停计划target_xyz_mm包含NaN或Inf")

    rotation = validate_topdown_rotation(
        plan.get("target_rotation_matrix")
    )

    orientation_name = str(
        plan.get("selected", {}).get("orientation", "")
    )
    supported_names = {
        "as-is", "roll180", "edge", "edge_roll180",
        "edge90", "edge90_roll180",
    }
    if orientation_name not in supported_names:
        raise ValueError("基础计划缺少受支持的selected.orientation")

    return (
        path,
        plan,
        cleaned_path,
        target_xyz_mm,
        orientation_name,
        rotation,
    )


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="50mm方块顶部安全悬停/抓取纯离线IK规划"
    )
    parser.add_argument(
        "--pose-file",
        default="data/captured_poses/cube50_hover_v1.json",
    )
    parser.add_argument("--target-z-mm", type=float)
    parser.add_argument(
        "--base-plan",
        help="已有hover/分段下降计划；提供后把本次IK结果追加到末尾",
    )
    parser.add_argument(
        "--waypoint-name",
        default="grasp",
        help="追加路点名称：grasp或连续编号的descent_XX",
    )
    parser.add_argument(
        "--max-descent-step-mm",
        type=float,
        default=DEFAULT_MAX_DESCENT_STEP_MM,
        help="从基础计划末路点到新路点的最大下降量；默认30mm",
    )
    parser.add_argument(
        "--use-captured-grasp",
        action="store_true",
        help="追加grasp时精确采用pose-file中的joint_rad，不重新选择IK姿态",
    )
    parser.add_argument("--random-seeds", type=int, default=60)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument(
        "--motion-profile",
        choices=MOTION_PROFILES,
        default=DEFAULT_MOTION_PROFILE,
        help="候选预计运动时间所用曲线；必须与执行器一致",
    )
    parser.add_argument(
        "--v-max-rad-s",
        type=float,
        default=DEFAULT_V_MAX_RAD_S,
        help="候选评分所用全局规划峰值rad/s；默认0.20",
    )
    parser.add_argument(
        "--j6-v-max-rad-s",
        type=float,
        default=DEFAULT_J6_V_MAX_RAD_S,
        help="候选评分所用J6独立规划峰值rad/s；默认0.10",
    )
    parser.add_argument(
        "--output",
        help="输出计划JSON；未指定时按hover/grasp模式选择默认文件名",
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)

    waypoint_name = str(args.waypoint_name).strip().lower()
    if waypoint_name != "grasp" and not re.fullmatch(
        r"descent_[0-9]{2}", waypoint_name
    ):
        raise ValueError("--waypoint-name必须是grasp或descent_XX")
    if (
        not math.isfinite(args.max_descent_step_mm)
        or args.max_descent_step_mm <= 0.0
    ):
        raise ValueError("--max-descent-step-mm必须是大于0的有限数")
    if args.base_plan is None and waypoint_name != "grasp":
        raise ValueError("无--base-plan时只生成hover，不接受descent_XX名称")
    for name, value in (
        ("v-max-rad-s", args.v_max_rad_s),
        ("j6-v-max-rad-s", args.j6_v_max_rad_s),
    ):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"--{name}必须是大于0的有限数")

    pose_path = resolve_project_path(args.pose_file)
    record = json.loads(pose_path.read_text(encoding="utf-8"))
    recorded_xyz_mm = [float(value) for value in record["tcp_xyz_mm"]]
    recorded_joint_q = [float(value) for value in record["joint_rad"]]
    if len(recorded_xyz_mm) != 3 or not all(
        math.isfinite(value) for value in recorded_xyz_mm
    ):
        raise ValueError("pose-file中的tcp_xyz_mm必须是3个有限数")
    if len(recorded_joint_q) != 6 or not all(
        math.isfinite(value) for value in recorded_joint_q
    ):
        raise ValueError("pose-file中的joint_rad必须是6个有限数")
    if args.use_captured_grasp and args.base_plan is None:
        raise ValueError("--use-captured-grasp必须与--base-plan一起使用")
    if args.use_captured_grasp and args.target_z_mm is not None:
        raise ValueError(
            "--use-captured-grasp会采用示教TCP高度，不能再指定--target-z-mm"
        )

    target_z_mm = args.target_z_mm
    if args.base_plan is None:
        if target_z_mm is None:
            target_z_mm = 80.0
        default_output = "data/plans/cube50_hover_plan.json"
    else:
        if args.use_captured_grasp:
            target_z_mm = recorded_xyz_mm[2]
        elif target_z_mm is None:
            raise ValueError("追加grasp时必须显式给出--target-z-mm")
        default_output = f"data/plans/cube50_{waypoint_name}_plan.json"

    if not math.isfinite(target_z_mm):
        raise ValueError("--target-z-mm必须是有限数")

    output_path = resolve_project_path(args.output or default_output)

    if output_path.exists() and not args.overwrite:
        raise FileExistsError(
            f"{output_path} 已存在；如需覆盖请添加 --overwrite"
        )

    base_plan_path = None
    base_plan = None
    base_joint_path = None
    base_orientation_name = None
    base_target_rotation = None
    if args.base_plan is not None:
        (
            base_plan_path,
            base_plan,
            base_joint_path,
            base_target_xyz_mm,
            base_orientation_name,
            base_target_rotation,
        ) = load_base_hover_plan(args.base_plan)
        if output_path == base_plan_path:
            raise ValueError("输出文件不能覆盖基础悬停计划")
        descent_mm = base_target_xyz_mm[2] - target_z_mm
        if descent_mm <= 0.0 or descent_mm > args.max_descent_step_mm:
            raise ValueError(
                f"追加{waypoint_name}下降{descent_mm:.1f}mm不在"
                f"(0, {args.max_descent_step_mm:.1f}]mm"
            )
        existing_descent_count = sum(
            item["name"].startswith("descent_") for item in base_joint_path
        )
        if waypoint_name.startswith("descent_"):
            expected_name = f"descent_{existing_descent_count + 1:02d}"
            if waypoint_name != expected_name:
                raise ValueError(
                    f"下一下降路点必须命名为{expected_name}，实际为{waypoint_name}"
                )
        target_x_mm = base_target_xyz_mm[0]
        target_y_mm = base_target_xyz_mm[1]
    else:
        descent_mm = None
        target_x_mm = recorded_xyz_mm[0]
        target_y_mm = recorded_xyz_mm[1]

    target_xyz = np.array([
        target_x_mm / 1000.0,
        target_y_mm / 1000.0,
        target_z_mm / 1000.0,
    ])

    tcp = load_tcp(verbose=True)
    from S1_SDK import S1_solver
    solver = S1_solver(tcp)

    rng = np.random.RandomState(0)
    seeds = [
        recorded_joint_q,
        list(READY_Q),
        list(GRASP_REGION_SEED_Q),
        [0.0, 1.2, 0.9, -0.7, 0.0, 0.0],
        [0.0, 1.4, 0.6, -0.7, 0.0, 0.0],
        [0.0, 0.9, 1.4, -0.3, 0.0, 0.0],
    ]
    if base_joint_path is not None:
        seeds.insert(0, list(base_joint_path[-1]["q"]))

    for _ in range(args.random_seeds):
        seeds.append([
            float(rng.uniform(lower, upper))
            for lower, upper in JOINT_LIMITS
        ])

    orientations = orientation_candidates_from_pose(record)
    if base_orientation_name is not None:
        assert base_target_rotation is not None
        orientations = [(base_orientation_name, base_target_rotation)]

    candidates = []
    solved_count = 0

    with hush_sdk():
        for orientation_name, target_rotation in orientations:
            target_quaternion = rotation_to_quaternion(target_rotation)
            target_pose = list(target_xyz) + list(target_quaternion)

            for _ in range(args.rounds):
                for seed in seeds:
                    solution = solver.inverse_quat(
                        target_pose,
                        list(seed),
                    )
                    if not solution:
                        continue

                    q = [float(value) for value in solution]
                    solved_count += 1

                    if any(
                        max(abs(a - b) for a, b in zip(q, old["q"]))
                        < 1e-3
                        for old in candidates
                    ):
                        continue

                    fk = [float(value) for value in solver.forward_quat(q)]
                    fk_rotation = quaternion_to_rotation(
                        np.array(fk[3:], dtype=float)
                    )

                    position_error_mm = (
                        np.linalg.norm(
                            np.array(fk[:3]) - target_xyz
                        ) * 1000.0
                    )
                    target_height_clearance_mm = (
                        fk[2] * 1000.0 - target_z_mm
                    )

                    orientation_error_deg = math.degrees(
                        math.acos(
                            np.clip(
                                (
                                    np.trace(
                                        fk_rotation.T @ target_rotation
                                    ) - 1.0
                                ) / 2.0,
                                -1.0,
                                1.0,
                            )
                        )
                    )

                    hard_ok, minimum_margin_deg, margins_deg = (
                        joint_report(q)
                    )
                    ready_delta = max(
                        abs(a - b) for a, b in zip(q, READY_Q)
                    )
                    if base_joint_path is None:
                        reference_q = list(READY_Q)
                        reference_name = "ready"
                    else:
                        reference_q = base_joint_path[-1]["q"]
                        reference_name = base_joint_path[-1]["name"]
                    reference_delta = max(
                        abs(a - b) for a, b in zip(q, reference_q)
                    )

                    valid = (
                        hard_ok
                        and minimum_margin_deg >= MIN_MARGIN_DEG
                        and position_error_mm <= MAX_POSITION_ERROR_MM
                        and orientation_error_deg
                        <= MAX_ORIENTATION_ERROR_DEG
                        and (
                            base_joint_path is None
                            or target_height_clearance_mm >= -0.001
                        )
                        and (
                            base_joint_path is None
                            or reference_delta
                            <= MAX_STANDOFF_GRASP_DELTA_RAD
                        )
                    )

                    candidates.append({
                        "q": q,
                        "orientation": orientation_name,
                        "source": "ik",
                        "fk_xyz_mm": [
                            1000.0 * value for value in fk[:3]
                        ],
                        "position_error_mm": position_error_mm,
                        "target_height_clearance_mm": (
                            target_height_clearance_mm
                        ),
                        "orientation_error_deg": orientation_error_deg,
                        "joint_margins_deg": margins_deg,
                        "minimum_joint_margin_deg": minimum_margin_deg,
                        "max_delta_from_ready_rad": ready_delta,
                        "reference_waypoint": reference_name,
                        "max_delta_from_reference_rad": reference_delta,
                        "direct_ready_segment_ok": (
                            ready_delta <= MAX_READY_DELTA_RAD
                        ),
                        "valid": valid,
                    })

        exact_captured_candidate = None
        if args.use_captured_grasp:
            assert base_joint_path is not None
            orientation_name, target_rotation = orientations[0]
            exact_captured_candidate = evaluate_fixed_candidate(
                recorded_joint_q,
                solver,
                target_xyz,
                target_z_mm,
                target_rotation,
                orientation_name,
                base_joint_path[-1]["q"],
                base_joint_path[-1]["name"],
            )
            candidates.append(exact_captured_candidate)
            solved_count += 1

        print("\n全部唯一候选诊断：")

    selection_reference_q = (
        list(READY_Q)
        if base_joint_path is None
        else list(base_joint_path[-1]["q"])
    )
    for candidate in candidates:
        candidate.update(estimate_candidate_motion_metrics(
            candidate["q"],
            selection_reference_q,
            args.v_max_rad_s,
            args.j6_v_max_rad_s,
            args.motion_profile,
        ))

    print(
        "MOTION_SCORING =",
        f"profile={args.motion_profile} ",
        f"v_max={args.v_max_rad_s:.3f}rad/s ",
        f"j6_v_max={args.j6_v_max_rad_s:.3f}rad/s",
    )

    for index, candidate in enumerate(candidates, start=1):
        reasons = []

        if (
            candidate["minimum_joint_margin_deg"]
            < MIN_MARGIN_DEG
        ):
            reasons.append(
                "joint_margin"
                f"<{MIN_MARGIN_DEG:.1f}deg"
            )

        if (
            candidate["max_delta_from_ready_rad"]
            > MAX_READY_DELTA_RAD
            and base_joint_path is None
        ):
            reasons.append(
                "ready_delta"
                f">{MAX_READY_DELTA_RAD:.3f}rad"
            )

        if (
            base_joint_path is not None
            and candidate["max_delta_from_reference_rad"]
            > MAX_STANDOFF_GRASP_DELTA_RAD
        ):
            reasons.append(
                f"{candidate['reference_waypoint']}_delta"
                f">{MAX_STANDOFF_GRASP_DELTA_RAD:.3f}rad"
            )

        if (
            candidate["position_error_mm"]
            > MAX_POSITION_ERROR_MM
        ):
            reasons.append(
                "position_error"
                f">{MAX_POSITION_ERROR_MM:.1f}mm"
            )

        if (
            candidate["orientation_error_deg"]
            > MAX_ORIENTATION_ERROR_DEG
        ):
            reasons.append(
                "orientation_error"
                f">{MAX_ORIENTATION_ERROR_DEG:.1f}deg"
            )

        if (
            base_joint_path is not None
            and candidate["target_height_clearance_mm"] < 0.0
        ):
            reasons.append("fk_z<target_z")

        q_deg = [
            round(math.degrees(value), 2)
            for value in candidate["q"]
        ]

        print(
            f"RAW_CANDIDATE_{index}: "
            f"source={candidate.get('source', 'unknown')} "
            f"orientation={candidate['orientation']} "
            f"q_deg={q_deg} "
            f"pos_err={candidate['position_error_mm']:.3f}mm "
            f"ori_err={candidate['orientation_error_deg']:.3f}deg "
            f"min_margin="
            f"{candidate['minimum_joint_margin_deg']:.2f}deg "
            f"ready_delta="
            f"{candidate['max_delta_from_ready_rad']:.3f}rad "
            f"reference_delta="
            f"{candidate['max_delta_from_reference_rad']:.3f}rad "
            f"j6_delta="
            f"{math.degrees(candidate['j6_delta_from_reference_rad']):.2f}deg "
            f"est_duration="
            f"{candidate['estimated_motion_duration_s']:.3f}s "
            f"z_clearance="
            f"{candidate['target_height_clearance_mm']:+.6f}mm "
            f"reject={reasons or ['NONE']}"
        )

    valid_candidates = [
        candidate for candidate in candidates if candidate["valid"]
    ]

    valid_candidates.sort(key=candidate_selection_key)

    print("OFFLINE_ONLY：未访问串口，未检查实机碰撞。")
    if base_plan_path is not None:
        print("BASE_PLAN =", base_plan_path)
        print("APPENDED_WAYPOINT =", waypoint_name)
        print("DESCENT_STEP_MM =", round(descent_mm, 3))
    print(
        "TARGET_XYZ_MM =",
        [round(value * 1000.0, 3) for value in target_xyz],
    )
    print("TARGET_APPROACH = [0, 0, -1]")
    print("IK_SOLUTIONS_RETURNED =", solved_count)
    print("UNIQUE_CANDIDATES =", len(candidates))
    print("VALID_CANDIDATES =", len(valid_candidates))

    if (
        args.use_captured_grasp
        and exact_captured_candidate is not None
        and not exact_captured_candidate["valid"]
    ):
        print("PLAN_FAILED：示教关节姿态未通过全部安全条件。")
        return 2

    if not valid_candidates:
        print("PLAN_FAILED：没有同时满足所有安全条件的IK解。")
        return 2

    for index, candidate in enumerate(valid_candidates[:5], start=1):
        q_deg = [
            round(math.degrees(value), 2)
            for value in candidate["q"]
        ]
        print(
            f"CANDIDATE_{index}: "
            f"source={candidate.get('source', 'unknown')} "
            f"orientation={candidate['orientation']} "
            f"q_deg={q_deg} "
            f"pos_err={candidate['position_error_mm']:.3f}mm "
            f"ori_err={candidate['orientation_error_deg']:.3f}deg "
            f"min_margin={candidate['minimum_joint_margin_deg']:.2f}deg "
            f"ready_delta={candidate['max_delta_from_ready_rad']:.3f}rad "
            f"reference_delta="
            f"{candidate['max_delta_from_reference_rad']:.3f}rad "
            f"j6_delta="
            f"{math.degrees(candidate['j6_delta_from_reference_rad']):.2f}deg "
            f"est_duration="
            f"{candidate['estimated_motion_duration_s']:.3f}s "
            f"z_clearance="
            f"{candidate['target_height_clearance_mm']:+.6f}mm"
        )

    selected = (
        exact_captured_candidate
        if args.use_captured_grasp
        else valid_candidates[0]
    )
    assert selected is not None
    selected_q = selected["q"]
    selected_rotation = dict(orientations)[selected["orientation"]]
    print(
        "TARGET_CLOSING_AXIS =",
        [round(float(value), 6) for value in selected_rotation[:, 1]],
    )

    if base_joint_path is not None:
        joint_path = [
            {"name": item["name"], "q": list(item["q"])}
            for item in base_joint_path
        ]
        joint_path.append({
            "name": waypoint_name,
            "q": selected_q,
        })
    elif selected["direct_ready_segment_ok"]:
        joint_path = [
            {
                "name": "ready",
                "q": list(READY_Q),
            },
            {
                "name": "hover",
                "q": selected_q,
            },
        ]
    else:
        midpoint_q = [
            0.5 * (start + target)
            for start, target in zip(READY_Q, selected_q)
        ]

        joint_path = [
            {
                "name": "ready",
                "q": list(READY_Q),
            },
            {
                "name": "midpoint",
                "q": midpoint_q,
            },
            {
                "name": "hover",
                "q": selected_q,
            },
        ]

    segment_deltas = []

    for previous, current in zip(joint_path, joint_path[1:]):
        delta = max(
            abs(a - b)
            for a, b in zip(previous["q"], current["q"])
        )
        segment_deltas.append({
            "from": previous["name"],
            "to": current["name"],
            "max_joint_delta_rad": delta,
        })

    print("PLANNED_JOINT_PATH:")

    for waypoint in joint_path:
        print(
            f"  {waypoint['name']}:",
            ",".join(f"{value:.6f}" for value in waypoint["q"]),
        )

    for segment in segment_deltas:
        print(
            f"  {segment['from']}->{segment['to']}: "
            f"delta={segment['max_joint_delta_rad']:.3f}rad"
        )


    plan = {
        "status": "KINEMATICS_ONLY_COLLISION_NOT_CHECKED",
        "mode": (
            "APPEND_CAPTURED_GRASP_TO_BASE_HOVER"
            if args.use_captured_grasp
            else (
                f"APPEND_{waypoint_name.upper()}_TO_BASE_PLAN"
                if base_plan_path is not None
                else "PLAN_HOVER"
            )
        ),
        "source_pose": str(pose_path),
        "source_base_plan": (
            str(base_plan_path) if base_plan_path is not None else None
        ),
        "appended_waypoint_name": (
            waypoint_name if base_plan_path is not None else None
        ),
        "descent_from_base_mm": descent_mm,
        "target_xyz_m": target_xyz.tolist(),
        "target_xyz_mm": (
            target_xyz * 1000.0
        ).tolist(),
        "target_rotation_matrix": selected_rotation.tolist(),
        "selected": selected,
        "joint_path": joint_path,
        "segment_deltas": segment_deltas,
        "valid_candidates": valid_candidates,
        "motion_scoring": {
            "motion_profile": args.motion_profile,
            "v_max_rad_s": args.v_max_rad_s,
            "j6_v_max_rad_s": args.j6_v_max_rad_s,
            "selection_order": [
                "estimated_motion_duration_s",
                "j6_delta_from_reference_rad",
                "max_delta_from_reference_rad",
                "negative_minimum_joint_margin_deg",
                "position_error_mm",
                "orientation_error_deg",
            ],
        },
        "thresholds": {
            "minimum_joint_margin_deg": MIN_MARGIN_DEG,
            "max_delta_from_ready_rad": MAX_READY_DELTA_RAD,
            "max_standoff_grasp_delta_rad": (
                MAX_STANDOFF_GRASP_DELTA_RAD
            ),
            "max_descent_step_mm": args.max_descent_step_mm,
            "max_position_error_mm": MAX_POSITION_ERROR_MM,
            "max_orientation_error_deg": MAX_ORIENTATION_ERROR_DEG,
        },
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(plan, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(
        "SELECTED_Q_CSV =",
        ",".join(f"{value:.6f}" for value in selected["q"]),
    )
    print("PLAN_SAVED =", output_path)
    print("COLLISION_NOT_CHECKED：禁止直接执行该关节角。")


if __name__ == "__main__":
    raise SystemExit(main())
