#!/usr/bin/env python3
"""Run the bound Go2 visual alignment plus a no-contact descent round trip."""
from pathlib import Path
import sys

from run_go2_visual_alignment import main


DEFAULT_DESCENT_CONFIG = (
    Path(__file__).resolve().parents[1]
    / "config"
    / "go2_crouch_right_visual_safe_descent_nocw_metalbracket_v1.json"
)


if __name__ == "__main__":
    argv = list(sys.argv[1:])
    if "--config" not in argv:
        argv = ["--config", str(DEFAULT_DESCENT_CONFIG), *argv]
    raise SystemExit(main(argv))
