#!/usr/bin/env python3
"""Summarize existing CommandTrace JSONL without importing hardware packages."""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path


def number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{name} must be a finite number')
    return float(value)


def vector(value, name):
    if not isinstance(value, list) or len(value) != 6:
        raise ValueError(f'{name} must contain six values')
    return [number(x, name) for x in value]


def analyze_trace(rows):
    """Use logged per-command deltas; never divide skipped-row motion by one tick.

    Measured-position rates are averages between recorded snapshots, sampled
    before their respective commands. They are neither SDK velocity samples
    nor evidence of fresh per-motor feedback. Exact repeats may be quantization,
    stationary motion, or cached feedback, and are reported without diagnosing it.
    """
    segments = []
    previous = None
    total = 0
    gaps = 0
    top_steps = []
    for line_number, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            raise ValueError(f'row {line_number} must be an object')
        phase = row.get('phase')
        if not isinstance(phase, str) or not phase:
            raise ValueError(f'row {line_number} has no phase')
        elapsed = number(row.get('elapsed_s'), 'elapsed_s')
        index = number(row.get('command_index'), 'command_index')
        if not index.is_integer() or index < 1:
            raise ValueError('command_index must be a positive integer')
        command = vector(row.get('command_q_rad'), 'command_q_rad')
        measured = row.get('measured_q_rad')
        measured = None if measured is None else vector(measured, 'measured_q_rad')
        delta = row.get('command_delta_rad')
        delta = None if delta is None else vector(delta, 'command_delta_rad')
        interval = row.get('command_interval_s')
        interval = None if interval is None else number(interval, 'command_interval_s')
        if interval is not None and interval <= 0:
            raise ValueError('command_interval_s must be positive when present')
        maximum_interval = number(row.get('maximum_interval_since_record_s', interval or 0),
                                  'maximum_interval_since_record_s')
        if maximum_interval < 0:
            raise ValueError('maximum interval cannot be negative')
        if interval is not None and maximum_interval + 1e-12 < interval:
            raise ValueError('maximum interval is smaller than current interval')
        if previous is not None:
            if elapsed <= previous['elapsed'] or index <= previous['index']:
                raise ValueError('trace times and command indices must increase strictly')
            if index != previous['index'] + 1:
                gaps += 1
        new_segment = not segments or segments[-1]['phase'] != phase
        if new_segment:
            segments.append(dict(phase=phase,start_s=elapsed,end_s=elapsed,recorded_rows=0,
                                 max_command_step_rad=0.,max_recorded_command_interval_s=0.,
                                 max_snapshot_tracking_error_rad=[0.]*6,
                                 max_abs_measured_window_velocity_rad_s=[0.]*6,
                                 max_exact_repeat_window_s=[0.]*6,
                                 measured_window_count=0,missing_measured_rows=0,
                                 entry_command_delta_rad=delta))
            repeat_started = [elapsed]*6
        segment = segments[-1]
        segment['end_s'] = elapsed
        segment['recorded_rows'] += 1
        segment['max_recorded_command_interval_s'] = max(
            segment['max_recorded_command_interval_s'], maximum_interval)
        if delta is not None:
            peak = max(map(abs, delta))
            segment['max_command_step_rad'] = max(segment['max_command_step_rad'], peak)
            if peak > 0:
                top_steps.append(dict(elapsed_s=elapsed,phase=phase,
                                      maximum_step_rad=peak,command_delta_rad=delta))
                top_steps = sorted(top_steps,key=lambda x:x['maximum_step_rad'],reverse=True)[:12]
        if measured is None:
            segment['missing_measured_rows'] += 1
            repeat_started = [elapsed]*6
        else:
            for j in range(6):
                segment['max_snapshot_tracking_error_rad'][j] = max(
                    segment['max_snapshot_tracking_error_rad'][j],abs(command[j]-measured[j]))
            if not new_segment and previous is not None and previous['measured'] is not None:
                dt = elapsed-previous['elapsed']
                segment['measured_window_count'] += 1
                for j in range(6):
                    change = measured[j]-previous['measured'][j]
                    segment['max_abs_measured_window_velocity_rad_s'][j] = max(
                        segment['max_abs_measured_window_velocity_rad_s'][j],abs(change/dt))
                    if change == 0:
                        segment['max_exact_repeat_window_s'][j] = max(
                            segment['max_exact_repeat_window_s'][j],elapsed-repeat_started[j])
                    else:
                        repeat_started[j] = elapsed
            else:
                repeat_started = [elapsed]*6
        previous = dict(elapsed=elapsed,index=index,measured=measured)
        total += 1
    if not total:
        raise ValueError('trace contains no records')
    return dict(schema_version=1,recorded_rows=total,recorded_index_gaps=gaps,
                measurement_timing='before_current_command',
                feedback_freshness='not established by this trace',
                measured_velocity_semantics='recorded-snapshot window average; not SDK or instantaneous velocity',
                tracking_error_semantics='current command minus pre-command snapshot; not a synchronous motor error',
                phase_semantics='labels as recorded; historical planning labels may also cover motion',
                segments=segments,largest_recorded_command_steps=top_steps)


def read_rows(path):
    with Path(path).open(encoding='utf-8-sig') as stream:
        for line_number,line in enumerate(stream,1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f'invalid JSON at line {line_number}: {exc}') from exc


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trace',type=Path)
    parser.add_argument('--output',type=Path,help='create a new report; existing files are never overwritten')
    args=parser.parse_args(argv)
    try:
        result=analyze_trace(read_rows(args.trace))
        text=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
        if args.output:
            with args.output.open('x',encoding='utf-8') as stream:
                stream.write(text)
        else:
            print(text,end='')
    except (ValueError,OSError) as exc:
        parser.exit(2,f'trace analysis failed: {exc}\n')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
