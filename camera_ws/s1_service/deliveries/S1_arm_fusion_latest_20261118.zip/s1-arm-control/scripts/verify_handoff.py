#!/usr/bin/env python3
"""Offline package integrity, entry preflight and optional fixture regression."""
import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/"scripts"),str(ROOT/"tests")]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tests",action="store_true")
    args=parser.parse_args()
    os.chdir(ROOT)
    for line in (ROOT/"SHA256SUMS").read_text().splitlines():
        digest,relative=line.split("  ",1)
        if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=digest:
            raise RuntimeError("file changed: "+relative)
    import run_arm_integration as entry
    for side,options in [("right",[]),("left",["--config","config/go2_left_full_flow_size_adaptive_20261112_v1.json","--search-plan","data/plans/go2_left_grasp_search_20261112_v1.json","data/plans/go2_left_grasp_search_20261112_v1_report.json"])]:
        with contextlib.redirect_stdout(io.StringIO()):code=entry.main(options)
        if code:raise RuntimeError(side+" preflight failed")
        print(side+" offline preflight PASS")
    if args.tests:
        modules=json.loads((ROOT/"VALIDATION.json").read_text())["test_modules"]
        result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromNames(modules))
        return 0 if result.wasSuccessful() else 1
    print("Package integrity PASS; no camera/serial access")
    return 0

if __name__=="__main__":raise SystemExit(main())
