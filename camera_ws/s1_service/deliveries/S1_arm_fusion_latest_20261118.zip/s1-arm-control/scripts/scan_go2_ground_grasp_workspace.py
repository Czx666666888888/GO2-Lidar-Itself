#!/usr/bin/env python3
"""Offline map of the commissioned Go2 right-side ground grasp workspace.

This tool never opens the S1 serial device or the D455.  It replays the exact
observed geometry and bound configuration, translates the target over a
support-plane grid, and checks four square-yaw cases at each point:

1. fixed observation-camera visibility (pinhole/FOV and depth only),
2. continuous high-view IK from the measured alignment start,
3. self/floor collision and commissioned tilt-torque envelope,
4. high-view wrist orientation plus pregrasp and low contact-height descent.

The result is candidate evidence, not permission to enlarge live bounds.  Go2,
the collection box, cables and transient obstacles are not represented by the
S1 collision model, so every new boundary still needs staged physical tests.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
from typing import Any

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SCRIPTS_DIR, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from run_go2_visual_alignment import (  # noqa: E402
    apply_local_j2_tilt_limit,
    apply_local_j3_tilt_limit,
    check_collision_path,
    compute_grasp_orientation_plan,
    compute_safe_descent_plan,
    load_alignment_config,
    resolve_adaptive_pregrasp_config,
    resolve_adaptive_secure_no_lift_config,
    resolve_project_path,
)
from s1_control.go2_deployment import file_sha256  # noqa: E402
from s1_control.go2_visual_alignment import (  # noqa: E402
    blended_support_up_normal,
    densify_joint_path,
    solve_continuous_ik_path,
    validate_torque_envelope,
)
from s1_control.kinematics import Kinematics  # noqa: E402
from s1_control.tilt_gravity import (  # noqa: E402
    UrdfGravityModel,
    differential_tilt_compensation_from_support_up,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record  # noqa: E402
from s1_control.wrist_visual_servo import load_wrist_servo_config  # noqa: E402


DEFAULT_BASELINE = (
    PROJECT_ROOT
    / "data/go2_visual_alignment_runs/"
    "new_s1_go2_50mm40g_random_orientation_full_flow_v10/run.json"
)
DEFAULT_OUTPUT = (
    PROJECT_ROOT
    / "data/workspace_scans/"
    "new_s1_go2_right_ground_workspace_coarse_v1.json"
)


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def finite_vector(raw: Any, length: int, name: str) -> np.ndarray:
    value = np.asarray(raw, dtype=np.float64)
    if value.shape != (length,) or not np.isfinite(value).all():
        raise ValueError(f"{name} must contain {length} finite values")
    return value


def unit_vector(raw: Any, name: str) -> np.ndarray:
    value = finite_vector(raw, 3, name)
    norm = float(np.linalg.norm(value))
    if norm < 1e-9:
        raise ValueError(f"{name} cannot be zero")
    return value / norm


def inclusive_values(start: float, stop: float, step: float) -> list[float]:
    if not all(math.isfinite(value) for value in (start, stop, step)):
        raise ValueError("grid bounds must be finite")
    if step <= 0.0 or stop < start:
        raise ValueError("grid requires positive step and stop >= start")
    count = int(math.floor((stop - start) / step + 1e-9))
    values = [start + index * step for index in range(count + 1)]
    if values[-1] < stop - 1e-6:
        values.append(stop)
    return [float(round(value, 9)) for value in values]


def support_plane_basis(support_up: Any) -> tuple[np.ndarray, np.ndarray]:
    normal = unit_vector(support_up, "support_up_normal_base")
    base_x = np.asarray([1.0, 0.0, 0.0], dtype=np.float64)
    axis_u = base_x - float(np.dot(base_x, normal)) * normal
    axis_u = unit_vector(axis_u, "support_plane_axis_u")
    axis_v = unit_vector(np.cross(normal, axis_u), "support_plane_axis_v")
    if float(np.dot(axis_v, [0.0, 1.0, 0.0])) < 0.0:
        axis_v = -axis_v
    return axis_u, axis_v


def rotate_about_axis(vector: Any, axis: Any, angle_deg: float) -> np.ndarray:
    value = unit_vector(vector, "vector")
    normal = unit_vector(axis, "axis")
    angle = math.radians(float(angle_deg))
    rotated = (
        value * math.cos(angle)
        + np.cross(normal, value) * math.sin(angle)
        + normal * float(np.dot(normal, value)) * (1.0 - math.cos(angle))
    )
    return unit_vector(rotated, "rotated_vector")


def cartesian_line(start_pose: Any, target_pose: Any, step_mm: float) -> list[list[float]]:
    start = finite_vector(start_pose, 7, "start_pose")
    target = finite_vector(target_pose, 7, "target_pose")
    distance_mm = 1000.0 * float(np.linalg.norm(target[:3] - start[:3]))
    count = max(1, int(math.ceil(distance_mm / float(step_mm))))
    poses = [start.tolist()]
    for index in range(1, count + 1):
        alpha = index / count
        pose = start.copy()
        pose[:3] = (1.0 - alpha) * start[:3] + alpha * target[:3]
        pose[3:] = start[3:]
        poses.append(pose.tolist())
    return poses


def camera_projection(
    point_base_m: Any,
    transform_base_camera: Any,
    intrinsics: Any,
    width: int,
    height: int,
    margin_px: float,
    minimum_depth_mm: float,
    maximum_depth_mm: float,
) -> dict:
    point = finite_vector(point_base_m, 3, "point_base_m")
    transform = np.asarray(transform_base_camera, dtype=np.float64)
    camera_matrix = np.asarray(intrinsics, dtype=np.float64)
    if transform.shape != (4, 4) or camera_matrix.shape != (3, 3):
        raise ValueError("camera transform and intrinsics have invalid shapes")
    homogeneous = np.concatenate([point, [1.0]])
    point_camera = np.linalg.inv(transform) @ homogeneous
    depth_m = float(point_camera[2])
    if depth_m <= 1e-9:
        pixel = [float("nan"), float("nan")]
    else:
        pixel = [
            float(camera_matrix[0, 0] * point_camera[0] / depth_m + camera_matrix[0, 2]),
            float(camera_matrix[1, 1] * point_camera[1] / depth_m + camera_matrix[1, 2]),
        ]
    depth_mm = 1000.0 * depth_m
    inside = bool(
        math.isfinite(pixel[0])
        and math.isfinite(pixel[1])
        and margin_px <= pixel[0] <= width - 1 - margin_px
        and margin_px <= pixel[1] <= height - 1 - margin_px
        and minimum_depth_mm <= depth_mm <= maximum_depth_mm
    )
    return {
        "point_camera_m": point_camera[:3].tolist(),
        "pixel_uv": pixel,
        "depth_mm": depth_mm,
        "margin_px": float(margin_px),
        "depth_range_mm": [float(minimum_depth_mm), float(maximum_depth_mm)],
        "fixed_observation_visible": inside,
    }


def bounds(records: list[dict], key: str) -> dict | None:
    accepted = [record for record in records if record.get(key) is True]
    if not accepted:
        return None
    uv = np.asarray([[record["u_offset_mm"], record["v_offset_mm"]] for record in accepted])
    xyz = np.asarray([record["target_top_base_xyz_mm"] for record in accepted])
    return {
        "count": len(accepted),
        "support_plane_u_mm": [float(uv[:, 0].min()), float(uv[:, 0].max())],
        "support_plane_v_mm": [float(uv[:, 1].min()), float(uv[:, 1].max())],
        "target_base_x_mm": [float(xyz[:, 0].min()), float(xyz[:, 0].max())],
        "target_base_y_mm": [float(xyz[:, 1].min()), float(xyz[:, 1].max())],
        "target_base_z_mm": [float(xyz[:, 2].min()), float(xyz[:, 2].max())],
    }


def failure(exc: Exception) -> dict:
    return {"type": type(exc).__name__, "message": str(exc)}


def scan_point(
    *,
    u_mm: float,
    v_mm: float,
    axis_u: np.ndarray,
    axis_v: np.ndarray,
    support_up: np.ndarray,
    applied_support_up: np.ndarray,
    baseline_target: np.ndarray,
    baseline_high_pose: np.ndarray,
    baseline_high_q: np.ndarray,
    baseline_edge_axis: np.ndarray,
    baseline_clearance_mm: float,
    orientation_angles_deg: list[float],
    target_height_mm: float,
    transform_base_camera: np.ndarray,
    intrinsics: np.ndarray,
    image_size: tuple[int, int],
    camera_margin_px: float,
    camera_depth_range_mm: tuple[float, float],
    alignment: dict,
    orientation_config: dict,
    pregrasp_config: dict,
    secure_config: dict,
    tcp_kinematics,
    collision_checker,
    tilt_model,
    side_scale: float,
    torque_limits: Any,
    high_path_step_mm: float,
) -> dict:
    shift = (u_mm / 1000.0) * axis_u + (v_mm / 1000.0) * axis_v
    target = baseline_target + shift
    target_high_pose = baseline_high_pose.copy()
    target_high_pose[:3] = target + (baseline_clearance_mm / 1000.0) * support_up
    record = {
        "u_offset_mm": float(u_mm),
        "v_offset_mm": float(v_mm),
        "target_top_base_xyz_mm": (1000.0 * target).tolist(),
        "high_tcp_base_xyz_mm": (1000.0 * target_high_pose[:3]).tolist(),
        "initial_alignment_distance_mm": float(
            1000.0 * np.linalg.norm(target_high_pose[:3] - baseline_high_pose[:3])
        ),
        "fixed_observation": camera_projection(
            target,
            transform_base_camera,
            intrinsics,
            image_size[0],
            image_size[1],
            camera_margin_px,
            camera_depth_range_mm[0],
            camera_depth_range_mm[1],
        ),
        "high_alignment_pass": False,
        "passing_orientation_count": 0,
        "any_orientation_grasp_geometry_pass": False,
        "all_orientations_grasp_geometry_pass": False,
        "complete_from_fixed_observation_candidate": False,
        "orientation_cases": [],
    }
    try:
        tcp_path = cartesian_line(baseline_high_pose, target_high_pose, high_path_step_mm)
        ik = solve_continuous_ik_path(
            tcp_kinematics,
            baseline_high_q.tolist(),
            tcp_path,
            maximum_joint_step_rad=float(alignment["maximum_joint_step_rad"]),
            minimum_joint_margin_deg=float(alignment["minimum_joint_margin_deg"]),
            maximum_fk_position_error_mm=float(alignment["maximum_fk_position_error_mm"]),
            maximum_fk_orientation_error_deg=float(alignment["maximum_fk_orientation_error_deg"]),
        )
        joint_path = ik["joint_path"]
        collision = check_collision_path(
            collision_checker,
            joint_path,
            float(alignment["collision_step_rad"]),
        )
        torque = validate_torque_envelope(
            densify_joint_path(joint_path, float(alignment["collision_step_rad"])),
            lambda q: side_scale
            * differential_tilt_compensation_from_support_up(
                tilt_model, q, applied_support_up
            ),
            torque_limits,
        )
        record["high_alignment"] = {
            "tcp_segment_count": len(tcp_path),
            "joint_path_count": len(joint_path),
            "minimum_joint_margin_deg": min(
                float(sample["minimum_joint_margin_deg"])
                for sample in ik.get("samples", [])
            ) if ik.get("samples") else None,
            "collision_sample_count": int(collision["sample_count"]),
            "maximum_torque_fraction": float(torque["maximum_limit_fraction"]),
            "final_q_rad": list(joint_path[-1]),
        }
        record["high_alignment_pass"] = True
    except Exception as exc:
        record["high_alignment_failure"] = failure(exc)
        return record

    final_high_q = finite_vector(
        record["high_alignment"]["final_q_rad"], 6, "final_high_q"
    )
    fake_capture = {
        "detection": {
            "selected": {
                "accepted": True,
                "target_id": "synthetic_workspace_target",
                "core_height_mm": {"p90": float(target_height_mm)},
            }
        }
    }
    effective_pregrasp, _ = resolve_adaptive_pregrasp_config(
        fake_capture, pregrasp_config
    )
    effective_secure, _ = resolve_adaptive_secure_no_lift_config(
        fake_capture, secure_config
    )
    for angle_deg in orientation_angles_deg:
        edge = rotate_about_axis(baseline_edge_axis, support_up, angle_deg)
        observation = {
            "surface_point_base_m": target.tolist(),
            "support_up_normal_base": support_up.tolist(),
            "target_edge_axis_base": edge.tolist(),
            "orientation_symmetry_period_deg": 90.0,
            "orientation_confidence_score": 1.0,
            "orientation_p90_deviation_deg": 0.0,
        }
        case = {"target_yaw_mod90_deg": float(angle_deg), "pass": False}
        stage = "orientation"
        try:
            orientation = compute_grasp_orientation_plan(
                final_high_q,
                observation,
                config=orientation_config,
                tcp_kinematics=tcp_kinematics,
                collision_checker=collision_checker,
                tilt_model=tilt_model,
                applied_support_up=applied_support_up,
                compensation_scale=side_scale,
                torque_limits=torque_limits,
            )
            selected = orientation["selected"]
            oriented_q = finite_vector(
                selected["joint_path"][-1], 6, "oriented_q"
            )
            stage = "pregrasp_descent"
            pregrasp = compute_safe_descent_plan(
                oriented_q,
                observation,
                descent_config=effective_pregrasp,
                alignment=alignment,
                tcp_kinematics=tcp_kinematics,
                collision_checker=collision_checker,
                tilt_model=tilt_model,
                applied_support_up=applied_support_up,
                side_scale=float(secure_config["pregrasp_descent_compensation_scale"]),
                torque_limits=torque_limits,
            )
            pregrasp_q = finite_vector(
                pregrasp["joint_path"][-1], 6, "pregrasp_q"
            )
            stage = "low_descent"
            low = compute_safe_descent_plan(
                pregrasp_q,
                observation,
                descent_config=effective_secure,
                alignment=alignment,
                tcp_kinematics=tcp_kinematics,
                collision_checker=collision_checker,
                tilt_model=tilt_model,
                applied_support_up=applied_support_up,
                side_scale=float(secure_config["low_stage_compensation_scale"]),
                torque_limits=torque_limits,
            )
            case.update(
                {
                    "pass": True,
                    "selected_candidate": selected["name"],
                    "rotation_from_current_deg": float(
                        selected["rotation_from_current_deg"]
                    ),
                    "orientation_minimum_joint_margin_deg": float(
                        selected["minimum_joint_margin_deg"]
                    ),
                    "orientation_maximum_torque_fraction": float(
                        selected["torque"]["maximum_limit_fraction"]
                    ),
                    "pregrasp_descent_distance_mm": float(
                        pregrasp["descent_distance_mm"]
                    ),
                    "pregrasp_minimum_joint_margin_deg": min(
                        float(sample["minimum_joint_margin_deg"])
                        for sample in pregrasp["ik"]["samples"]
                    ),
                    "pregrasp_maximum_torque_fraction": float(
                        pregrasp["torque"]["maximum_limit_fraction"]
                    ),
                    "low_descent_distance_mm": float(low["descent_distance_mm"]),
                    "low_minimum_joint_margin_deg": min(
                        float(sample["minimum_joint_margin_deg"])
                        for sample in low["ik"]["samples"]
                    ),
                    "low_maximum_torque_fraction": float(
                        low["torque"]["maximum_limit_fraction"]
                    ),
                }
            )
        except Exception as exc:
            case["failure_stage"] = stage
            case["failure"] = failure(exc)
        record["orientation_cases"].append(case)
    record["passing_orientation_count"] = sum(
        case["pass"] for case in record["orientation_cases"]
    )
    record["any_orientation_grasp_geometry_pass"] = (
        record["passing_orientation_count"] > 0
    )
    record["all_orientations_grasp_geometry_pass"] = all(
        case["pass"] for case in record["orientation_cases"]
    )
    record["complete_from_fixed_observation_candidate"] = bool(
        record["fixed_observation"]["fixed_observation_visible"]
        and record["all_orientations_grasp_geometry_pass"]
    )
    return record


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Offline candidate map for Go2 right-side ground grasp workspace"
    )
    parser.add_argument("--baseline-run", default=str(DEFAULT_BASELINE))
    parser.add_argument(
        "--confirm-baseline-placement",
        action="store_true",
        help="record that the operator saw the payload land inside the box on this run",
    )
    parser.add_argument("--config")
    parser.add_argument("--capture-npz")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--u-min-mm", type=float, default=-120.0)
    parser.add_argument("--u-max-mm", type=float, default=120.0)
    parser.add_argument("--v-min-mm", type=float, default=-120.0)
    parser.add_argument("--v-max-mm", type=float, default=120.0)
    parser.add_argument("--grid-step-mm", type=float, default=30.0)
    parser.add_argument("--high-path-step-mm", type=float, default=10.0)
    parser.add_argument("--orientation-deg", default="0,15,30,45")
    parser.add_argument("--camera-margin-px", type=float, default=55.0)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)

    baseline_path = resolve_project_path(args.baseline_run)
    baseline = load_json(baseline_path)
    baseline_status = baseline.get("status")
    if baseline_status != "VISUAL_ADAPTIVE_GRASP_BOX_PLACE_ROUND_TRIP_DONE" and not (
        baseline_status == "VISUAL_ADAPTIVE_GRASP_BOX_MOTION_DONE_PLACEMENT_UNVERIFIED"
        and args.confirm_baseline_placement
    ):
        raise ValueError("baseline needs a complete flow with confirmed placement")
    config_path = resolve_project_path(args.config or baseline["config"])
    if file_sha256(config_path) != str(baseline["config_sha256"]).lower():
        raise RuntimeError("current flow config does not match the successful baseline")
    loaded_config_path, config = load_alignment_config(config_path)
    if loaded_config_path != config_path:
        raise RuntimeError("resolved flow config path changed unexpectedly")
    plan_path = resolve_project_path(config["deployment_plan"])
    wrist_path = resolve_project_path(config["wrist_servo_config"])
    if file_sha256(plan_path) != str(baseline["plan_sha256"]).lower():
        raise RuntimeError("current deployment plan does not match the baseline")
    if file_sha256(wrist_path) != str(baseline["wrist_config_sha256"]).lower():
        raise RuntimeError("current wrist config does not match the baseline")

    capture_path = resolve_project_path(
        args.capture_npz or (baseline_path.parent / "initial_capture.npz")
    )
    capture = np.load(capture_path, allow_pickle=False)
    intrinsics = np.asarray(capture["K"], dtype=np.float64)
    rgb_shape = tuple(int(value) for value in capture["rgb"].shape)

    plan = load_json(plan_path)
    mount_path = resolve_project_path(plan["mount_config"])
    mount = load_json(mount_path)
    mount, _ = apply_local_j3_tilt_limit(mount, config["runtime"])
    mount, _ = apply_local_j2_tilt_limit(mount, config["runtime"])
    loaded = load_wrist_servo_config(wrist_path)
    alignment = dict(config["alignment"])
    initial_alignment_limit_mm = (
        None if config.get("adaptive_grasp_box_place", {}).get("adaptive_target_size", False)
        else float(alignment["maximum_initial_tangent_error_mm"])
    )
    orientation_config = dict(config["adaptive_grasp_orientation"])
    pregrasp_config = dict(config["adaptive_pregrasp"])
    secure_config = dict(config["adaptive_secure_no_lift"])
    side_scale = float(
        plan["motion"]["tilt_compensation"]["side_deploy_scale"]
    )
    torque_limits = mount["diagnostic"]["correction_absolute_limits_nm"]

    planning = baseline["planning"]
    final_observation = baseline["final_observation"]
    baseline_high_q = finite_vector(
        planning["planning_start_q_rad"], 6, "planning_start_q_rad"
    )
    baseline_target = finite_vector(
        final_observation["surface_point_base_m"], 3, "baseline_target"
    )
    support_up = unit_vector(
        final_observation["support_up_normal_base"], "support_up_normal_base"
    )
    baseline_edge = unit_vector(
        final_observation["target_edge_axis_base"], "target_edge_axis_base"
    )
    target_height_mm = float(
        baseline["final_capture"]["detection"]["selected"]["core_height_mm"][
            pregrasp_config["height_statistic"]
        ]
    )
    transform_base_camera = np.asarray(planning["T_base_camera"], dtype=np.float64)
    axis_u, axis_v = support_plane_basis(support_up)

    from S1_SDK.hardware.collision import CollisionChecker

    collision_checker = CollisionChecker("gripper")
    if collision_checker.model is None:
        collision_checker._load_model(gripper=True)
    if collision_checker.model is None or collision_checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")
    tcp_kinematics = Kinematics(verbose=False)
    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    commander = commander_from_mount_record(tilt_model, mount, side_scale)
    applied_support_up = blended_support_up_normal(
        commander.nominal_support_up_normal_base,
        support_up,
        float(loaded.record["tilt_compensation"]["support_normal_blend"]),
    )
    baseline_high_pose = finite_vector(
        tcp_kinematics.fk(baseline_high_q.tolist()), 7, "baseline_high_pose"
    )

    baseline_clearance_mm = float(
        1000.0 * np.dot(baseline_high_pose[:3] - baseline_target, support_up)
    )
    detector_roi = planning["initial_capture"]["detection"]["workspace_roi_px"]
    roi_x0, roi_y0, roi_x1, roi_y1 = detector_roi
    angles = [float(value.strip()) for value in args.orientation_deg.split(",")]
    if not angles or any(not 0.0 <= value <= 45.0 for value in angles):
        raise ValueError("orientation-deg values must be within [0, 45]")
    u_values = inclusive_values(args.u_min_mm, args.u_max_mm, args.grid_step_mm)
    v_values = inclusive_values(args.v_min_mm, args.v_max_mm, args.grid_step_mm)
    minimum_depth_mm = float(loaded.record["safety"]["minimum_camera_target_depth_mm"])
    maximum_depth_mm = float(loaded.record["safety"]["maximum_camera_target_depth_mm"])

    print("OFFLINE_ONLY = True")
    print("ARM_SERIAL_ACCESS = False")
    print("CAMERA_ACCESS = False")
    print("BASELINE_RUN =", baseline_path)
    print("CONFIG_SHA256 =", baseline["config_sha256"])
    print("PLAN_SHA256 =", baseline["plan_sha256"])
    print("GRID_POINT_COUNT =", len(u_values) * len(v_values))
    print("ORIENTATION_CASES_DEG =", angles)

    records = []
    failure_counts: Counter[str] = Counter()
    for u_mm in u_values:
        for v_mm in v_values:
            record = scan_point(
                u_mm=u_mm,
                v_mm=v_mm,
                axis_u=axis_u,
                axis_v=axis_v,
                support_up=support_up,
                applied_support_up=applied_support_up,
                baseline_target=baseline_target,
                baseline_high_pose=baseline_high_pose,
                baseline_high_q=baseline_high_q,
                baseline_edge_axis=baseline_edge,
                baseline_clearance_mm=baseline_clearance_mm,
                orientation_angles_deg=angles,
                target_height_mm=target_height_mm,
                transform_base_camera=transform_base_camera,
                intrinsics=intrinsics,
                image_size=(rgb_shape[1], rgb_shape[0]),
                camera_margin_px=float(args.camera_margin_px),
                camera_depth_range_mm=(minimum_depth_mm, maximum_depth_mm),
                alignment=alignment,
                orientation_config=orientation_config,
                pregrasp_config=pregrasp_config,
                secure_config=secure_config,
                tcp_kinematics=tcp_kinematics,
                collision_checker=collision_checker,
                tilt_model=tilt_model,
                side_scale=side_scale,
                torque_limits=torque_limits,
                high_path_step_mm=float(args.high_path_step_mm),
            )
            pixel_u, pixel_v = record["fixed_observation"]["pixel_uv"]
            record["fixed_observation"]["center_inside_detector_roi"] = bool(
                roi_x0 <= pixel_u < roi_x1 and roi_y0 <= pixel_v < roi_y1
            )
            record["within_current_initial_alignment_limit"] = (
                None if initial_alignment_limit_mm is None
                else record["initial_alignment_distance_mm"] <= initial_alignment_limit_mm
            )
            records.append(record)
            if "high_alignment_failure" in record:
                failure_counts[
                    "high:" + record["high_alignment_failure"]["type"]
                ] += 1
            for case in record["orientation_cases"]:
                if not case["pass"]:
                    failure_counts[
                        "grasp:" + case["failure"]["type"]
                    ] += 1
            print(
                "POINT"
                f" u={u_mm:+.1f} v={v_mm:+.1f}"
                f" visible={record['fixed_observation']['fixed_observation_visible']}"
                f" high={record['high_alignment_pass']}"
                " all_yaw="
                f"{record['all_orientations_grasp_geometry_pass']}"
            )

    summary = {
        "grid_point_count": len(records),
        "fixed_observation_visible_count": sum(
            bool(record["fixed_observation"]["fixed_observation_visible"])
            for record in records
        ),
        "high_alignment_pass_count": sum(
            bool(record["high_alignment_pass"]) for record in records
        ),
        "any_orientation_grasp_geometry_pass_count": sum(
            record["any_orientation_grasp_geometry_pass"] for record in records
        ),
        "inside_detector_roi_count": sum(
            record["fixed_observation"]["center_inside_detector_roi"] for record in records
        ),
        "within_current_initial_alignment_limit_count": (
            None if initial_alignment_limit_mm is None else sum(
                record["within_current_initial_alignment_limit"] for record in records
            )
        ),
        "all_orientations_grasp_geometry_pass_count": sum(
            bool(record["all_orientations_grasp_geometry_pass"])
            for record in records
        ),
        "complete_from_fixed_observation_candidate_count": sum(
            bool(record["complete_from_fixed_observation_candidate"])
            for record in records
        ),
        "failure_counts": dict(sorted(failure_counts.items())),
        "fixed_observation_visible_bounds": bounds(
            [
                {
                    **record,
                    "visible": record["fixed_observation"][
                        "fixed_observation_visible"
                    ],
                }
                for record in records
            ],
            "visible",
        ),
        "high_alignment_bounds": bounds(records, "high_alignment_pass"),
        "all_orientations_grasp_geometry_bounds": bounds(
            records, "all_orientations_grasp_geometry_pass"
        ),
        "complete_from_fixed_observation_candidate_bounds": bounds(
            records, "complete_from_fixed_observation_candidate"
        ),
    }
    output = {
        "schema_version": 1,
        "mode": "go2_right_ground_grasp_workspace_offline_scan",
        "status": "offline_candidate_only_pending_staged_physical_validation",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "arm_serial_access": False,
        "camera_access": False,
        "baseline": {
            "run": str(baseline_path.relative_to(PROJECT_ROOT)),
            "run_sha256": file_sha256(baseline_path),
            "run_status": baseline_status,
            "placement_confirmed_by_operator": args.confirm_baseline_placement,
            "config": str(config_path.relative_to(PROJECT_ROOT)),
            "config_sha256": file_sha256(config_path),
            "plan": str(plan_path.relative_to(PROJECT_ROOT)),
            "plan_sha256": file_sha256(plan_path),
            "wrist_config": str(wrist_path.relative_to(PROJECT_ROOT)),
            "wrist_config_sha256": file_sha256(wrist_path),
            "capture_npz": str(capture_path.relative_to(PROJECT_ROOT)),
            "capture_npz_sha256": file_sha256(capture_path),
            "target_top_base_xyz_mm": (1000.0 * baseline_target).tolist(),
            "high_tcp_base_xyz_mm": (
                1000.0 * baseline_target + baseline_clearance_mm * support_up
            ).tolist(),
            "alignment_start_q_rad": baseline_high_q.tolist(),
            "alignment_start_tcp_base_xyz_mm": (
                1000.0 * baseline_high_pose[:3]
            ).tolist(),
            "normal_clearance_mm": baseline_clearance_mm,
            "target_height_mm": target_height_mm,
        },
        "support_plane_frame": {
            "support_up_normal_base": support_up.tolist(),
            "applied_support_up_normal_base": applied_support_up.tolist(),
            "axis_u_base": axis_u.tolist(),
            "axis_v_base": axis_v.tolist(),
            "interpretation": "u is projected base +X; v is chosen toward base +Y",
        },
        "scan_parameters": {
            "u_values_mm": u_values,
            "v_values_mm": v_values,
            "orientation_cases_deg": angles,
            "orientation_angles_relative_to_observed_baseline_edge": True,
            "current_initial_alignment_limit_mm": initial_alignment_limit_mm,
            "detector_roi_px": detector_roi,
            "high_path_step_mm": float(args.high_path_step_mm),
            "camera_margin_px": float(args.camera_margin_px),
            "tilt_correction_absolute_limits_nm": torque_limits,
            "camera_depth_range_mm": [minimum_depth_mm, maximum_depth_mm],
        },
        "model_limitations": [
            "candidate evidence only; live workspace bounds are not modified",
            "collision model does not include the full Go2 body, box, cables or people",
            "fixed-observation visibility is a pinhole/depth check, not an occlusion or detector guarantee",
            "all new boundary points require staged supervised physical validation",
        ],
        "summary": summary,
        "points": records,
    }
    output_path = resolve_project_path(args.output)
    if output_path.exists() and not args.overwrite:
        raise FileExistsError(f"output already exists: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("SUMMARY =", json.dumps(summary, ensure_ascii=False, sort_keys=True))
    print("OUTPUT =", output_path)
    print("RESULT = OFFLINE_WORKSPACE_SCAN_DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
