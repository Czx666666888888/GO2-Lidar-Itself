#!/usr/bin/env python3
"""Supervised first-motion diagnostic for a newly installed S1 arm.

The operator teaches a collision-free high-hover pose.  The script locks that
exact pose, moves only J1 by a small positive angle, holds briefly, and returns
to the taught pose.  It never accesses a camera or commands the gripper.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import re
import statistics
import sys
import threading
import time


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
for path in (PROJECT_ROOT, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from diagnose_wrist_hold_tracking import finite_vector, wait_for_valid_feedback
from s1_control.arm import (
    Arm,
    J6_INDEX,
    SafetyLimits,
    motion_duration_s,
    motion_profile_progress,
)
from s1_control.kinematics import Kinematics
from s1_control.wrist_visual_servo import joint_margin_details


DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "small_joint_motion_runs"
RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
J1_INDEX = 0
LOCK_MAXIMUM_SPAN_RAD = 0.01
MOTION_SETTLE_SECONDS = 1.0
ENDPOINT_SETTLE_SECONDS = 0.5
MOTION_START_MAX_DRIFT_RAD = 0.01
MOTION_START_MAX_SPAN_RAD = 0.003


def parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        description="新S1首次小范围运动：示教锁定后J1微动并原路返回"
    )
    ap.add_argument("--dev", default="/dev/ttyUSB0")
    ap.add_argument("--end", default="gripper")
    ap.add_argument("--j1-delta-rad", type=float, default=0.02)
    ap.add_argument("--v-max-rad-s", type=float, default=0.05)
    ap.add_argument("--teach-hz", type=float, default=50.0)
    ap.add_argument("--lock-sample-hz", type=float, default=10.0)
    ap.add_argument("--lock-sample-count", type=int, default=15)
    ap.add_argument("--target-hold-s", type=float, default=0.8)
    ap.add_argument("--return-hold-s", type=float, default=0.8)
    ap.add_argument("--min-joint-margin-deg", type=float, default=15.0)
    ap.add_argument("--max-tcp-displacement-mm", type=float, default=12.0)
    ap.add_argument("--max-tcp-z-change-mm", type=float, default=2.0)
    ap.add_argument("--max-temp-c", type=float, default=55.0)
    ap.add_argument("--run-id")
    ap.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    ap.add_argument("--execute", action="store_true")
    return ap


def validate_args(args) -> None:
    positive = {
        "--j1-delta-rad": args.j1_delta_rad,
        "--v-max-rad-s": args.v_max_rad_s,
        "--teach-hz": args.teach_hz,
        "--lock-sample-hz": args.lock_sample_hz,
        "--target-hold-s": args.target_hold_s,
        "--return-hold-s": args.return_hold_s,
        "--max-tcp-displacement-mm": args.max_tcp_displacement_mm,
        "--max-tcp-z-change-mm": args.max_tcp_z_change_mm,
        "--max-temp-c": args.max_temp_c,
    }
    for name, value in positive.items():
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be positive and finite")
    if args.j1_delta_rad > 0.025:
        raise ValueError("--j1-delta-rad cannot exceed 0.025rad in this diagnostic")
    if args.v_max_rad_s > 0.08:
        raise ValueError("--v-max-rad-s cannot exceed 0.08rad/s in this diagnostic")
    if args.lock_sample_count < 10:
        raise ValueError("--lock-sample-count must be at least 10")
    if (
        args.target_hold_s <= ENDPOINT_SETTLE_SECONDS
        or args.return_hold_s <= ENDPOINT_SETTLE_SECONDS
    ):
        raise ValueError(
            "endpoint hold durations must exceed the endpoint settling window"
        )
    if not math.isfinite(args.min_joint_margin_deg) or args.min_joint_margin_deg < 0:
        raise ValueError("--min-joint-margin-deg must be finite and non-negative")
    if args.run_id is not None and not RUN_ID_PATTERN.fullmatch(args.run_id):
        raise ValueError("--run-id contains unsupported characters")


def build_j1_target(q_reference, delta_rad: float) -> list[float]:
    q = finite_vector(q_reference, 6, "q_reference")
    if not math.isfinite(delta_rad) or delta_rad <= 0.0 or delta_rad > 0.025:
        raise ValueError("J1 delta must be in (0, 0.025]rad")
    target = list(q)
    target[J1_INDEX] += float(delta_rad)
    return target


def tcp_delta_mm(reference_tcp, target_tcp) -> dict:
    reference = finite_vector(reference_tcp, 7, "reference_tcp")
    target = finite_vector(target_tcp, 7, "target_tcp")
    xyz = [1000.0 * (target[i] - reference[i]) for i in range(3)]
    return {
        "xyz_mm": xyz,
        "xy_norm_mm": math.hypot(xyz[0], xyz[1]),
        "norm_mm": math.sqrt(sum(value * value for value in xyz)),
        "z_change_mm": xyz[2],
    }


def summarize_lock_rows(rows) -> dict:
    if len(rows) < 2:
        raise ValueError("lock sampling needs at least two rows")
    vectors = [finite_vector(row, 6, "lock_position") for row in rows]
    median_q = [
        statistics.median(row[joint] for row in vectors) for joint in range(6)
    ]
    spans = [
        max(row[joint] for row in vectors) - min(row[joint] for row in vectors)
        for joint in range(6)
    ]
    return {
        "median_q_rad": median_q,
        "joint_span_rad": spans,
        "maximum_span_rad": max(spans),
        "maximum_span_joint": 1 + max(range(6), key=lambda index: spans[index]),
        "sample_count": len(vectors),
    }


def collect_lock_rows_low_load(arm, teach_hz, sample_hz, sample_count):
    """Keep 50Hz gravity compensation while reading position at only 10Hz."""
    control_period = 1.0 / teach_hz
    sample_period = 1.0 / sample_hz
    next_sample = time.monotonic()
    rows = []
    while len(rows) < sample_count:
        cycle_started = time.monotonic()
        arm.gravity()
        now = time.monotonic()
        if now >= next_sample:
            rows.append(finite_vector(arm.get_pos(), 7, "position")[:6])
            next_sample = now + sample_period
        time.sleep(max(0.0, control_period - (time.monotonic() - cycle_started)))
    temperature = finite_vector(arm.get_temp(), 7, "temperature")
    return summarize_lock_rows(rows), temperature


def teaching_until_locked(arm, args):
    print("TEACHING_ENABLED：持续托住机械臂；本测试不启动D455。")
    print("摆到右侧无碰撞高悬停并静止后输入 l；输入 q 取消并失能。")
    while True:
        state = {"command": None, "error": None}

        def read_command():
            try:
                state["command"] = input("TEACH_COMMAND [l/q]: ").strip().lower()
            except BaseException as exc:
                state["error"] = exc

        reader = threading.Thread(
            target=read_command,
            name="small_motion_teach_command",
            daemon=True,
        )
        reader.start()
        next_temperature_check = time.monotonic()
        while reader.is_alive():
            cycle_started = time.monotonic()
            arm.gravity()
            now = time.monotonic()
            if now >= next_temperature_check:
                temperature = finite_vector(arm.get_temp(), 7, "temperature")
                if max(temperature) > args.max_temp_c:
                    raise RuntimeError("motor temperature exceeds configured limit")
                next_temperature_check = now + 1.0
            time.sleep(
                max(0.0, 1.0 / args.teach_hz - (time.monotonic() - cycle_started))
            )
        reader.join(timeout=0.0)
        if state["error"] is not None:
            raise state["error"]
        if state["command"] == "q":
            return None, None
        if state["command"] != "l":
            print("只接受 l 或 q；继续重力补偿示教。")
            continue

        summary, temperature = collect_lock_rows_low_load(
            arm,
            args.teach_hz,
            args.lock_sample_hz,
            args.lock_sample_count,
        )
        if summary["maximum_span_rad"] > LOCK_MAXIMUM_SPAN_RAD:
            print(
                "LOCK_REJECTED：姿态仍在移动；"
                f"J{summary['maximum_span_joint']} span="
                f"{summary['maximum_span_rad']:.5f}rad。继续示教。"
            )
            continue
        q_lock = list(summary["median_q_rad"])
        margins = joint_margin_details(q_lock)
        minimum_margin = min(item["margin_deg"] for item in margins)
        if minimum_margin < args.min_joint_margin_deg:
            limiting = min(margins, key=lambda item: item["margin_deg"])
            print(
                f"LOCK_REJECTED：J{limiting['joint']} margin="
                f"{minimum_margin:.2f}deg < {args.min_joint_margin_deg:.2f}deg。"
                "继续示教。"
            )
            continue

        arm._arm.joint_control_mit(list(q_lock))
        record = {
            **summary,
            "temperature_c": temperature,
            "joint_margin_deg": minimum_margin,
            "joint_margin_details": margins,
        }
        print("LOCKED_Q =", [round(value, 6) for value in q_lock])
        print("LOCK_SAMPLE_RATE_HZ =", args.lock_sample_hz)
        print("LOCK_SAMPLE_MAX_SPAN_RAD =", round(summary["maximum_span_rad"], 6))
        print("LOCK_JOINT_MARGIN_DEG =", round(minimum_margin, 3))
        print("LOCKED：已切换到同姿态关节保持。")
        return q_lock, record


def read_motion_start(arm, sample_count: int = 10, sample_period_s: float = 0.02):
    rows = []
    for _ in range(sample_count):
        cycle_started = time.monotonic()
        rows.append(finite_vector(arm.get_pos(), 7, "position")[:6])
        time.sleep(max(0.0, sample_period_s - (time.monotonic() - cycle_started)))
    return summarize_lock_rows(rows)


def move_with_trace(arm, q_from, q_to, label: str):
    """Run the established S-curve while retaining bounded feedback evidence."""
    limits = arm.limits
    delta = max(abs(a - b) for a, b in zip(q_from, q_to))
    ramp = max(
        motion_duration_s(
            delta,
            limits.v_max_rad_s,
            limits.motion_profile,
        ),
        motion_duration_s(
            abs(q_to[J6_INDEX] - q_from[J6_INDEX]),
            limits.j6_v_max_rad_s,
            limits.motion_profile,
            minimum_s=0.0,
        ),
    )
    trajectory_time = 0.0
    wall_started = time.monotonic()
    samples = []
    cached_temperature = finite_vector(arm.get_temp(), 7, "temperature")
    cycle_index = 0
    failure = None
    while True:
        cycle_started = time.monotonic()
        u = min(1.0, trajectory_time / ramp)
        progress = motion_profile_progress(u, limits.motion_profile)
        target = [
            q_from[index] + progress * (q_to[index] - q_from[index])
            for index in range(6)
        ]
        arm._arm.joint_control_mit(list(target))
        position = finite_vector(arm.get_pos(), 7, "position")[:6]
        velocity = finite_vector(arm.get_vel(), 7, "velocity")[:6]
        if cycle_index % 5 == 0:
            cached_temperature = finite_vector(arm.get_temp(), 7, "temperature")
        error = [position[index] - target[index] for index in range(6)]
        samples.append(
            {
                "wall_elapsed_s": time.monotonic() - wall_started,
                "trajectory_time_s": trajectory_time,
                "progress": progress,
                "target_q_rad": target,
                "position_q_rad": position,
                "velocity_rad_s": velocity,
                "error_rad": error,
            }
        )
        bad = arm.guard(
            position,
            velocity,
            cached_temperature,
            target,
            settling=trajectory_time < limits.settle_seconds,
        )
        if bad:
            failure = f"{label}: {bad}"
            break
        if u >= 1.0:
            break
        trajectory_time = min(ramp, trajectory_time + arm.dt)
        cycle_index += 1
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    summary = {
        "label": label,
        "planned_duration_s": ramp,
        "sample_count": len(samples),
        "maximum_track_error_rad": max(
            abs(value) for sample in samples for value in sample["error_rad"]
        ),
        "failure": failure,
        "samples": samples,
    }
    return summary, failure


def hold_pose(
    arm,
    target,
    duration_s: float,
    label: str,
    settle_s: float = ENDPOINT_SETTLE_SECONDS,
):
    started = time.monotonic()
    samples = []
    maximum_error = 0.0
    cycle = 0
    temperature = finite_vector(arm.get_temp(), 7, "temperature")
    failure = None
    while True:
        cycle_started = time.monotonic()
        elapsed = cycle_started - started
        arm._arm.joint_control_mit(list(target))
        position = finite_vector(arm.get_pos(), 7, "position")[:6]
        velocity = finite_vector(arm.get_vel(), 7, "velocity")[:6]
        if cycle % 5 == 0:
            temperature = finite_vector(arm.get_temp(), 7, "temperature")
        error = max(abs(a - b) for a, b in zip(position, target))
        maximum_error = max(maximum_error, error)
        bad = arm.guard(
            position,
            velocity,
            temperature,
            target,
            settling=elapsed < settle_s,
        )
        samples.append(
            {
                "elapsed_s": elapsed,
                "position_q_rad": position,
                "velocity_rad_s": velocity,
                "maximum_error_rad": error,
            }
        )
        if bad:
            failure = f"{label}: {bad}"
            break
        if elapsed >= duration_s:
            break
        cycle += 1
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle_started)))
    evaluation_rows = [
        sample["position_q_rad"]
        for sample in samples
        if sample["elapsed_s"] >= settle_s
    ]
    if not evaluation_rows:
        evaluation_rows = [samples[-1]["position_q_rad"]]
    median_q = [
        statistics.median(row[joint] for row in evaluation_rows)
        for joint in range(6)
    ]
    summary = {
        "sample_count": len(samples),
        "evaluation_sample_count": len(evaluation_rows),
        "settle_s": settle_s,
        "median_q_rad": median_q,
        "maximum_track_error_rad": maximum_error,
        "temperature_c": temperature,
        "failure": failure,
        "samples": samples,
    }
    return summary, failure


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    validate_args(args)
    print("MODE = new-s1-small-j1-round-trip")
    print("CAMERA_ACCESS = False")
    print("GRIPPER_COMMANDS = False")
    print("J1_DELTA_RAD =", args.j1_delta_rad)
    print("V_MAX_RAD_S =", args.v_max_rad_s)
    print("MOTION_PROFILE = s_curve")
    print("TEACH/LOCK_SAMPLE_HZ =", f"{args.teach_hz}/{args.lock_sample_hz}")
    if not args.execute:
        print("OFFLINE_ONLY：未构造Arm、未访问串口、未使能机械臂。")
        return 0

    print("\n实机条件：Go2趴下且静止，机械臂常红并有软支撑；")
    print("示教姿态位于机身右侧高悬停区，末端水平圆弧方向至少有30mm净空。")
    if input("确认满足后输入 e：").strip().lower() != "e":
        print("CANCELLED_BEFORE_ARM_ACCESS")
        return 1

    run_id = args.run_id or datetime.now().strftime("small_j1_%Y%m%d-%H%M%S")
    run_dir = args.output_root.expanduser().resolve() / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    run_dir.mkdir(parents=True)
    output_path = run_dir / "run.json"
    record = {
        "schema_version": 1,
        "mode": "new-s1-small-j1-round-trip",
        "run_id": run_id,
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "camera_access": False,
        "gripper_commands": False,
        "parameters": vars(args) | {"output_root": str(args.output_root)},
        "result": "STARTED",
    }
    arm = None
    return_code = 1
    try:
        limits = SafetyLimits(
            hz=50.0,
            v_max_rad_s=args.v_max_rad_s,
            j6_v_max_rad_s=args.v_max_rad_s,
            motion_profile="s_curve",
            max_track_err_rad=0.012,
            max_speed_rad_s=0.5,
            max_temp_c=args.max_temp_c,
            max_joint_delta_rad=0.025,
            # The complete default 0.02rad S-curve lasts about 0.8s.  Keep the
            # transient allowance through that bounded move; the strict
            # endpoint hold check below still rejects a joint that never moved.
            settle_seconds=MOTION_SETTLE_SECONDS,
        )
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=limits,
            check_collision=False,
        )
        connected_q, connected_temperature, startup = wait_for_valid_feedback(
            arm, args.max_temp_c
        )
        record["startup_feedback"] = startup
        print("STARTUP_FEEDBACK_READY =", startup["ready"])
        print("CONNECTED_Q =", [round(value, 6) for value in connected_q])
        print(
            "CONNECTED_TEMPERATURE_C =",
            [round(value, 1) for value in connected_temperature],
        )
        if input("确认继续托稳且示教范围无碰撞，输入 e：").strip().lower() != "e":
            record["result"] = "CANCELLED_BEFORE_TEACHING"
            raise KeyboardInterrupt

        arm.enable()
        arm.gravity()
        q_reference, teach_lock = teaching_until_locked(arm, args)
        if q_reference is None:
            record["result"] = "CANCELLED_DURING_TEACHING"
            raise KeyboardInterrupt

        q_preview_target = build_j1_target(q_reference, args.j1_delta_rad)
        target_margins = joint_margin_details(q_preview_target)
        target_minimum_margin = min(item["margin_deg"] for item in target_margins)
        if target_minimum_margin < args.min_joint_margin_deg:
            raise RuntimeError(
                f"target joint margin {target_minimum_margin:.2f}deg is insufficient"
            )

        kinematics = Kinematics(verbose=True)
        reference_tcp = finite_vector(kinematics.fk(q_reference), 7, "reference_tcp")
        target_tcp = finite_vector(
            kinematics.fk(q_preview_target), 7, "target_tcp"
        )
        cartesian = tcp_delta_mm(reference_tcp, target_tcp)
        if cartesian["norm_mm"] > args.max_tcp_displacement_mm:
            raise RuntimeError(
                f"predicted TCP displacement {cartesian['norm_mm']:.2f}mm exceeds limit"
            )
        if abs(cartesian["z_change_mm"]) > args.max_tcp_z_change_mm:
            raise RuntimeError(
                f"predicted TCP z change {cartesian['z_change_mm']:.2f}mm exceeds limit"
            )

        record.update(
            {
                "teach_lock": teach_lock,
                "reference_q_rad": q_reference,
                "preview_target_q_rad": q_preview_target,
                "reference_tcp_xyz_xyzw": reference_tcp,
                "target_tcp_xyz_xyzw": target_tcp,
                "predicted_tcp_delta": cartesian,
                "target_joint_margin_details": target_margins,
            }
        )
        print("REFERENCE_Q =", [round(value, 6) for value in q_reference])
        print("PREVIEW_TARGET_Q =", [round(value, 6) for value in q_preview_target])
        print("PREDICTED_TCP_DELTA_MM =", [round(v, 3) for v in cartesian["xyz_mm"]])
        print("PREDICTED_TCP_DISPLACEMENT_MM =", round(cartesian["norm_mm"], 3))
        print("TARGET_MINIMUM_JOINT_MARGIN_DEG =", round(target_minimum_margin, 3))
        print("LIVE_GEOMETRY_OK = True")
        print("外部环境未建模；本次只有J1正向微动，仍须人工确认圆弧净空。")
        if input("确认至少30mm水平净空且软支撑不阻碍运动，输入 e 执行：").strip().lower() != "e":
            record["result"] = "CANCELLED_BEFORE_MOTION"
            raise KeyboardInterrupt

        motion_start_summary = read_motion_start(arm)
        q_motion_start = list(motion_start_summary["median_q_rad"])
        start_drift = [
            q_motion_start[index] - q_reference[index] for index in range(6)
        ]
        maximum_start_drift = max(abs(value) for value in start_drift)
        if motion_start_summary["maximum_span_rad"] > MOTION_START_MAX_SPAN_RAD:
            raise RuntimeError(
                "motion-start feedback is not stationary: "
                f"span={motion_start_summary['maximum_span_rad']:.5f}rad"
            )
        if maximum_start_drift > MOTION_START_MAX_DRIFT_RAD:
            raise RuntimeError(
                f"motion-start drift {maximum_start_drift:.5f}rad exceeds limit"
            )

        q_target = build_j1_target(q_motion_start, args.j1_delta_rad)
        target_margins = joint_margin_details(q_target)
        target_minimum_margin = min(item["margin_deg"] for item in target_margins)
        motion_start_tcp = finite_vector(
            kinematics.fk(q_motion_start), 7, "motion_start_tcp"
        )
        target_tcp = finite_vector(kinematics.fk(q_target), 7, "target_tcp")
        cartesian = tcp_delta_mm(motion_start_tcp, target_tcp)
        if target_minimum_margin < args.min_joint_margin_deg:
            raise RuntimeError(
                f"rebased target margin {target_minimum_margin:.2f}deg is insufficient"
            )
        if cartesian["norm_mm"] > args.max_tcp_displacement_mm:
            raise RuntimeError("rebased target exceeds TCP displacement limit")
        if abs(cartesian["z_change_mm"]) > args.max_tcp_z_change_mm:
            raise RuntimeError("rebased target exceeds TCP z-change limit")
        record.update(
            {
                "motion_start_sampling": motion_start_summary,
                "motion_start_q_rad": q_motion_start,
                "motion_start_drift_from_lock_rad": start_drift,
                "motion_start_maximum_drift_rad": maximum_start_drift,
                "target_q_rad": q_target,
                "motion_start_tcp_xyz_xyzw": motion_start_tcp,
                "target_tcp_xyz_xyzw": target_tcp,
                "rebased_predicted_tcp_delta": cartesian,
            }
        )
        print("MOTION_START_Q =", [round(value, 6) for value in q_motion_start])
        print("MOTION_START_DRIFT_RAD =", [round(value, 6) for value in start_drift])
        print("MOTION_START_MAX_SPAN_RAD =", round(motion_start_summary["maximum_span_rad"], 6))
        print("REBASED_TARGET_Q =", [round(value, 6) for value in q_target])
        print("REBASED_TCP_DELTA_MM =", [round(v, 3) for v in cartesian["xyz_mm"]])

        print("ENABLED：开始J1小范围往返。")
        outbound_trace, failure = move_with_trace(
            arm, q_motion_start, q_target, "motion_start->j1_target"
        )
        record["outbound_trace"] = outbound_trace
        if failure:
            raise RuntimeError(failure)
        print("到达: motion_start->j1_target")
        target_hold, failure = hold_pose(
            arm, q_target, args.target_hold_s, "target_hold"
        )
        record["target_hold"] = target_hold
        if failure:
            raise RuntimeError(failure)
        target_error = max(
            abs(a - b) for a, b in zip(target_hold["median_q_rad"], q_target)
        )
        if target_error > 0.01:
            raise RuntimeError(f"target median error {target_error:.5f}rad is too large")

        return_trace, failure = move_with_trace(
            arm, q_target, q_motion_start, "j1_target->motion_start"
        )
        record["return_trace"] = return_trace
        if failure:
            raise RuntimeError(failure)
        print("到达: j1_target->motion_start")
        return_hold, failure = hold_pose(
            arm, q_motion_start, args.return_hold_s, "return_hold"
        )
        record["return_hold"] = return_hold
        if failure:
            raise RuntimeError(failure)
        return_error = max(
            abs(a - b) for a, b in zip(return_hold["median_q_rad"], q_motion_start)
        )
        if return_error > 0.01:
            raise RuntimeError(f"return median error {return_error:.5f}rad is too large")

        observed_delta = (
            target_hold["median_q_rad"][J1_INDEX]
            - return_hold["median_q_rad"][J1_INDEX]
        )
        record["observed_j1_delta_rad"] = observed_delta
        record["target_median_error_rad"] = target_error
        record["return_median_error_rad"] = return_error
        record["result"] = "SMALL_J1_ROUND_TRIP_DONE"
        print("OBSERVED_J1_DELTA_RAD =", round(observed_delta, 6))
        print("TARGET_MEDIAN_ERROR_RAD =", round(target_error, 6))
        print("RETURN_MEDIAN_ERROR_RAD =", round(return_error, 6))
        print("DIAGNOSTIC_STATUS = SMALL_J1_MOTION_OK")
        return_code = 0
    except KeyboardInterrupt:
        if record["result"] == "STARTED":
            record["result"] = "CANCELLED"
        print("CANCELLED")
    except Exception as exc:
        record["result"] = f"ABORTED: {type(exc).__name__}: {exc}"
        record["error"] = repr(exc)
        print(record["result"])
    finally:
        if arm is not None:
            try:
                arm.disable()
                print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
            except Exception as exc:
                record["disable_error"] = repr(exc)
                print("DISABLE_FAILED:", repr(exc))
        record["finished_at"] = datetime.now().astimezone().isoformat(
            timespec="seconds"
        )
        output_path.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print("LOG_SAVED =", output_path)
        print("RESULT =", record["result"])
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
