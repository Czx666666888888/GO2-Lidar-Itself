#!/usr/bin/env python3
"""Install a boot-time system service; does not start or move the arm."""
import argparse
import os
from pathlib import Path
import pwd
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--user", required=True)
    parser.add_argument("--python", required=True)
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error("run with sudo to install the system boot service")
    account = pwd.getpwnam(args.user)
    root = Path(__file__).resolve().parents[1]
    def quote(value):
        return '"' + str(value).replace("%", "%%").replace('\\', '\\\\').replace('"', '\\"') + '"'
    device_unit = subprocess.check_output(
        ["systemd-escape", "--path", "--suffix=device", args.dev], text=True).strip()
    service = f"""[Unit]
Description=S1 zero hold and autonomous grasp service
After={device_unit}
Requires={device_unit}

[Service]
Type=simple
User={account.pw_name}
Group={account.pw_gid}
WorkingDirectory={str(root).replace("%", "%%")}
Environment=OPENBLAS_NUM_THREADS=1
Environment=PYTHONUNBUFFERED=1
ExecStart={quote(args.python)} -uB {quote(root / "scripts/run_arm_integration.py")} --dev {quote(args.dev)} --execute
TimeoutStopSec=infinity
Restart=no

[Install]
WantedBy=multi-user.target
"""
    Path("/etc/systemd/system/s1-arm-integration.service").write_text(service)
    subprocess.run(["systemctl", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "enable", "s1-arm-integration.service"], check=True)
    print("Installed and enabled for boot. Not started; no arm commands sent.")
    print("Start when ready: sudo systemctl start s1-arm-integration.service")

if __name__ == "__main__":
    main()
