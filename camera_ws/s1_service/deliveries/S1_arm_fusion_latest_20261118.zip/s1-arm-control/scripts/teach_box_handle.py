#!/usr/bin/env python3
"""Native gravity-assisted manual teaching; never sends position trajectories."""
import argparse
from collections import deque
from datetime import datetime
import json
from pathlib import Path
import queue
import sys
import threading
import time
ROOT=Path(__file__).resolve().parents[1]
for p in (ROOT,Path.home()/'thirdparty/S1_SDK_V2-official/src'):
    sys.path.insert(0,str(p))


def gravity_tick(arm):
    arm.gravity()
    return list(arm.get_pos())


def make_pose(samples,kinematics,gripper):
    import statistics
    state=[statistics.median(row[i] for row in samples) for i in range(7)]
    tcp=list(kinematics.fk(state[:6]))
    return dict(name='hinged_box_handle',captured_at=datetime.now().astimezone().isoformat(),joint_rad=state[:6],
        gripper_feedback=state[6],gripper_gap_mm=gripper.gap_from_fb(state[6]),tcp_xyz_quat_xyzw=tcp,
        tcp_xyz_mm=[1000*float(x) for x in tcp[:3]],source='native_gravity_manual_teach')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dev',default='/dev/ttyUSB0')
    parser.add_argument('--out',default=str(ROOT/'data/captured_poses/hinged_box_handle.json'))
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args(argv)
    if not args.execute:
        print('OFFLINE: add --execute for native gravity teaching; p=save handle pose, q=disable and exit')
        return 0
    import fcntl
    from s1_control.arm import Arm,SafetyLimits
    from s1_control.gripper import Gripper
    from s1_control.kinematics import Kinematics
    from execute_go2_observe_deployment import wait_for_valid_feedback
    lock=open('/tmp/s1-arm-'+Path(args.dev).resolve().name+'.lock','a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    print('请全程托住机械臂。原生重力补偿用于手动拖动，不是零位保持；Go2倾斜时仍可能下垂。')
    print('本程序不翻盒、不夹紧把手、不发送位置轨迹。退出时失能，请先托稳或放到支撑上。')
    if input('已托稳，输入 e 开启重力示教：').strip().lower()!='e':return 1
    arm=None
    commands=queue.Queue()
    try:
        arm=Arm(dev=args.dev,end_effector='gripper',check_collision=False,limits=SafetyLimits(hz=50.0))
        wait_for_valid_feedback(arm,arm.limits.max_temp_c)
        gripper=Gripper(arm);kinematics=Kinematics(verbose=False)
        arm.enable()
        arm.gravity()
        print('GRAVITY_TEACH_READY = True',flush=True)
        print('托住并缓慢摆到把手夹持位，保持不动，输入 p 回车保存；托稳后输入 q 回车退出。',flush=True)
        def reader():
            while True:
                try:command=input().strip().lower()
                except (EOFError,KeyboardInterrupt):command='q'
                commands.put(command)
                if command=='q':return
        threading.Thread(target=reader,daemon=True).start()
        samples=deque(maxlen=5);last_temp=0.0
        while True:
            started=time.monotonic()
            samples.append(gravity_tick(arm))
            if started-last_temp>=1:
                if max(arm.get_temp())>arm.limits.max_temp_c:raise RuntimeError('existing temperature limit exceeded')
                last_temp=started
            try:command=commands.get_nowait()
            except queue.Empty:command=None
            if command=='q':break
            if command=='p':
                record=make_pose(list(samples),kinematics,gripper)
                out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
                out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
                print('POSE_SAVED =',out,flush=True)
                print('HANDLE_Q_RAD =',record['joint_rad'],flush=True)
                print('继续重力示教；请托稳后输入 q 退出。',flush=True)
            time.sleep(max(0,0.02-(time.monotonic()-started)))
    except KeyboardInterrupt:
        print('CANCELLED')
    finally:
        if arm is not None:
            try:arm.disable()
            finally:arm.close()
            print('DISABLED：继续托稳直到放到支撑上。',flush=True)
        lock.close()
    return 0
if __name__=='__main__':raise SystemExit(main())
