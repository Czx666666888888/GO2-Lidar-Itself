#!/usr/bin/env python3
import argparse
import json
import math
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.arm import Arm, SafetyLimits
from s1_control.gripper import Gripper


REFERENCE_START_Q = [
    0.039482,
    -0.001335,
    -0.000191,
    -0.009346,
    0.029564,
    0.020409,
]

MAX_START_DIFFERENCE_RAD = 0.02
START_SAFE_WINDOWS_RAD = [
    (-0.08, 0.08),
    (-0.02, 0.08),
    (-0.02, 0.08),
    (-0.08, 0.08),
    (-0.08, 0.08),
    (-0.08, 0.08),
]


def resolve_path(raw):
    path = Path(raw)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path


def serial_readiness(arm, reference_q, duration_s=3.0):
    period = 0.05  # 20Hz，避免主动增加串口负担
    deadline = time.monotonic() + duration_s
    next_tick = time.monotonic()

    samples = 0
    max_read_ms = 0.0
    max_drift_rad = 0.0
    finite_ok = True

    while time.monotonic() < deadline:
        before = time.monotonic()
        position = list(arm.get_pos())
        read_ms = (time.monotonic() - before) * 1000.0

        max_read_ms = max(max_read_ms, read_ms)
        samples += 1

        if len(position) < 7:
            finite_ok = False
            break

        if not all(math.isfinite(value) for value in position):
            finite_ok = False
            break

        drift = max(
            abs(position[index] - reference_q[index])
            for index in range(6)
        )
        max_drift_rad = max(max_drift_rad, drift)

        next_tick += period
        delay = next_tick - time.monotonic()

        if delay > 0:
            time.sleep(delay)
        else:
            next_tick = time.monotonic()

    passed = (
        finite_ok
        and samples >= 50
        and max_read_ms <= 20.0
        and max_drift_rad <= MAX_START_DIFFERENCE_RAD
    )

    return {
        "passed": passed,
        "samples": samples,
        "max_read_ms": max_read_ms,
        "max_drift_rad": max_drift_rad,
        "finite_ok": finite_ok,
    }


def hold_open(arm, gripper, q, open_mm, duration_s):
    deadline = time.monotonic() + duration_s
    next_tick = time.monotonic()

    while time.monotonic() < deadline:
        arm._arm.joint_control_mit(list(q))
        gripper.command_mm(open_mm)

        position = list(arm.get_pos())
        velocity = list(arm._arm.get_vel())
        temperature = list(arm._arm.get_temp())

        fault = arm.guard(
            position,
            velocity,
            temperature,
            q,
            settling=False,
        )

        if fault:
            return fault

        next_tick += arm.dt
        delay = next_tick - time.monotonic()

        if delay > 0:
            time.sleep(delay)
        else:
            next_tick = time.monotonic()

    return None


def main():
    parser = argparse.ArgumentParser(
        description="已离线验证路径的S1中间点测试"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument(
        "--plan",
        default="data/plans/cube50_hover_plan.json",
    )
    parser.add_argument(
        "--report",
        default=(
            "data/plans/"
            "cube50_hover_collision_report.json"
        ),
    )
    parser.add_argument("--open-mm", type=float, default=65.0)
    parser.add_argument(
        "--v-max-rad-s",
        type=float,
        default=0.05,
    )
    parser.add_argument("--hold-s", type=float, default=2.0)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    plan = json.loads(
        resolve_path(args.plan).read_text(encoding="utf-8")
    )
    report = json.loads(
        resolve_path(args.report).read_text(encoding="utf-8")
    )

    if report.get("status") != "OFFLINE_MODEL_PASS":
        raise RuntimeError(
            "离线碰撞报告未通过，拒绝连接执行"
        )

    waypoint_map = {
        waypoint["name"]: waypoint["q"]
        for waypoint in plan["joint_path"]
    }

    if "ready" not in waypoint_map:
        raise ValueError("规划中缺少ready路点")
    if "midpoint" not in waypoint_map:
        raise ValueError("规划中缺少midpoint路点")

    ready_q = waypoint_map["ready"]
    midpoint_q = waypoint_map["midpoint"]

    arm = Arm(
        dev=args.dev,
        end_effector="gripper",
        limits=SafetyLimits(
            hz=50.0,
            v_max_rad_s=args.v_max_rad_s,
            max_joint_delta_rad=1.0,
        ),
    )

    # 不在实时串口会话内运行MuJoCo。
    arm._arm.collision_checker = None
    gripper = Gripper(arm)

    start = arm.read_joint_median()
    start_q = [float(value) for value in start[:6]]
    
    start_in_safe_window = all(
        lower <= value <= upper
        for value, (lower, upper) in zip(
            start_q,
            START_SAFE_WINDOWS_RAD,
        )
    )

    start_ready_delta = max(
        abs(a - b)
        for a, b in zip(start_q, ready_q)
    )
    ready_midpoint_delta = max(
        abs(a - b)
        for a, b in zip(ready_q, midpoint_q)
    )

    print(
        "START_Q =",
        [round(value, 6) for value in start_q],
    )
    print(
        "START_SAFE_WINDOW_OK =",
        start_in_safe_window,
    )
    print(
        "START_GAP_MM =",
        round(gripper.gap_from_fb(start[6]), 2),
    )
    print(
        "START_TO_READY_DELTA_RAD =",
        round(start_ready_delta, 3),
    )
    print(
        "READY_TO_MIDPOINT_DELTA_RAD =",
        round(ready_midpoint_delta, 3),
    )

    geometry_ok = (
        start_in_safe_window
        and start_ready_delta <= 1.0
        and ready_midpoint_delta <= 1.0
    )

    print("开始3秒串口只读稳定性检查。")
    readiness = serial_readiness(
        arm,
        start_q,
        duration_s=3.0,
    )

    print("SERIAL_SAMPLES =", readiness["samples"])
    print(
        "SERIAL_MAX_READ_MS =",
        round(readiness["max_read_ms"], 3),
    )
    print(
        "SERIAL_MAX_DRIFT_RAD =",
        round(readiness["max_drift_rad"], 6),
    )
    print(
        "SERIAL_FINITE_OK =",
        readiness["finite_ok"],
    )
    print(
        "SERIAL_NUMERIC_READINESS_OK =",
        readiness["passed"],
    )
    print("GEOMETRY_REFERENCE_OK =", geometry_ok)

    precheck_ok = geometry_ok and readiness["passed"]
    print("PRECHECK_OK =", precheck_ok)

    if not args.execute:
        try:
            arm.disable()
        finally:
            print(
                "SERIAL_READINESS_ONLY_DONE："
                "未使能、未运动，已发送失能命令。"
            )
        return 0 if precheck_ok else 2

    if not precheck_ok:
        try:
            arm.disable()
        finally:
            print("预检未通过，拒绝使能。")
        return 2

    temperature = list(arm._arm.get_temp())
    print("TEMPERATURE_C =", temperature)

    if max(temperature) > 50.0:
        try:
            arm.disable()
        finally:
            print("温度超过50°C，拒绝使能。")
        return 2

    confirmation = input(
        "确认机械臂有软支撑、运动范围清空，"
        "并且本次终端没有出现motor timeout后，"
        "输入 e："
    ).strip()

    if confirmation != "e":
        try:
            arm.disable()
        finally:
            print("未确认，已发送失能命令。")
        return 1

    route = [
        ("start", start_q),
        ("ready", ready_q),
        ("midpoint", midpoint_q),
    ]

    open_fb = gripper.mm_to_fb(args.open_mm)
    enable_attempted = False
    completed = False

    try:
        enable_attempted = True
        arm.enable()
        print("ENABLED")

        for (from_name, q_from), (to_name, q_to) in zip(
            route,
            route[1:],
        ):
            label = f"{from_name}->{to_name}"
            fault = arm.move(
                q_from,
                q_to,
                label,
                grip_cmd=open_fb,
                grip_force=gripper.force,
            )

            print(
                "到达:" if not fault else "中止:",
                label,
                fault or "",
            )

            if fault:
                raise RuntimeError(fault)

        fault = hold_open(
            arm,
            gripper,
            midpoint_q,
            args.open_mm,
            args.hold_s,
        )

        if fault:
            raise RuntimeError(
                f"midpoint_hold: {fault}"
            )

        print("中间点保持完成，开始原路返回。")

        for (from_name, q_from), (to_name, q_to) in zip(
            reversed(route),
            list(reversed(route))[1:],
        ):
            label = f"{from_name}->{to_name}"
            fault = arm.move(
                q_from,
                q_to,
                label,
                grip_cmd=open_fb,
                grip_force=gripper.force,
            )

            print(
                "到达:" if not fault else "中止:",
                label,
                fault or "",
            )

            if fault:
                raise RuntimeError(fault)

        completed = True
        print("MIDPOINT_ROUND_TRIP_DONE")

    except Exception as exc:
        print("EXECUTION_ABORT:", repr(exc))

    finally:
        if enable_attempted:
            try:
                arm.disable()
                print("DISABLED")
            except Exception as exc:
                print(
                    "DISABLE_FAILED:",
                    repr(exc),
                )

    return 0 if completed else 2


if __name__ == "__main__":
    raise SystemExit(main())