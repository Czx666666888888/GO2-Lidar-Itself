#!/usr/bin/env python3
import argparse
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.arm import Arm, SafetyLimits
from s1_control.gripper import Gripper


def parse_targets(raw: str):
    try:
        values = [float(x.strip()) for x in raw.split(",") if x.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("开口序列必须是逗号分隔的数字") from exc

    if not values:
        raise argparse.ArgumentTypeError("开口序列不能为空")

    for value in values:
        if not 5.0 <= value <= 100.0:
            raise argparse.ArgumentTypeError(
                f"{value} mm 超出本测试允许范围 5～100 mm"
            )
    return values


def main():
    parser = argparse.ArgumentParser(
        description="Theseus S1 夹爪空载开合安全测试"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--end", default="gripper")
    parser.add_argument(
        "--targets-mm",
        type=parse_targets,
        default=parse_targets("20,40,20"),
        help="夹爪开口序列，例如 20,40,20",
    )
    parser.add_argument("--dwell-s", type=float, default=1.5)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    if args.dwell_s < 0.5:
        raise ValueError("--dwell-s 不得小于 0.5 秒")

    limits = SafetyLimits(hz=50.0, v_max_rad_s=0.05)
    arm = Arm(
        dev=args.dev,
        end_effector=args.end,
        limits=limits,
    )
    gripper = Gripper(arm)

    start = arm.read_joint_median()
    hold_q = list(start[:6])
    start_gap = gripper.gap_from_fb(start[6])

    print("HOLD_Q =", [round(q, 4) for q in hold_q])
    print(f"START_GAP = {start_gap:.1f} mm")
    print("TARGETS_MM =", args.targets_mm)

    for target_mm in args.targets_mm:
        print(
            f"  {target_mm:.1f} mm"
            f" -> FB={gripper.mm_to_fb(target_mm):.4f}"
        )

    print("PREFLIGHT_OK")

    if not args.execute:
        print("未指定 --execute；机械臂和夹爪均不会使能。")
        return

    # 本测试保持六轴当前位置，不需要 MuJoCo 路径碰撞计算。
    arm._arm.collision_checker = None

    enable_attempted = False
    max_hold_error = 0.0

    try:
        enable_attempted = True
        arm.enable()
        print("ENABLED")

        settle_until = time.monotonic() + 0.5

        for target_mm in args.targets_mm:
            target_fb = gripper.mm_to_fb(target_mm)
            deadline = time.monotonic() + args.dwell_s
            next_tick = time.monotonic()

            while time.monotonic() < deadline:
                arm._arm.joint_control_mit(hold_q)
                gripper.command_mm(target_mm)

                measured = list(arm.get_pos())
                velocity = list(arm._arm.get_vel())
                temperature = list(arm._arm.get_temp())

                hold_error = max(
                    abs(measured[i] - hold_q[i]) for i in range(6)
                )
                max_hold_error = max(max_hold_error, hold_error)

                fault = arm.guard(
                    measured,
                    velocity,
                    temperature,
                    hold_q,
                    settling=time.monotonic() < settle_until,
                )
                if fault:
                    raise RuntimeError(f"GUARD_ABORT: {fault}")

                next_tick += arm.dt
                delay = next_tick - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
                else:
                    next_tick = time.monotonic()

            feedback = list(arm.get_pos())
            actual_fb = feedback[6]
            actual_gap = gripper.gap_from_fb(actual_fb)

            print(
                f"TARGET={target_mm:.1f} mm  "
                f"FB_CMD={target_fb:.4f}  "
                f"FB_REAL={actual_fb:.4f}  "
                f"GAP_REAL={actual_gap:.1f} mm"
            )

        print(f"MAX_HOLD_ERROR={max_hold_error:.4f} rad")
        print("EMPTY_GRIPPER_TEST_DONE")

    except KeyboardInterrupt:
        print("USER_ABORT")

    except Exception as exc:
        print("TEST_FAILED:", repr(exc))
        raise

    finally:
        if enable_attempted:
            try:
                arm.disable()
                print("DISABLED")
            except Exception as exc:
                print("DISABLE_FAILED:", repr(exc))


if __name__ == "__main__":
    main()