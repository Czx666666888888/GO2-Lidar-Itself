#!/usr/bin/env python3
"""Build and fully sample the provisional Go2-right observation deployment."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys

import mujoco


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from S1_SDK.hardware.collision import CollisionChecker
from s1_control.go2_deployment import (
    file_sha256,
    interpolate_segment,
    joint_hard_limit_violations,
    joint_margin_deg,
    load_deployment_config,
    max_joint_delta,
    route_waypoints,
)
from s1_control.kinematics import Kinematics
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    differential_tilt_compensation,
    limited_correction,
    locate_official_gripper_urdf,
)


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "go2_crouch_right_observe_deployment.json"
DEFAULT_PLAN = PROJECT_ROOT / "data" / "plans" / "go2_crouch_right_observe_deployment_v1.json"
DEFAULT_REPORT = PROJECT_ROOT / "data" / "plans" / "go2_crouch_right_observe_collision_report_v1.json"


def resolve_project_path(raw: str | Path) -> Path:
    path = Path(raw).expanduser()
    return path if path.is_absolute() else PROJECT_ROOT / path


def set_model_q(checker, q):
    mujoco.mj_resetData(checker.model, checker.data)
    model_q = list(q)
    model_q[3] += 0.01
    for index, value in enumerate(model_q):
        joint_id = checker.joint_indices[index]
        address = checker.model.jnt_qposadr[joint_id]
        checker.data.qpos[address] = value
    mujoco.mj_forward(checker.model, checker.data)
    return model_q


def collision_sets(checker, model_q):
    exclusions = {tuple(sorted(pair)) for pair in checker.exclude_pairs}
    dynamic_pair = tuple(sorted(("geom1", "geom5")))
    if not (0.0 <= model_q[2] <= 0.02) or model_q[3] < -0.02:
        exclusions.add(dynamic_pair)
    else:
        exclusions.discard(dynamic_pair)

    active = set()
    excluded = set()
    floor = set()
    for index in range(checker.data.ncon):
        contact = checker.data.contact[index]
        names = []
        for geom_id in (contact.geom1, contact.geom2):
            names.append(checker.model.geom(geom_id).name or f"geom{geom_id}")
        pair = tuple(sorted(names))
        if "floor" in pair:
            floor.add(pair)
        elif pair in exclusions:
            excluded.add(pair)
        else:
            active.add(pair)
    return active, excluded, floor


def geom_positions_mm(checker, requested_names):
    positions = {}
    requested = set(requested_names)
    for geom_id in range(checker.model.ngeom):
        name = checker.model.geom(geom_id).name or f"geom{geom_id}"
        if name in requested:
            positions[name] = [
                1000.0 * float(value)
                for value in checker.data.geom_xpos[geom_id]
            ]
    missing = requested.difference(positions)
    if missing:
        raise RuntimeError(f"collision model is missing geoms: {sorted(missing)}")
    return positions


def phase_for_segment(name_from: str, name_to: str) -> str:
    segment = f"{name_from}->{name_to}".replace("left_", "right_")
    if segment == "zero_reference->rear_ready":
        return "vertical_escape"
    if segment in {
        "rear_ready->high_turn_mid",
        "high_turn_mid->right_ready",
    }:
        return "high_turn"
    if segment in {
        "right_ready->right_observe_mid",
        "right_observe_mid->right_observe",
    }:
        return "side_deploy"
    raise ValueError(f"unclassified deployment segment: {segment}")


def main() -> int:
    parser = argparse.ArgumentParser(description="离线生成并全路径检查Go2右侧观察位自动部署计划")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-plan", default=str(DEFAULT_PLAN))
    parser.add_argument("--output-report", default=str(DEFAULT_REPORT))
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    config_path = resolve_project_path(args.config)
    plan_path = resolve_project_path(args.output_plan)
    report_path = resolve_project_path(args.output_report)
    for path in (plan_path, report_path):
        if path.exists() and not args.overwrite:
            raise FileExistsError(f"{path} already exists; use --overwrite")

    record = load_deployment_config(config_path)
    mount_path = resolve_project_path(record["mount_config"])
    if not mount_path.is_file():
        raise FileNotFoundError(f"mount config not found: {mount_path}")
    mount_record = json.loads(mount_path.read_text(encoding="utf-8"))
    route = route_waypoints(record)
    safety = record["safety"]
    sample_step = float(safety["sample_step_rad"])
    maximum_segment_delta = float(safety["maximum_segment_delta_rad"])
    required_margin = float(safety["minimum_operational_joint_margin_deg"])
    tilt_config = record["motion"]["tilt_compensation"]
    phase_scales = {
        "vertical_escape": float(tilt_config["vertical_escape_scale"]),
        "high_turn": float(tilt_config["high_turn_scale"]),
        "side_deploy": float(tilt_config["side_deploy_scale"]),
    }
    allowed_scales = [
        float(value)
        for value in mount_record["diagnostic"]["allowed_scale_steps"]
    ]
    for phase, scale in phase_scales.items():
        if not any(math.isclose(scale, item, abs_tol=1e-9) for item in allowed_scales):
            raise ValueError(
                f"{phase} compensation scale {scale} is not an approved step "
                f"{allowed_scales}"
            )
    side_sign = -1 if record["route"]["side"] == "left" else 1
    transition_pose = str(tilt_config["transition_pose"])
    transition_s = float(tilt_config["scale_transition_s"])
    if transition_pose not in {"right_ready", "left_ready"}:
        raise ValueError("tilt compensation transition pose must be right_ready")
    if not math.isfinite(transition_s) or transition_s <= 0.0:
        raise ValueError("tilt compensation transition duration must be positive")
    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    rear_edge_lower_deg = float(
        mount_record["mount_measurement"]["rear_edge_lower_deg"]
    )
    correction_limits_nm = mount_record["diagnostic"][
        "correction_absolute_limits_nm"
    ]

    plan = {
        "schema_version": 1,
        "status": "provisional_supervised_commissioning",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_config": str(config_path),
        "source_config_sha256": file_sha256(config_path),
        "mount_config": str(mount_path),
        "mount_config_sha256": file_sha256(mount_path),
        "frame_convention": record["frame_convention"],
        "side": record["route"]["side"],
        "joint_path": route,
        "start_safe_windows_rad": safety["start_safe_windows_rad"],
        "motion": record["motion"],
        "external_environment_model": {
            "mode": "phase_envelope_without_exact_go2_cad",
            "go2_body_envelope": safety["go2_body_envelope"],
            "unmodelled_external_obstacles": safety["unmodelled_external_obstacles"],
        },
        "endpoint_evidence": record["endpoint_evidence"],
    }
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(
        json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    checker = CollisionChecker("gripper")
    if checker.model is None:
        checker._load_model(gripper=True)
    if checker.model is None or checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")
    kinematics = Kinematics(verbose=True)

    allowed_start_contacts = {
        tuple(sorted(pair)) for pair in safety["allowed_start_model_contacts"]
    }
    body = safety["go2_body_envelope"]
    body_half_width = float(body["body_half_width_y_mm"])
    body_minimum_z = float(body["minimum_distal_geom_center_z_inside_body_width_mm"])
    distal_geoms = [str(name) for name in body["distal_geoms"]]
    escape = safety["vertical_escape"]
    high_turn = safety["high_turn"]
    side_deploy = safety["side_deploy"]

    sample_count = 0
    hard_limit_violations = []
    operational_minimum_margin = float("inf")
    segment_delta_violations = []
    active_collisions = []
    allowed_start_contact_count = 0
    excluded_contact_samples = 0
    floor_contact_samples = 0
    envelope_violations = []
    tcp_min = [float("inf")] * 3
    tcp_max = [float("-inf")] * 3
    first_tcp_xy = None
    previous_escape_z = None
    maximum_abs_requested_tilt_correction_nm = [0.0] * 6
    tilt_torque_cap_violations = []

    def evaluate_tilt_torque(*, label, phase, q, scale, alpha):
        differential = differential_tilt_compensation(
            tilt_model,
            q,
            rear_edge_lower_deg,
        )
        requested, applied = limited_correction(
            differential,
            scale,
            correction_limits_nm,
        )
        for joint_index, value in enumerate(requested):
            maximum_abs_requested_tilt_correction_nm[joint_index] = max(
                maximum_abs_requested_tilt_correction_nm[joint_index],
                abs(float(value)),
            )
        clipped_joints = [
            index + 1
            for index, (requested_value, applied_value) in enumerate(
                zip(requested, applied)
            )
            if abs(float(requested_value) - float(applied_value)) > 1e-9
        ]
        if clipped_joints:
            tilt_torque_cap_violations.append({
                "label": label,
                "phase": phase,
                "alpha": alpha,
                "scale": scale,
                "clipped_joints": clipped_joints,
                "differential_nm": [float(value) for value in differential],
                "requested_nm": [float(value) for value in requested],
                "applied_nm": [float(value) for value in applied],
            })

    for previous, current in zip(route, route[1:]):
        segment = f"{previous['name']}->{current['name']}"
        phase = phase_for_segment(previous["name"], current["name"])
        segment_delta = max_joint_delta(previous["q"], current["q"])
        if segment_delta > maximum_segment_delta:
            segment_delta_violations.append({
                "segment": segment,
                "delta_rad": segment_delta,
                "maximum_rad": maximum_segment_delta,
            })

        for local_index, (alpha, q) in enumerate(
            interpolate_segment(previous["q"], current["q"], sample_step)
        ):
            if sample_count and local_index == 0:
                continue
            sample_count += 1
            violations = joint_hard_limit_violations(q)
            if violations:
                hard_limit_violations.append({
                    "segment": segment,
                    "alpha": alpha,
                    "violations": violations,
                })
            if phase != "vertical_escape":
                operational_minimum_margin = min(
                    operational_minimum_margin, joint_margin_deg(q)
                )

            evaluate_tilt_torque(
                label=segment,
                phase=phase,
                q=q,
                scale=phase_scales[phase],
                alpha=alpha,
            )

            tcp_mm = [1000.0 * value for value in kinematics.fk(q)[:3]]
            for axis in range(3):
                tcp_min[axis] = min(tcp_min[axis], tcp_mm[axis])
                tcp_max[axis] = max(tcp_max[axis], tcp_mm[axis])

            model_q = set_model_q(checker, q)
            active, excluded, floor = collision_sets(checker, model_q)
            if excluded:
                excluded_contact_samples += 1
            if floor:
                floor_contact_samples += 1
            if active:
                if (
                    segment == "zero_reference->rear_ready"
                    and alpha == 0.0
                    and active.issubset(allowed_start_contacts)
                ):
                    allowed_start_contact_count += 1
                else:
                    active_collisions.append({
                        "segment": segment,
                        "alpha": alpha,
                        "pairs": [list(pair) for pair in sorted(active)],
                    })

            geoms = geom_positions_mm(checker, distal_geoms)
            if phase == "vertical_escape":
                if first_tcp_xy is None:
                    first_tcp_xy = tcp_mm[:2]
                lateral = math.hypot(
                    tcp_mm[0] - first_tcp_xy[0],
                    tcp_mm[1] - first_tcp_xy[1],
                )
                if lateral > float(escape["maximum_tcp_xy_departure_mm"]):
                    envelope_violations.append({
                        "segment": segment,
                        "alpha": alpha,
                        "reason": "vertical_escape_tcp_xy_departure",
                        "value_mm": lateral,
                    })
                if abs(q[0]) > float(escape["maximum_abs_j1_rad"]):
                    envelope_violations.append({
                        "segment": segment,
                        "alpha": alpha,
                        "reason": "vertical_escape_j1_motion",
                        "value_rad": q[0],
                    })
                if (
                    previous_escape_z is not None
                    and tcp_mm[2] < previous_escape_z - float(escape["maximum_tcp_z_backtrack_mm"])
                ):
                    envelope_violations.append({
                        "segment": segment,
                        "alpha": alpha,
                        "reason": "vertical_escape_descended",
                        "previous_z_mm": previous_escape_z,
                        "current_z_mm": tcp_mm[2],
                    })
                previous_escape_z = tcp_mm[2]
            elif phase == "high_turn" and tcp_mm[2] < float(high_turn["minimum_tcp_z_mm"]):
                envelope_violations.append({
                    "segment": segment,
                    "alpha": alpha,
                    "reason": "high_turn_tcp_too_low",
                    "tcp_z_mm": tcp_mm[2],
                })
            elif phase == "side_deploy" and side_sign * tcp_mm[1] < float(side_deploy["minimum_tcp_y_mm"]):
                envelope_violations.append({
                    "segment": segment,
                    "alpha": alpha,
                    "reason": "side_deploy_not_outside_body",
                    "tcp_y_mm": tcp_mm[1],
                })

            if phase != "vertical_escape":
                for geom_name, position in geoms.items():
                    if abs(position[1]) < body_half_width and position[2] < body_minimum_z:
                        envelope_violations.append({
                            "segment": segment,
                            "alpha": alpha,
                            "reason": "distal_geom_low_inside_body_width",
                            "geom": geom_name,
                            "position_mm": position,
                        })

    # The transition itself holds right_ready fixed.  Because correction is
    # linear in scale, checking its largest endpoint proves every intermediate
    # scale in the smooth 0.25 -> 1.0 ramp remains below the same hard caps.
    transition_q = next(
        item["q"] for item in route if item["name"] == transition_pose
    )
    evaluate_tilt_torque(
        label=f"{transition_pose}_scale_transition_endpoint",
        phase="scale_transition",
        q=transition_q,
        scale=phase_scales["side_deploy"],
        alpha=1.0,
    )

    joint_safety_ok = (
        not hard_limit_violations
        and not segment_delta_violations
        and operational_minimum_margin >= required_margin
    )
    self_collision_ok = not active_collisions
    external_ok = not envelope_violations
    tilt_torque_cap_ok = not tilt_torque_cap_violations
    passed = (
        joint_safety_ok
        and self_collision_ok
        and external_ok
        and tilt_torque_cap_ok
    )
    report = {
        "schema_version": 1,
        "status": "OFFLINE_DEPLOYMENT_PASS" if passed else "OFFLINE_DEPLOYMENT_FAIL",
        "warning": "Go2精确CAD、线束、配重与收纳盒未进入MuJoCo；阶段式禁入闸不能替代首次实机人工净空确认。",
        "source_plan": str(plan_path),
        "source_plan_sha256": file_sha256(plan_path),
        "source_config": str(config_path),
        "source_config_sha256": file_sha256(config_path),
        "mount_config": str(mount_path),
        "mount_config_sha256": file_sha256(mount_path),
        "sample_step_rad": sample_step,
        "sample_count": sample_count,
        "joint_safety_ok": joint_safety_ok,
        "operational_minimum_joint_margin_deg": operational_minimum_margin,
        "required_joint_margin_deg": required_margin,
        "hard_limit_violations": hard_limit_violations,
        "segment_delta_violations": segment_delta_violations,
        "self_collision_ok": self_collision_ok,
        "active_collisions": active_collisions,
        "allowed_start_contact_count": allowed_start_contact_count,
        "excluded_contact_samples": excluded_contact_samples,
        "floor_contact_samples": floor_contact_samples,
        "external_phase_envelope_ok": external_ok,
        "external_phase_envelope_violations": envelope_violations,
        "tilt_compensation_scale_schedule": {
            **phase_scales,
            "transition_pose": transition_pose,
            "scale_transition_s": transition_s,
        },
        "maximum_abs_requested_tilt_correction_nm": (
            maximum_abs_requested_tilt_correction_nm
        ),
        "tilt_torque_cap_ok": tilt_torque_cap_ok,
        "tilt_torque_cap_violations": tilt_torque_cap_violations,
        "tcp_min_mm": tcp_min,
        "tcp_max_mm": tcp_max,
        "unmodelled_external_obstacles": safety["unmodelled_external_obstacles"],
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("OFFLINE_ONLY = True")
    print("ARM_SERIAL_ACCESS = False")
    print("PLAN_ROUTE =", " -> ".join(item["name"] for item in route))
    print("SAMPLE_COUNT =", sample_count)
    print("OPERATIONAL_MINIMUM_JOINT_MARGIN_DEG =", round(operational_minimum_margin, 3))
    print("TCP_MIN_MM =", [round(value, 2) for value in tcp_min])
    print("TCP_MAX_MM =", [round(value, 2) for value in tcp_max])
    print("SELF_COLLISION_OK =", self_collision_ok)
    print("EXTERNAL_PHASE_ENVELOPE_OK =", external_ok)
    print("TILT_TORQUE_CAP_OK =", tilt_torque_cap_ok)
    print(
        "MAX_ABS_REQUESTED_TILT_CORRECTION_NM =",
        [round(value, 6) for value in maximum_abs_requested_tilt_correction_nm],
    )
    print("UNMODELLED_EXTERNAL_OBSTACLES =", safety["unmodelled_external_obstacles"])
    print("PLAN_SAVED =", plan_path)
    print("REPORT_SAVED =", report_path)
    print("RESULT =", report["status"])
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
