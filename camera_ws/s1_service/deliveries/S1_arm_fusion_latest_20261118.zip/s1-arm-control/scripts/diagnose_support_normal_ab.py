#!/usr/bin/env python3
"""Run the no-planned-motion support-normal compensation A/B diagnostic."""
from __future__ import annotations

import sys

from run_wrist_high_hover_servo import main as run_high_hover_main


def main(argv=None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if "--compensation-ab-only" not in args:
        args.append("--compensation-ab-only")
    return run_high_hover_main(args)


if __name__ == "__main__":
    raise SystemExit(main())
