#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""S1夹爪连续尺寸接触探测台架脚本。

默认只打印配置，不构造Arm、不访问串口。实机模式只保持当前六关节姿态，
不会规划、下降或提升机械臂。

S1标准夹爪没有速度接口，本脚本不再用时间斜坡伪造匀速闭合，而是使用
原生“目标位置+力矩上限”：向20 mm探测目标闭合，等待实际开口稳定后，
用空载基线区分夹空与接触，并把稳定开口作为连续尺寸反馈。

建议顺序：

1. ``--mode empty --execute``：夹爪行程内完全无物体，生成稳定空载基线；
2. ``--mode contact --execute``：把物块放在已经对准的夹爪之间，只探测接触；
3. 接触判定稳定后才显式加入 ``--secure``，施加6 mm命令预紧；仍不提升。
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
from collections import deque
from dataclasses import asdict
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.adaptive_grasp import (
    ContactDetector,
    EmptyProbeBaseline,
    ProbeSample,
    load_empty_baseline,
    load_probe_parameters,
    save_empty_baseline,
    settled_window,
    window_closing_speed_mm_s,
)
from s1_control.arm import Arm, SafetyLimits
from s1_control.gripper import Gripper

DEFAULT_CONFIG = PROJECT_ROOT / "config" / "adaptive_grasp.yaml"
DEFAULT_BASELINE = (
    PROJECT_ROOT / "data" / "adaptive_grasp" / "empty_baseline.json"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="S1夹爪连续尺寸接触探测（默认离线，不访问串口）"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--end", default="gripper")
    parser.add_argument(
        "--mode",
        choices=("empty", "contact"),
        default="empty",
        help="empty生成稳定空载基线；contact使用基线探测物块",
    )
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--baseline", default=str(DEFAULT_BASELINE))
    parser.add_argument(
        "--secure",
        action="store_true",
        help="接触后施加配置中的命令预紧并保持；不提升",
    )
    parser.add_argument(
        "--log",
        default=None,
        help="实验JSON日志路径；省略时写入data/adaptive_grasp/",
    )
    parser.add_argument("--execute", action="store_true")
    return parser.parse_args()


def _all_finite(values) -> bool:
    return all(math.isfinite(float(value)) for value in values)


class BenchRunner:
    """以固定六关节姿态运行夹爪台架试验。"""

    def __init__(self, arm, gripper, hold_q, parameters):
        self.arm = arm
        self.gripper = gripper
        self.hold_q = list(hold_q)
        self.parameters = parameters
        self.started = time.monotonic()
        self.settling_until = self.started + 0.5
        self.records: list[dict] = []
        self.max_hold_error_rad = 0.0

    def tick(self, command_gap_mm, force_nm, phase):
        # Route the six arm joints through the active position commander.
        # On a level bench this falls back to joint_control_mit; on the Go2
        # installation it preserves the configured tilt-gravity compensation.
        self.arm.command_position(self.hold_q)
        self.gripper.command_mm(command_gap_mm, force=force_nm)

        position = self.arm.get_pos()
        velocity = self.arm.get_vel()
        torque = self.arm.get_tau()
        temperature = self.arm.get_temp()
        vectors = (position, velocity, torque, temperature)
        lengths = tuple(len(vector) for vector in vectors)
        if min(lengths) < 7:
            raise RuntimeError(f"反馈数组长度不足: {lengths}")
        if not all(_all_finite(vector) for vector in vectors):
            raise RuntimeError("反馈中出现Nan或Inf")

        hold_error = max(
            abs(position[index] - self.hold_q[index])
            for index in range(6)
        )
        self.max_hold_error_rad = max(self.max_hold_error_rad, hold_error)
        if hold_error > self.parameters.max_joint_hold_error_rad:
            raise RuntimeError(
                f"六关节保持误差{hold_error:.4f}rad超过"
                f"{self.parameters.max_joint_hold_error_rad:.4f}rad"
            )
        if max(temperature) > self.parameters.max_temperature_c:
            raise RuntimeError(
                f"温度{max(temperature):.1f}C超过"
                f"{self.parameters.max_temperature_c:.1f}C"
            )

        fault = self.arm.guard(
            position,
            velocity,
            temperature,
            self.hold_q,
            settling=time.monotonic() < self.settling_until,
        )
        if fault:
            raise RuntimeError(f"GUARD_ABORT: {fault}")

        sample = ProbeSample(
            t_s=time.monotonic() - self.started,
            command_gap_mm=float(command_gap_mm),
            actual_gap_mm=self.gripper.gap_from_fb(position[6]),
            gripper_tau_nm=float(torque[6]),
        )
        self.records.append(
            {
                "phase": phase,
                **asdict(sample),
                "joint_hold_error_rad": hold_error,
                "gripper_velocity_sdk": float(velocity[6]),
                "max_temperature_c": max(float(value) for value in temperature),
            }
        )
        return sample

    def hold(self, gap_mm, force_nm, duration_s, phase):
        deadline = time.monotonic() + duration_s
        next_tick = time.monotonic()
        last_sample = None
        while time.monotonic() < deadline:
            last_sample = self.tick(gap_mm, force_nm, phase)
            next_tick += 1.0 / self.parameters.hz
            delay = next_tick - time.monotonic()
            if delay > 0.0:
                time.sleep(delay)
            else:
                next_tick = time.monotonic()
        return last_sample

    def probe_until_settled(self):
        phase = "limited_close_probe"
        phase_started = time.monotonic()
        next_tick = phase_started
        window: deque[ProbeSample] = deque(
            maxlen=self.parameters.evaluation_capacity
        )

        while True:
            sample = self.tick(
                self.parameters.target_gap_mm,
                self.parameters.probe_force_nm,
                phase,
            )
            window.append(sample)
            elapsed = time.monotonic() - phase_started
            if (
                elapsed >= self.parameters.minimum_observe_s
                and settled_window(list(window), self.parameters)
            ):
                return list(window)
            if elapsed >= self.parameters.timeout_s:
                speed = window_closing_speed_mm_s(list(window))
                gaps = [item.actual_gap_mm for item in window]
                gap_range = max(gaps) - min(gaps) if gaps else float("nan")
                raise RuntimeError(
                    "探测闭合在超时前未形成稳定窗口: "
                    f"timeout={self.parameters.timeout_s:.2f}s "
                    f"actual={sample.actual_gap_mm:.2f}mm "
                    f"speed={speed}mm/s range={gap_range:.2f}mm"
                )

            next_tick += 1.0 / self.parameters.hz
            delay = next_tick - time.monotonic()
            if delay > 0.0:
                time.sleep(delay)
            else:
                next_tick = time.monotonic()


def _default_log_path(mode: str) -> Path:
    stamp = time.strftime("%Y%m%d-%H%M%S")
    return (
        PROJECT_ROOT
        / "data"
        / "adaptive_grasp"
        / f"{stamp}_{mode}.json"
    )


def _write_log(path, args, parameters, runner, outcome, error, baseline):
    output = Path(path).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "schema_version": 2,
        "mode": args.mode,
        "secure_requested": bool(args.secure),
        "outcome": outcome,
        "error": error,
        "parameters": asdict(parameters),
        "baseline": baseline.to_record() if baseline else None,
        "max_joint_hold_error_rad": (
            runner.max_hold_error_rad if runner else None
        ),
        "samples": runner.records if runner else [],
    }
    output.write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return output


def print_configuration(args, parameters, baseline):
    print("MODE =", args.mode)
    print("CONFIG =", Path(args.config).expanduser().resolve())
    print(
        "PROBE_COMMAND_MM =",
        f"{parameters.start_gap_mm:.1f}->{parameters.target_gap_mm:.1f}",
    )
    print("PROBE_FORCE_NM =", parameters.probe_force_nm)
    print("PROBE_TIMEOUT_S =", parameters.timeout_s)
    print("EVALUATION_WINDOW_S =", parameters.evaluation_window_s)
    print("SECURE_PRELOAD_MM =", parameters.secure_preload_command_mm)
    print("SECURE_FORCE_NM =", parameters.secure_force_nm)
    print("SECURE_REQUESTED =", bool(args.secure))
    if baseline:
        print("BASELINE =", Path(args.baseline).expanduser().resolve())
        print(
            "CONTACT_TRACKING_THRESHOLD_MM =",
            round(
                baseline.tracking_excess_p99_mm
                + parameters.tracking_margin_over_empty_mm,
                4,
            ),
        )
        print(
            "CONTACT_TORQUE_DELTA_THRESHOLD_NM =",
            round(
                baseline.tau_abs_deviation_p99_nm
                + parameters.torque_margin_over_empty_nm,
                6,
            ),
        )


def main() -> int:
    args = parse_args()
    if args.secure and args.mode != "contact":
        raise ValueError("--secure只能与--mode contact一起使用")

    parameters = load_probe_parameters(args.config)
    baseline = None
    if args.mode == "contact":
        baseline = load_empty_baseline(args.baseline)
        baseline.assert_compatible(parameters)
    print_configuration(args, parameters, baseline)

    if not args.execute:
        print("OFFLINE_ONLY：未构造Arm、未访问串口、不会使能。")
        return 0

    condition = (
        "空夹爪且全行程无遮挡"
        if args.mode == "empty"
        else "物块已放在对准的两指之间"
    )
    print(
        "本脚本只保持当前六关节姿态，不下降、不提升。\n"
        f"必须满足：电机常红、机械臂有软支撑、{condition}。"
    )
    if input("确认后输入 e：").strip().lower() != "e":
        print("CANCELLED：未连接机械臂。")
        return 0


    limits = SafetyLimits(
        hz=parameters.hz,
        v_max_rad_s=0.05,
        max_track_err_rad=parameters.max_joint_hold_error_rad,
        max_temp_c=parameters.max_temperature_c,
    )
    arm = None
    runner = None
    enable_attempted = False
    outcome = "NOT_STARTED"
    error_text = None
    log_path = Path(args.log) if args.log else _default_log_path(args.mode)
    pending_baseline = None

    try:
        arm = Arm(
            dev=args.dev,
            end_effector=args.end,
            limits=limits,
            check_collision=False,
        )
        gripper = Gripper(arm)
        start = arm.read_joint_median(n=10, warmup_s=1.0)
        hold_q = list(start[:6])
        current_gap = gripper.gap_from_fb(start[6])
        temperature = arm.get_temp()
        if len(temperature) < 7 or not _all_finite(temperature):
            raise RuntimeError("初始温度反馈无效")
        print("HOLD_Q =", [round(value, 4) for value in hold_q])
        print(f"START_GAP_MM = {current_gap:.2f}")
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        if input("确认终端无motor timeout后输入 e 使能：").strip().lower() != "e":
            outcome = "CANCELLED_AFTER_CONNECT"
            return 0

        enable_attempted = True
        arm.enable()
        print("ENABLED")
        runner = BenchRunner(arm, gripper, hold_q, parameters)

        opened = runner.hold(
            parameters.start_gap_mm,
            parameters.secure_force_nm,
            parameters.open_hold_s,
            "open_to_start",
        )
        if (
            parameters.start_gap_mm - opened.actual_gap_mm
            > parameters.empty_max_final_excess_mm
        ):
            raise RuntimeError(
                f"夹爪未能张开到起始区域: actual={opened.actual_gap_mm:.2f}mm"
            )
        print(f"OPEN_READY_GAP_MM = {opened.actual_gap_mm:.2f}")

        stable_samples = runner.probe_until_settled()
        stable_gap = statistics.median(
            sample.actual_gap_mm for sample in stable_samples
        )
        stable_speed = window_closing_speed_mm_s(stable_samples)
        stable_range = max(
            sample.actual_gap_mm for sample in stable_samples
        ) - min(sample.actual_gap_mm for sample in stable_samples)
        print(
            "PROBE_SETTLED",
            f"gap={stable_gap:.2f}mm",
            f"speed={stable_speed:.3f}mm/s",
            f"range={stable_range:.3f}mm",
        )

        if args.mode == "empty":
            final_excess = stable_gap - parameters.target_gap_mm
            if final_excess > parameters.empty_max_final_excess_mm:
                raise RuntimeError(
                    f"空载稳定开口比目标大{final_excess:.2f}mm，超过"
                    f"{parameters.empty_max_final_excess_mm:.2f}mm；"
                    "探测力矩不足或夹爪受阻"
                )
            pending_baseline = EmptyProbeBaseline.from_samples(
                stable_samples,
                parameters,
            )
            baseline = pending_baseline
            print("EMPTY_TRACKING_P99_MM =", round(
                baseline.tracking_excess_p99_mm, 4
            ))
            print("EMPTY_TAU_CENTER_NM =", round(baseline.tau_center_nm, 6))
            print("EMPTY_TAU_DEV_P99_NM =", round(
                baseline.tau_abs_deviation_p99_nm, 6
            ))
            outcome = "EMPTY_BASELINE_DONE"
        else:
            detector = ContactDetector(parameters, baseline)
            decision = None
            for sample in stable_samples:
                decision = detector.update(sample)
            if not decision or not decision.detected:
                print("CONTACT_RESULT = MISS")
                outcome = "CONTACT_MISS"
            else:
                print(
                    "CONTACT_RESULT = DETECTED",
                    f"gap={decision.contact_gap_mm:.2f}mm",
                    f"excess={decision.tracking_excess_mm:.2f}mm",
                    f"tau_delta={decision.torque_delta_nm:.6f}",
                    f"closing_speed={decision.closing_speed_mm_s}",
                )
                outcome = "CONTACT_DETECTED"
                if args.secure:
                    secure_gap = max(
                        parameters.target_gap_mm,
                        decision.contact_gap_mm
                        - parameters.secure_preload_command_mm,
                    )
                    secured = runner.hold(
                        secure_gap,
                        parameters.secure_force_nm,
                        parameters.secure_hold_s,
                        "secure_hold",
                    )
                    print(
                        "SECURE_HOLD_DONE",
                        f"command={secure_gap:.2f}mm",
                        f"actual={secured.actual_gap_mm:.2f}mm",
                        f"force_limit={parameters.secure_force_nm:.2f}",
                    )
                    outcome = "SECURE_HOLD_DONE"

        released = runner.hold(
            parameters.start_gap_mm,
            parameters.secure_force_nm,
            parameters.open_hold_s,
            "release",
        )
        print(f"RELEASE_GAP_MM = {released.actual_gap_mm:.2f}")
        if pending_baseline is not None:
            saved = save_empty_baseline(args.baseline, pending_baseline)
            print("BASELINE_SAVED =", saved)
        print("MAX_JOINT_HOLD_ERROR_RAD =", round(
            runner.max_hold_error_rad, 6
        ))
        return 0

    except KeyboardInterrupt:
        outcome = "USER_ABORT"
        error_text = "KeyboardInterrupt"
        print("USER_ABORT")
        return 130
    except Exception as exc:
        outcome = "FAILED"
        error_text = repr(exc)
        print("TEST_FAILED:", error_text)
        return 1
    finally:
        if arm is not None:
            if enable_attempted:
                try:
                    arm.disable()
                    print("DISABLED：电机应为常红。")
                except Exception as exc:
                    print("DISABLE_FAILED:", repr(exc))
            else:
                try:
                    arm.close()
                except Exception as exc:
                    print("CLOSE_FAILED:", repr(exc))
        if runner is not None:
            saved_log = _write_log(
                log_path,
                args,
                parameters,
                runner,
                outcome,
                error_text,
                baseline,
            )
            print("LOG_SAVED =", saved_log)
            print("RESULT =", outcome)


if __name__ == "__main__":
    raise SystemExit(main())
