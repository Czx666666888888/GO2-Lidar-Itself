# -*- coding: utf-8 -*-
"""走位保持诊断：命令机械臂到指定关节位姿并保持，供尺子实测/肉眼核对指尖位置。
不检测目标、不接触、不动夹爪。序列：读起点→(READY)→target 保持→原路返回→失能。

复用 s1_control（安全闸/斜坡/FK 全在库里）。这是旧 s1_goto_hold_diag.py 的 s1_control 版。

用法（先移走障碍物）：
  python scripts/goto_hold.py                                  # 预检，不上电
  python scripts/goto_hold.py --target-q=<CSV> --execute       # 上电到 target 保持（负值用 =）
  python scripts/goto_hold.py --ready-only --execute           # 只到 READY 保持
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from s1_control.arm import Arm, SafetyLimits            # noqa: E402
from s1_control.kinematics import Kinematics, READY_Q   # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev", default="/dev/s1-arm")
    ap.add_argument("--end", default="gripper")
    ap.add_argument("--target-q", default="", help="6 关节 CSV（负值用 =）")
    ap.add_argument("--ready-only", action="store_true", help="只到 READY 保持")
    ap.add_argument("--hold-s", type=float, default=20.0)
    ap.add_argument("--v-max-rad-s", type=float, default=0.12)
    ap.add_argument("--max-joint-delta-rad", type=float, default=2.0)
    ap.add_argument("--execute", action="store_true")
    args = ap.parse_args()

    if args.ready_only:
        target_q = list(READY_Q)
    elif args.target_q:
        target_q = [float(x) for x in args.target_q.split(",")]
        assert len(target_q) == 6, f"target-q 需 6 值，收到 {len(target_q)}"
    else:
        print("需要 --target-q 或 --ready-only"); return

    kin = Kinematics(verbose=True)
    print("FK(target) TCP mm =", [round(v * 1000, 1) for v in kin.fk(target_q)[:3]])
    print("FK(READY)  TCP mm =", [round(v * 1000, 1) for v in kin.fk(READY_Q)[:3]])

    limits = SafetyLimits(v_max_rad_s=args.v_max_rad_s,
                          max_joint_delta_rad=args.max_joint_delta_rad)
    arm = Arm(dev=args.dev, end_effector=args.end, limits=limits)

    start_q = arm.read_joint_median()[:6]
    print("start_q =", [f"{q:+.4f}" for q in start_q])

    waypoints = ([] if args.ready_only else [("ready", list(READY_Q))]) + [("target", target_q)]
    arm.preflight(waypoints, start_q)
    print("PREFLIGHT_OK")
    if not args.execute:
        print("未指定 --execute，只做预检，结束。"); arm.close(); return

    seq = ([] if args.ready_only else [(start_q, list(READY_Q), "start->ready")])
    seq.append((list(READY_Q) if not args.ready_only else start_q, target_q, "->target"))

    arm.enable()
    abort = None
    try:
        for qf, qt, label in seq:
            abort = arm.move(qf, qt, label)
            print(("中止:" if abort else "到达:"), label, abort or "")
            if abort:
                break
        if not abort:
            t0 = time.monotonic(); last = -2.0
            while time.monotonic() - t0 < args.hold_s:
                arm._arm.joint_control_mit(list(target_q))
                now = time.monotonic() - t0
                if now - last >= 2.0:
                    tcp = kin.fk(arm.get_pos()[:6])
                    print(f"  t={now:4.1f}s  FK指尖mm={[round(v*1000,1) for v in tcp[:3]]}")
                    last = now
                time.sleep(arm.dt)
            ret = ([(target_q, list(READY_Q), "target->ready"),
                    (list(READY_Q), start_q, "ready->start")]
                   if not args.ready_only else [(target_q, start_q, "target->start")])
            for qf, qt, label in ret:
                ab = arm.move(qf, qt, label)
                print(("中止:" if ab else "到达:"), label, ab or "")
                if ab:
                    abort = ab; break
    finally:
        arm.disable()
        print("已失能")
    print("DIAG_ABORT:" if abort else "DIAG_DONE", abort or "")


if __name__ == "__main__":
    main()
