#!/usr/bin/env python3
"""Execute a bounded D455 multi-view scan on the Go2 right side.

This first commissioning executor never aligns, changes grasp orientation,
descends, commands the gripper, lifts, or visits the collection box.  It deploys
to the commissioned right-observe hub, captures there, and only visits the
offline-selected reversible spoke views when no target was accepted.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import math
from pathlib import Path
import sys

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SCRIPTS_DIR, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from execute_go2_observe_deployment import (  # noqa: E402
    guarded_hold,
    planned_phases,
    ramp_compensation_scale,
    wait_for_valid_feedback,
    write_json,
)
from run_go2_visual_alignment import (  # noqa: E402
    compute_observation,
    hold_for_operator_support_before_disable,
    load_alignment_config,
    load_detector_config,
    resolve_project_path,
    run_capture_process_while_holding,
)
from s1_control.arm import Arm, SafetyLimits  # noqa: E402
from s1_control.go2_deployment import (  # noqa: E402
    file_sha256,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)
from s1_control.kinematics import Kinematics  # noqa: E402
from s1_control.tilt_gravity import (  # noqa: E402
    UrdfGravityModel,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record  # noqa: E402
from s1_control.wrist_visual_servo import (  # noqa: E402
    dynamic_base_camera,
    load_wrist_servo_config,
    support_plane_geometry,
)


DEFAULT_PLAN = (
    PROJECT_ROOT / "data/plans/go2_right_multiview_observation_scan_candidate_v1.json"
)
DEFAULT_REPORT = (
    PROJECT_ROOT
    / "data/plans/go2_right_multiview_observation_scan_collision_report_v1.json"
)
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data/go2_multiview_scan_runs"
MAXIMUM_LIVE_PLANNED_SUPPORT_NORMAL_DEVIATION_DEG = 2.0


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def verify_scan_artifacts(plan_path: Path, report_path: Path) -> tuple[dict, dict]:
    plan = load_json(plan_path)
    report = load_json(report_path)
    if plan.get("mode") != "go2_right_multiview_observation_scan_offline_plan":
        raise ValueError("multiview plan mode is incompatible")
    if plan.get("status") != (
        "offline_multiview_scan_candidate_pending_physical_validation"
    ):
        raise ValueError("multiview plan is not a complete offline candidate")
    if plan.get("arm_serial_access") is not False or plan.get("camera_access") is not False:
        raise ValueError("multiview plan was not generated offline-only")
    if report.get("status") != "OFFLINE_MULTIVIEW_SCAN_PASS":
        raise ValueError("multiview collision report did not pass")
    if str(report.get("source_plan_sha256", "")).lower() != file_sha256(plan_path):
        raise RuntimeError("multiview collision report is not bound to this plan")
    for key, sha_key in (
        ("baseline_run", "baseline_run_sha256"),
        ("workspace_scan", "workspace_scan_sha256"),
        ("flow_config", "flow_config_sha256"),
        ("deployment_plan", "deployment_plan_sha256"),
        ("wrist_config", "wrist_config_sha256"),
        ("mount_config", "mount_config_sha256"),
    ):
        path = resolve_project_path(plan[key])
        if file_sha256(path) != str(plan[sha_key]).lower():
            raise RuntimeError(f"multiview bound artifact changed: {key}")
    selected = list(plan.get("selected_views", []))
    if not 1 <= len(selected) <= 7:
        raise ValueError("multiview selected view count must be within [1, 7]")
    if selected[0].get("name") != "view_up000_vp000_np000":
        raise ValueError("first multiview capture must be the commissioned hub")
    if plan.get("uncovered_point_ids") and not plan.get("grasp_search", False):
        raise ValueError("multiview plan leaves candidate grasp points uncovered")
    return plan, report


def target_coordinates(observation: dict, scan: dict) -> dict:
    target = np.asarray(observation["surface_point_base_m"], dtype=float)
    baseline = np.asarray(
        scan["baseline"]["target_top_base_xyz_mm"],
        dtype=float,
    ) / 1000.0
    frame = scan["support_plane_frame"]
    axis_u = np.asarray(frame["axis_u_base"], dtype=float)
    axis_v = np.asarray(frame["axis_v_base"], dtype=float)
    support_up = np.asarray(frame["support_up_normal_base"], dtype=float)
    delta_mm = 1000.0 * (target - baseline)
    u_mm = float(np.dot(delta_mm, axis_u))
    v_mm = float(np.dot(delta_mm, axis_v))
    normal_mm = float(np.dot(delta_mm, support_up))
    points = list(scan["points"])
    nearest = min(
        points,
        key=lambda item: math.hypot(
            u_mm - float(item["u_offset_mm"]),
            v_mm - float(item["v_offset_mm"]),
        ),
    )
    nearest_distance = math.hypot(
        u_mm - float(nearest["u_offset_mm"]),
        v_mm - float(nearest["v_offset_mm"]),
    )
    return {
        "target_base_xyz_mm": (1000.0 * target).tolist(),
        "u_mm": u_mm,
        "v_mm": v_mm,
        "support_normal_offset_mm": normal_mm,
        "nearest_offline_point": {
            "u_mm": float(nearest["u_offset_mm"]),
            "v_mm": float(nearest["v_offset_mm"]),
            "planar_distance_mm": nearest_distance,
            "high_alignment_pass": bool(nearest.get("high_alignment_pass")),
            "all_orientations_grasp_geometry_pass": bool(
                nearest.get("all_orientations_grasp_geometry_pass")
            ),
        },
        "classification": (
            "inside_nearest_40mm_candidate_cell"
            if nearest_distance <= math.sqrt(2.0) * 20.0
            else "outside_scanned_candidate_cells"
        ),
    }


def detection_accepted(capture_result: dict) -> bool:
    detection = capture_result.get("detection", {})
    selected = detection.get("selected")
    return bool(
        isinstance(selected, dict)
        and selected.get("accepted") is True
        and str(detection.get("status", "")).startswith("DETECTED")
    )


def validated_support_plane_from_capture(
    capture_result: dict,
    q_observed,
    *,
    loaded,
    flange_kinematics,
    planned_support_up,
    maximum_deviation_deg: float = (
        MAXIMUM_LIVE_PLANNED_SUPPORT_NORMAL_DEVIATION_DEG
    ),
) -> dict:
    """Validate a support plane even when the detector reports NO_TARGET."""
    metadata = capture_result.get("capture_metadata", {})
    if metadata.get("quality_pass") is not True:
        raise ValueError("RGB-D capture quality gate failed before scan motion")
    detection = capture_result.get("detection", {})
    plane = detection.get("plane")
    if not isinstance(plane, dict) or plane.get("quality_pass") is not True:
        raise ValueError("support-plane quality gate failed before scan motion")
    normal_camera = np.asarray(plane.get("normal_cam"), dtype=float)
    if normal_camera.shape != (3,) or not np.all(np.isfinite(normal_camera)):
        raise ValueError("support-plane camera normal must contain three finite values")
    q = np.asarray(q_observed, dtype=float)
    if q.shape != (6,) or not np.all(np.isfinite(q)):
        raise ValueError("observed scan joints must contain six finite values")
    transform_base_camera = dynamic_base_camera(
        flange_kinematics.fk(q.tolist()),
        loaded.transform_flange_camera,
    )
    geometry = support_plane_geometry(normal_camera, transform_base_camera)
    maximum_camera_tilt_deg = float(
        loaded.record["safety"]["maximum_camera_tilt_from_down_deg"]
    )
    camera_tilt_deg = float(geometry["camera_tilt_from_support_down_deg"])
    if camera_tilt_deg > maximum_camera_tilt_deg:
        raise RuntimeError(
            "camera tilt from support down "
            f"{camera_tilt_deg:.2f} deg exceeds {maximum_camera_tilt_deg:.2f} deg"
        )
    live_support_up = np.asarray(geometry["support_up_normal_base"], dtype=float)
    planned = np.asarray(planned_support_up, dtype=float)
    if planned.shape != (3,) or not np.all(np.isfinite(planned)):
        raise ValueError("planned support up normal must contain three finite values")
    planned /= np.linalg.norm(planned)
    deviation_deg = math.degrees(
        math.acos(float(np.clip(np.dot(live_support_up, planned), -1.0, 1.0)))
    )
    if deviation_deg > float(maximum_deviation_deg):
        raise RuntimeError(
            "live support normal deviates from the bound planning normal by "
            f"{deviation_deg:.2f} deg, exceeding {maximum_deviation_deg:.2f} deg"
        )
    return {
        **geometry,
        "planning_support_up_normal_base": planned.tolist(),
        "deviation_from_planning_deg": deviation_deg,
        "maximum_deviation_deg": float(maximum_deviation_deg),
        "plane_quality": {
            "rmse_mm": plane.get("rmse_mm"),
            "inlier_ratio": plane.get("inlier_ratio"),
            "sample_count": plane.get("sample_count"),
        },
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Go2 right-side D455 multi-view scan-only commissioning"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--plan", default=str(DEFAULT_PLAN))
    parser.add_argument("--collision-report", default=str(DEFAULT_REPORT))
    parser.add_argument("--run-id")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)

    plan_path = resolve_project_path(args.plan)
    report_path = resolve_project_path(args.collision_report)
    plan, report = verify_scan_artifacts(plan_path, report_path)
    flow_config_path = resolve_project_path(plan["flow_config"])
    _, flow_config = load_alignment_config(flow_config_path)
    deployment_path = resolve_project_path(plan["deployment_plan"])
    deployment = load_json(deployment_path)
    deployment_report_path = resolve_project_path(
        flow_config["deployment_collision_report"]
    )
    mount_path = resolve_project_path(plan["mount_config"])
    mount_record = load_json(mount_path)
    verify_bound_report(deployment_path, deployment_report_path, mount_path)
    wrist_path = resolve_project_path(plan["wrist_config"])
    loaded = load_wrist_servo_config(wrist_path)
    scan_path = resolve_project_path(plan["workspace_scan"])
    scan = load_json(scan_path)
    planned_support_up = np.asarray(
        scan["support_plane_frame"]["support_up_normal_base"],
        dtype=float,
    )
    selected_views = list(plan["selected_views"])
    deployment_waypoints = list(deployment["joint_path"])
    motion = deployment["motion"]
    tilt_config = motion["tilt_compensation"]
    vertical_scale = float(tilt_config["vertical_escape_scale"])
    high_turn_scale = float(tilt_config["high_turn_scale"])
    side_scale = float(tilt_config["side_deploy_scale"])
    transition_s = float(tilt_config["scale_transition_s"])
    if not math.isclose(vertical_scale, high_turn_scale, abs_tol=1e-9):
        raise ValueError("vertical and high-turn compensation scales must match")
    if str(tilt_config["transition_pose"]) != "right_ready":
        raise ValueError("tilt transition pose must remain right_ready")

    runtime = flow_config["runtime"]
    capture_quality_override = dict(flow_config["capture_quality_override"])
    print("MODE = GO2_RIGHT_MULTIVIEW_SCAN_ONLY")
    print("PLAN_FILE =", plan_path)
    print("PLAN_SHA256 =", file_sha256(plan_path))
    print("COLLISION_REPORT =", report_path)
    print("COLLISION_REPORT_VERIFIED = True")
    print("DEPLOYMENT_COLLISION_REPORT_VERIFIED = True")
    print("SELECTED_VIEWS =", [item["name"] for item in selected_views])
    print("COVERED_OFFLINE_CANDIDATE_POINTS =", len(plan["covered_point_ids"]))
    print("UNMODELLED_EXTERNAL_OBSTACLES =", report["warning"])
    print(
        "FORBIDDEN = center-alignment, J6-grasp-orientation, descent, "
        "gripper-command, contact, lift, box-place"
    )
    if not args.execute:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("CAMERA_ACCESS = False")
        print("RESULT = OFFLINE_PREFLIGHT_OK")
        return 0

    print("\nFirst physical run: scan only. Go2 must remain crouched and stationary.")
    print(
        "Start from red mechanical zero; keep soft support clear of every right-side "
        "hub/spoke path; exactly one test target may be placed on the ground."
    )
    print(
        "The fixed box, D455 cable, S1 harness and people must remain outside the "
        "entire scan envelope."
    )
    if input("Confirm all conditions, then input e: ").strip().lower() != "e":
        print("RESULT = CANCELLED_BEFORE_CONNECTION")
        return 2

    run_id = args.run_id or datetime.now().strftime("multiview_%Y%m%d-%H%M%S")
    run_dir = DEFAULT_OUTPUT_ROOT / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": "go2_right_multiview_scan_only",
        "status": "started",
        "plan": str(plan_path),
        "plan_sha256": file_sha256(plan_path),
        "collision_report": str(report_path),
        "collision_report_sha256": file_sha256(report_path),
        "captures": [],
        "visited_views": [],
    }
    write_json(log_path, log)

    limits = SafetyLimits(
        hz=float(motion["hz"]),
        v_max_rad_s=float(motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(motion["j6_v_max_rad_s"]),
        motion_profile=str(motion["profile"]),
        max_track_err_rad=float(motion["maximum_track_error_rad"]),
        max_speed_rad_s=float(motion["maximum_measured_speed_rad_s"]),
        max_temp_c=float(motion["maximum_temperature_c"]),
        max_joint_delta_rad=0.9,
        settle_seconds=float(motion["settle_seconds"]),
    )
    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
    vision_config, vision_config_path = load_detector_config(
        loaded.vision_config_path
    )

    arm = None
    commander = None
    enabled = False
    at_hub = False
    deployed_phases = []
    current_view = None
    safely_returned = False
    result = "ABORTED"
    try:
        arm = Arm(
            dev=args.dev,
            end_effector="gripper",
            limits=limits,
            check_collision=False,
        )
        commander = commander_from_mount_record(
            tilt_model,
            mount_record,
            vertical_scale,
        )
        arm.set_position_commander(commander)
        start_q, temperature, readiness = wait_for_valid_feedback(
            arm,
            limits.max_temp_c,
        )
        print("STARTUP_FEEDBACK_READY =", readiness["ready"])
        print("START_Q =", [round(value, 6) for value in start_q])
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        violations = start_window_violations(
            start_q,
            deployment["start_safe_windows_rad"],
        )
        rear_ready = [float(value) for value in deployment_waypoints[1]["q"]]
        start_delta = max_joint_delta(start_q, rear_ready)
        live_ok = not violations and start_delta <= limits.max_joint_delta_rad
        print("START_SAFE_WINDOW_OK =", not violations)
        for violation in violations:
            print("START_WINDOW_VIOLATION =", violation)
        print("START_TO_REAR_READY_DELTA_RAD =", round(start_delta, 6))
        print("LIVE_PRECHECK_OK =", live_ok)
        log.update(
            {
                "start_q": start_q,
                "temperature_c": temperature,
                "startup_readiness": readiness,
                "start_window_violations": violations,
                "start_to_rear_ready_delta_rad": start_delta,
            }
        )
        write_json(log_path, log)
        if not live_ok:
            result = "LIVE_PRECHECK_REJECTED"
            return 2

        arm.preflight(
            [(item["name"], item["q"]) for item in deployment_waypoints[1:]],
            start_q,
            collision_report_verified=True,
        )
        hub_q = list(plan["hub"]["q_rad"])
        for view in selected_views:
            path = [list(item) for item in view["path_from_hub_q_rad"]]
            if max_joint_delta(path[0], hub_q) > 1e-6:
                raise RuntimeError(f"scan path does not start at hub: {view['name']}")
            arm.preflight(
                [
                    (f"{view['name']}_{index:02d}", q)
                    for index, q in enumerate(path[1:], start=1)
                ],
                hub_q,
                collision_report_verified=True,
            )
            arm.preflight(
                [
                    (f"{view['name']}_return_{index:02d}", q)
                    for index, q in enumerate(reversed(path[:-1]), start=1)
                ],
                path[-1],
                collision_report_verified=True,
            )
        print(
            "Confirm the full deployment and all hub/spoke paths remain clear; "
            "input d to enable."
        )
        if input("SCAN_ENABLE_CONFIRM [d]: ").strip().lower() != "d":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        phases = planned_phases(start_q, deployment_waypoints, "right_observe")
        arm.enable()
        enabled = True
        print("ENABLED_WITH_TILT_COMPENSATION scale =", commander.compensation_scale)
        guarded_hold(arm, start_q, 0.5, "initial_hold")
        for name, points in phases:
            if name == "side_deploy":
                transition = ramp_compensation_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=vertical_scale,
                    end_scale=side_scale,
                    duration_s=transition_s,
                    label="right_ready_scale_up",
                )
                log.setdefault("compensation_transitions", []).append(transition)
                write_json(log_path, log)
            print("DEPLOY_PHASE =", name)
            fault = arm.move_waypoints(points, name)
            if fault:
                raise RuntimeError(fault)
            deployed_phases.append((name, points))
            print("REACHED =", name)
        at_hub = True
        print("SCAN_HUB_REACHED = True")

        target_found = False
        for view_index, view in enumerate(selected_views, start=1):
            current_view = view
            path = [list(item) for item in view["path_from_hub_q_rad"]]
            if view_index > 1:
                if not at_hub:
                    raise RuntimeError("scan route lost the right-observe hub")
                print("SCAN_VIEW_OUTBOUND =", view["name"])
                fault = arm.move_waypoints(path[1:], f"scan_outbound_{view['name']}")
                if fault:
                    raise RuntimeError(fault)
                at_hub = False
            q_hold = list(view["q_rad"])
            guarded_hold(arm, q_hold, 0.5, f"settle_{view['name']}")
            capture, q_observed = run_capture_process_while_holding(
                arm,
                q_hold,
                wrist_config_path=wrist_path,
                vision_config_path=vision_config_path,
                run_dir=run_dir,
                capture_label=f"view_{view_index:02d}",
                timeout_s=float(runtime["worker_timeout_s"]),
                label=f"multiview_capture_{view_index:02d}",
                hold_hz=float(runtime["capture_hold_hz"]),
                velocity_guard_hz=float(runtime["capture_velocity_guard_hz"]),
                temperature_period_s=float(runtime["capture_temperature_period_s"]),
                camera_attempts=int(runtime["camera_attempts"]),
                camera_retry_delay_s=float(runtime["camera_retry_delay_s"]),
                capture_quality_override=capture_quality_override,
                write_raw_capture_previews=False,
            )
            capture_record = {
                "view_index": view_index,
                "view_name": view["name"],
                "planned_q_rad": q_hold,
                "observed_q_rad": list(q_observed),
                "capture": capture,
                "target_accepted": detection_accepted(capture),
            }
            support_plane = validated_support_plane_from_capture(
                capture,
                q_observed,
                loaded=loaded,
                flange_kinematics=flange_kinematics,
                planned_support_up=planned_support_up,
            )
            support_update = commander.set_support_up_normal(
                support_plane["support_up_normal_base"],
                source=f"validated_support_plane:multiview:{view['name']}",
            )
            guarded_hold(
                arm,
                list(q_observed),
                float(commander.normal_transition_s) + 0.25,
                f"support_normal_transition_{view['name']}",
            )
            capture_record["support_plane"] = support_plane
            capture_record["support_normal_update"] = support_update
            print(
                "MULTIVIEW_SUPPORT_NORMAL_UPDATE ="
                f" view={view['name']}"
                f" deviation={support_plane['deviation_from_planning_deg']:.3f}deg"
                f" tilt={support_plane['camera_tilt_from_support_down_deg']:.3f}deg"
                f" rmse={support_plane['plane_quality']['rmse_mm']}mm"
            )
            log["visited_views"].append(view["name"])
            if capture_record["target_accepted"]:
                observation_record = compute_observation(
                    capture,
                    q_observed,
                    loaded=loaded,
                    flange_kinematics=flange_kinematics,
                    observation_safety=loaded.record["safety"],
                )
                coordinates = target_coordinates(
                    observation_record["observation"],
                    scan,
                )
                capture_record["observation"] = observation_record
                capture_record["target_coordinates"] = coordinates
                log["selected_target"] = {
                    "view_name": view["name"],
                    "coordinates": coordinates,
                }
                print(
                    "MULTIVIEW_TARGET_FOUND ="
                    f" view={view['name']}"
                    f" u={coordinates['u_mm']:.1f}mm"
                    f" v={coordinates['v_mm']:.1f}mm"
                    f" normal={coordinates['support_normal_offset_mm']:.1f}mm"
                    f" classification={coordinates['classification']}"
                )
                target_found = True
            else:
                detection = capture.get("detection", {})
                print(
                    "MULTIVIEW_NO_ACCEPTED_TARGET ="
                    f" view={view['name']}"
                    f" status={detection.get('status')}"
                    f" candidates={len(detection.get('candidates', []))}"
                )
            log["captures"].append(capture_record)
            write_json(log_path, log)

            if view_index > 1:
                print("SCAN_VIEW_RETURN_TO_HUB =", view["name"])
                fault = arm.move_waypoints(
                    list(reversed(path[:-1])),
                    f"scan_return_{view['name']}",
                )
                if fault:
                    raise RuntimeError(fault)
                at_hub = True
            current_view = None
            if target_found:
                print("MULTIVIEW_EARLY_STOP = target accepted")
                break

        for name, points in reversed(deployed_phases):
            return_name = f"{name}_return"
            print("RETURN_PHASE =", return_name)
            fault = arm.move_waypoints(list(reversed(points)), return_name)
            if fault:
                raise RuntimeError(fault)
            if name == "side_deploy":
                transition = ramp_compensation_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=side_scale,
                    end_scale=high_turn_scale,
                    duration_s=transition_s,
                    label="right_ready_scale_down",
                )
                log.setdefault("compensation_transitions", []).append(transition)
                write_json(log_path, log)
        safely_returned = True
        result = (
            "MULTIVIEW_TARGET_FOUND_SAFE_RETURN"
            if target_found
            else "MULTIVIEW_NO_TARGET_SAFE_RETURN"
        )
        return 0
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        print(result)
        log["exception"] = result
        if current_view is not None:
            log["exception_view"] = current_view.get("name")
        if commander is not None and commander.last_snapshot is not None:
            log["last_tilt_compensation_snapshot"] = commander.last_snapshot
        write_json(log_path, log)
        if arm is not None and enabled and not safely_returned:
            support = hold_for_operator_support_before_disable(
                arm,
                timeout_s=30.0,
                command_hz=10.0,
                prompt="SCAN_ABORTED: support the arm, then input s: ",
            )
            log["operator_support_before_disable"] = support
            write_json(log_path, log)
        return 1
    finally:
        if arm is not None:
            try:
                arm.disable()
            except Exception as exc:
                print("DISABLE_WARNING =", repr(exc))
        log["status"] = result
        write_json(log_path, log)
        print("DISABLED: motors should be solid red; keep supporting the arm.")
        print("LOG_SAVED =", log_path)
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
