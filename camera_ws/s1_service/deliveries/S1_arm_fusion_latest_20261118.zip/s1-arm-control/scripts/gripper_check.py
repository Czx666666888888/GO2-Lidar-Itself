# -*- coding: utf-8 -*-
"""夹爪开口验证：臂保持 READY 不动，命令夹爪张到目标 mm 序列，供卡尺实测。

验证 s1_control.gripper 的 mm→fb 映射在实机上正确（对齐 config/gripper.yaml 卡尺验证点）。
只动夹爪(ID7)、臂停 READY；不接触任何目标。

★通电前务必确认夹爪手指行程范围内【无遮挡】★
  （本项目前身教训：夹爪被物理挡住会造成“命令无响应”的假象，误导整轮诊断。）

用法：
  python scripts/gripper_check.py                       # 预检不通电
  python scripts/gripper_check.py --execute             # 通电，默认张到 20/50/81/100mm 各保持
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from s1_control.arm import Arm, SafetyLimits            # noqa: E402
from s1_control.gripper import Gripper                  # noqa: E402
from s1_control.kinematics import READY_Q               # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dev", default="/dev/s1-arm")
    ap.add_argument("--end", default="gripper")
    ap.add_argument("--targets-mm", default="20,50,81,100", help="张开目标序列 mm（CSV）")
    ap.add_argument("--dwell-s", type=float, default=4.0, help="每档保持秒数，够读卡尺")
    ap.add_argument("--v-max-rad-s", type=float, default=0.12)
    ap.add_argument("--execute", action="store_true")
    args = ap.parse_args()

    targets = [float(x) for x in args.targets_mm.split(",")]
    arm = Arm(dev=args.dev, end_effector=args.end,
              limits=SafetyLimits(v_max_rad_s=args.v_max_rad_s))
    grip = Gripper(arm)

    print("目标开口序列 mm ->  fb 命令：")
    for mm in targets:
        print(f"  {mm:5.1f} mm -> fb={grip.mm_to_fb(mm):.4f}")

    start = arm.read_joint_median()
    start_q = start[:6]
    print("start_q =", [f"{q:+.4f}" for q in start_q], "grip_fb=", f"{start[6]:+.4f}",
          f"当前开口≈{grip.gap_from_fb(start[6]):.1f}mm")
    arm.preflight([("ready", list(READY_Q))], start_q)
    print("PREFLIGHT_OK  ★确认夹爪行程内无遮挡再上电★")
    if not args.execute:
        print("未指定 --execute，只做预检，结束。"); arm.close(); return

    arm.enable()
    try:
        # 先到 READY（夹爪不发命令）
        abort = arm.move(start_q, list(READY_Q), "start->READY")
        print(("中止:" if abort else "到达:"), "READY", abort or "")
        if abort:
            return
        print("\nmm_cmd  fb_cmd   fb_real   gap_real_mm   <-- 读卡尺")
        for mm in targets:
            fb_cmd = grip.mm_to_fb(mm)
            t0 = time.monotonic()
            while time.monotonic() - t0 < args.dwell_s:
                arm._arm.joint_control_mit(list(READY_Q))
                grip.command_mm(mm)
                time.sleep(arm.dt)
            fb_real = arm.get_pos()[6]
            print(f"{mm:5.1f}   {fb_cmd:+.4f}  {fb_real:+.4f}   {grip.gap_from_fb(fb_real):5.1f}")
    finally:
        arm.disable()
        print("已失能")
    print("GRIPPER_CHECK_DONE")


if __name__ == "__main__":
    main()
