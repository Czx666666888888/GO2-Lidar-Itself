#!/usr/bin/env python3
"""Plan and verify the fixed Go2 funnel-box placement route offline."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import mujoco
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from S1_SDK.hardware.collision import CollisionChecker  # noqa: E402
from s1_control.calib import load_tcp  # noqa: E402
from s1_control.go2_deployment import (  # noqa: E402
    interpolate_segment,
    joint_hard_limit_violations,
    joint_margin_deg,
    max_joint_delta,
)
from s1_control.kinematics import Kinematics  # noqa: E402
from s1_control.tilt_gravity import (  # noqa: E402
    UrdfGravityModel,
    differential_tilt_compensation_from_support_up,
    gravity_vector_base_from_support_up,
    limited_correction,
    locate_official_gripper_urdf,
)


def resolve_project_path(raw: str | Path) -> Path:
    from s1_control.project_paths import project_path
    return project_path(raw, PROJECT_ROOT)


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finite_vector(raw, length: int, name: str) -> np.ndarray:
    value = np.asarray(raw, dtype=np.float64)
    if value.shape != (length,) or not np.isfinite(value).all():
        raise ValueError(f"{name} must contain {length} finite values")
    return value


def unit_vector(raw, name: str) -> np.ndarray:
    value = finite_vector(raw, 3, name)
    norm = float(np.linalg.norm(value))
    if norm < 1e-9:
        raise ValueError(f"{name} cannot be zero")
    return value / norm


def set_model_q(checker, q):
    mujoco.mj_resetData(checker.model, checker.data)
    model_q = list(q)
    model_q[3] += 0.01
    checker.data.qpos[:6] = np.asarray(model_q, dtype=float)
    mujoco.mj_forward(checker.model, checker.data)
    return model_q


def collision_sets(checker, model_q):
    exclusions = {tuple(sorted(pair)) for pair in checker.exclude_pairs}
    dynamic_pair = tuple(sorted(("geom1", "geom5")))
    if not (0.0 <= model_q[2] <= 0.02) or model_q[3] < -0.02:
        exclusions.discard(dynamic_pair)
    active = set()
    excluded = set()
    floor = set()
    for index in range(checker.data.ncon):
        contact = checker.data.contact[index]
        names = tuple(sorted((
            mujoco.mj_id2name(checker.model, mujoco.mjtObj.mjOBJ_GEOM, contact.geom1),
            mujoco.mj_id2name(checker.model, mujoco.mjtObj.mjOBJ_GEOM, contact.geom2),
        )))
        if "floor" in names:
            floor.add(names)
        elif names in exclusions:
            excluded.add(names)
        else:
            active.add(names)
    return active, excluded, floor


def split_joint_segment(name_prefix: str, start_q, end_q, maximum_delta_rad: float) -> list[dict]:
    start = finite_vector(start_q, 6, "segment start")
    end = finite_vector(end_q, 6, "segment end")
    segment_count = max(1, int(math.ceil(float(np.max(np.abs(end - start))) / maximum_delta_rad)))
    rows = []
    for index in range(1, segment_count + 1):
        alpha = index / segment_count
        rows.append({
            "name": f"{name_prefix}_{index:02d}" if index < segment_count else name_prefix,
            "q": ((1.0 - alpha) * start + alpha * end).tolist(),
        })
    return rows


def urdf_revolute_effort_limits(path: Path) -> np.ndarray:
    limits = []
    for joint in ET.parse(path).getroot().findall("joint"):
        if joint.get("type") not in {"revolute", "continuous"}:
            continue
        limit = joint.find("limit")
        if limit is None or limit.get("effort") is None:
            raise ValueError(f"URDF joint {joint.get('name')} has no effort limit")
        limits.append(float(limit.get("effort")))
    result = np.asarray(limits[:6], dtype=float)
    if result.shape != (6,) or not np.isfinite(result).all() or np.any(result <= 0.0):
        raise ValueError("URDF must provide six positive finite effort limits")
    return result


def payload_design_envelope(
    static_gravity_nm,
    urdf_effort_limits_nm,
    dynamic_factor: float,
) -> tuple[np.ndarray, np.ndarray]:
    static = finite_vector(static_gravity_nm, 6, "static payload gravity")
    effort = finite_vector(urdf_effort_limits_nm, 6, "URDF effort limits")
    factor = float(dynamic_factor)
    if not math.isfinite(factor) or factor < 1.0:
        raise ValueError("payload dynamic factor must be finite and >= 1.0")
    if np.any(effort <= 0.0):
        raise ValueError("URDF effort limits must be positive")
    design_torque = factor * np.abs(static)
    return design_torque, design_torque / effort


def box_frame(box_calibration: dict) -> dict:
    normal = unit_vector(box_calibration["support_up_normal_base"], "support up")
    rear_axis = np.array([1.0, 0.0, 0.0])
    rear_axis -= float(np.dot(rear_axis, normal)) * normal
    rear_axis /= np.linalg.norm(rear_axis)
    right_axis = np.cross(normal, rear_axis)
    if float(np.dot(right_axis, [0.0, 1.0, 0.0])) < 0.0:
        right_axis *= -1.0
    release_tcp = finite_vector(
        box_calibration["release"]["tcp_xyz_quat_xyzw"], 7, "release TCP"
    )
    return {
        "support_up": normal,
        "rear_axis": rear_axis,
        "right_axis": right_axis,
        "release_xyz_m": release_tcp[:3],
    }


def relative_box_coordinates_mm(xyz_m, frame: dict) -> tuple[float, float, float]:
    displacement = 1000.0 * (finite_vector(xyz_m, 3, "xyz") - frame["release_xyz_m"])
    return (
        float(np.dot(displacement, frame["rear_axis"])),
        float(np.dot(displacement, frame["right_axis"])),
        float(np.dot(displacement, frame["support_up"])),
    )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Offline fixed-funnel box placement planner")
    parser.add_argument("--box-calibration", required=True)
    parser.add_argument("--deployment-plan", required=True)
    parser.add_argument("--deployment-collision-report", required=True)
    parser.add_argument("--mount-config", required=True)
    parser.add_argument(
        "--output-plan",
        default="data/plans/go2_fixed_funnel_box_place_plan_v1.json",
    )
    parser.add_argument(
        "--output-report",
        default="data/plans/go2_fixed_funnel_box_place_collision_report_v1.json",
    )
    parser.add_argument("--maximum-waypoint-delta-rad", type=float, default=0.45)
    parser.add_argument("--sample-step-rad", type=float, default=0.005)
    parser.add_argument("--minimum-joint-margin-deg", type=float, default=10.0)
    parser.add_argument("--tilt-compensation-scale", type=float, default=0.20)
    parser.add_argument("--box-envelope-margin-mm", type=float, default=5.0)
    parser.add_argument("--payload-dynamic-factor", type=float, default=2.0)
    parser.add_argument(
        "--maximum-payload-design-effort-fraction", type=float, default=0.30
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)

    box_path = resolve_project_path(args.box_calibration)
    deployment_path = resolve_project_path(args.deployment_plan)
    deployment_report_path = resolve_project_path(args.deployment_collision_report)
    mount_path = resolve_project_path(args.mount_config)
    plan_path = resolve_project_path(args.output_plan)
    report_path = resolve_project_path(args.output_report)
    if not args.overwrite:
        for path in (plan_path, report_path):
            if path.exists():
                raise FileExistsError(f"output already exists: {path}")
    box = load_json(box_path)
    deployment = load_json(deployment_path)
    deployment_report = load_json(deployment_report_path)
    mount = load_json(mount_path)
    if box.get("status") != "candidate_pending_empty_route_validation":
        raise ValueError("box calibration status is not ready for empty-route planning")
    if deployment_report.get("status") != "OFFLINE_DEPLOYMENT_PASS":
        raise ValueError("deployment collision report did not pass")
    if deployment_report.get("source_plan_sha256") != file_sha256(deployment_path):
        raise ValueError("deployment collision report is not bound to the deployment plan")
    if Path(box["bindings"]["mount_config"]).resolve() != mount_path.resolve():
        raise ValueError("box calibration and planner use different mount configs")
    if box["bindings"]["mount_config_sha256"] != file_sha256(mount_path):
        raise ValueError("box calibration mount binding is stale")

    deployment_rows = deployment.get("joint_path", [])
    rear_ready = next(row for row in deployment_rows if row["name"] == "rear_ready")
    transport_q = box["transport_reference"]["q_rad"]
    opening_q = box["opening_hover"]["q_rad"]
    release_q = box["release"]["q_rad"]
    route = [{"name": "rear_ready", "q": list(rear_ready["q"])}]
    route.extend(split_joint_segment(
        "box_transport_reference",
        rear_ready["q"],
        transport_q,
        float(args.maximum_waypoint_delta_rad),
    ))
    route.extend(split_joint_segment(
        "box_opening_hover",
        transport_q,
        opening_q,
        float(args.maximum_waypoint_delta_rad),
    ))
    route.extend(split_joint_segment(
        "box_release",
        opening_q,
        release_q,
        float(args.maximum_waypoint_delta_rad),
    ))

    frame = box_frame(box)
    box_record = box["box"]
    payload = box["payload"]
    tilt_scale = float(args.tilt_compensation_scale)
    approved_tilt_scales = sorted(
        float(value)
        for value in mount.get("diagnostic", {}).get("allowed_scale_steps", [])
    )
    if not approved_tilt_scales:
        raise ValueError("mount record has no approved compensation scale steps")
    tilt_scale_is_mount_approved = any(
        math.isclose(tilt_scale, value, abs_tol=1e-9)
        for value in approved_tilt_scales
    )
    tilt_scale_override = None
    if not tilt_scale_is_mount_approved:
        if not 0.0 < tilt_scale < approved_tilt_scales[0]:
            raise ValueError(
                "route-specific compensation scale must be an approved mount step "
                "or lower than the minimum approved step"
            )
        tilt_scale_override = {
            "scope": "go2_fixed_funnel_box_empty_and_loaded_route_only",
            "status": "provisional_working_threshold_pending_physical_validation",
            "value": tilt_scale,
            "source_mount_minimum_approved_step": approved_tilt_scales[0],
            "safety_argument": (
                "This route-specific value is below the minimum mount-approved step, "
                "so it reduces differential tilt feedforward torque. All hard torque, "
                "tracking, speed, temperature and finally-disable guards remain active."
            ),
        }
    top_half = 0.5 * float(box_record["top_opening_mm"][0])
    projected_half = 0.5 * float(payload["projected_width_at_maximum_yaw_mm"])
    maximum_center_error = float(payload["maximum_release_center_error_mm"])
    payload_half_envelope = projected_half + maximum_center_error
    if payload_half_envelope + float(args.box_envelope_margin_mm) > top_half:
        raise ValueError("payload envelope does not fit through the top opening")

    plan = {
        "schema_version": 1,
        "status": "candidate_pending_empty_route_physical_validation",
        "mode": "go2_fixed_funnel_box_place",
        "bindings": {
            "box_calibration": str(box_path),
            "box_calibration_sha256": file_sha256(box_path),
            "deployment_plan": str(deployment_path),
            "deployment_plan_sha256": file_sha256(deployment_path),
            "deployment_collision_report": str(deployment_report_path),
            "deployment_collision_report_sha256": file_sha256(deployment_report_path),
            "mount_config": str(mount_path),
            "mount_config_sha256": file_sha256(mount_path),
        },
        "route": route,
        "reverse_route_after_release": list(reversed(route[:-1])),
        "box_envelope": {
            "opening_center_to_go2_front_end_mm": box_record["opening_center_to_go2_front_end_mm"],
            "opening_center_to_go2_rear_end_mm": box_record["opening_center_to_go2_rear_end_mm"],
            "half_width_mm": 0.5 * float(box_record["outer_size_mm"][1]),
            "top_opening_half_width_mm": top_half,
            "payload_half_envelope_mm": payload_half_envelope,
            "margin_mm": float(args.box_envelope_margin_mm),
        },
        "motion": {
            "profile": "s_curve",
            "v_max_rad_s": 0.06,
            "j6_v_max_rad_s": 0.06,
            "tilt_compensation_scale": tilt_scale,
            "tilt_compensation_scale_mount_approved": tilt_scale_is_mount_approved,
            "tilt_compensation_working_threshold_override": tilt_scale_override,
            "maximum_waypoint_delta_rad": float(args.maximum_waypoint_delta_rad),
            "sample_step_rad": float(args.sample_step_rad),
        },
        "payload": {
            "maximum_mass_g": payload["maximum_target_mass_g"],
            "dynamic_design_factor": float(args.payload_dynamic_factor),
            "dynamic_design_equivalent_mass_g": (
                float(payload["maximum_target_mass_g"])
                * float(args.payload_dynamic_factor)
            ),
            "point_mass_link": "gripper",
            "point_mass_center_link_m": list(load_tcp(verbose=False)[:3]),
        },
        "physical_validation_sequence": [
            "empty_gripper forward to release without opening command",
            "empty_gripper reverse to rear_ready",
            "incremental physical payload tests after operator accepts empty route",
            "validate gripper slip resistance separately at 40g, 150g and 300g",
        ],
    }
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")

    checker = CollisionChecker("gripper")
    if checker.model is None:
        checker._load_model(gripper=True)
    if checker.model is None or checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")
    kinematics = Kinematics(verbose=False)
    gravity_urdf_path = locate_official_gripper_urdf()
    gravity_model = UrdfGravityModel.from_file(gravity_urdf_path)
    urdf_effort_limits = urdf_revolute_effort_limits(gravity_urdf_path)
    support_up = frame["support_up"]
    actual_gravity = gravity_vector_base_from_support_up(support_up)
    correction_limits = np.asarray(
        mount["diagnostic"]["correction_absolute_limits_nm"], dtype=float
    )
    payload_mass_kg = float(payload["maximum_target_mass_g"]) / 1000.0
    payload_center = np.asarray(plan["payload"]["point_mass_center_link_m"], dtype=float)

    sample_count = 0
    hard_limit_violations = []
    segment_delta_violations = []
    active_collisions = []
    floor_contacts = []
    box_envelope_violations = []
    tilt_torque_cap_violations = []
    minimum_margin = float("inf")
    maximum_payload_gravity_nm = np.zeros(6)
    maximum_payload_effort_fraction = np.zeros(6)
    maximum_payload_design_torque_nm = np.zeros(6)
    maximum_payload_design_effort_fraction = np.zeros(6)
    maximum_tilt_correction_fraction = np.zeros(6)
    path_profile = []

    for first, second in zip(route, route[1:]):
        label = f"{first['name']}->{second['name']}"
        segment_delta = max_joint_delta(first["q"], second["q"])
        if segment_delta > float(args.maximum_waypoint_delta_rad) + 1e-9:
            segment_delta_violations.append({"segment": label, "delta_rad": segment_delta})
        for local_index, (alpha, q) in enumerate(
            interpolate_segment(first["q"], second["q"], float(args.sample_step_rad))
        ):
            if sample_count and local_index == 0:
                continue
            sample_count += 1
            violations = joint_hard_limit_violations(q)
            if violations:
                hard_limit_violations.append({"segment": label, "alpha": alpha, "violations": violations})
            minimum_margin = min(minimum_margin, joint_margin_deg(q))
            tcp = finite_vector(kinematics.fk(q), 7, "TCP")
            rear_mm, right_mm, normal_mm = relative_box_coordinates_mm(tcp[:3], frame)
            path_profile.append({
                "segment": label,
                "alpha": alpha,
                "tcp_box_rear_right_normal_mm": [rear_mm, right_mm, normal_mm],
            })
            if normal_mm < float(box["opening_hover"]["raise_mm"]) - 1.0:
                allowed_center = top_half - payload_half_envelope - float(args.box_envelope_margin_mm)
                if abs(rear_mm) > allowed_center or abs(right_mm) > allowed_center:
                    box_envelope_violations.append({
                        "segment": label,
                        "alpha": alpha,
                        "reason": "payload_not_inside_top_opening_during_low_approach",
                        "rear_right_normal_mm": [rear_mm, right_mm, normal_mm],
                        "allowed_center_abs_mm": allowed_center,
                    })
            if second["name"].startswith("box_transport_reference") and normal_mm < 80.0:
                box_envelope_violations.append({
                    "segment": label,
                    "alpha": alpha,
                    "reason": "rear_ready_to_transport_dipped_below_high_clearance",
                    "normal_raise_mm": normal_mm,
                })

            model_q = set_model_q(checker, q)
            active, _, floor = collision_sets(checker, model_q)
            if active:
                active_collisions.append({"segment": label, "alpha": alpha, "pairs": [list(pair) for pair in sorted(active)]})
            if floor:
                floor_contacts.append({"segment": label, "alpha": alpha, "pairs": [list(pair) for pair in sorted(floor)]})

            tilt_delta = differential_tilt_compensation_from_support_up(gravity_model, q, support_up)
            tilt_requested, tilt_applied = limited_correction(
                tilt_delta,
                tilt_scale,
                correction_limits,
            )
            payload_torque = gravity_model.point_mass_gravity_compensation(
                q,
                actual_gravity,
                link_name="gripper",
                mass_kg=payload_mass_kg,
                center_of_mass_link_m=payload_center,
            )
            tilt_fractions = np.abs(tilt_requested) / correction_limits
            payload_fractions = np.abs(payload_torque) / urdf_effort_limits
            payload_design_torque, payload_design_fractions = payload_design_envelope(
                payload_torque,
                urdf_effort_limits,
                float(args.payload_dynamic_factor),
            )
            maximum_tilt_correction_fraction = np.maximum(
                maximum_tilt_correction_fraction, tilt_fractions
            )
            maximum_payload_gravity_nm = np.maximum(
                maximum_payload_gravity_nm, np.abs(payload_torque)
            )
            maximum_payload_effort_fraction = np.maximum(
                maximum_payload_effort_fraction, payload_fractions
            )
            maximum_payload_design_torque_nm = np.maximum(
                maximum_payload_design_torque_nm, payload_design_torque
            )
            maximum_payload_design_effort_fraction = np.maximum(
                maximum_payload_design_effort_fraction, payload_design_fractions
            )
            clipped = [
                index + 1
                for index, (requested, applied) in enumerate(zip(tilt_requested, tilt_applied))
                if abs(float(requested) - float(applied)) > 1e-9
            ]
            if clipped:
                tilt_torque_cap_violations.append({
                    "segment": label,
                    "alpha": alpha,
                    "clipped_joints": clipped,
                    "tilt_requested_nm": tilt_requested.tolist(),
                    "tilt_applied_nm": tilt_applied.tolist(),
                })

    passed = (
        not hard_limit_violations
        and not segment_delta_violations
        and minimum_margin >= float(args.minimum_joint_margin_deg)
        and not active_collisions
        and not floor_contacts
        and not box_envelope_violations
        and not tilt_torque_cap_violations
        and float(np.max(maximum_payload_design_effort_fraction))
        <= float(args.maximum_payload_design_effort_fraction)
    )
    report = {
        "schema_version": 1,
        "status": "OFFLINE_BOX_ROUTE_PASS" if passed else "OFFLINE_BOX_ROUTE_FAIL",
        "source_plan": str(plan_path),
        "source_plan_sha256": file_sha256(plan_path),
        "sample_count": sample_count,
        "minimum_joint_margin_deg": minimum_margin,
        "required_joint_margin_deg": float(args.minimum_joint_margin_deg),
        "hard_limit_violations": hard_limit_violations,
        "segment_delta_violations": segment_delta_violations,
        "self_collision_ok": not active_collisions,
        "active_collisions": active_collisions,
        "floor_contact_ok": not floor_contacts,
        "floor_contacts": floor_contacts,
        "box_payload_envelope_ok": not box_envelope_violations,
        "box_payload_envelope_violations": box_envelope_violations,
        "maximum_tilt_correction_limit_fraction_per_joint": maximum_tilt_correction_fraction.tolist(),
        "tilt_torque_cap_ok": not tilt_torque_cap_violations,
        "tilt_torque_cap_violations": tilt_torque_cap_violations,
        "payload_gravity_model": {
            "mass_kg": payload_mass_kg,
            "center_of_mass_link_m": payload_center.tolist(),
            "urdf_effort_limits_nm": urdf_effort_limits.tolist(),
            "maximum_incremental_payload_gravity_nm_per_joint": maximum_payload_gravity_nm.tolist(),
            "maximum_incremental_payload_effort_fraction_per_joint": maximum_payload_effort_fraction.tolist(),
            "dynamic_design_factor": float(args.payload_dynamic_factor),
            "dynamic_design_equivalent_mass_kg": (
                payload_mass_kg * float(args.payload_dynamic_factor)
            ),
            "maximum_design_payload_torque_nm_per_joint": maximum_payload_design_torque_nm.tolist(),
            "maximum_design_payload_effort_fraction_per_joint": maximum_payload_design_effort_fraction.tolist(),
            "maximum_allowed_design_payload_effort_fraction": float(
                args.maximum_payload_design_effort_fraction
            ),
            "passed": float(np.max(maximum_payload_design_effort_fraction))
            <= float(args.maximum_payload_design_effort_fraction),
            "interpretation": (
                "The 300g rated point-mass gravity is multiplied by the 2.0 dynamic "
                "design factor and compared with official URDF joint effort. This is "
                "not a gripper-friction, controller-stability or drop-impact proof."
            ),
        },
        "path_profile": path_profile,
        "limitations": [
            "Go2 exact CAD and deformable cables are not in MuJoCo",
            "box wall collision uses the fixed opening/payload envelope and requires supervised empty-route validation",
            "300g rated target is modelled as a point mass at the calibrated TCP",
            "the 2.0 dynamic factor is a conservative quasi-static design envelope, not a trajectory dynamics simulation",
            "gripper slip resistance at 300g requires separate supervised physical validation",
        ],
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print("OFFLINE_ONLY = True")
    print("ARM_SERIAL_ACCESS = False")
    print("CAMERA_ACCESS = False")
    print("PLAN_ROUTE =", " -> ".join(item["name"] for item in route))
    print("SAMPLE_COUNT =", sample_count)
    print("MINIMUM_JOINT_MARGIN_DEG =", round(minimum_margin, 3))
    print("SELF_COLLISION_OK =", not active_collisions)
    print("FLOOR_CONTACT_OK =", not floor_contacts)
    print("BOX_PAYLOAD_ENVELOPE_OK =", not box_envelope_violations)
    print("TILT_TORQUE_CAP_OK =", not tilt_torque_cap_violations)
    print("MAXIMUM_TILT_CORRECTION_LIMIT_FRACTION_PER_JOINT =", [round(float(value), 3) for value in maximum_tilt_correction_fraction])
    print("RATED_PAYLOAD_MASS_G =", round(1000.0 * payload_mass_kg, 3))
    print("PAYLOAD_DYNAMIC_DESIGN_FACTOR =", round(float(args.payload_dynamic_factor), 3))
    print("DYNAMIC_DESIGN_EQUIVALENT_MASS_G =", round(1000.0 * payload_mass_kg * float(args.payload_dynamic_factor), 3))
    print("MAXIMUM_300G_PAYLOAD_GRAVITY_NM_PER_JOINT =", [round(float(value), 4) for value in maximum_payload_gravity_nm])
    print("MAXIMUM_600G_DESIGN_TORQUE_NM_PER_JOINT =", [round(float(value), 4) for value in maximum_payload_design_torque_nm])
    print("MAXIMUM_600G_DESIGN_URDF_EFFORT_FRACTION_PER_JOINT =", [round(float(value), 4) for value in maximum_payload_design_effort_fraction])
    print("PLAN_SAVED =", plan_path)
    print("REPORT_SAVED =", report_path)
    print("RESULT =", report["status"])
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
