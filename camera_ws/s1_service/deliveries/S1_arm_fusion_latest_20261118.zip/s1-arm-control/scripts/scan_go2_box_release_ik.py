#!/usr/bin/env python3
"""Offline continuity scan above a taught Go2 collection-box release pose.

The first publisher lock is the authoritative release pose.  The second lock
is only a transport/reference seed; it is deliberately not required to be
vertically aligned or to preserve the release orientation.  No serial or
camera modules are imported by this script.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import sys

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.kinematics import Kinematics  # noqa: E402
from s1_control.wrist_visual_servo import (  # noqa: E402
    JOINT_LIMITS_RAD,
    joint_margin_details,
)


def resolve_project_path(raw: str | Path) -> Path:
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def finite_vector(raw, length: int, name: str) -> np.ndarray:
    value = np.asarray(raw, dtype=np.float64)
    if value.shape != (length,) or not np.isfinite(value).all():
        raise ValueError(f"{name} must contain {length} finite values")
    return value


def unit_vector(raw, name: str) -> np.ndarray:
    value = finite_vector(raw, 3, name)
    norm = float(np.linalg.norm(value))
    if norm < 1e-9:
        raise ValueError(f"{name} cannot be zero")
    return value / norm


def unit_quaternion(raw, name: str) -> np.ndarray:
    value = finite_vector(raw, 4, name)
    norm = float(np.linalg.norm(value))
    if norm < 1e-9:
        raise ValueError(f"{name} cannot be zero")
    return value / norm


def quaternion_error_deg(first, second) -> float:
    a = unit_quaternion(first, "first quaternion")
    b = unit_quaternion(second, "second quaternion")
    cosine = abs(float(np.clip(np.dot(a, b), -1.0, 1.0)))
    return math.degrees(2.0 * math.acos(cosine))


def support_up_from_mount(mount: dict) -> np.ndarray:
    measurement = mount.get("mount_measurement", {})
    rear_deg = float(measurement["rear_edge_lower_deg"])
    side_deg = float(measurement["left_right_tilt_deg"])
    direction = str(measurement.get("left_right_tilt_direction", ""))
    if not all(math.isfinite(value) for value in (rear_deg, side_deg)):
        raise ValueError("mount tilt must be finite")
    if not 0.0 <= rear_deg <= 10.0 or not 0.0 <= abs(side_deg) <= 10.0:
        raise ValueError("mount tilt is outside the commissioned range")
    side_sign = -1.0 if ("right" in direction.lower() or "右" in direction) else 1.0
    return unit_vector(
        [
            -math.tan(math.radians(rear_deg)),
            side_sign * math.tan(math.radians(abs(side_deg))),
            1.0,
        ],
        "support_up_normal_base",
    )


def lock_q(events: list, index: int, name: str) -> np.ndarray:
    if len(events) <= index or not isinstance(events[index], dict):
        raise ValueError(f"missing {name} lock event")
    event = events[index]
    q = finite_vector(event.get("q_lock_rad"), 6, f"{name}.q_lock_rad")
    if float(event.get("maximum_span_rad", float("inf"))) > 0.01:
        raise ValueError(f"{name} lock was not stationary")
    return q


def inside_hard_limits(q: np.ndarray) -> bool:
    return all(
        lower <= float(value) <= upper
        for value, (lower, upper) in zip(q, JOINT_LIMITS_RAD)
    )


def candidate_seeds(previous: np.ndarray, release: np.ndarray, transit: np.ndarray) -> list[list[float]]:
    seeds = [previous.tolist(), release.tolist(), transit.tolist()]
    for joint, amount in (
        (0, 0.03), (1, 0.03), (1, 0.06), (2, 0.03),
        (2, 0.06), (3, 0.03), (3, 0.06), (5, 0.03),
    ):
        for sign in (-1.0, 1.0):
            seed = previous.copy()
            seed[joint] += sign * amount
            seeds.append(seed.tolist())
    return seeds


def solve_level(
    kinematics,
    target_xyz: np.ndarray,
    target_orientation: np.ndarray,
    previous_q: np.ndarray,
    release_q: np.ndarray,
    transit_q: np.ndarray,
    *,
    minimum_margin_deg: float,
    maximum_joint_step_rad: float,
    maximum_position_error_mm: float,
    maximum_orientation_error_deg: float,
    rounds: int,
) -> tuple[dict | None, dict]:
    candidates = []
    unique = set()
    rejection_counts: Counter[str] = Counter()
    for _ in range(rounds):
        for seed in candidate_seeds(previous_q, release_q, transit_q):
            solution = kinematics.ik(
                target_xyz.tolist(), target_orientation.tolist(), seed
            )
            if solution is None:
                rejection_counts["ik_none"] += 1
                continue
            q = finite_vector(solution, 6, "IK solution")
            key = tuple(round(float(value), 7) for value in q)
            if key in unique:
                continue
            unique.add(key)
            if not inside_hard_limits(q):
                rejection_counts["hard_joint_limit"] += 1
                continue
            details = joint_margin_details(q.tolist())
            minimum_margin = min(float(item["margin_deg"]) for item in details)
            delta = np.abs(q - previous_q)
            maximum_delta = float(np.max(delta))
            if minimum_margin < minimum_margin_deg:
                rejection_counts["minimum_joint_margin"] += 1
                continue
            if maximum_delta > maximum_joint_step_rad:
                rejection_counts["joint_continuity"] += 1
                continue
            fk = finite_vector(kinematics.fk(q.tolist()), 7, "FK result")
            position_error_mm = 1000.0 * float(np.linalg.norm(fk[:3] - target_xyz))
            orientation_error_deg = quaternion_error_deg(
                fk[3:].tolist(), target_orientation.tolist()
            )
            if position_error_mm > maximum_position_error_mm:
                rejection_counts["fk_position_error"] += 1
                continue
            if orientation_error_deg > maximum_orientation_error_deg:
                rejection_counts["fk_orientation_error"] += 1
                continue
            candidates.append({
                "q_rad": q.tolist(),
                "joint_margins_deg": [float(item["margin_deg"]) for item in details],
                "minimum_joint_margin_deg": minimum_margin,
                "j3_margin_deg": float(details[2]["margin_deg"]),
                "maximum_joint_step_rad": maximum_delta,
                "sum_joint_step_rad": float(np.sum(delta)),
                "fk_position_error_mm": position_error_mm,
                "fk_orientation_error_deg": orientation_error_deg,
            })
    if not candidates:
        return None, {
            "unique_solution_count": len(unique),
            "valid_candidate_count": 0,
            "rejection_counts": dict(sorted(rejection_counts.items())),
        }
    candidates.sort(key=lambda item: (
        item["maximum_joint_step_rad"],
        item["sum_joint_step_rad"],
        -item["minimum_joint_margin_deg"],
        item["fk_position_error_mm"],
    ))
    return candidates[0], {
        "unique_solution_count": len(unique),
        "valid_candidate_count": len(candidates),
        "rejection_counts": dict(sorted(rejection_counts.items())),
    }


def analyze_transport_joint_interpolation(
    kinematics,
    transport_q: np.ndarray,
    opening_q: np.ndarray,
    release_tcp: np.ndarray,
    support_up: np.ndarray,
    *,
    maximum_sample_joint_step_rad: float = 0.01,
) -> dict:
    maximum_delta = float(np.max(np.abs(opening_q - transport_q)))
    sample_count = max(2, int(math.ceil(maximum_delta / maximum_sample_joint_step_rad)) + 1)
    normal_values = []
    tangent_values = []
    orientation_values = []
    minimum_joint_margin = float("inf")
    minimum_j4_margin = float("inf")
    for index in range(sample_count):
        alpha = index / (sample_count - 1)
        q = (1.0 - alpha) * transport_q + alpha * opening_q
        fk = finite_vector(kinematics.fk(q.tolist()), 7, "transport interpolation FK")
        displacement_mm = 1000.0 * (fk[:3] - release_tcp[:3])
        normal_raise = float(np.dot(displacement_mm, support_up))
        tangent = displacement_mm - normal_raise * support_up
        details = joint_margin_details(q.tolist())
        normal_values.append(normal_raise)
        tangent_values.append(float(np.linalg.norm(tangent)))
        orientation_values.append(quaternion_error_deg(fk[3:], release_tcp[3:]))
        minimum_joint_margin = min(
            minimum_joint_margin,
            min(float(item["margin_deg"]) for item in details),
        )
        minimum_j4_margin = min(minimum_j4_margin, float(details[3]["margin_deg"]))
    return {
        "sample_count": sample_count,
        "maximum_segment_joint_delta_rad": maximum_delta,
        "minimum_normal_raise_mm": min(normal_values),
        "maximum_normal_raise_mm": max(normal_values),
        "normal_raise_monotonic_down": all(
            later <= earlier + 1e-6
            for earlier, later in zip(normal_values, normal_values[1:])
        ),
        "maximum_tangent_drift_mm": max(tangent_values),
        "minimum_tangent_drift_mm": min(tangent_values),
        "maximum_orientation_error_from_release_deg": max(orientation_values),
        "minimum_joint_margin_deg": minimum_joint_margin,
        "minimum_j4_margin_deg": minimum_j4_margin,
    }


def scan_release_normal(
    publisher: dict,
    mount: dict,
    kinematics,
    *,
    step_mm: float,
    maximum_raise_mm: float,
    minimum_margin_deg: float,
    maximum_joint_step_rad: float,
    maximum_position_error_mm: float,
    maximum_orientation_error_deg: float,
    rounds: int,
) -> dict:
    if publisher.get("mode") != "tilt-locked-eye-in-hand-pose-publisher":
        raise ValueError("publisher log mode is incompatible")
    if publisher.get("result") != "COMPLETED_BY_OPERATOR":
        raise ValueError("publisher session did not complete normally")
    events = publisher.get("lock_events")
    if not isinstance(events, list) or len(events) != 2:
        raise ValueError("scan requires exactly two locks: release then transport reference")
    release_q = lock_q(events, 0, "release")
    transit_q = lock_q(events, 1, "transport")
    release_tcp = finite_vector(kinematics.fk(release_q.tolist()), 7, "release TCP")
    transit_tcp = finite_vector(kinematics.fk(transit_q.tolist()), 7, "transport TCP")
    support_up = support_up_from_mount(mount)
    previous_q = release_q.copy()
    levels = []
    first_failure = None
    raise_values = np.arange(step_mm, maximum_raise_mm + 0.5 * step_mm, step_mm)
    for raw_raise_mm in raise_values:
        raise_mm = float(raw_raise_mm)
        target_xyz = release_tcp[:3] + (raise_mm / 1000.0) * support_up
        selected, diagnostics = solve_level(
            kinematics,
            target_xyz,
            release_tcp[3:],
            previous_q,
            release_q,
            transit_q,
            minimum_margin_deg=minimum_margin_deg,
            maximum_joint_step_rad=maximum_joint_step_rad,
            maximum_position_error_mm=maximum_position_error_mm,
            maximum_orientation_error_deg=maximum_orientation_error_deg,
            rounds=rounds,
        )
        record = {
            "raise_mm": raise_mm,
            "target_tcp_xyz_mm": (1000.0 * target_xyz).tolist(),
            "diagnostics": diagnostics,
            "reachable_continuously": selected is not None,
        }
        if selected is None:
            first_failure = record
            break
        record.update(selected)
        record["transport_joint_interpolation"] = analyze_transport_joint_interpolation(
            kinematics,
            transit_q,
            finite_vector(selected["q_rad"], 6, "opening q"),
            release_tcp,
            support_up,
        )
        levels.append(record)
        previous_q = finite_vector(selected["q_rad"], 6, "selected q")
    maximum_continuous_raise_mm = levels[-1]["raise_mm"] if levels else 0.0
    transport_displacement = 1000.0 * (transit_tcp[:3] - release_tcp[:3])
    transport_normal_raise = float(np.dot(transport_displacement, support_up))
    transport_tangent = transport_displacement - transport_normal_raise * support_up
    return {
        "schema_version": 1,
        "mode": "go2_box_release_support_normal_ik_scan",
        "offline_only": True,
        "arm_serial_access": False,
        "camera_access": False,
        "release_q_rad": release_q.tolist(),
        "release_tcp_xyz_quat_xyzw": release_tcp.tolist(),
        "transport_reference_q_rad": transit_q.tolist(),
        "transport_reference_tcp_xyz_quat_xyzw": transit_tcp.tolist(),
        "support_up_normal_base": support_up.tolist(),
        "transport_reference_geometry": {
            "normal_raise_mm": transport_normal_raise,
            "tangent_displacement_base_xyz_mm": transport_tangent.tolist(),
            "tangent_drift_mm": float(np.linalg.norm(transport_tangent)),
        },
        "limits": {
            "step_mm": step_mm,
            "maximum_raise_mm": maximum_raise_mm,
            "minimum_joint_margin_deg": minimum_margin_deg,
            "maximum_joint_step_rad": maximum_joint_step_rad,
            "maximum_fk_position_error_mm": maximum_position_error_mm,
            "maximum_fk_orientation_error_deg": maximum_orientation_error_deg,
            "ik_rounds": rounds,
        },
        "levels": levels,
        "maximum_continuous_raise_mm": maximum_continuous_raise_mm,
        "first_failure": first_failure,
        "status": "scan_complete",
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Offline support-normal IK scan above a taught fixed-box release pose"
    )
    parser.add_argument("--publisher-log", required=True)
    parser.add_argument("--mount-config", required=True)
    parser.add_argument(
        "--output",
        default="data/plans/go2_fixed_funnel_box_release_ik_scan_v1.json",
    )
    parser.add_argument("--step-mm", type=float, default=5.0)
    parser.add_argument("--maximum-raise-mm", type=float, default=140.0)
    parser.add_argument("--minimum-joint-margin-deg", type=float, default=10.0)
    parser.add_argument("--maximum-joint-step-rad", type=float, default=0.12)
    parser.add_argument("--maximum-position-error-mm", type=float, default=1.5)
    parser.add_argument("--maximum-orientation-error-deg", type=float, default=1.0)
    parser.add_argument("--ik-rounds", type=int, default=8)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)
    if not 1.0 <= args.step_mm <= 10.0:
        raise ValueError("step-mm must be within [1, 10]")
    if not args.step_mm <= args.maximum_raise_mm <= 200.0:
        raise ValueError("maximum-raise-mm is invalid")
    if not 5.0 <= args.minimum_joint_margin_deg <= 20.0:
        raise ValueError("minimum-joint-margin-deg must be within [5, 20]")
    if not 0.02 <= args.maximum_joint_step_rad <= 0.2:
        raise ValueError("maximum-joint-step-rad must be within [0.02, 0.2]")
    if not 1 <= args.ik_rounds <= 20:
        raise ValueError("ik-rounds must be within [1, 20]")
    output_path = resolve_project_path(args.output)
    if output_path.exists() and not args.overwrite:
        raise FileExistsError(f"output already exists: {output_path}")
    record = scan_release_normal(
        load_json(resolve_project_path(args.publisher_log)),
        load_json(resolve_project_path(args.mount_config)),
        Kinematics(verbose=False),
        step_mm=float(args.step_mm),
        maximum_raise_mm=float(args.maximum_raise_mm),
        minimum_margin_deg=float(args.minimum_joint_margin_deg),
        maximum_joint_step_rad=float(args.maximum_joint_step_rad),
        maximum_position_error_mm=float(args.maximum_position_error_mm),
        maximum_orientation_error_deg=float(args.maximum_orientation_error_deg),
        rounds=int(args.ik_rounds),
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print("OFFLINE_ONLY = True")
    print("ARM_SERIAL_ACCESS = False")
    print("CAMERA_ACCESS = False")
    print("SUPPORT_UP_NORMAL_BASE =", [round(value, 6) for value in record["support_up_normal_base"]])
    for level in record["levels"]:
        transit = level["transport_joint_interpolation"]
        print(
            "LEVEL",
            f"raise={level['raise_mm']:.1f}mm",
            f"J3_margin={level['j3_margin_deg']:.2f}deg",
            f"min_margin={level['minimum_joint_margin_deg']:.2f}deg",
            f"dq={level['maximum_joint_step_rad']:.4f}rad",
            f"fk={level['fk_position_error_mm']:.3f}mm",
            f"transit_min_normal={transit['minimum_normal_raise_mm']:.1f}mm",
            f"transit_max_tangent={transit['maximum_tangent_drift_mm']:.1f}mm",
            f"transit_monotonic={transit['normal_raise_monotonic_down']}",
        )
    failure = record["first_failure"]
    if failure is not None:
        print("FIRST_FAILURE_RAISE_MM =", failure["raise_mm"])
        print("FIRST_FAILURE_DIAGNOSTICS =", failure["diagnostics"])
    print("MAXIMUM_CONTINUOUS_NORMAL_RAISE_MM =", record["maximum_continuous_raise_mm"])
    print("SCAN_SAVED =", output_path)
    print("RESULT = BOX_RELEASE_NORMAL_IK_SCAN_DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
