#!/usr/bin/env python3
"""Finalize two supervised tilt-locked poses for the fixed Go2 funnel box.

The live pose publisher remains the only process that owns the S1 serial bus.
This script is deliberately offline-only: it reads the publisher JSON, checks
the first lock as ``release`` and the second as ``hover``, evaluates both with
forward kinematics, and writes a hash-bound calibration record.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path
import sys

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from s1_control.kinematics import Kinematics  # noqa: E402


DEFAULT_OUTPUT = (
    PROJECT_ROOT
    / "calibration/go2_fixed_funnel_box_nocw_metalbracket_v1.json"
)


def resolve_project_path(raw: str | Path) -> Path:
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    return path.resolve()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def finite_vector(raw, length: int, name: str) -> list[float]:
    if not isinstance(raw, (list, tuple)) or len(raw) != length:
        raise ValueError(f"{name} must contain {length} values")
    values = [float(value) for value in raw]
    if not all(math.isfinite(value) for value in values):
        raise ValueError(f"{name} contains NaN or Inf")
    return values


def unit_vector(raw, name: str) -> np.ndarray:
    vector = np.asarray(finite_vector(raw, 3, name), dtype=float)
    norm = float(np.linalg.norm(vector))
    if norm < 1e-9:
        raise ValueError(f"{name} cannot be zero")
    return vector / norm


def quaternion_to_rotation(raw) -> np.ndarray:
    quaternion = np.asarray(finite_vector(raw, 4, "quaternion"), dtype=float)
    norm = float(np.linalg.norm(quaternion))
    if norm < 1e-9:
        raise ValueError("quaternion cannot be zero")
    x, y, z, w = quaternion / norm
    return np.array([
        [
            1.0 - 2.0 * (y * y + z * z),
            2.0 * (x * y - z * w),
            2.0 * (x * z + y * w),
        ],
        [
            2.0 * (x * y + z * w),
            1.0 - 2.0 * (x * x + z * z),
            2.0 * (y * z - x * w),
        ],
        [
            2.0 * (x * z - y * w),
            2.0 * (y * z + x * w),
            1.0 - 2.0 * (x * x + y * y),
        ],
    ])


def rotation_error_deg(first, second) -> float:
    a = np.asarray(first, dtype=float)
    b = np.asarray(second, dtype=float)
    cosine = float(np.clip((np.trace(a.T @ b) - 1.0) / 2.0, -1.0, 1.0))
    return math.degrees(math.acos(cosine))


def support_up_from_mount(mount: dict) -> np.ndarray:
    measurement = mount.get("mount_measurement", {})
    rear_deg = float(measurement["rear_edge_lower_deg"])
    right_deg = float(measurement["left_right_tilt_deg"])
    direction = str(measurement.get("left_right_tilt_direction", ""))
    if not all(math.isfinite(value) for value in (rear_deg, right_deg)):
        raise ValueError("mount tilt must be finite")
    if not 0.0 <= rear_deg <= 10.0 or not 0.0 <= abs(right_deg) <= 10.0:
        raise ValueError("mount tilt is outside the commissioned range")
    right_sign = -1.0 if ("right" in direction.lower() or "右" in direction) else 1.0
    raw = [
        -math.tan(math.radians(rear_deg)),
        right_sign * math.tan(math.radians(abs(right_deg))),
        1.0,
    ]
    return unit_vector(raw, "support_up_normal_base")


def projected_square_width_mm(edge_mm: float, yaw_error_deg: float) -> float:
    edge = float(edge_mm)
    yaw = abs(float(yaw_error_deg))
    if not math.isfinite(edge) or edge <= 0.0:
        raise ValueError("edge_mm must be positive and finite")
    if not math.isfinite(yaw) or yaw > 45.0:
        raise ValueError("yaw_error_deg must be within [0, 45]")
    angle = math.radians(yaw)
    return edge * (math.cos(angle) + math.sin(angle))


def validate_lock_event(event: dict, name: str) -> list[float]:
    q = finite_vector(event.get("q_lock_rad"), 6, f"{name}.q_lock_rad")
    if float(event.get("maximum_span_rad", float("inf"))) > 0.01:
        raise ValueError(f"{name} was not stationary when locked")
    if float(event.get("joint_margin_deg", float("-inf"))) < 15.0:
        raise ValueError(f"{name} joint margin is below 15deg")
    correction = event.get("correction")
    if not isinstance(correction, dict) or correction.get("clipped") is not False:
        raise ValueError(f"{name} tilt correction was clipped or not recorded")
    return q


def build_record(
    publisher_log: dict,
    mount: dict,
    *,
    publisher_path: Path,
    mount_path: Path,
    fk,
    finger_rim_clearance_mm: float,
    payload_mass_g: float,
    opening_center_to_front_mm: float = 90.0,
    opening_center_to_rear_mm: float = 210.0,
    diagnostic_callback=None,
    ik_scan: dict | None = None,
    ik_scan_path: Path | None = None,
    opening_hover_raise_mm: float = 45.0,
) -> dict:
    if publisher_log.get("mode") != "tilt-locked-eye-in-hand-pose-publisher":
        raise ValueError("publisher log mode is incompatible")
    if publisher_log.get("result") != "COMPLETED_BY_OPERATOR":
        raise ValueError("publisher session did not complete normally")
    events = publisher_log.get("lock_events")
    if not isinstance(events, list) or len(events) != 2:
        raise ValueError("box teach requires exactly two locks: release then hover")
    recorded_mount = Path(str(publisher_log.get("mount_config", ""))).resolve()
    if recorded_mount != mount_path.resolve():
        raise ValueError("publisher and finalizer use different mount configs")
    scale = float(publisher_log.get("compensation_scale", float("nan")))
    if not math.isclose(scale, 0.25, abs_tol=1e-9):
        raise ValueError("box teach must use the commissioned rear/high scale 0.25")
    clearance = float(finger_rim_clearance_mm)
    if not 8.0 <= clearance <= 15.0:
        raise ValueError("confirmed finger/rim clearance must be within [8, 15]mm")
    payload = float(payload_mass_g)
    if not 0.0 < payload <= 300.0:
        raise ValueError("competition payload mass must be within (0, 300]g")
    center_to_front = float(opening_center_to_front_mm)
    center_to_rear = float(opening_center_to_rear_mm)
    if not all(math.isfinite(value) and value > 0.0 for value in (center_to_front, center_to_rear)):
        raise ValueError("opening-center box offsets must be positive and finite")
    if not math.isclose(center_to_front + center_to_rear, 300.0, abs_tol=10.0):
        raise ValueError("opening-center front/rear offsets must sum to the 300mm box length")

    release_q = validate_lock_event(events[0], "release")
    hover_q = validate_lock_event(events[1], "hover")
    release_tcp = finite_vector(fk(release_q), 7, "release_tcp")
    hover_tcp = finite_vector(fk(hover_q), 7, "hover_tcp")
    release_xyz = np.asarray(release_tcp[:3], dtype=float)
    hover_xyz = np.asarray(hover_tcp[:3], dtype=float)
    support_up = support_up_from_mount(mount)
    displacement_mm = 1000.0 * (hover_xyz - release_xyz)
    normal_raise_mm = float(np.dot(displacement_mm, support_up))
    tangent = displacement_mm - normal_raise_mm * support_up
    tangent_drift_mm = float(np.linalg.norm(tangent))
    orientation_error = rotation_error_deg(
        quaternion_to_rotation(release_tcp[3:]),
        quaternion_to_rotation(hover_tcp[3:]),
    )
    release_rotation = quaternion_to_rotation(release_tcp[3:])
    approach_axis = release_rotation[:, 0]
    approach_error = math.degrees(math.acos(float(np.clip(
        np.dot(approach_axis, -support_up), -1.0, 1.0
    ))))
    teach_geometry = {
        "normal_raise_mm": normal_raise_mm,
        "tangent_drift_mm": tangent_drift_mm,
        "tangent_displacement_base_xyz_mm": tangent.tolist(),
        "total_displacement_base_xyz_mm": displacement_mm.tolist(),
        "orientation_error_deg": orientation_error,
        "release_approach_error_deg": approach_error,
    }
    if diagnostic_callback is not None:
        diagnostic_callback(teach_geometry)
    if approach_error > 12.0:
        raise ValueError("release tool approach is not sufficiently support-normal")

    opening_hover = None
    if ik_scan is None:
        if not 70.0 <= normal_raise_mm <= 140.0:
            raise ValueError("hover must be 70-140mm above release along support normal")
        if tangent_drift_mm > 15.0:
            raise ValueError("hover tangent drift exceeds 15mm")
        if orientation_error > 5.0:
            raise ValueError("release/hover orientation difference exceeds 5deg")
    else:
        if ik_scan_path is None:
            raise ValueError("ik_scan_path is required when ik_scan is supplied")
        if ik_scan.get("mode") != "go2_box_release_support_normal_ik_scan":
            raise ValueError("IK scan mode is incompatible")
        if ik_scan.get("status") != "scan_complete":
            raise ValueError("IK scan did not complete")
        scan_release_q = finite_vector(ik_scan.get("release_q_rad"), 6, "scan release q")
        scan_transport_q = finite_vector(
            ik_scan.get("transport_reference_q_rad"), 6, "scan transport q"
        )
        if not np.allclose(scan_release_q, release_q, atol=1e-8):
            raise ValueError("IK scan release pose does not match publisher")
        if not np.allclose(scan_transport_q, hover_q, atol=1e-8):
            raise ValueError("IK scan transport pose does not match publisher")
        scan_support_up = unit_vector(
            ik_scan.get("support_up_normal_base"), "scan support normal"
        )
        if not np.allclose(scan_support_up, support_up, atol=1e-8):
            raise ValueError("IK scan support normal does not match mount")
        requested_raise = float(opening_hover_raise_mm)
        if not math.isfinite(requested_raise) or requested_raise <= 0.0:
            raise ValueError("opening hover raise must be positive")
        matching = [
            level for level in ik_scan.get("levels", [])
            if math.isclose(float(level.get("raise_mm", float("nan"))), requested_raise, abs_tol=1e-6)
        ]
        if len(matching) != 1:
            raise ValueError("IK scan does not contain the requested opening hover level")
        level = matching[0]
        if level.get("reachable_continuously") is not True:
            raise ValueError("requested opening hover is not continuously reachable")
        if float(level.get("minimum_joint_margin_deg", float("-inf"))) < 15.0:
            raise ValueError("opening hover joint margin is below 15deg")
        interpolation = level.get("transport_joint_interpolation", {})
        if interpolation.get("normal_raise_monotonic_down") is not True:
            raise ValueError("transport-to-opening path is not monotonic toward the box")
        if float(interpolation.get("minimum_normal_raise_mm", float("-inf"))) < requested_raise - 0.5:
            raise ValueError("transport-to-opening path dips below the opening hover")
        if float(interpolation.get("maximum_tangent_drift_mm", float("inf"))) > 30.0:
            raise ValueError("transport-to-opening tangent drift exceeds 30mm")
        if float(interpolation.get("minimum_joint_margin_deg", float("-inf"))) < 15.0:
            raise ValueError("transport-to-opening joint margin is below 15deg")
        if not 70.0 <= normal_raise_mm <= 160.0:
            raise ValueError("transport reference must remain 70-160mm above release")
        if tangent_drift_mm > 30.0:
            raise ValueError("transport reference tangent drift exceeds 30mm")
        if orientation_error > 25.0:
            raise ValueError("transport/release orientation difference exceeds 25deg")
        opening_q = finite_vector(level.get("q_rad"), 6, "opening hover q")
        opening_tcp = finite_vector(fk(opening_q), 7, "opening hover tcp")
        opening_hover = {
            "raise_mm": requested_raise,
            "q_rad": list(opening_q),
            "tcp_xyz_quat_xyzw": list(opening_tcp),
            "tcp_xyz_mm": (1000.0 * np.asarray(opening_tcp[:3], dtype=float)).tolist(),
            "scan_level": level,
        }

    maximum_yaw_deg = 8.0
    projected_width = projected_square_width_mm(50.0, maximum_yaw_deg)
    if projected_width + 2.0 * 10.0 > 90.0:
        raise ValueError("configured top-opening envelope cannot contain the target")

    bindings = {
        "publisher_log": str(publisher_path),
        "publisher_log_sha256": file_sha256(publisher_path),
        "mount_config": str(mount_path),
        "mount_config_sha256": file_sha256(mount_path),
    }
    if ik_scan_path is not None:
        bindings.update({
            "ik_scan": str(ik_scan_path),
            "ik_scan_sha256": file_sha256(ik_scan_path),
        })
    record = {
        "schema_version": 1,
        "name": "go2_fixed_funnel_box_nocw_metalbracket_v1",
        "status": "candidate_pending_empty_route_validation",
        "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "valid_only_if": (
            "Go2 remains in the current crouched no-counterweight configuration; "
            "the S1 base, D455 metal bracket, fixed white funnel box, battery box, "
            "cables, gripper and TCP do not move or loosen."
        ),
        "revalidate_when": (
            "Any listed mount or payload changes, the box moves, the box opening "
            "deforms, or empty-route/placement behavior differs from commissioning."
        ),
        "bindings": bindings,
        "box": {
            "outer_size_mm": [300.0, 140.0, 140.0],
            "long_axis": "Go2 front/rear",
            "opening_center_to_go2_front_end_mm": center_to_front,
            "opening_center_to_go2_rear_end_mm": center_to_rear,
            "top_opening_mm": [90.0, 90.0],
            "throat_opening_mm": [60.0, 60.0],
            "funnel_present": True,
            "soft_liner_present": False,
            "fixed_to_go2": True,
        },
        "payload": {
            "maximum_target_mass_g": payload,
            "maximum_target_edge_mm": 50.0,
            "maximum_release_yaw_error_deg": maximum_yaw_deg,
            "target_release_yaw_error_deg": 5.0,
            "maximum_release_center_error_mm": 10.0,
            "target_release_center_error_mm": 5.0,
            "projected_width_at_maximum_yaw_mm": projected_width,
        },
        "release_constraints": {
            "operator_confirmed_minimum_finger_above_rim_mm": clearance,
            "minimum_finger_above_rim_mm": 8.0,
            "maximum_tool_approach_error_deg": 12.0,
            "release_hold_s": 1.0,
            "release_gap_minimum_mm": 62.0,
        },
        "support_up_normal_base": support_up.tolist(),
        "release": {
            "q_rad": release_q,
            "tcp_xyz_quat_xyzw": release_tcp,
            "tcp_xyz_mm": (1000.0 * release_xyz).tolist(),
            "lock_event": events[0],
        },
        "transport_reference": {
            "q_rad": hover_q,
            "tcp_xyz_quat_xyzw": hover_tcp,
            "tcp_xyz_mm": (1000.0 * hover_xyz).tolist(),
            "lock_event": events[1],
        },
        "transport_reference_geometry": teach_geometry,
    }
    if opening_hover is None:
        record["hover"] = record.pop("transport_reference")
        record["teach_geometry"] = record.pop("transport_reference_geometry")
    else:
        record["opening_hover"] = opening_hover
        record["path_semantics"] = (
            "transport_reference -> monotonic oblique joint path -> opening_hover "
            "-> short support-normal descent -> release"
        )
    return record


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Offline finalizer for the fixed Go2 funnel-box teach poses"
    )
    parser.add_argument("--publisher-log", required=True)
    parser.add_argument("--mount-config", required=True)
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--finger-rim-clearance-mm", type=float, required=True)
    parser.add_argument("--payload-mass-g", type=float, default=300.0)
    parser.add_argument("--opening-center-to-front-mm", type=float, default=90.0)
    parser.add_argument("--opening-center-to-rear-mm", type=float, default=210.0)
    parser.add_argument("--ik-scan")
    parser.add_argument("--opening-hover-raise-mm", type=float, default=45.0)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args(argv)

    publisher_path = resolve_project_path(args.publisher_log)
    mount_path = resolve_project_path(args.mount_config)
    output_path = resolve_project_path(args.output)
    if output_path.exists() and not args.overwrite:
        raise FileExistsError(f"output already exists: {output_path}")
    def print_geometry_diagnostic(geometry: dict) -> None:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("BOX_NORMAL_RAISE_MM =", round(geometry["normal_raise_mm"], 3))
        print("BOX_TANGENT_DRIFT_MM =", round(geometry["tangent_drift_mm"], 3))
        print(
            "BOX_TANGENT_DISPLACEMENT_BASE_XYZ_MM =",
            [round(value, 3) for value in geometry["tangent_displacement_base_xyz_mm"]],
        )
        print(
            "BOX_TOTAL_DISPLACEMENT_BASE_XYZ_MM =",
            [round(value, 3) for value in geometry["total_displacement_base_xyz_mm"]],
        )
        print("BOX_ORIENTATION_ERROR_DEG =", round(geometry["orientation_error_deg"], 3))
        print("BOX_RELEASE_APPROACH_ERROR_DEG =", round(geometry["release_approach_error_deg"], 3))

    ik_scan_path = resolve_project_path(args.ik_scan) if args.ik_scan else None
    record = build_record(
        load_json(publisher_path),
        load_json(mount_path),
        publisher_path=publisher_path,
        mount_path=mount_path,
        fk=Kinematics(verbose=False).fk,
        finger_rim_clearance_mm=args.finger_rim_clearance_mm,
        payload_mass_g=args.payload_mass_g,
        opening_center_to_front_mm=args.opening_center_to_front_mm,
        opening_center_to_rear_mm=args.opening_center_to_rear_mm,
        diagnostic_callback=print_geometry_diagnostic,
        ik_scan=load_json(ik_scan_path) if ik_scan_path is not None else None,
        ik_scan_path=ik_scan_path,
        opening_hover_raise_mm=args.opening_hover_raise_mm,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    geometry = record.get("teach_geometry", record["transport_reference_geometry"])
    print("RELEASE_Q =", [round(value, 6) for value in record["release"]["q_rad"]])
    if "opening_hover" in record:
        print("TRANSPORT_REFERENCE_Q =", [round(value, 6) for value in record["transport_reference"]["q_rad"]])
        print("OPENING_HOVER_Q =", [round(value, 6) for value in record["opening_hover"]["q_rad"]])
        print("OPENING_HOVER_RAISE_MM =", record["opening_hover"]["raise_mm"])
    else:
        print("HOVER_Q =", [round(value, 6) for value in record["hover"]["q_rad"]])
    print("BOX_CALIBRATION_SAVED =", output_path)
    print("RESULT = BOX_TEACH_FINALIZED_PENDING_EMPTY_ROUTE_VALIDATION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
