"""Optional shared-camera snapshot client used only during wrist video recording."""
import io
import json
import socket
import struct
import numpy as np


def receive_exact(connection, size):
    pieces = bytearray()
    while len(pieces) < size:
        data = connection.recv(size-len(pieces))
        if not data:
            raise RuntimeError("recording camera connection closed")
        pieces.extend(data)
    return bytes(pieces)


def request_snapshot(path, options):
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
        connection.settimeout(max(30.0,(options['warmup_frames']+options['depth_frames'])/options['fps']+10.0))
        connection.connect(path)
        connection.sendall((json.dumps(options)+"\n").encode())
        success, size = struct.unpack('!BQ',receive_exact(connection,9))
        body = receive_exact(connection,size)
    if not success:
        raise RuntimeError("recording camera: "+body.decode())
    with np.load(io.BytesIO(body),allow_pickle=False) as data:
        result={key:data[key].copy() for key in ['rgb','depth_m','K','distortion_coeffs']}
        result['metadata']=json.loads(str(data['metadata_json'].item()))
    return result
