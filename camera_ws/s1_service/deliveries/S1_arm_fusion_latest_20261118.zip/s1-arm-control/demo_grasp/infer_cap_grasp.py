# -*- coding: utf-8 -*-
"""Offline single-frame grasp SYNTHESIS + reachability check for the red cap.

Reads one captured D455 RGBD frame (frame_bottle.npz), runs the Graspness net to
propose 6-DoF parallel-jaw grasps (camera frame), transforms them to the S1 base
frame with the 0723 extrinsic, keeps those on the red cap with width <= gripper
max, ranks by score, and prints a report. NO arm hardware, NO power.

    conda activate graspness
    python infer_cap_grasp.py --npz frame_bottle.npz \
        --checkpoint minkuresunet_realsense.tar \
        --extrinsic ../../industrial-agent/calibration/s1_d455_official_20260723_candidate.json \
        --extrinsic-key selection.T_base_cam_candidate
"""
import os
import sys
import json
import argparse
import numpy as np
import torch

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(ROOT_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'utils'))
from models.graspnet import GraspNet, pred_decode              # noqa: E402
from dataset.graspnet_dataset import minkowski_collate_fn      # noqa: E402


def load_extrinsic(path, key):
    obj = json.loads(open(path).read())
    for part in key.split('.'):
        obj = obj[part]
    T = np.asarray(obj, dtype=float)
    assert T.shape == (4, 4), f"extrinsic not 4x4: {T.shape}"
    return T


def build_cloud(depth_m, K):
    """Organized HxWx3 point cloud in camera frame (meters)."""
    h, w = depth_m.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    u = np.arange(w)[None, :].repeat(h, axis=0)
    v = np.arange(h)[:, None].repeat(w, axis=1)
    z = depth_m
    x = (u - cx) * z / fx
    y = (v - cy) * z / fy
    return np.stack([x, y, z], axis=-1).astype(np.float32)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--npz', required=True)
    ap.add_argument('--checkpoint', required=True)
    ap.add_argument('--extrinsic',
                    default=str(__import__('pathlib').Path(__file__).resolve().parents[1] / 'calibration' / 'extrinsic_camera.json'),
                    help='默认指向本仓 calibration/extrinsic_camera.json（自包含，不再指向 industrial-agent）')
    ap.add_argument('--extrinsic-key', default='value_T_base_cam',
                    help='本仓 extrinsic_camera.json 用扁平键 value_T_base_cam')
    ap.add_argument('--seed_feat_dim', type=int, default=512)
    ap.add_argument('--num_point', type=int, default=15000)
    ap.add_argument('--repeats', type=int, default=5, help='aggregate near-cap grasps over N random-subsample passes')
    ap.add_argument('--voxel_size', type=float, default=0.005)
    ap.add_argument('--z-min', type=float, default=0.30, help='camera z crop min (m)')
    ap.add_argument('--z-max', type=float, default=0.85, help='camera z crop max (m)')
    ap.add_argument('--arm-exclude-x', type=float, default=0.12,
                    help='drop cloud points with base-x below this (removes the in-view arm/gripper, m)')
    ap.add_argument('--cap-radius', type=float, default=0.035, help='keep grasps within this of cap centre (m)')
    ap.add_argument('--gripper-max-width', type=float, default=0.100, help='S1 usable max opening (m)')
    ap.add_argument('--topk', type=int, default=10)
    ap.add_argument('--out', default='cap_grasp_report.json')
    cfgs = ap.parse_args()

    d = np.load(cfgs.npz, allow_pickle=True)
    depth_m = d['depth_m'].astype(np.float32)
    K = d['K'].astype(np.float64)
    cap_p_cam = d['cap_p_cam'].astype(np.float64)
    T_base_cam = load_extrinsic(cfgs.extrinsic, cfgs.extrinsic_key)
    R_bc, p_bc = T_base_cam[:3, :3], T_base_cam[:3, 3]

    def to_base(pts):  # pts Nx3 camera -> base
        return (R_bc @ pts.T).T + p_bc

    cap_p_base = to_base(cap_p_cam[None, :])[0]

    # ---- point cloud + workspace crop (camera-frame cloud fed to net) ----
    cloud = build_cloud(depth_m, K).reshape(-1, 3)
    z = cloud[:, 2]
    valid = (z > cfgs.z_min) & (z < cfgs.z_max)
    cloud_v = cloud[valid]
    # base-frame crop to table volume (drop floor/arm/background)
    cb = to_base(cloud_v)
    ws = (cb[:, 2] > -0.03) & (cb[:, 2] < 0.35) & (cb[:, 0] > cfgs.arm_exclude_x)
    cloud_masked = cloud_v[ws]
    if len(cloud_masked) < 100:
        raise RuntimeError(f"workspace cloud too small: {len(cloud_masked)}")

    n = cfgs.num_point
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    net = GraspNet(seed_feat_dim=cfgs.seed_feat_dim, is_training=False).to(device)
    ckpt = torch.load(cfgs.checkpoint, map_location=device)
    net.load_state_dict(ckpt['model_state_dict'])
    net.eval()
    print(f"-> loaded {cfgs.checkpoint} (epoch {ckpt.get('epoch','?')}); "
          f"cloud {len(cloud_masked)} -> sampled {n} x {cfgs.repeats} passes")

    # aggregate over R random-subsample passes (the cap is tiny -> single-pass
    # near-cap counts swing 0..~20; union stabilises the candidate set)
    all_preds, cloud_sampled = [], None
    for _ in range(cfgs.repeats):
        if len(cloud_masked) >= n:
            idxs = np.random.choice(len(cloud_masked), n, replace=False)
        else:
            idxs = np.concatenate([np.arange(len(cloud_masked)),
                                   np.random.choice(len(cloud_masked), n - len(cloud_masked), replace=True)])
        cloud_sampled = cloud_masked[idxs]
        ret = {'point_clouds': cloud_sampled.astype(np.float32),
               'coors': (cloud_sampled / cfgs.voxel_size).astype(np.float32),
               'feats': np.ones_like(cloud_sampled).astype(np.float32)}
        batch = minkowski_collate_fn([ret])
        for k in batch:
            if 'list' in k:
                batch[k] = [[x.to(device) for x in sub] for sub in batch[k]]
            else:
                batch[k] = batch[k].to(device)
        with torch.no_grad():
            end_points = net(batch)
            all_preds.append(pred_decode(end_points)[0].detach().cpu().numpy())
    preds = np.concatenate(all_preds, axis=0)   # [R*M, 17]

    # GraspGroup layout: [score,width,height,depth, R(9), t(3), obj_id]
    score, width = preds[:, 0], preds[:, 1]
    R = preds[:, 4:13].reshape(-1, 3, 3)
    t = preds[:, 13:16]
    t_base = to_base(t)
    dist_cap = np.linalg.norm(t_base - cap_p_base[None, :], axis=1)

    # ---- diagnostics: what does the net actually want to grasp? ----
    print(f"\n[diag] overall score: max={score.max():.3f} p99={np.percentile(score,99):.3f} "
          f"p90={np.percentile(score,90):.3f} median={np.median(score):.3f}")
    for r in (0.035, 0.05, 0.08, 0.12):
        m = dist_cap < r
        print(f"[diag] within {int(r*1000):>3}mm of cap: {int(m.sum()):>4}  "
              f"maxscore={score[m].max() if m.any() else 0:.3f}")
    oo = np.argsort(-score)[:10]
    print("[diag] top-10 grasps overall (score/width_mm/dist_cap_mm/base_xyz_mm):")
    for i in oo:
        print(f"       {score[i]:.3f}  {width[i]*1000:>5.1f}  {dist_cap[i]*1000:>6.1f}  "
              f"{[round(float(v*1000),1) for v in t_base[i]]}")
    np.save(cfgs.out.replace('.json', '_preds_base.npy'),
            np.column_stack([score, width, dist_cap, t_base]))

    dcap_pts = np.linalg.norm(cloud_sampled - cap_p_cam[None, :].astype(np.float32), axis=1)
    print(f"[diag] sampled cloud points within 30mm of cap centre: {int((dcap_pts<0.03).sum())} "
          f"(of {len(cloud_sampled)})")

    # ---- overlay grasp centres on RGB for visual verification ----
    try:
        import cv2
        vis = cv2.cvtColor(d['rgb'], cv2.COLOR_RGB2BGR)
        fx, fy, cx0, cy0 = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
        def proj(pc):
            return int(round(pc[0]/pc[2]*fx + cx0)), int(round(pc[1]/pc[2]*fy + cy0))
        for i in oo:                              # top-10 overall = red dots
            if t[i, 2] > 0:
                cv2.circle(vis, proj(t[i]), 5, (0, 0, 255), -1)
        near = np.where(dist_cap < cfgs.cap_radius)[0]
        for i in near:                            # near-cap = green rings
            if t[i, 2] > 0:
                cv2.circle(vis, proj(t[i]), 7, (0, 255, 0), 2)
        cv2.circle(vis, proj(cap_p_cam), 11, (255, 0, 0), 2)   # cap detection = blue
        op = cfgs.out.replace('.json', '_overlay.png')
        cv2.imwrite(op, vis)
        print(f"[diag] overlay saved {op} (red=top overall, green=near-cap, blue=cap)")
    except Exception as e:
        print(f"[diag] overlay failed: {e}")

    keep = (dist_cap < cfgs.cap_radius) & (width <= cfgs.gripper_max_width)
    # dump near-cap candidates with full-precision base pose for the S1 IK check
    kk = np.where(keep)[0]
    if len(kk):
        Rk = np.einsum('ij,njk->nik', R_bc, R[kk]).reshape(len(kk), 9)
        cand = np.column_stack([score[kk], width[kk], t_base[kk], Rk])  # [n, 1+1+3+9]
        np.save(cfgs.out.replace('.json', '_cap_candidates.npy'), cand)
        print(f"[diag] saved {int(len(kk))} cap candidates (full R_base) to "
              f"{cfgs.out.replace('.json', '_cap_candidates.npy')}")
    print(f"total grasps {len(preds)}; near cap(<{cfgs.cap_radius*1000:.0f}mm) "
          f"& width<= {cfgs.gripper_max_width*1000:.0f}mm -> {int(keep.sum())}")

    order = np.argsort(-score[keep])
    idx_keep = np.where(keep)[0][order]

    report = {'cap_p_base_mm': [round(float(v*1000), 1) for v in cap_p_base],
              'extrinsic': cfgs.extrinsic, 'n_total': int(len(preds)),
              'n_near_cap': int(keep.sum()), 'grasps': []}
    print(f"\ncap centre (base) = {report['cap_p_base_mm']} mm")
    print("rank  score  width_mm  tilt_from_vert  base_xyz_mm            approach_base")
    for rank, i in enumerate(idx_keep[:cfgs.topk]):
        Rb = R_bc @ R[i]
        approach = Rb[:, 0]                       # graspnet: x-axis = approach dir
        approach = approach / (np.linalg.norm(approach) + 1e-9)
        tilt = float(np.degrees(np.arccos(np.clip(-approach[2], -1, 1))))  # 0=straight down
        tb = t_base[i]
        g = {'rank': rank, 'score': round(float(score[i]), 4),
             'width_mm': round(float(width[i] * 1000), 1),
             'tilt_from_vertical_deg': round(tilt, 1),
             'base_xyz_mm': [round(float(v * 1000), 1) for v in tb],
             'approach_base': [round(float(v), 3) for v in approach],
             'R_base': [[round(float(x), 4) for x in row] for row in Rb]}
        report['grasps'].append(g)
        print(f"{rank:>3}  {g['score']:.3f}  {g['width_mm']:>7.1f}  {g['tilt_from_vertical_deg']:>10.1f}   "
              f"{str(g['base_xyz_mm']):>22}  {g['approach_base']}")

    json.dump(report, open(cfgs.out, 'w'), indent=1)
    print(f"\nsaved {cfgs.out}")
    if not report['grasps']:
        print("!! no grasp survived cap+width filter -- widen --cap-radius or check detection")


if __name__ == '__main__':
    main()
