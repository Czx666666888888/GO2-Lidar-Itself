# -*- coding: utf-8 -*-
"""Capture ONE aligned D455 RGBD frame + red-cap mask for offline grasp inference.

Runs in the S1 conda env (pyrealsense2 + cv2 + numpy). Touches NO arm hardware.
Saves an .npz (rgb, depth_m, K, cap pixel/bbox/mask, depth_scale) and an
annotated PNG so the operator can confirm the cap was detected.

    conda activate S1
    python capture_frame.py --out ~/work/graspness_pkg/frame_bottle.npz
"""
import argparse
import math
import numpy as np
import cv2
import pyrealsense2 as rs


def red_cap_pixel(rgb):
    """Return (cx, cy, mask, meta) for the red bottle cap. Ported verbatim from
    industrial-agent scripts/s1_hover_point_test.py::_red_target_pixel."""
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    _S_MIN = 90
    low = cv2.inRange(hsv, np.array([0, _S_MIN, 40], np.uint8), np.array([10, 255, 255], np.uint8))
    high = cv2.inRange(hsv, np.array([158, _S_MIN, 40], np.uint8), np.array([180, 255, 255], np.uint8))
    mask = cv2.bitwise_or(low, high)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    count, labels, stats, centroids = cv2.connectedComponentsWithStats(mask)
    MIN_AREA = 100
    MIN_CIRC = 0.5
    valid = []
    for i in range(1, count):
        if stats[i][4] < MIN_AREA:
            continue
        blob = (labels == i).astype(np.uint8)
        contours, _ = cv2.findContours(blob, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        contour = max(contours, key=cv2.contourArea)
        perim = cv2.arcLength(contour, True)
        if perim <= 0:
            continue
        circ = 4.0 * math.pi * cv2.contourArea(contour) / (perim * perim)
        if circ < MIN_CIRC:
            continue
        valid.append((i, circ))
    if not valid:
        raise RuntimeError("red bottle cap not detected")
    chosen, chosen_circ = max(valid, key=lambda it: stats[it[0]][4])
    cx, cy = centroids[chosen]
    x, y, w, h, area = [int(v) for v in stats[chosen]]
    cap_mask = (labels == chosen)
    return float(cx), float(cy), cap_mask, {
        "bbox_xywh": [x, y, w, h], "area_px": int(area), "circularity": float(chosen_circ)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--serial", default="231622302209")
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--warmup", type=int, default=15)
    ap.add_argument("--timeout-ms", type=int, default=15000)
    ap.add_argument("--out", default="frame_bottle.npz")
    args = ap.parse_args()

    pipeline = rs.pipeline()
    config = rs.config()
    config.enable_device(args.serial)
    config.enable_stream(rs.stream.color, args.width, args.height, rs.format.rgb8, args.fps)
    config.enable_stream(rs.stream.depth, args.width, args.height, rs.format.z16, args.fps)
    align = rs.align(rs.stream.color)
    profile = pipeline.start(config)
    try:
        depth_scale = float(profile.get_device().first_depth_sensor().get_depth_scale())
        for _ in range(args.warmup):
            pipeline.wait_for_frames(args.timeout_ms)
        frames = align.process(pipeline.wait_for_frames(args.timeout_ms))
        color_frame = frames.get_color_frame()
        depth_frame = frames.get_depth_frame()
        if not color_frame or not depth_frame:
            raise RuntimeError("aligned RGB/depth frame missing")
        rgb = np.asanyarray(color_frame.get_data()).copy()          # HxWx3 uint8, RGB
        depth_raw = np.asanyarray(depth_frame.get_data())            # HxW uint16
        depth_m = depth_raw.astype(np.float32) * depth_scale         # HxW float32, meters
        intr = color_frame.profile.as_video_stream_profile().intrinsics
        K = np.array([[intr.fx, 0, intr.ppx], [0, intr.fy, intr.ppy], [0, 0, 1]], np.float64)
    finally:
        pipeline.stop()

    cx, cy, cap_mask, meta = red_cap_pixel(rgb)
    iu, iv = int(round(cx)), int(round(cy))
    patch = depth_m[max(0, iv - 3):iv + 4, max(0, iu - 3):iu + 4]
    dvalid = patch[patch > 0]
    cap_depth = float(np.median(dvalid)) if dvalid.size else 0.0
    p_cam = np.array([(cx - K[0, 2]) * cap_depth / K[0, 0],
                      (cy - K[1, 2]) * cap_depth / K[1, 1], cap_depth])

    np.savez_compressed(
        args.out, rgb=rgb, depth_m=depth_m, K=K, depth_scale=depth_scale,
        cap_pixel=np.array([cx, cy]), cap_bbox=np.array(meta["bbox_xywh"]),
        cap_mask=cap_mask, cap_depth_m=cap_depth, cap_p_cam=p_cam)

    vis = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    cv2.drawMarker(vis, (iu, iv), (0, 255, 0), cv2.MARKER_CROSS, 30, 2)
    x, y, w, h = meta["bbox_xywh"]
    cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 255, 0), 2)
    png = args.out.rsplit(".", 1)[0] + "_vis.png"
    cv2.imwrite(png, vis)

    valid_depth = int((depth_m > 0).sum())
    print(f"saved {args.out}  rgb{rgb.shape} depth_valid={valid_depth}px scale={depth_scale}")
    print(f"K: fx={K[0,0]:.2f} fy={K[1,1]:.2f} cx={K[0,2]:.2f} cy={K[1,2]:.2f}")
    print(f"cap pixel=({cx:.1f},{cy:.1f}) depth={cap_depth*1000:.1f}mm "
          f"p_cam={[round(v,4) for v in p_cam]} area={meta['area_px']}px circ={meta['circularity']:.3f}")
    print(f"annotated {png}")


if __name__ == "__main__":
    main()
