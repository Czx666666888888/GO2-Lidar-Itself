# -*- coding: utf-8 -*-
"""Capture an aligned RealSense RGB-D snapshot without touching the S1 arm.

The script deliberately keeps camera acquisition separate from target detection:
one captured ``.npz`` can be replayed by multiple perception algorithms.  The
RealSense and OpenCV imports are lazy so importing this module for unit tests does
not open a camera or require the hardware packages.
"""
from __future__ import annotations

import argparse
import json
import math
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


def fuse_depth_frames(depth_frames, depth_scale, min_valid_samples=None):
    """Fuse aligned uint16 depth frames with a zero-aware temporal median.

    A pixel is emitted only when at least ``min_valid_samples`` frames contain a
    finite, positive measurement.  The returned array is float32 metres; invalid
    pixels are exactly zero.
    """
    stack = np.asarray(depth_frames)
    if stack.ndim != 3 or stack.shape[0] < 1:
        raise ValueError("depth_frames must have shape NxHxW with N>=1")
    if not math.isfinite(float(depth_scale)) or float(depth_scale) <= 0.0:
        raise ValueError("depth_scale must be finite and positive")

    frame_count = int(stack.shape[0])
    if min_valid_samples is None:
        min_valid_samples = max(1, int(math.ceil(frame_count / 2.0)))
    min_valid_samples = int(min_valid_samples)
    if not 1 <= min_valid_samples <= frame_count:
        raise ValueError("min_valid_samples must be within [1, frame_count]")

    stack_f = stack.astype(np.float32, copy=False)
    valid = np.isfinite(stack_f) & (stack_f > 0.0)
    valid_count = valid.sum(axis=0)
    masked = np.where(valid, stack_f, np.nan)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        median_raw = np.nanmedian(masked, axis=0)
    median_raw = np.where(valid_count >= min_valid_samples, median_raw, 0.0)
    median_raw = np.nan_to_num(median_raw, nan=0.0, posinf=0.0, neginf=0.0)
    return (median_raw * float(depth_scale)).astype(np.float32)


def interval_statistics(intervals_ms):
    values = np.asarray(intervals_ms, dtype=np.float64)
    if values.size == 0:
        return {
            "frame_interval_ms_mean": 0.0,
            "frame_interval_ms_max": 0.0,
            "frame_interval_ms_p95": 0.0,
        }
    if not np.isfinite(values).all() or (values < 0.0).any():
        raise ValueError("frame intervals must be finite and non-negative")
    return {
        "frame_interval_ms_mean": float(values.mean()),
        "frame_interval_ms_max": float(values.max()),
        "frame_interval_ms_p95": float(np.percentile(values, 95)),
    }


def evaluate_capture_quality(
    metadata,
    min_valid_depth_ratio=0.60,
    max_frame_interval_ms=250.0,
):
    """Return ``(passed, reasons)`` for explicit, machine-readable gates."""
    reasons = []
    usb_type = str(metadata.get("usb_type", ""))
    valid_ratio = float(metadata.get("valid_depth_ratio_fused", 0.0))
    max_interval = float(metadata.get("frame_interval_ms_max", float("inf")))

    if not usb_type.startswith("3"):
        reasons.append(f"usb_type={usb_type or 'unknown'} is not USB 3.x")
    if not math.isfinite(valid_ratio) or valid_ratio < float(min_valid_depth_ratio):
        reasons.append(
            f"valid_depth_ratio={valid_ratio:.4f} < {float(min_valid_depth_ratio):.4f}"
        )
    if not math.isfinite(max_interval) or max_interval > float(max_frame_interval_ms):
        reasons.append(
            f"frame_interval_ms_max={max_interval:.3f} > "
            f"{float(max_frame_interval_ms):.3f}"
        )
    return not reasons, reasons


def _device_info(device, rs, key, fallback="unsupported"):
    return device.get_info(key) if device.supports(key) else fallback


def select_device(context, rs, requested_serial=None):
    devices = list(context.query_devices())
    if not devices:
        raise RuntimeError("no RealSense device detected")
    if requested_serial:
        for device in devices:
            serial = _device_info(device, rs, rs.camera_info.serial_number, "")
            if serial == requested_serial:
                return device
        available = [
            _device_info(device, rs, rs.camera_info.serial_number, "unknown")
            for device in devices
        ]
        raise RuntimeError(
            f"requested RealSense serial {requested_serial!r} not found; "
            f"available={available}"
        )
    if len(devices) != 1:
        serials = [
            _device_info(device, rs, rs.camera_info.serial_number, "unknown")
            for device in devices
        ]
        raise RuntimeError(
            "multiple RealSense devices detected; pass --serial explicitly: "
            f"{serials}"
        )
    return devices[0]


def capture_aligned_rgbd(
    *,
    serial=None,
    width=640,
    height=480,
    fps=30,
    warmup_frames=30,
    depth_frames=15,
    min_depth_samples=None,
    timeout_ms=5000,
    min_valid_depth_ratio=0.60,
    max_frame_interval_ms=250.0,
):
    """Capture aligned RGB plus temporally fused depth; never imports S1 code."""
    import os
    recording_socket = os.environ.get("S1_RGBD_RECORD_SOCKET")
    if recording_socket:
        from demo_grasp.recording_capture import request_snapshot
        return request_snapshot(recording_socket, dict(
            serial=serial,width=width,height=height,fps=fps,
            warmup_frames=warmup_frames,depth_frames=depth_frames,
            min_depth_samples=min_depth_samples,timeout_ms=timeout_ms,
            min_valid_depth_ratio=min_valid_depth_ratio,
            max_frame_interval_ms=max_frame_interval_ms))
    import time

    call_started = time.perf_counter()
    import_started = time.perf_counter()
    import pyrealsense2 as rs
    stage_timing_s = {
        "pyrealsense_import": time.perf_counter() - import_started,
    }

    if min(width, height, fps, depth_frames, timeout_ms) <= 0:
        raise ValueError("width/height/fps/depth_frames/timeout_ms must be positive")
    if warmup_frames < 0:
        raise ValueError("warmup_frames must be non-negative")

    setup_started = time.perf_counter()
    context = rs.context()
    selected = select_device(context, rs, serial)
    api_serial = _device_info(selected, rs, rs.camera_info.serial_number, "")

    pipeline = rs.pipeline(context)
    config = rs.config()
    config.enable_device(api_serial)
    config.enable_stream(rs.stream.color, width, height, rs.format.rgb8, fps)
    config.enable_stream(rs.stream.depth, width, height, rs.format.z16, fps)
    align = rs.align(rs.stream.color)
    stage_timing_s["device_setup"] = time.perf_counter() - setup_started

    started = False
    raw_depth_frames = []
    valid_ratios = []
    intervals_ms = []
    last_arrival = None
    rgb = None
    color_frame = None
    result = None
    try:
        pipeline_start_started = time.perf_counter()
        profile = pipeline.start(config)
        stage_timing_s["pipeline_start"] = (
            time.perf_counter() - pipeline_start_started
        )
        started = True
        profile_device = profile.get_device()
        depth_scale = float(profile_device.first_depth_sensor().get_depth_scale())

        warmup_started = time.perf_counter()
        for _ in range(int(warmup_frames)):
            pipeline.wait_for_frames(int(timeout_ms))
        stage_timing_s["warmup"] = time.perf_counter() - warmup_started

        depth_capture_started = time.perf_counter()
        for _ in range(int(depth_frames)):
            frames = align.process(pipeline.wait_for_frames(int(timeout_ms)))
            color_frame = frames.get_color_frame()
            depth_frame = frames.get_depth_frame()
            if not color_frame or not depth_frame:
                raise RuntimeError("aligned RGB/depth frame missing")

            now = time.perf_counter()
            if last_arrival is not None:
                intervals_ms.append((now - last_arrival) * 1000.0)
            last_arrival = now

            rgb = np.asanyarray(color_frame.get_data()).copy()
            depth_raw = np.asanyarray(depth_frame.get_data()).copy()
            raw_depth_frames.append(depth_raw)
            valid_ratios.append(float((depth_raw > 0).mean()))
        stage_timing_s["depth_capture"] = (
            time.perf_counter() - depth_capture_started
        )

        if rgb is None or color_frame is None:
            raise RuntimeError("capture produced no frames")

        if min_depth_samples is None:
            min_depth_samples = max(1, int(math.ceil(depth_frames / 2.0)))
        depth_fusion_started = time.perf_counter()
        depth_m = fuse_depth_frames(
            raw_depth_frames,
            depth_scale,
            min_valid_samples=min_depth_samples,
        )
        stage_timing_s["depth_fusion"] = (
            time.perf_counter() - depth_fusion_started
        )
        intr = color_frame.profile.as_video_stream_profile().intrinsics
        K = np.array(
            [[intr.fx, 0.0, intr.ppx], [0.0, intr.fy, intr.ppy], [0.0, 0.0, 1.0]],
            dtype=np.float64,
        )

        metadata = {
            "schema_version": 1,
            "capture_utc": datetime.now(timezone.utc).isoformat(),
            "camera_name": _device_info(
                profile_device, rs, rs.camera_info.name
            ),
            "serial": _device_info(
                profile_device, rs, rs.camera_info.serial_number
            ),
            "firmware": _device_info(
                profile_device, rs, rs.camera_info.firmware_version
            ),
            "usb_type": _device_info(
                profile_device, rs, rs.camera_info.usb_type_descriptor
            ),
            "product_line": _device_info(
                profile_device, rs, rs.camera_info.product_line
            ),
            "width": int(width),
            "height": int(height),
            "fps": int(fps),
            "warmup_frames": int(warmup_frames),
            "depth_frames": int(depth_frames),
            "min_depth_samples": int(min_depth_samples),
            "depth_scale": depth_scale,
            "distortion_model": str(intr.model),
            "valid_depth_ratio_frame_mean": float(np.mean(valid_ratios)),
            "valid_depth_ratio_frame_min": float(np.min(valid_ratios)),
            "valid_depth_ratio_fused": float((depth_m > 0.0).mean()),
        }
        metadata.update(interval_statistics(intervals_ms))
        passed, reasons = evaluate_capture_quality(
            metadata,
            min_valid_depth_ratio=min_valid_depth_ratio,
            max_frame_interval_ms=max_frame_interval_ms,
        )
        metadata["quality_pass"] = bool(passed)
        metadata["quality_reasons"] = list(reasons)

        result = {
            "rgb": rgb,
            "depth_m": depth_m,
            "K": K,
            "distortion_coeffs": np.asarray(intr.coeffs, dtype=np.float64),
            "metadata": metadata,
        }
    finally:
        if started:
            pipeline_stop_started = time.perf_counter()
            pipeline.stop()
            stage_timing_s["pipeline_stop"] = (
                time.perf_counter() - pipeline_stop_started
            )

    stage_timing_s["total"] = time.perf_counter() - call_started
    result["metadata"]["stage_timing_s"] = {
        key: float(value) for key, value in stage_timing_s.items()
    }
    return result


def _depth_preview(depth_m, cv2):
    valid = np.isfinite(depth_m) & (depth_m > 0.0)
    gray = np.zeros(depth_m.shape, dtype=np.uint8)
    if valid.any():
        lo, hi = np.percentile(depth_m[valid], [2.0, 98.0])
        if hi <= lo:
            hi = lo + 1e-6
        normalized = np.clip((depth_m - lo) / (hi - lo), 0.0, 1.0)
        gray[valid] = np.round(normalized[valid] * 255.0).astype(np.uint8)
    colored = cv2.applyColorMap(gray, cv2.COLORMAP_TURBO)
    colored[~valid] = 0
    return colored


def save_capture(capture, out_path, write_preview=True):
    out_path = Path(out_path).expanduser().resolve()
    if out_path.suffix.lower() != ".npz":
        raise ValueError("--out must end in .npz")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    metadata_json = json.dumps(
        capture["metadata"], ensure_ascii=False, sort_keys=True
    )
    np.savez_compressed(
        out_path,
        rgb=capture["rgb"],
        depth_m=capture["depth_m"],
        K=capture["K"],
        distortion_coeffs=capture["distortion_coeffs"],
        metadata_json=np.array(metadata_json),
    )

    preview_paths = []
    if write_preview:
        import cv2

        rgb_path = out_path.with_name(f"{out_path.stem}_rgb.png")
        depth_path = out_path.with_name(f"{out_path.stem}_depth.png")
        rgb_bgr = cv2.cvtColor(capture["rgb"], cv2.COLOR_RGB2BGR)
        if not cv2.imwrite(str(rgb_path), rgb_bgr):
            raise RuntimeError(f"failed to save {rgb_path}")
        if not cv2.imwrite(
            str(depth_path), _depth_preview(capture["depth_m"], cv2)
        ):
            raise RuntimeError(f"failed to save {depth_path}")
        preview_paths.extend([rgb_path, depth_path])
    return out_path, preview_paths


def build_parser():
    parser = argparse.ArgumentParser(
        description="采集D455对齐RGB-D快照；不连接、不控制S1机械臂"
    )
    parser.add_argument("--out", required=True, help="输出.npz路径（必须显式指定）")
    parser.add_argument("--serial", default=None, help="多相机时必须指定RealSense API序列号")
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--warmup-frames", type=int, default=30)
    parser.add_argument("--depth-frames", type=int, default=15)
    parser.add_argument(
        "--min-depth-samples",
        type=int,
        default=None,
        help="每像素至少有效帧数；默认ceil(depth-frames/2)",
    )
    parser.add_argument("--timeout-ms", type=int, default=5000)
    parser.add_argument("--min-valid-depth-ratio", type=float, default=0.60)
    parser.add_argument("--max-frame-interval-ms", type=float, default=250.0)
    parser.add_argument("--no-preview", action="store_true")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    capture = capture_aligned_rgbd(
        serial=args.serial,
        width=args.width,
        height=args.height,
        fps=args.fps,
        warmup_frames=args.warmup_frames,
        depth_frames=args.depth_frames,
        min_depth_samples=args.min_depth_samples,
        timeout_ms=args.timeout_ms,
        min_valid_depth_ratio=args.min_valid_depth_ratio,
        max_frame_interval_ms=args.max_frame_interval_ms,
    )
    out_path, previews = save_capture(
        capture, args.out, write_preview=not args.no_preview
    )
    meta = capture["metadata"]
    print(f"CAPTURE_SAVED = {out_path}")
    for path in previews:
        print(f"PREVIEW_SAVED = {path}")
    print(f"CAMERA = {meta['camera_name']} serial={meta['serial']}")
    print(f"USB_TYPE = {meta['usb_type']}")
    print(f"DEPTH_SCALE = {meta['depth_scale']:.10f}")
    print(f"VALID_DEPTH_RATIO_FUSED = {meta['valid_depth_ratio_fused']:.4f}")
    print(f"FRAME_INTERVAL_MS_MEAN = {meta['frame_interval_ms_mean']:.3f}")
    print(f"FRAME_INTERVAL_MS_P95 = {meta['frame_interval_ms_p95']:.3f}")
    print(f"FRAME_INTERVAL_MS_MAX = {meta['frame_interval_ms_max']:.3f}")
    print(
        "CAPTURE_STAGE_TIMING_S =",
        json.dumps(meta.get("stage_timing_s", {}), sort_keys=True),
    )
    print(f"QUALITY_PASS = {meta['quality_pass']}")
    if meta["quality_reasons"]:
        for reason in meta["quality_reasons"]:
            print(f"QUALITY_REJECT = {reason}")
        return 2
    print("RGBD_CAPTURE_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
