# -*- coding: utf-8 -*-
"""Detect one elevated science target from a replayable RGB-D capture.

This is an offline, camera-frame-only perception stage.  It never imports the
S1 SDK, opens a serial port, enables the arm, or converts the result into the
robot base frame.  The detector fits the table plane, extracts elevated compact
components, erodes their boundary, and reports an explicit confidence gate.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = PROJECT_ROOT / "config" / "cube_vision.yaml"


def _finite_float(value, name):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def _clamp01(value):
    return float(np.clip(float(value), 0.0, 1.0))


def orientation_quality_profile(point_count, config):
    """Resolve auditable orientation gates from the available 3-D sample size.

    Small projected targets have quantized, jagged depth boundaries.  They keep
    all geometric gates, but may use a narrowly relaxed repeatability/confidence
    profile declared in configuration.  Missing ``small_sample`` preserves the
    original standard-only behavior for older configs.
    """
    point_count = int(point_count)
    if point_count < 0:
        raise ValueError("orientation point_count must be non-negative")

    standard_min_confidence = _finite_float(
        config["min_confidence_score"],
        "orientation.min_confidence_score",
    )
    standard_max_deviation = _finite_float(
        config["max_p90_deviation_deg"],
        "orientation.max_p90_deviation_deg",
    )
    if not 0.0 <= standard_min_confidence <= 1.0:
        raise ValueError("orientation min_confidence_score must be in [0, 1]")
    if not 0.0 < standard_max_deviation < 45.0:
        raise ValueError("orientation max_p90_deviation_deg must be in (0, 45)")

    profile = {
        "name": "standard",
        "sample_point_count": point_count,
        "min_confidence_score": standard_min_confidence,
        "max_p90_deviation_deg": standard_max_deviation,
    }
    small = config.get("small_sample")
    if small is None:
        return profile
    if not isinstance(small, dict):
        raise ValueError("orientation.small_sample must be a mapping")

    maximum_points = int(small["max_points"])
    small_min_confidence = _finite_float(
        small["min_confidence_score"],
        "orientation.small_sample.min_confidence_score",
    )
    small_max_deviation = _finite_float(
        small["max_p90_deviation_deg"],
        "orientation.small_sample.max_p90_deviation_deg",
    )
    if maximum_points < int(config["min_points"]):
        raise ValueError(
            "orientation.small_sample.max_points must be >= min_points"
        )
    if not 0.0 <= small_min_confidence <= standard_min_confidence:
        raise ValueError(
            "orientation.small_sample.min_confidence_score must be in "
            "[0, standard minimum]"
        )
    if not standard_max_deviation <= small_max_deviation < 45.0:
        raise ValueError(
            "orientation.small_sample.max_p90_deviation_deg must be in "
            "[standard maximum, 45)"
        )
    if point_count <= maximum_points:
        profile.update({
            "name": "small_sample",
            "min_confidence_score": small_min_confidence,
            "max_p90_deviation_deg": small_max_deviation,
        })
    return profile


def load_config(path=DEFAULT_CONFIG):
    import yaml

    path = Path(path).expanduser().resolve()
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(config, dict):
        raise ValueError("vision config must contain a mapping")
    return config, path


def load_capture(path):
    path = Path(path).expanduser().resolve()
    with np.load(path, allow_pickle=False) as replay:
        required = {"rgb", "depth_m", "K", "metadata_json"}
        missing = required.difference(replay.files)
        if missing:
            raise ValueError(f"capture is missing keys: {sorted(missing)}")
        rgb = replay["rgb"].copy()
        depth_m = replay["depth_m"].astype(np.float32, copy=True)
        K = replay["K"].astype(np.float64, copy=True)
        metadata = json.loads(str(replay["metadata_json"].item()))
    if rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("rgb must have shape HxWx3")
    if depth_m.shape != rgb.shape[:2]:
        raise ValueError("depth_m and rgb dimensions do not match")
    if K.shape != (3, 3) or not np.isfinite(K).all():
        raise ValueError("K must be a finite 3x3 matrix")
    if K[0, 0] <= 0.0 or K[1, 1] <= 0.0:
        raise ValueError("camera focal lengths must be positive")
    return {
        "path": path,
        "rgb": rgb,
        "depth_m": depth_m,
        "K": K,
        "metadata": metadata,
    }


def depth_to_points(depth_m, K):
    height, width = depth_m.shape
    vv, uu = np.indices((height, width), dtype=np.float32)
    z = depth_m.astype(np.float32, copy=False)
    x = (uu - float(K[0, 2])) * z / float(K[0, 0])
    y = (vv - float(K[1, 2])) * z / float(K[1, 1])
    return np.stack((x, y, z), axis=-1)


def normalized_roi(shape, normalized_xyxy):
    height, width = shape
    if len(normalized_xyxy) != 4:
        raise ValueError("workspace_roi.normalized_xyxy must have four values")
    x0n, y0n, x1n, y1n = map(float, normalized_xyxy)
    if not (0.0 <= x0n < x1n <= 1.0 and 0.0 <= y0n < y1n <= 1.0):
        raise ValueError("workspace ROI must lie within normalized image bounds")
    x0 = int(round(x0n * width))
    y0 = int(round(y0n * height))
    x1 = int(round(x1n * width))
    y1 = int(round(y1n * height))
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(width, x1), min(height, y1)
    if x1 - x0 < 8 or y1 - y0 < 8:
        raise ValueError("workspace ROI is too small")
    return x0, y0, x1, y1


def _plane_from_three(points):
    normal = np.cross(points[1] - points[0], points[2] - points[0])
    norm = float(np.linalg.norm(normal))
    if norm < 1e-10:
        return None
    normal = normal / norm
    return normal, -float(normal @ points[0])


def _signed_plane_distance(points, normal, offset):
    """Compute Nx3 point-to-plane values without small BLAS dispatches."""
    return (
        points[..., 0] * float(normal[0])
        + points[..., 1] * float(normal[1])
        + points[..., 2] * float(normal[2])
        + float(offset)
    )


def fit_table_plane(depth_m, K, roi_px, plane_config):
    points_image = depth_to_points(depth_m, K)
    x0, y0, x1, y1 = roi_px
    min_depth = _finite_float(plane_config["min_depth_m"], "min_depth_m")
    max_depth = _finite_float(plane_config["max_depth_m"], "max_depth_m")
    threshold_m = _finite_float(
        plane_config["ransac_inlier_threshold_mm"],
        "ransac_inlier_threshold_mm",
    ) / 1000.0
    if not 0.0 < min_depth < max_depth or threshold_m <= 0.0:
        raise ValueError("invalid plane depth or RANSAC threshold")

    roi_mask = np.zeros(depth_m.shape, dtype=bool)
    roi_mask[y0:y1, x0:x1] = True
    valid = (
        roi_mask
        & np.isfinite(depth_m)
        & (depth_m >= min_depth)
        & (depth_m <= max_depth)
    )
    all_points = points_image[valid]
    min_points = int(plane_config["min_valid_points"])
    if all_points.shape[0] < min_points:
        raise RuntimeError(
            f"not enough valid table points: {all_points.shape[0]} < {min_points}"
        )

    rng = np.random.default_rng(int(plane_config.get("random_seed", 7)))
    sample_cap = int(plane_config["sample_cap"])
    if all_points.shape[0] > sample_cap:
        sampled = all_points[
            rng.choice(all_points.shape[0], sample_cap, replace=False)
        ]
    else:
        sampled = all_points

    best_count = -1
    best_plane = None
    for _ in range(int(plane_config["ransac_iterations"])):
        triplet = sampled[rng.choice(sampled.shape[0], 3, replace=False)]
        candidate = _plane_from_three(triplet)
        if candidate is None:
            continue
        normal, offset = candidate
        distances = np.abs(_signed_plane_distance(sampled, normal, offset))
        count = int(np.count_nonzero(distances <= threshold_m))
        if count > best_count:
            best_count = count
            best_plane = (normal, offset)
    if best_plane is None:
        raise RuntimeError("RANSAC could not produce a table plane")

    normal, offset = best_plane
    inliers = (
        np.abs(_signed_plane_distance(sampled, normal, offset)) <= threshold_m
    )
    if int(np.count_nonzero(inliers)) < 3:
        raise RuntimeError("RANSAC table plane has fewer than three inliers")
    inlier_points = sampled[inliers]
    centroid = inlier_points.mean(axis=0)
    _, _, vh = np.linalg.svd(inlier_points - centroid, full_matrices=False)
    normal = vh[-1]
    if float(normal @ (-centroid)) < 0.0:
        normal = -normal
    offset = -float(normal @ centroid)

    signed_sample = _signed_plane_distance(sampled, normal, offset)
    final_inliers = np.abs(signed_sample) <= threshold_m
    inlier_ratio = float(np.mean(final_inliers))
    rmse_m = float(
        np.sqrt(np.mean(np.square(signed_sample[final_inliers])))
    )
    tilt_deg = float(
        np.degrees(np.arccos(np.clip(abs(float(normal[2])), 0.0, 1.0)))
    )

    signed_height_m = _signed_plane_distance(points_image, normal, offset)
    signed_height_m[~np.isfinite(depth_m) | (depth_m <= 0.0)] = np.nan
    return {
        "normal": normal,
        "offset_m": offset,
        "rmse_m": rmse_m,
        "inlier_ratio": inlier_ratio,
        "tilt_deg": tilt_deg,
        "roi_mask": roi_mask,
        "valid_mask": valid,
        "signed_height_m": signed_height_m,
        "points_image": points_image,
        "sample_count": int(sampled.shape[0]),
    }


def evaluate_plane(plane, config):
    reasons = []
    max_rmse_m = float(config["max_rmse_mm"]) / 1000.0
    min_ratio = float(config["min_inlier_ratio"])
    max_tilt = float(config["max_tilt_deg"])
    if plane["rmse_m"] > max_rmse_m:
        reasons.append(
            f"plane_rmse_mm={plane['rmse_m'] * 1000.0:.3f} > "
            f"{max_rmse_m * 1000.0:.3f}"
        )
    if plane["inlier_ratio"] < min_ratio:
        reasons.append(
            f"plane_inlier_ratio={plane['inlier_ratio']:.4f} < {min_ratio:.4f}"
        )
    if plane["tilt_deg"] > max_tilt:
        reasons.append(
            f"plane_tilt_deg={plane['tilt_deg']:.3f} > {max_tilt:.3f}"
        )
    return not reasons, reasons


def _score_candidate(candidate, plane, config):
    plane_cfg = config["plane"]
    component_cfg = config["component"]
    target_cfg = config["target"]
    good_rmse = float(plane_cfg["good_rmse_mm"])
    max_rmse = float(plane_cfg["max_rmse_mm"])
    rmse = plane["rmse_m"] * 1000.0
    if max_rmse <= good_rmse:
        raise ValueError("plane.max_rmse_mm must exceed plane.good_rmse_mm")
    plane_score = _clamp01((max_rmse - rmse) / (max_rmse - good_rmse))

    max_aspect = float(component_cfg["max_aspect_ratio"])
    aspect = float(candidate["aspect_ratio"])
    shape_score = _clamp01((max_aspect - aspect) / (max_aspect - 1.0))

    min_fill = float(component_cfg["min_fill_ratio"])
    good_fill = float(component_cfg["good_fill_ratio"])
    fill_score = _clamp01(
        (float(candidate["fill_ratio"]) - min_fill) / (good_fill - min_fill)
    )

    min_height = float(target_cfg["min_core_height_mm"])
    good_height = float(target_cfg["good_core_height_mm"])
    height_score = _clamp01(
        (float(candidate["core_height_mm"]["median"]) - min_height)
        / (good_height - min_height)
    )
    depth_score = _clamp01(candidate["core_depth_valid_ratio"])
    score = (
        0.25 * plane_score
        + 0.25 * depth_score
        + 0.25 * shape_score
        + 0.15 * fill_score
        + 0.10 * height_score
    )
    candidate["score_terms"] = {
        "plane": plane_score,
        "core_depth": depth_score,
        "shape": shape_score,
        "fill": fill_score,
        "height": height_score,
    }
    candidate["confidence_score"] = float(score)
    return float(score)


def adaptive_core_erode_px(width, height, component_config):
    """Choose edge erosion from the candidate scale, with explicit bounds."""
    short_side = min(int(width), int(height))
    fraction = float(component_config["core_erode_fraction"])
    minimum = int(component_config["core_erode_min_px"])
    maximum = int(component_config["core_erode_max_px"])
    if short_side <= 0:
        raise ValueError("candidate width and height must be positive")
    if not math.isfinite(fraction) or fraction <= 0.0:
        raise ValueError("component.core_erode_fraction must be positive")
    if minimum < 0 or maximum < minimum:
        raise ValueError(
            "component core erosion bounds must satisfy 0 <= min <= max"
        )
    # Use round-half-up instead of Python's banker's rounding so the mapping is
    # deterministic at .5-pixel boundaries.
    scaled = int(math.floor(short_side * fraction + 0.5))
    return max(minimum, min(maximum, scaled))


def oriented_core_depth_region(component_mask, inset_px):
    """Rasterize an inset minimum-area rectangle for raw-depth validation.

    The connected component itself contains only pixels that already have a
    usable 3-D height, so measuring validity on that mask would be circular.
    Instead, fit the component's expected rotated footprint, shrink every edge
    by the existing scale-aware erosion amount, and test the *raw* depth inside
    that expected interior.  Rotation no longer adds the empty corners of an
    axis-aligned bounding box, while genuine internal depth holes remain in the
    denominator and can still reject a reflective or otherwise unreliable top.
    """
    import cv2

    mask = np.asarray(component_mask, dtype=np.uint8)
    if mask.ndim != 2:
        raise ValueError("component_mask must be a 2-D array")
    inset = float(inset_px)
    if not math.isfinite(inset) or inset < 0.0:
        raise ValueError("inset_px must be finite and non-negative")

    y_px, x_px = np.nonzero(mask)
    if x_px.size < 4:
        return np.zeros_like(mask, dtype=bool), None
    points_px = np.column_stack((x_px, y_px)).astype(np.float32)
    center, size, angle_deg = cv2.minAreaRect(points_px)
    inner_width = float(size[0]) - 2.0 * inset
    inner_height = float(size[1]) - 2.0 * inset
    if inner_width <= 0.0 or inner_height <= 0.0:
        return np.zeros_like(mask, dtype=bool), None

    inner_rectangle = (center, (inner_width, inner_height), angle_deg)
    corners_px = cv2.boxPoints(inner_rectangle).astype(float)
    raster_corners = np.rint(corners_px).astype(np.int32)
    region = np.zeros_like(mask, dtype=np.uint8)
    cv2.fillConvexPoly(region, raster_corners, 1)
    return region.astype(bool), corners_px.tolist()


def _canonical_undirected_axis(axis):
    """Normalize an axis whose sign is physically irrelevant."""
    axis = np.asarray(axis, dtype=float)
    norm = float(np.linalg.norm(axis))
    if axis.shape != (3,) or not math.isfinite(norm) or norm < 1e-9:
        raise ValueError("orientation axis must be a finite non-zero 3-vector")
    axis = axis / norm
    for value in axis:
        if abs(float(value)) > 1e-9:
            if value < 0.0:
                axis = -axis
            break
    return axis


def _table_tangent_basis(normal_cam):
    """Build a deterministic orthonormal basis in the detected table plane."""
    normal = np.asarray(normal_cam, dtype=float)
    normal /= np.linalg.norm(normal)
    reference = np.array([1.0, 0.0, 0.0])
    tangent_u = reference - normal * float(reference @ normal)
    if float(np.linalg.norm(tangent_u)) < 1e-6:
        reference = np.array([0.0, 1.0, 0.0])
        tangent_u = reference - normal * float(reference @ normal)
    tangent_u /= np.linalg.norm(tangent_u)
    tangent_v = np.cross(normal, tangent_u)
    tangent_v /= np.linalg.norm(tangent_v)
    return tangent_u, tangent_v


def _rectangle_statistics(points_2d):
    import cv2

    points = np.asarray(points_2d, dtype=np.float32).reshape(-1, 2)
    if points.shape[0] < 4:
        raise ValueError("rectangle estimation requires at least four points")
    rectangle = cv2.minAreaRect(points)
    box = cv2.boxPoints(rectangle).astype(float)
    edges = [box[(index + 1) % 4] - box[index] for index in range(4)]
    lengths = [float(np.linalg.norm(edge)) for edge in edges]
    if min(lengths) < 1e-9:
        raise ValueError("minimum-area rectangle is degenerate")
    longest_index = int(np.argmax(lengths))
    axis = edges[longest_index] / lengths[longest_index]
    angle_rad = math.atan2(float(axis[1]), float(axis[0])) % (math.pi / 2.0)
    short_side = min(lengths[0], lengths[1])
    long_side = max(lengths[0], lengths[1])
    rectangle_area = short_side * long_side
    hull = cv2.convexHull(points)
    hull_area = float(cv2.contourArea(hull))
    return {
        "angle_rad_mod90": angle_rad,
        "short_side_m": short_side,
        "long_side_m": long_side,
        "aspect_ratio": long_side / short_side,
        "rectangularity": min(1.0, hull_area / rectangle_area),
    }


def _periodic_angle_delta_rad(angle, reference, period):
    return abs((angle - reference + 0.5 * period) % period - 0.5 * period)


def estimate_square_orientation(points_cam, normal_cam, config):
    """Estimate a square edge axis in the camera frame, modulo 90 degrees.

    The component points are projected into a metric table-plane basis before
    fitting, so image perspective does not get mistaken for base-frame yaw.
    Bootstrap fits provide an explicit stability gate; a noisy symmetric blob
    is rejected instead of being assigned an arbitrary angle.
    """
    points = np.asarray(points_cam, dtype=float)
    points = points[np.isfinite(points).all(axis=1)]
    quality_profile = orientation_quality_profile(points.shape[0], config)
    minimum_points = int(config["min_points"])
    if points.shape[0] < minimum_points:
        return None, ["orientation_points_below_minimum"]

    tangent_u, tangent_v = _table_tangent_basis(normal_cam)
    centered = points - np.median(points, axis=0)
    points_2d = np.column_stack((centered @ tangent_u, centered @ tangent_v))
    try:
        baseline = _rectangle_statistics(points_2d)
    except ValueError:
        return None, ["orientation_rectangle_degenerate"]

    bootstrap_count = int(config["bootstrap_samples"])
    bootstrap_fraction = float(config["bootstrap_fraction"])
    if bootstrap_count < 1 or not 0.5 <= bootstrap_fraction <= 1.0:
        raise ValueError(
            "orientation bootstrap_samples must be positive and "
            "bootstrap_fraction must be in [0.5, 1.0]"
        )
    rng = np.random.default_rng(int(config.get("random_seed", 13)))
    sample_size = max(4, int(round(points_2d.shape[0] * bootstrap_fraction)))
    angles = [float(baseline["angle_rad_mod90"])]
    for _ in range(bootstrap_count):
        indices = rng.choice(points_2d.shape[0], sample_size, replace=False)
        try:
            fit = _rectangle_statistics(points_2d[indices])
        except ValueError:
            continue
        angles.append(float(fit["angle_rad_mod90"]))

    if len(angles) < max(3, bootstrap_count // 2):
        return None, ["orientation_bootstrap_insufficient"]

    # A square is periodic every 90 degrees, hence the fourth-angle mean.
    fourth_angles = 4.0 * np.asarray(angles)
    mean_cos = float(np.mean(np.cos(fourth_angles)))
    mean_sin = float(np.mean(np.sin(fourth_angles)))
    concentration = math.hypot(mean_cos, mean_sin)
    mean_angle = (0.25 * math.atan2(mean_sin, mean_cos)) % (math.pi / 2.0)
    deviations_deg = [
        math.degrees(
            _periodic_angle_delta_rad(angle, mean_angle, math.pi / 2.0)
        )
        for angle in angles
    ]
    p90_deviation_deg = float(np.percentile(deviations_deg, 90.0))

    axis_cam = _canonical_undirected_axis(
        math.cos(mean_angle) * tangent_u
        + math.sin(mean_angle) * tangent_v
    )
    max_aspect = float(config["max_rectangle_aspect_ratio"])
    min_rectangularity = float(config["min_rectangularity"])
    shape_score = _clamp01(
        (max_aspect - baseline["aspect_ratio"])
        / max(1e-9, max_aspect - 1.0)
    )
    rectangularity_score = _clamp01(
        (baseline["rectangularity"] - min_rectangularity)
        / max(1e-9, 1.0 - min_rectangularity)
    )
    confidence = (
        0.50 * concentration
        + 0.25 * shape_score
        + 0.25 * rectangularity_score
    )
    orientation = {
        "symmetry_period_deg": 90.0,
        "axis_cam": axis_cam.tolist(),
        "angle_in_table_basis_mod90_deg": math.degrees(mean_angle),
        "confidence_score": float(confidence),
        "bootstrap_fit_count": len(angles),
        "angular_concentration": concentration,
        "p90_deviation_deg": p90_deviation_deg,
        "rectangle_aspect_ratio": float(baseline["aspect_ratio"]),
        "rectangle_fill_ratio": float(baseline["rectangularity"]),
        "rectangle_side_lengths_mm": [
            1000.0 * float(baseline["short_side_m"]),
            1000.0 * float(baseline["long_side_m"]),
        ],
        "quality_profile": quality_profile["name"],
        "sample_point_count": quality_profile["sample_point_count"],
        "applied_min_confidence_score": quality_profile[
            "min_confidence_score"
        ],
        "applied_max_p90_deviation_deg": quality_profile[
            "max_p90_deviation_deg"
        ],
    }
    reasons = []
    if baseline["aspect_ratio"] > max_aspect:
        reasons.append("orientation_rectangle_aspect_too_large")
    if baseline["rectangularity"] < min_rectangularity:
        reasons.append("orientation_rectangularity_too_low")
    if concentration < float(config["min_angular_concentration"]):
        reasons.append("orientation_angular_concentration_too_low")
    if p90_deviation_deg > quality_profile["max_p90_deviation_deg"]:
        reasons.append("orientation_bootstrap_deviation_too_large")
    if confidence < quality_profile["min_confidence_score"]:
        reasons.append("orientation_confidence_below_minimum")
    return orientation, reasons


def _project_orientation_axis_to_pixels(point_cam, axis_cam, length_m, K):
    endpoints = []
    for sign in (-0.5, 0.5):
        point = np.asarray(point_cam, dtype=float) + sign * length_m * np.asarray(
            axis_cam, dtype=float
        )
        if point[2] <= 1e-9:
            return None
        endpoints.append([
            float(K[0, 0] * point[0] / point[2] + K[0, 2]),
            float(K[1, 1] * point[1] / point[2] + K[1, 2]),
        ])
    return endpoints



def complete_missing_depth_contour(rgb, depth_m, component_mask, core_mask, plane, K,
                                   median_height_mm):
    """Grow a depth-backed object into same-color depth holes, not the ground."""
    import cv2
    seed = component_mask.astype(bool)
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(float)
    samples = lab[core_mask, 1:]
    if not len(samples):
        return None
    center = np.median(samples, axis=0)
    spread = np.linalg.norm(samples-center, axis=1)
    color_radius = max(10.0, 1.5*float(np.percentile(spread,95)))
    same_color = np.linalg.norm(lab[:,:,1:]-center,axis=2) <= color_radius
    missing = ~np.isfinite(depth_m) | (depth_m<=0)
    allowed = seed | (missing & same_color & plane["roi_mask"])
    count,labels = cv2.connectedComponents(allowed.astype(np.uint8),connectivity=8)
    ids,hits = np.unique(labels[seed],return_counts=True)
    selected = int(ids[np.argmax(hits)])
    mask = labels==selected
    if np.count_nonzero(mask) <= np.count_nonzero(seed):
        return None
    y,x = np.nonzero(mask)
    rays = np.column_stack(((x-K[0,2])/K[0,0],(y-K[1,2])/K[1,1],np.ones(len(x))))
    normal = np.asarray(plane["normal"])
    distance = (median_height_mm/1000.0-float(plane["offset_m"]))/(rays@normal)
    points = rays*distance[:,None]
    return {"mask":mask,"points":points,"center_cam_m":np.mean(points,axis=0),
            "source":"rgb_contour_on_measured_top_plane",
            "original_depth_pixels":int(np.count_nonzero(seed)),
            "completed_contour_pixels":int(np.count_nonzero(mask)),
            "color_radius_lab_ab":color_radius}



def color_supported_component_mask(rgb, depth_m, foreground, plane, config):
    """Merge depth fragments through same-color holes before candidate gating."""
    import cv2
    lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB).astype(float)[:,:,1:]
    raw=foreground.astype(bool)
    missing=~np.isfinite(depth_m)|(depth_m<=0)
    count,labels,stats,_=cv2.connectedComponentsWithStats(raw.astype(np.uint8),connectivity=8)
    merged=raw.copy()
    recovered=np.zeros_like(raw)
    min_pixels=int(config["component"]["min_core_pixels"])
    h=plane["signed_height_m"]*1000
    ground=plane["roi_mask"] & plane["valid_mask"] & (np.abs(h)<=float(config["plane"]["ransac_inlier_threshold_mm"]))
    ground_center=np.median(lab[ground],axis=0) if np.any(ground) else None
    ground_distance=np.linalg.norm(lab-ground_center,axis=2) if ground_center is not None else None
    for label in range(1,count):
        seed=labels==label
        if int(stats[label,cv2.CC_STAT_AREA])<min_pixels:
            continue
        height=float(np.nanmedian(h[seed]))
        if not config["target"]["min_core_height_mm"]<=height<=config["target"]["max_core_height_mm"]:
            continue
        color_core=cv2.erode(seed.astype(np.uint8),np.ones((3,3),np.uint8),iterations=2).astype(bool)
        colors=lab[color_core if np.any(color_core) else seed]
        center=np.median(colors,axis=0)
        radius=max(10.,1.5*float(np.percentile(np.linalg.norm(colors-center,axis=1),75)))
        target_distance=np.linalg.norm(lab-center,axis=2)
        same_color=target_distance<=radius
        if ground_distance is not None:
            same_color &= target_distance<ground_distance
        same_height=raw & (np.abs(h-height)<=float(config["plane"]["ransac_inlier_threshold_mm"]))
        allowed=(seed|(same_color&(missing|same_height)))&plane["roi_mask"]
        _,parts=cv2.connectedComponents(allowed.astype(np.uint8),connectivity=8)
        ids,hits=np.unique(parts[seed],return_counts=True)
        region=parts==int(ids[np.argmax(hits)])
        yy,xx=np.nonzero(region)
        max_side=int(config["component"]["max_bbox_side_px"])
        # Apply the existing object-size scope before union, so a background
        # fragment cannot connect all objects through a large depth-hole field.
        if len(xx) and (np.ptp(xx)+1>max_side or np.ptp(yy)+1>max_side):
            continue
        if np.count_nonzero(region)>np.count_nonzero(seed):
            merged|=region
            recovered|=region
    return merged.astype(np.uint8),recovered


def extract_candidates(depth_m, K, plane, roi_px, config, rgb=None, aggregate_depth_fragments=False):
    import cv2

    foreground_cfg = config["foreground"]
    component_cfg = config["component"]
    orientation_cfg = config["orientation"]
    target_cfg = config["target"]
    min_height_m = float(foreground_cfg["min_height_mm"]) / 1000.0
    max_height_m = float(foreground_cfg["max_height_mm"]) / 1000.0
    height_m = plane["signed_height_m"]
    foreground = (
        plane["roi_mask"]
        & plane["valid_mask"]
        & np.isfinite(height_m)
        & (height_m >= min_height_m)
        & (height_m <= max_height_m)
    ).astype(np.uint8)

    open_iterations = int(foreground_cfg.get("open_iterations", 0))
    if open_iterations > 0:
        foreground = cv2.morphologyEx(
            foreground,
            cv2.MORPH_OPEN,
            np.ones((3, 3), dtype=np.uint8),
            iterations=open_iterations,
        )

    measured_foreground=foreground.astype(bool)
    recovered_pixels=np.zeros_like(measured_foreground)
    if rgb is not None and aggregate_depth_fragments:
        foreground,recovered_pixels=color_supported_component_mask(
            rgb,depth_m,foreground,plane,config)
    count, labels, stats, centroids = cv2.connectedComponentsWithStats(
        foreground, connectivity=8
    )
    x0, y0, x1, y1 = roi_px
    border = int(component_cfg["reject_roi_border_px"])
    candidates = []
    for label in range(1, count):
        x, y, width, height, area = map(int, stats[label])
        contour_area = area
        if np.any(recovered_pixels & (labels==label)):
            area=int(np.count_nonzero((labels==label)&measured_foreground))
        bbox_area = max(1, width * height)
        aspect = max(width / max(1.0, height), height / max(1.0, width))
        fill_ratio = contour_area / float(bbox_area)
        reasons = []
        if area < int(component_cfg["min_area_px"]):
            reasons.append("area_below_minimum")
        if area > int(component_cfg["max_area_px"]):
            reasons.append("area_above_maximum")
        if min(width, height) < int(component_cfg["min_bbox_side_px"]):
            reasons.append("bbox_side_below_minimum")
        if max(width, height) > int(component_cfg["max_bbox_side_px"]):
            reasons.append("bbox_side_above_maximum")
        if aspect > float(component_cfg["max_aspect_ratio"]):
            reasons.append("aspect_ratio_too_large")
        if fill_ratio < float(component_cfg["min_fill_ratio"]):
            reasons.append("fill_ratio_too_low")
        if (
            x <= x0 + border
            or y <= y0 + border
            or x + width >= x1 - border
            or y + height >= y1 - border
        ):
            reasons.append("touches_workspace_roi_border")

        component_mask = (labels == label).astype(np.uint8)
        color_supported=bool(np.any(recovered_pixels & component_mask.astype(bool)))
        erode_px = adaptive_core_erode_px(width, height, component_cfg)
        if erode_px > 0:
            core_mask = cv2.erode(
                component_mask,
                np.ones((3, 3), dtype=np.uint8),
                iterations=erode_px,
            ).astype(bool)
        else:
            core_mask = component_mask.astype(bool)
        # Count real elevated depth samples, never RGB-filled missing pixels.
        core_mask &= measured_foreground
        core_pixels = int(np.count_nonzero(core_mask))
        if core_pixels < int(component_cfg["min_core_pixels"]):
            reasons.append("core_too_small_after_erosion")

        depth_region_mask, depth_region_corners_px = oriented_core_depth_region(
            component_mask,
            erode_px,
        )
        depth_region_pixels = int(np.count_nonzero(depth_region_mask))
        if depth_region_pixels == 0:
            core_depth_valid_ratio = 0.0
        else:
            core_depth = depth_m[depth_region_mask]
            core_depth_valid_ratio = float(
                np.mean(np.isfinite(core_depth) & (core_depth > 0.0))
            )
        depth_geometry_supported = color_supported and core_pixels >= int(orientation_cfg["min_points"])
        if (not depth_geometry_supported and core_depth_valid_ratio < float(
            component_cfg["min_core_depth_valid_ratio"]
        )):
            reasons.append("core_depth_valid_ratio_too_low")

        core_height_values = height_m[core_mask]
        core_height_values = core_height_values[np.isfinite(core_height_values)]
        if core_height_values.size:
            p10, median_height, p90 = np.percentile(
                core_height_values * 1000.0, [10.0, 50.0, 90.0]
            )
        else:
            p10 = median_height = p90 = float("nan")
            reasons.append("core_has_no_finite_height")
        if not math.isfinite(float(median_height)) or median_height < float(
            target_cfg["min_core_height_mm"]
        ):
            reasons.append("core_height_below_target_minimum")
        if math.isfinite(float(median_height)) and median_height > float(
            target_cfg["max_core_height_mm"]
        ):
            reasons.append("core_height_above_target_maximum")

        points = plane["points_image"][core_mask]
        points = points[np.isfinite(points).all(axis=1) & (points[:, 2] > 0.0)]
        if points.shape[0]:
            point_cam = np.median(points, axis=0)
        else:
            point_cam = np.array([np.nan, np.nan, np.nan])

        orientation_points = plane["points_image"][component_mask.astype(bool)]
        orientation_points = orientation_points[
            np.isfinite(orientation_points).all(axis=1)
            & (orientation_points[:, 2] > 0.0)
        ]
        contour_completion = None
        raw_orientation,raw_orientation_reasons=estimate_square_orientation(
            orientation_points,plane["normal"],orientation_cfg)
        if depth_geometry_supported and raw_orientation_reasons:
            yy,xx=np.nonzero(component_mask)
            rays=np.column_stack(((xx-K[0,2])/K[0,0],(yy-K[1,2])/K[1,1],np.ones(len(xx))))
            distance=(float(median_height)/1000-float(plane["offset_m"]))/(rays@np.asarray(plane["normal"]))
            orientation_points=rays*distance[:,None]
            point_cam=np.mean(orientation_points,axis=0)
            contour_completion={"source":"rgb_merged_depth_fragments_on_measured_top_plane",
                "original_depth_pixels":int(np.count_nonzero(component_mask.astype(bool)&measured_foreground)),
                "completed_contour_pixels":int(np.count_nonzero(component_mask)),
                "real_core_depth_samples":core_pixels,"depth_measurements_unchanged":True,
                "depth_quality_basis":"real_core_sample_count_and_measured_height"}
        orientation, orientation_reasons = estimate_square_orientation(
            orientation_points,
            plane["normal"],
            orientation_cfg,
        )
        if depth_geometry_supported and not raw_orientation_reasons:
            orientation,orientation_reasons=raw_orientation,raw_orientation_reasons
            contour_completion={"source":"rgb_grouped_real_depth_geometry",
                "real_core_depth_samples":core_pixels,"depth_measurements_unchanged":True,
                "depth_quality_basis":"real_core_sample_count_and_measured_height"}
        if rgb is not None and orientation_reasons and not reasons and math.isfinite(median_height):
            completed = complete_missing_depth_contour(rgb,depth_m,component_mask,
                core_mask,plane,K,float(median_height))
            if completed is not None:
                completed_orientation, completed_reasons = estimate_square_orientation(
                    completed["points"],plane["normal"],orientation_cfg)
                # Same original orientation standards apply to the recovered contour.
                if not completed_reasons:
                    yy,xx = np.nonzero(completed["mask"])
                    new_bbox = [int(xx.min()),int(yy.min()),int(np.ptp(xx)+1),int(np.ptp(yy)+1)]
                    if (new_bbox[2] <= int(component_cfg["max_bbox_side_px"])
                            and new_bbox[3] <= int(component_cfg["max_bbox_side_px"])
                            and completed["completed_contour_pixels"] <= int(component_cfg["max_area_px"])
                            and max(new_bbox[2]/new_bbox[3],new_bbox[3]/new_bbox[2]) <= float(component_cfg["max_aspect_ratio"])
                            and new_bbox[0] > x0+border and new_bbox[1] > y0+border
                            and new_bbox[0]+new_bbox[2] < x1-border
                            and new_bbox[1]+new_bbox[3] < y1-border):
                        orientation,orientation_reasons = completed_orientation,completed_reasons
                        point_cam = completed["center_cam_m"]
                        x,y,width,height = new_bbox
                        contour_completion = {k:v for k,v in completed.items()
                            if k not in {"mask","points","center_cam_m"}}
                        contour_completion["depth_measurements_unchanged"] = True
        reasons.extend(orientation_reasons)
        if orientation is not None and np.isfinite(point_cam).all():
            axis_length_m = min(orientation["rectangle_side_lengths_mm"]) / 1000.0
            orientation["axis_endpoints_px"] = (
                _project_orientation_axis_to_pixels(
                    point_cam,
                    orientation["axis_cam"],
                    axis_length_m,
                    K,
                )
            )

        center_u, center_v = map(float, centroids[label])
        if contour_completion is not None:
            center_u = float(K[0,0]*point_cam[0]/point_cam[2]+K[0,2])
            center_v = float(K[1,1]*point_cam[1]/point_cam[2]+K[1,2])
        center_depth = float(point_cam[2]) if np.isfinite(point_cam[2]) else 0.0
        approx_width_mm = width * center_depth / float(K[0, 0]) * 1000.0
        approx_height_mm = height * center_depth / float(K[1, 1]) * 1000.0
        candidate = {
            "component_id": int(label),
            "bbox_px": [x, y, width, height],
            "centroid_px": [center_u, center_v],
            "area_px": area,
            "contour_area_px": contour_area,
            "core_erode_px_used": erode_px,
            "core_pixels": core_pixels,
            "core_depth_region_method": "oriented_rectangle_inset",
            "core_depth_region_pixels": depth_region_pixels,
            "core_depth_region_corners_px": depth_region_corners_px,
            "aspect_ratio": float(aspect),
            "fill_ratio": float(fill_ratio),
            "core_depth_valid_ratio": core_depth_valid_ratio,
            "core_height_mm": {
                "p10": float(p10) if math.isfinite(float(p10)) else None,
                "median": (
                    float(median_height)
                    if math.isfinite(float(median_height))
                    else None
                ),
                "p90": float(p90) if math.isfinite(float(p90)) else None,
            },
            "surface_point_cam_m": [
                float(value) if math.isfinite(float(value)) else None
                for value in point_cam
            ],
            "orientation": orientation,
            "contour_completion": contour_completion,
            "approx_bbox_size_mm": [
                float(approx_width_mm),
                float(approx_height_mm),
            ],
            "reject_reasons": reasons,
        }
        if not reasons:
            score = _score_candidate(candidate, plane, config)
            if score < float(target_cfg["min_confidence_score"]):
                reasons.append("confidence_below_minimum")
        candidate["accepted"] = not reasons
        candidates.append(candidate)
    return foreground.astype(bool), candidates


def detect_from_arrays(rgb, depth_m, K, metadata, config, source="<memory>"):
    result = {
        "schema_version": 2,
        "detector": "table_plane_height_orientation_v3",
        "target_label": "science_target",
        "source": str(source),
        "depth_source": "raw_d455_temporal_median",
        "camera_frame_only": True,
        "control_ready": False,
        "provisional": True,
        "status": "INPUT_REJECTED",
        "reasons": [],
        "candidates": [],
        "accepted_targets": [],
        "selected": None,
    }
    if rgb.shape[:2] != depth_m.shape:
        raise ValueError("rgb and depth dimensions do not match")
    if bool(config["input"].get("require_capture_quality_pass", True)) and not bool(
        metadata.get("quality_pass", False)
    ):
        result["reasons"].append("source_capture_quality_not_passed")
        return result

    roi_px = normalized_roi(
        depth_m.shape, config["workspace_roi"]["normalized_xyxy"]
    )
    result["workspace_roi_px"] = list(roi_px)
    try:
        plane = fit_table_plane(depth_m, K, roi_px, config["plane"])
    except RuntimeError as error:
        result["status"] = "PLANE_REJECTED"
        result["reasons"].append(str(error))
        return result
    plane_ok, plane_reasons = evaluate_plane(plane, config["plane"])
    result["plane"] = {
        "normal_cam": [float(value) for value in plane["normal"]],
        "offset_m": float(plane["offset_m"]),
        "rmse_mm": float(plane["rmse_m"] * 1000.0),
        "inlier_ratio": float(plane["inlier_ratio"]),
        "tilt_deg": float(plane["tilt_deg"]),
        "sample_count": int(plane["sample_count"]),
        "quality_pass": bool(plane_ok),
        "quality_reasons": plane_reasons,
    }
    if not plane_ok:
        result["status"] = "PLANE_REJECTED"
        result["reasons"].extend(plane_reasons)
        return result

    foreground, candidates = extract_candidates(
        depth_m, K, plane, roi_px, config, rgb=rgb
    )
    if not any(c["accepted"] for c in candidates):
        foreground,candidates=extract_candidates(depth_m,K,plane,roi_px,config,
            rgb=rgb,aggregate_depth_fragments=True)
    if config["workspace_roi"].get("search_full_frame_on_miss", False) and not any(
        candidate["accepted"] for candidate in candidates
    ):
        # Keep the same fitted support plane and target criteria. Only the
        # segmentation mask expands when the normal observation ROI finds none.
        height, width = depth_m.shape
        search_roi = (0, 0, width, height)
        search_plane = {
            **plane,
            "roi_mask": np.ones(depth_m.shape, dtype=bool),
            "valid_mask": (
                np.isfinite(depth_m)
                & (depth_m >= float(config["plane"]["min_depth_m"]))
                & (depth_m <= float(config["plane"]["max_depth_m"]))
            ),
        }
        foreground, candidates = extract_candidates(
            depth_m, K, search_plane, search_roi, config, rgb=rgb
        )
        if not any(c["accepted"] for c in candidates):
            foreground,candidates=extract_candidates(depth_m,K,search_plane,search_roi,config,
                rgb=rgb,aggregate_depth_fragments=True)
        result["candidate_search_roi_px"] = list(search_roi)
    result["foreground_pixel_count"] = int(np.count_nonzero(foreground))
    result["candidates"] = candidates
    accepted = sorted(
        (candidate for candidate in candidates if candidate["accepted"]),
        key=lambda candidate: int(candidate["component_id"]),
    )
    accepted_targets = []
    for candidate in accepted:
        target = dict(candidate)
        target["label"] = "science_target"
        target["target_id"] = f"component_{int(candidate['component_id']):03d}"
        accepted_targets.append(target)
    result["accepted_targets"] = accepted_targets
    result["accepted_candidate_count"] = len(accepted_targets)
    if len(accepted_targets) == 0:
        result["status"] = "NO_TARGET"
        result["reasons"].append("no_candidate_passed_all_gates")
    elif len(accepted_targets) > 1:
        result["status"] = "MULTIPLE_TARGETS_CAMERA_FRAME_ONLY"
    else:
        result["selected"] = dict(accepted_targets[0])
        result["status"] = "DETECTED_CAMERA_FRAME_ONLY"
    return result


def detect_capture(capture, config):
    return detect_from_arrays(
        capture["rgb"],
        capture["depth_m"],
        capture["K"],
        capture["metadata"],
        config,
        source=capture["path"],
    )


def save_result(result, output_path):
    output_path = Path(output_path).expanduser().resolve()
    if output_path.suffix.lower() != ".json":
        raise ValueError("--out must end in .json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        ) + "\n",
        encoding="utf-8",
    )
    return output_path


def save_preview(rgb, result, output_path):
    import cv2

    output_path = Path(output_path).expanduser().resolve()
    if output_path.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
        raise ValueError("--preview must end in .png/.jpg/.jpeg")
    canvas = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    if "workspace_roi_px" in result:
        x0, y0, x1, y1 = result["workspace_roi_px"]
        cv2.rectangle(canvas, (x0, y0), (x1 - 1, y1 - 1), (255, 180, 0), 2)
    for candidate in result.get("candidates", []):
        x, y, width, height = candidate["bbox_px"]
        color = (0, 220, 0) if candidate["accepted"] else (0, 0, 220)
        cv2.rectangle(canvas, (x, y), (x + width - 1, y + height - 1), color, 2)
        cv2.putText(
            canvas,
            f"{candidate['component_id']}:{candidate.get('confidence_score', 0.0):.2f}",
            (x, max(14, y - 5)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            color,
            1,
            cv2.LINE_AA,
        )
        orientation = candidate.get("orientation")
        if isinstance(orientation, dict):
            endpoints = orientation.get("axis_endpoints_px")
            if isinstance(endpoints, list) and len(endpoints) == 2:
                start = tuple(int(round(value)) for value in endpoints[0])
                end = tuple(int(round(value)) for value in endpoints[1])
                cv2.line(canvas, start, end, (255, 0, 255), 2, cv2.LINE_AA)
        core_corners = candidate.get("core_depth_region_corners_px")
        if isinstance(core_corners, list) and len(core_corners) == 4:
            polygon = np.rint(np.asarray(core_corners, dtype=float)).astype(
                np.int32
            )
            cv2.polylines(
                canvas,
                [polygon],
                True,
                (0, 255, 255),
                1,
                cv2.LINE_AA,
            )
    cv2.putText(
        canvas,
        result["status"],
        (12, 24),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (0, 255, 255),
        2,
        cv2.LINE_AA,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(output_path), canvas):
        raise RuntimeError(f"failed to save preview: {output_path}")
    return output_path


def build_parser():
    parser = argparse.ArgumentParser(
        description=(
            "离线检测一个science_target；只输出相机坐标诊断，绝不控制S1机械臂"
        )
    )
    parser.add_argument("--npz", required=True, help="capture_rgbd.py生成的输入")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--out", required=True, help="显式指定检测JSON输出")
    parser.add_argument("--preview", default=None, help="可选标注预览图")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    config, config_path = load_config(args.config)
    capture = load_capture(args.npz)
    result = detect_capture(capture, config)
    result["config_path"] = str(config_path)
    output_path = save_result(result, args.out)
    print(f"DETECTION_SAVED = {output_path}")
    if args.preview:
        preview_path = save_preview(capture["rgb"], result, args.preview)
        print(f"PREVIEW_SAVED = {preview_path}")
    print(f"STATUS = {result['status']}")
    print(f"CONTROL_READY = {result['control_ready']}")
    if result.get("plane"):
        print(f"PLANE_RMSE_MM = {result['plane']['rmse_mm']:.3f}")
        print(f"PLANE_INLIER_RATIO = {result['plane']['inlier_ratio']:.4f}")
    print(f"ACCEPTED_CANDIDATES = {result.get('accepted_candidate_count', 0)}")
    if result.get("selected"):
        target = result["selected"]
        print(f"TARGET_CONFIDENCE = {target['confidence_score']:.3f}")
        print(
            "TARGET_SURFACE_POINT_CAM_M = "
            + ",".join(f"{value:.6f}" for value in target["surface_point_cam_m"])
        )
        print(
            f"TARGET_CORE_HEIGHT_MM = {target['core_height_mm']['median']:.2f}"
        )
        print("SCIENCE_TARGET_DETECTED_CAMERA_FRAME_ONLY")
        return 0
    accepted_targets = result.get("accepted_targets", [])
    if accepted_targets:
        for target in accepted_targets:
            print(
                "TARGET_CANDIDATE =",
                target["target_id"],
                f"confidence={target['confidence_score']:.3f}",
                "surface_cam_m="
                + ",".join(
                    f"{value:.6f}"
                    for value in target["surface_point_cam_m"]
                ),
            )
        print("MULTIPLE_SCIENCE_TARGETS_DETECTED_CAMERA_FRAME_ONLY")
        return 0
    for reason in result["reasons"]:
        print(f"DETECTION_REJECT = {reason}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
