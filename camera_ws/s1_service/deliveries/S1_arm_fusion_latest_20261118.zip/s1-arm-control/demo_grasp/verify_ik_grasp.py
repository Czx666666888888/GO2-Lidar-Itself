# -*- coding: utf-8 -*-
"""S1-side reachability check for graspness cap grasps. Pure kinematics via
S1_solver -- NO S1_arm, NO serial, NO power, NO display.

Convention (confirmed 2026-07-24): S1 TCP frame col0 = approach (+X_tool, into
object), col1 = Y_tool = finger closing. graspnet R_g: col0 = approach, col1 =
closing. So target R_tcp = R_base directly (antipodal symmetry -> also try the
180-deg roll about approach). New TCP = [164.4, 0.5, -8.9] mm.

    conda activate S1
    python verify_ik_grasp.py --cand cap_grasp_report_cap_candidates.npy
"""
import argparse
import os
import contextlib
import numpy as np
from S1_SDK import S1_solver


@contextlib.contextmanager
def hush():
    """Silence the SDK's C-level '逆解失败' prints on fd 1/2."""
    save1, save2 = os.dup(1), os.dup(2)
    devnull = os.open(os.devnull, os.O_WRONLY)
    os.dup2(devnull, 1); os.dup2(devnull, 2)
    try:
        yield
    finally:
        os.dup2(save1, 1); os.dup2(save2, 2)
        os.close(devnull); os.close(save1); os.close(save2)

# TCP 从本仓标定文件读（不硬编，随重标自动更新；见 calibration/tcp.json 的 provisional 说明）。
def _load_new_tcp():
    import json, pathlib
    f = pathlib.Path(__file__).resolve().parents[1] / 'calibration' / 'tcp.json'
    try:
        v = [float(x) for x in json.loads(f.read_text(encoding='utf-8'))['value_m']]
        print(f'[verify_ik] TCP 读自 {f} = {v} (★provisional★)')
        return v
    except Exception as e:
        fallback = [0.1644, 0.0005, -0.0089]
        print(f'[verify_ik] !! 读 tcp.json 失败({e})，回退硬编 {fallback}')
        return fallback
NEW_TCP = _load_new_tcp()
OLD_TCP = [0.1701999990716822, -0.00879999762574336, -0.013600006856725456]
# JOINT_LIMITS (rad) from scripts/win_prototype/s1_hold_position.py
JL = [(np.radians(-170), np.radians(170)), (np.radians(0), np.radians(180)),
      (np.radians(0), np.radians(170)), (np.radians(-90), np.radians(87)),
      (np.radians(-90), np.radians(90)), (np.radians(-90), np.radians(90))]
READY = [0.0, 0.19, 0.38, 0.20, 0.0, 0.0]
# top-down anchor pose (data/s1_validate_touch.json v1)
Q_MED = [0.03948211669921875, 1.7896919250488281, 1.2861442565917969,
         0.9973678588867188, -0.034523963928222656, -0.08983802795410156]
TCP_FK = [0.29209211468696594, 0.008467626757919788, 0.021126849576830864,
          -0.034508153796195984, 0.6800686717033386, 0.05765288323163986, 0.7300629615783691]


def R_to_quat(R):
    """3x3 rotation -> quaternion xyzw."""
    t = np.trace(R)
    if t > 0:
        s = np.sqrt(t + 1.0) * 2
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        w = (R[2, 1] - R[1, 2]) / s; x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s; z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        w = (R[0, 2] - R[2, 0]) / s; x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s; z = (R[1, 2] + R[2, 1]) / s
    else:
        s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        w = (R[1, 0] - R[0, 1]) / s; x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s; z = 0.25 * s
    q = np.array([x, y, z, w]); return q / np.linalg.norm(q)


def quat_to_R(q):
    x, y, z, w = q / np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                     [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                     [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def within_limits(q):
    return all(JL[i][0] - 1e-3 <= q[i] <= JL[i][1] + 1e-3 for i in range(6))


def try_ik(solver, pos_xyz, R_tcp, seeds):
    """Return (q, pose_err_mm, ori_err_deg, orient_tag) for first valid IK, else None."""
    best = None
    for tag, Rt in (("as-is", R_tcp), ("roll180", R_tcp @ np.diag([1.0, -1.0, -1.0]))):
        q_target = R_to_quat(Rt)
        pose = list(pos_xyz) + list(q_target)
        for seed in seeds:
            sol = solver.inverse_quat(pose, list(seed))
            if not sol:
                continue
            sol = [float(v) for v in sol]
            fk = solver.forward_quat(sol)
            perr = np.linalg.norm(np.array(fk[:3]) - np.array(pos_xyz)) * 1000
            Rf = quat_to_R(np.array(fk[3:]))
            oerr = np.degrees(np.arccos(np.clip((np.trace(Rf.T @ Rt) - 1) / 2, -1, 1)))
            ok = within_limits(sol) and perr < 3.0 and oerr < 5.0
            cand = (sol, perr, oerr, tag, ok)
            if ok:
                return cand
            if best is None or perr < best[1]:
                best = cand
    return best  # may be a non-ok best-effort, or None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cand", required=True, help="*_cap_candidates.npy from infer_cap_grasp")
    ap.add_argument("--topn", type=int, default=12)
    ap.add_argument("--min-tilt", dest="min_tilt", type=float, default=45.0,
                    help="pick best reachable grasp with approach tilt >= this (deg); 45+=horizontal/side")
    ap.add_argument("--standoff", type=float, default=0.06, help="pre-grasp back-off along -approach (m)")
    ap.add_argument("--max-closing-tilt", dest="max_closing_tilt", type=float, default=20.0,
                    help="require grasp closing axis within this many deg of horizontal (cap = vertical cylinder)")
    cfgs = ap.parse_args()

    # ---- anchor self-check (validates convention + solver) ----
    sv_old = S1_solver(OLD_TCP)
    fk = sv_old.forward_quat(Q_MED)
    perr = np.linalg.norm(np.array(fk[:3]) - np.array(TCP_FK[:3])) * 1000
    ik = sv_old.inverse_quat(list(TCP_FK), list(Q_MED))
    qerr = max(abs(a - b) for a, b in zip(ik, Q_MED)) if ik else 9.99
    print(f"[anchor] FK(q_med,oldTCP) pos err = {perr:.2f} mm   "
          f"IK(tcp_fk)->q err = {qerr:.4f} rad  {'OK' if perr<3 and qerr<0.02 else 'CHECK!'}",
          flush=True)

    # rich seed set: structured top-down/region seeds + random within limits,
    # so a single local-IK miss is not mistaken for "unreachable"
    global SEEDS
    rng = np.random.RandomState(0)
    SEEDS = [Q_MED, READY, [0, 1.2, 0.9, -0.7, 0, 0], [0.04, 1.79, 1.29, 0.99, 0, 0],
             [0, 1.4, 0.6, -0.7, 0, 0], [0, 0.9, 1.4, -0.3, 0, 0]]
    for _ in range(60):
        SEEDS.append([float(rng.uniform(lo, hi)) for lo, hi in JL])

    # ---- cap candidates: sweep ALL, bin by approach tilt ----
    sv = S1_solver(NEW_TCP)
    cand = np.load(cfgs.cand)
    print(f"\n{len(cand)} cap candidates; new TCP {NEW_TCP}; {len(SEEDS)} seeds each")
    rows = []   # (tilt, reachable, score, width, sol, tag, pos, R)
    with hush():
        for row in cand:
            score, width = row[0], row[1]
            pos = row[2:5]
            R = row[5:14].reshape(3, 3)
            approach = R[:, 0] / np.linalg.norm(R[:, 0])
            tilt = np.degrees(np.arccos(np.clip(-approach[2], -1, 1)))
            res = try_ik(sv, pos, R, seeds=SEEDS)
            reach = bool(res and res[4])
            rows.append((tilt, reach, float(score), float(width),
                         res[0] if res else None, res[3] if res else '-', pos, R))
    tilts = np.array([r[0] for r in rows])
    reach = np.array([r[1] for r in rows])
    print("\n[tilt bins]  (0deg=straight-down top-down, 90deg=horizontal/side)")
    print("  band        n   reachable")
    for lo, hi in [(0, 20), (20, 45), (45, 70), (70, 91)]:
        m = (tilts >= lo) & (tilts < hi)
        print(f"  {lo:2d}-{hi:2d}deg   {int(m.sum()):3d}   {int(reach[m].sum()):3d}")
    print(f"  TOTAL      {len(rows):3d}   {int(reach.sum()):3d}")

    def show(title, sel):
        idx = [i for i in np.argsort([-rows[i][2] for i in range(len(rows))]) if sel(rows[i])][:6]
        print(f"\n{title}: {sum(1 for r in rows if sel(r))} reachable")
        for i in idx:
            t, rc, sc, w, sol, tag = rows[i][:6]
            deg = [round(float(np.degrees(v)), 1) for v in sol] if sol else None
            print(f"  score {sc:.3f}  width {w*1000:5.1f}mm  tilt {t:5.1f}  {tag:7} joints_deg {deg}")
    show("Reachable top-down-ish (tilt<45)", lambda r: r[1] and r[0] < 45)
    show("Reachable horizontal/side (tilt>=45)", lambda r: r[1] and r[0] >= 45)

    # closing-axis horizontality: for a vertical cap cylinder a good grasp
    # closes the fingers HORIZONTALLY across the cap (Y_tool ~ in xy-plane).
    def closing_horiz_deg(R):
        return abs(np.degrees(np.arcsin(np.clip(R[:, 1][2], -1, 1))))
    print("\n[closing-axis horizontality among REACHABLE] (0=horizontal across cap, good)")
    for lo, hi in [(0, 15), (15, 30), (30, 50), (50, 91)]:
        c = [r for r in rows if r[1] and lo <= closing_horiz_deg(r[7]) < hi]
        print(f"  closing {lo:2d}-{hi:2d}deg off-horizontal : {len(c):3d} reachable")

    # ---- best reachable grasp that is BOTH IK-reachable AND closes near
    #      horizontal (<= --max-closing-tilt); emit grasp-q + STANDOFF-q ----
    band = [r for r in rows if r[1] and closing_horiz_deg(r[7]) <= cfgs.max_closing_tilt]
    if not band:
        print(f"\nno reachable grasp with closing within {cfgs.max_closing_tilt} of horizontal "
              f"(graspness may lack a clean cap grasp -> consider analytic)"); return
    best = max(band, key=lambda r: r[2])
    tilt, _, score, width, grasp_q, tag, pos, R = best
    approach = R[:, 0] / np.linalg.norm(R[:, 0])       # into object
    standoff_pos = np.asarray(pos) - approach * cfgs.standoff
    with hush():
        so = try_ik(sv, standoff_pos, R, seeds=[grasp_q] + SEEDS)
    print(f"\n=== BEST reachable grasp (closing within {cfgs.max_closing_tilt} of horizontal) ===")
    print(f"score {score:.3f} width {width*1000:.1f}mm  approach-tilt-from-vert {tilt:.1f}  "
          f"closing-off-horizontal {closing_horiz_deg(R):.1f}  orient {tag}")
    print(f"grasp pos base mm   = {[round(float(v*1000),1) for v in pos]}")
    print(f"approach (into obj) = {[round(float(v),3) for v in approach]}")
    print(f"closing  (Y_tool)   = {[round(float(v),3) for v in R[:,1]]}")
    print(f"GRASP  target-q (rad,CSV) = {','.join(f'{v:.4f}' for v in grasp_q)}")
    if so and so[4]:
        sq = so[0]
        print(f"STANDOFF {cfgs.standoff*1000:.0f}mm back:")
        print(f"  pos base mm = {[round(float(v*1000),1) for v in standoff_pos]}")
        print(f"  STANDOFF target-q (rad,CSV) = {','.join(f'{v:.4f}' for v in sq)}")
        print(f"  --> hover check: python scripts/s1_goto_hold_diag.py --target-q={','.join(f'{v:.4f}' for v in sq)}")
    else:
        print(f"STANDOFF {cfgs.standoff*1000:.0f}mm not IK-reachable; try smaller --standoff")


if __name__ == "__main__":
    main()
