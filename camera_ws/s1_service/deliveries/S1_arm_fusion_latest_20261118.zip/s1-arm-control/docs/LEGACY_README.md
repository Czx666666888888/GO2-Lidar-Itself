# s1-arm-control

单独控制 Theseus S1 六轴机械臂（+ 平行夹爪 ID7 + D455 相机）的独立项目。
从 `industrial-agent` 抽取**当前正确的控制方案**而来，丢弃了 win 原型残留、多轮标定弯路、错误诊断脚本等中间过程。

## 定位与分层

```
s1_control/    ★核心控制库：纯 S1_SDK，自包含、可移植，不碰相机/串口/graspness
  ├ calib.py       读 calibration/ 与 config/，加载时打印 provisional 提示
  ├ kinematics.py  FK/IK（S1_solver + TCP），多种子稳健逆解
  ├ arm.py         构造/enable/50Hz 斜坡 move/安全闸/disable
  └ gripper.py     夹爪 mm↔fb 映射、command_mm、接触判据
scripts/       核心工装（只依赖 s1_control）
  ├ goto_hold.py         走位保持诊断（供尺子/肉眼核对）
  └ grip_lift_place.py   通用目标抓-提-放回；默认真正离线，--execute 才连接实机
calibration/   ★标定成果随仓入库（provisional，见该目录 README）
config/        夹爪标定 + cap31/cube50 目标参数档案
demo_grasp/    ★可选抓取 demo：依赖 graspness 重环境，与 core 解耦（见该目录 README）
```

**红线**：`s1_control` + `scripts` + `calibration` + `config` 完全自包含，只依赖机器级基础设施
（conda 环境 `S1`、`S1_SDK`、numpy）。`demo_grasp` 是单独一层，依赖重环境，core 不因它背负依赖。

## 快速上手（S1 conda 环境）

```bash
conda activate S1                      # S1_SDK 已可编辑安装于此环境
# 离线自检（不通电）：
python -c "import s1_control"          # 应不拉入 pyrealsense2/cv2/serial
python scripts/goto_hold.py --ready-only     # 预检，打印 FK + provisional
# 通电（★必须有人看护，手在断电开关上★）：
python scripts/goto_hold.py --ready-only --execute
```

## 50 mm 方块抓取 MVP

方块抓取不覆盖原瓶盖流程：`cap31` 保留为回归基线，`cube50` 是独立目标档案。
当前实施顺序与验收门见 [`docs/cube_grasp_mvp.md`](docs/cube_grasp_mvp.md)。

```bash
# 0. 纯离线生成与当前计划SHA-256绑定的全路径碰撞报告
python scripts/check_cube_hover_path.py \
  --plan data/plans/cube50_hover_plan.json \
  --step-rad 0.02 \
  --min-joint-margin-deg 10 \
  --min-tcp-z-mm 60 \
  --output data/plans/cube50_hover_collision_report.json \
  --overwrite

# 1. 真正离线：验证计划/报告绑定，不构造 Arm、不访问串口、不改变使能状态
python scripts/grip_lift_place.py \
  --target-profile cube50 \
  --plan data/plans/cube50_hover_plan.json \
  --collision-report data/plans/cube50_hover_collision_report.json \
  --hover-only

# 2. 只有在路径已通过全路径碰撞检查后，才进行有人看护的空载悬停往返
python scripts/grip_lift_place.py \
  --target-profile cube50 \
  --plan data/plans/cube50_hover_plan.json \
  --collision-report data/plans/cube50_hover_collision_report.json \
  --hover-only \
  --execute

# 3. 基于已验证的80 mm悬停计划，纯离线追加60 mm grasp路点
python scripts/plan_cube_hover.py \
  --base-plan data/plans/cube50_hover_plan.json \
  --target-z-mm 60 \
  --output data/plans/cube50_grasp_plan.json \
  --overwrite

# 4. 对包含grasp的完整路线重新生成独立碰撞报告
python scripts/check_cube_hover_path.py \
  --plan data/plans/cube50_grasp_plan.json \
  --step-rad 0.02 \
  --min-joint-margin-deg 10 \
  --min-tcp-z-mm 60 \
  --output data/plans/cube50_grasp_collision_report.json \
  --overwrite

# 5. 首次实物测试：只下降、合爪判定、张开撤回，绝不提升
python scripts/grip_lift_place.py \
  --target-profile cube50 \
  --plan data/plans/cube50_grasp_plan.json \
  --collision-report data/plans/cube50_grasp_collision_report.json \
  --contact-only \
  --execute

# 6. 只有接触判据重复验证后，才允许去掉--contact-only进行20 mm提升
python scripts/grip_lift_place.py \
  --target-profile cube50 \
  --plan data/plans/cube50_grasp_plan.json \
  --collision-report data/plans/cube50_grasp_collision_report.json \
  --execute
```

`--plan` 与三个 `--*-q` 参数互斥，避免同一次执行出现两套路点来源。当前正式
支持 `ready -> [midpoint/approach] -> hover/standoff -> [descent_01...]
-> grasp`。动态视觉流程会把高位预对准到抓取点均分为不超过 15 mm 的下降段，
这些点继续用于 IK、关节余量和逐点碰撞检查；执行下降、提升、放回和异常撤回时，
整条升降路径只运行一次全局 S 曲线，中间检查点不再将速度降到零。各阶段仍严格
复用同一组路点；名称断号或其他复杂路径
会明确拒绝，绝不会静默丢弃中间点。

视觉目标包含三维台面内的方块边缘轴。规划器按正方形90°对称性和夹爪180°
对称性评估四组top-down姿态，按全局/J6限速估算运动时间并优先选择更短的有效IK解；hover之后
全部下降路点锁定同一旋转矩阵，避免接近目标后转腕。

单目标随机尺寸、位置和角度抓取通过后，多目标第一阶段采用严格离线流程：每个连通域
独立绑定中心、深度、高度、方向和置信度，分别做基座变换、IK与碰撞检查，再按预计
运动时间选择目标。用法与安全边界见
[`docs/multi_target_grasp_offline.md`](docs/multi_target_grasp_offline.md)。

实机 `--execute` 强制要求 `--plan`，并要求碰撞报告为新版格式、通过安全阈值检查，
且记录的计划 SHA-256 与本次计划逐字节一致。计划发生任何改动后，旧报告都会被拒绝，
必须重新运行离线全路径检查。实机阶段不运行 MuJoCo，避免仿真步进干扰串口控制周期。

`cube50` 的 65 mm 预张开已做空载验证，但闭合量、接触阈值和低力矩仍是
provisional。必须先测量打印方块实际宽度，并完成“空夹3次 + 实物夹持3次”对照，
再允许接入自主视觉执行。

## 安全（务必遵守）

- **通电全程有人看护**，手在断电开关上；异常/异响/扎向桌面立即断电。脚本 `finally` 均 `disable()` 兜底。
- 执行脚本连接实机前，电机必须已常红且机械臂有可靠软支撑；不要在电机绿色保持时运行会构造 `Arm` 的诊断代码。
- **安全闸阈值是可调工作值，不是死线**——为适配新工况就该调（见 `s1_control/arm.py` 顶部“两类阈值”说明）。
- **标定值是暂时的**——绑定 2026-07 物理摆放，相机移动/换末端即作废（见 `calibration/README.md`）。
- 抓取执行是**一次连续通电会话**，中途不断电（与标定期“每采样点断电”不同）。
- SDK 打印任一批 `motor timeout` 时，不以“动作看起来正常”为继续自主测试的依据；VM结果只作为功能验证，Orin仍需重新做通信压力测试。
- SDK目前没有提供可由Python读取的底层timeout计数，所以3秒数值稳定性检查不能证明“没有timeout”。只有本次连接后终端完全没有出现 `motor timeout`，才可输入当前项目约定的小写 `no`；否则取消，不使能。

## 依赖

见 `environment/S1_environment.md`。核心：conda `S1` 环境 + `S1_SDK`（`~/thirdparty/S1_SDK_V2-official`，可编辑安装）+ numpy + pyyaml。相机/demo 另见各自 README。
