#!/usr/bin/env python3
"""Deploy from S1 zero and run a bounded wrist-camera commissioning stage.

The selected configuration determines whether the run stops after alignment,
performs a no-contact descent, or verifies adaptive contact without lifting.
Every mode returns over its checked outbound path and disables in ``finally``.
"""
from __future__ import annotations

import argparse
from dataclasses import replace
from datetime import datetime
import json
import math
import multiprocessing
from pathlib import Path
import re
import statistics
import sys
import threading
import time
import traceback

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = Path(__file__).resolve().parent
SDK_SOURCE = Path.home() / "thirdparty" / "S1_SDK_V2-official" / "src"
for import_path in (PROJECT_ROOT, SCRIPTS_DIR, SDK_SOURCE):
    if import_path.is_dir() and str(import_path) not in sys.path:
        sys.path.insert(0, str(import_path))

from demo_grasp.capture_rgbd import capture_aligned_rgbd, save_capture
from demo_grasp.detect_science_target_rgbd import (
    detect_capture,
    load_config as load_vision_config,
    save_preview,
    save_result,
)
from execute_go2_observe_deployment import (
    guarded_hold,
    planned_phases,
    ramp_compensation_scale,
    wait_for_valid_feedback,
    write_json,
)
from execute_go2_fixed_funnel_box_empty_route import (
    mount_record_with_lower_route_scale,
    validate_route_shape,
    verify_box_artifacts,
)
from grip_lift_place import run_adaptive_acquisition
from gripper_contact_probe import BenchRunner
from s1_control.adaptive_grasp import EmptyProbeBaseline, load_empty_baseline, load_probe_parameters
from s1_control.arm import Arm, SafetyLimits
from s1_control.command_continuity import (
    CommandTrace, continuous_command_path, offset_command_path,
)
from s1_control.feedback_path import move_feedback_synchronized
from s1_control.go2_deployment import (
    file_sha256,
    load_deployment_config,
    max_joint_delta,
    start_window_violations,
    verify_bound_report,
)
from s1_control.go2_visual_alignment import (
    blended_support_up_normal,
    build_fixed_position_orientation_path,
    build_tangent_tcp_path,
    densify_joint_path,
    joint_margin_deg,
    quaternion_error_deg,
    quaternion_slerp,
    rotation_matrix_to_quaternion,
    solve_continuous_ik_path,
    square_grasp_orientation_candidates,
    validate_workspace_point,
    validate_torque_envelope,
)
from s1_control.kinematics import Kinematics
from s1_control.gripper import Gripper
from s1_control.tilt_gravity import (
    UrdfGravityModel,
    differential_tilt_compensation_from_support_up,
    locate_official_gripper_urdf,
)
from s1_control.tilt_motion import commander_from_mount_record
from s1_control.wrist_visual_servo import (
    JOINT_LIMITS_RAD,
    dynamic_base_camera,
    extract_single_surface_observation,
    load_wrist_servo_config,
)


DEFAULT_CONFIG = PROJECT_ROOT / "config" / "go2_crouch_right_visual_alignment.json"
DEFAULT_OUTPUT_ROOT = PROJECT_ROOT / "data" / "go2_visual_alignment_runs"
RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
GO2_CAPTURE_QUALITY_SCOPE = "go2_visual_alignment_vm_usb_only"
GO2_GEOMETRY_QUALITY_SCOPE = "go2_visual_alignment_go2_crouch_right_only"


def commissioning_vector(raw, size, label):
    """Return one finite commissioning vector without relying on arm helpers."""
    value = np.asarray(raw, dtype=float)
    if value.shape != (size,) or not np.all(np.isfinite(value)):
        raise ValueError(f"{label} must contain {size} finite values")
    return value


def load_workspace_commissioning_point(
    scan_raw,
    *,
    requested_u_mm,
    requested_v_mm,
    tolerance_mm,
    active_config_path,
    active_config,
    plan_path,
    wrist_path,
    loaded_workspace,
):
    """Authorize one scanned high-view point for an alignment-only run.

    This deliberately does not promote the offline scan to validated evidence.
    It only creates a bounded runtime scope around one explicitly requested
    point, while retaining all live vision, IK, collision, torque and endpoint
    checks.  Descent and gripper operations are forbidden in this mode.
    """
    scan_path = resolve_project_path(scan_raw)
    scan = json.loads(scan_path.read_text(encoding="utf-8"))
    if scan.get("mode") != "go2_right_ground_grasp_workspace_offline_scan":
        raise ValueError("commissioning workspace scan mode is incompatible")
    if scan.get("status") != (
        "offline_candidate_only_pending_staged_physical_validation"
    ):
        raise ValueError("commissioning workspace scan status is incompatible")
    if scan.get("arm_serial_access") is not False or scan.get("camera_access") is not False:
        raise ValueError("commissioning evidence must come from an offline-only scan")
    baseline = scan.get("baseline", {})
    if str(baseline.get("plan_sha256", "")).lower() != file_sha256(plan_path):
        raise RuntimeError("commissioning scan uses a different deployment plan")
    if str(baseline.get("wrist_config_sha256", "")).lower() != file_sha256(wrist_path):
        raise RuntimeError("commissioning scan uses a different wrist config")

    baseline_flow_path = resolve_project_path(baseline.get("config", ""))
    if str(baseline.get("config_sha256", "")).lower() != file_sha256(
        baseline_flow_path
    ):
        raise RuntimeError("commissioning scan baseline flow config has changed")
    baseline_flow = json.loads(baseline_flow_path.read_text(encoding="utf-8"))
    baseline_base = baseline_flow.get("base_alignment_config", {})
    baseline_base_path = resolve_project_path(baseline_base.get("path", ""))
    baseline_base_sha = str(baseline_base.get("sha256", "")).lower()
    if file_sha256(baseline_base_path) != baseline_base_sha:
        raise RuntimeError("commissioning scan base alignment config has changed")
    active_base = active_config.get("base_alignment_config")
    active_uses_baseline = active_config_path == baseline_base_path
    if isinstance(active_base, dict):
        active_uses_baseline = active_uses_baseline or (
            resolve_project_path(active_base.get("path", "")) == baseline_base_path
            and str(active_base.get("sha256", "")).lower() == baseline_base_sha
        )
    if not active_uses_baseline:
        raise RuntimeError("active config is not derived from the scanned alignment base")

    values = (requested_u_mm, requested_v_mm, tolerance_mm)
    if not all(math.isfinite(float(value)) for value in values):
        raise ValueError("commissioning point and tolerance must be finite")
    if not 3.0 <= float(tolerance_mm) <= 15.0:
        raise ValueError("commissioning point tolerance must be within [3, 15]mm")
    selected = None
    for point in scan.get("points", []):
        if (
            math.isclose(float(point.get("u_offset_mm", float("nan"))), float(requested_u_mm), abs_tol=1e-6)
            and math.isclose(float(point.get("v_offset_mm", float("nan"))), float(requested_v_mm), abs_tol=1e-6)
        ):
            selected = point
            break
    if selected is None:
        raise ValueError("requested commissioning point is not present in the scan")
    if selected.get("high_alignment_pass") is not True:
        raise ValueError("requested commissioning point failed offline high alignment")
    fixed_observation = selected.get("fixed_observation", {})
    if fixed_observation.get("fixed_observation_visible") is not True:
        raise ValueError("requested point is outside the fixed observation visibility gate")

    workspace = json.loads(json.dumps(loaded_workspace))
    baseline_high = commissioning_vector(
        baseline.get("high_tcp_base_xyz_mm"), 3, "baseline high TCP"
    )
    candidate_high = commissioning_vector(
        selected.get("high_tcp_base_xyz_mm"), 3, "candidate high TCP"
    )
    margin = float(tolerance_mm)
    workspace["tcp_base_x_mm"] = [
        float(
            min(
                float(workspace["tcp_base_x_mm"][0]),
                baseline_high[0] - margin,
                candidate_high[0] - margin,
            )
        ),
        float(
            max(
                float(workspace["tcp_base_x_mm"][1]),
                baseline_high[0] + margin,
                candidate_high[0] + margin,
            )
        ),
    ]
    workspace["tcp_base_y_mm"] = [
        float(
            min(
                float(workspace["tcp_base_y_mm"][0]),
                baseline_high[1] - margin,
                candidate_high[1] - margin,
            )
        ),
        float(
            max(
                float(workspace["tcp_base_y_mm"][1]),
                baseline_high[1] + margin,
                candidate_high[1] + margin,
            )
        ),
    ]
    clearance = float(baseline["normal_clearance_mm"])
    workspace["normal_clearance_mm"] = [
        min(float(workspace["normal_clearance_mm"][0]), clearance - margin),
        max(float(workspace["normal_clearance_mm"][1]), clearance + margin),
    ]
    maximum_initial_tangent_error_mm = max(
        40.0,
        math.hypot(float(requested_u_mm), float(requested_v_mm)) + margin,
    )
    return {
        "status": "single_offline_point_pending_alignment_only_validation",
        "scan_path": str(scan_path),
        "scan_sha256": file_sha256(scan_path),
        "requested_u_mm": float(requested_u_mm),
        "requested_v_mm": float(requested_v_mm),
        "tolerance_mm": margin,
        "baseline_target_top_base_xyz_mm": list(
            baseline["target_top_base_xyz_mm"]
        ),
        "support_plane_frame": scan["support_plane_frame"],
        "selected_scan_point": selected,
        "runtime_workspace_override": workspace,
        "maximum_initial_tangent_error_mm": maximum_initial_tangent_error_mm,
        "restrictions": [
            "alignment_only",
            "no_orientation_change",
            "no_descent",
            "no_gripper_close",
            "no_lift",
            "no_box_place",
        ],
    }


def validate_workspace_commissioning_observation(observation, commissioning):
    target = commissioning_vector(
        observation.get("surface_point_base_m"), 3, "observed target surface"
    )
    baseline = commissioning_vector(
        commissioning["baseline_target_top_base_xyz_mm"],
        3,
        "commissioning baseline target",
    ) / 1000.0
    frame = commissioning["support_plane_frame"]
    axis_u = commissioning_vector(frame["axis_u_base"], 3, "support axis u")
    axis_v = commissioning_vector(frame["axis_v_base"], 3, "support axis v")
    support_up = commissioning_vector(
        frame["support_up_normal_base"], 3, "support up normal"
    )
    delta = 1000.0 * (target - baseline)
    observed_u_mm = float(np.dot(delta, axis_u))
    observed_v_mm = float(np.dot(delta, axis_v))
    support_normal_offset_mm = float(np.dot(delta, support_up))
    point_error_mm = math.hypot(
        observed_u_mm - float(commissioning["requested_u_mm"]),
        observed_v_mm - float(commissioning["requested_v_mm"]),
    )
    tolerance = float(commissioning["tolerance_mm"])
    if point_error_mm > tolerance:
        raise RuntimeError(
            "observed target is outside the requested commissioning cell: "
            f"u={observed_u_mm:.1f}mm v={observed_v_mm:.1f}mm "
            f"cell_error={point_error_mm:.1f}mm limit={tolerance:.1f}mm"
        )
    if abs(support_normal_offset_mm) > 8.0:
        raise RuntimeError(
            "observed target is not on the scanned support plane: "
            f"normal_offset={support_normal_offset_mm:.1f}mm"
        )
    return {
        "observed_u_mm": observed_u_mm,
        "observed_v_mm": observed_v_mm,
        "support_normal_offset_mm": support_normal_offset_mm,
        "requested_cell_error_mm": point_error_mm,
        "result": "COMMISSIONING_POINT_MATCH",
    }


def resolve_project_path(raw: str | Path) -> Path:
    from s1_control.project_paths import project_path
    return project_path(raw, PROJECT_ROOT)


def load_alignment_config(path: str | Path, *, payload_mass_g: float | None = None) -> tuple[Path, dict]:
    config_path = resolve_project_path(path)
    record = json.loads(config_path.read_text(encoding="utf-8"))
    base_binding = record.get("base_alignment_config")
    if base_binding is not None:
        if not isinstance(base_binding, dict):
            raise ValueError("base_alignment_config must be an object")
        base_path = resolve_project_path(base_binding.get("path", ""))
        expected_sha256 = str(base_binding.get("sha256", "")).lower()
        if not base_path.is_file():
            raise FileNotFoundError(f"base alignment config does not exist: {base_path}")
        actual_sha256 = file_sha256(base_path)
        if actual_sha256 != expected_sha256:
            raise RuntimeError(
                "base alignment config SHA-256 mismatch: "
                f"expected={expected_sha256} actual={actual_sha256}"
            )
        base_record = json.loads(base_path.read_text(encoding="utf-8"))
        allowed_overrides = {
            "schema_version",
            "name",
            "status",
            "description",
            "operation",
            "orientation_only_required",
            "base_alignment_config",
            "safe_descent",
            "adaptive_pregrasp",
            "adaptive_secure_no_lift",
            "adaptive_grasp_orientation",
            "adaptive_grasp_box_place",
            "runtime",
            "physical_scope",
            "geometry_quality_override",
        }
        unexpected = set(record).difference(allowed_overrides)
        if unexpected:
            raise ValueError(
                "derived descent config contains unsupported overrides: "
                f"{sorted(unexpected)}"
            )
        merged = dict(base_record)
        merged.update(record)
        if "runtime" in record:
            runtime_override = record["runtime"]
            if not isinstance(runtime_override, dict):
                raise ValueError("derived runtime override must be an object")
            merged["runtime"] = {
                **dict(base_record.get("runtime", {})),
                **runtime_override,
            }
        record = merged
    if record.get("schema_version") != 1:
        raise ValueError("alignment config schema_version must be 1")
    if record.get("status") != "provisional_supervised_commissioning":
        raise ValueError("alignment config must remain provisional commissioning")
    alignment = record.get("alignment", {})
    positive = (
        "maximum_initial_tangent_error_mm",
        "success_tangent_error_mm",
        "maximum_cartesian_step_mm",
        "maximum_joint_step_rad",
        "minimum_joint_margin_deg",
        "maximum_fk_position_error_mm",
        "maximum_fk_orientation_error_deg",
        "maximum_final_normal_drift_mm",
        "collision_step_rad",
        "hold_after_alignment_s",
    )
    for key in positive:
        value = float(alignment.get(key, float("nan")))
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"alignment.{key} must be positive and finite")
    if float(alignment["maximum_initial_tangent_error_mm"]) > 40.0:
        raise ValueError("first alignment range cannot exceed 40mm")
    if float(alignment["success_tangent_error_mm"]) > 5.0:
        raise ValueError("first alignment success threshold cannot exceed 5mm")
    if float(alignment["maximum_cartesian_step_mm"]) > 5.0:
        raise ValueError("first Cartesian path sample spacing cannot exceed 5mm")
    runtime = record.get("runtime", {})
    if "j3_tilt_correction_limit_nm" in runtime:
        if (runtime.get("simplified_full_flow") is not True
                or float(runtime["j3_tilt_correction_limit_nm"]) not in (.25, .32)):
            raise ValueError("J3 tilt limit override is approved only as 0.25 or 0.32Nm in simplified full flow")
    for flag in ("continuous_alignment_commands", "record_control_trace",
                 "preserve_learned_position_bias", "stop_after_center_alignment",
                 "feedback_synchronized_alignment", "simplified_full_flow"):
        if not isinstance(runtime.get(flag, False), bool):
            raise ValueError(f"runtime.{flag} must be boolean")
    if runtime.get("continuous_alignment_commands", False) and (
        (record.get("orientation_only_required") is not True
         and not runtime.get("simplified_full_flow", False))
        or runtime.get("record_control_trace") is not True
    ):
        raise ValueError("continuous alignment commissioning requires orientation-only and tracing")
    if runtime.get("preserve_learned_position_bias", False):
        if not runtime.get("continuous_alignment_commands", False) or not (
            runtime.get("stop_after_center_alignment", False)
            or runtime.get("simplified_full_flow", False)
        ):
            raise ValueError("position-bias mapping requires the center-only diagnostic")
        maximum_offset = float(runtime.get("maximum_learned_position_bias_rad", .05))
        live_downward = float(runtime.get("maximum_live_alignment_downward_mm", 3.0))
        if not math.isfinite(maximum_offset) or not 0 < maximum_offset <= .05:
            raise ValueError("learned position bias limit must be in (0, 0.05]rad")
        if not math.isfinite(live_downward) or not 0 < live_downward <= 3.0:
            raise ValueError("live alignment downward limit must be in (0, 3]mm")
    if runtime.get("simplified_full_flow", False) and (
        record.get("operation") != "adaptive_grasp_box_place_round_trip"
        or runtime.get("feedback_synchronized_alignment", False)
        or runtime.get("stop_after_center_alignment", False)
        or not runtime.get("preserve_learned_position_bias", False)
        or record.get("adaptive_grasp_orientation", {}).get("full_flow_enabled") is not True
    ):
        raise ValueError("simplified full flow requires mapped, traced full box-place operation")
    if runtime.get("feedback_synchronized_alignment", False) and not (
        runtime.get("preserve_learned_position_bias", False)
        and runtime.get("stop_after_center_alignment", False)
    ):
        raise ValueError("feedback synchronization requires mapped center-only diagnostic")
    if runtime.get("stop_after_center_alignment", False) and record.get(
        "orientation_only_required"
    ) is not True:
        raise ValueError("center-only diagnostic must retain orientation-only restrictions")
    if runtime.get("support_normal_deviation_reference", "mount_record_pitch_only") not in {
        "mount_record_pitch_only", "mount_record_pitch_roll"
    }:
        raise ValueError("runtime support-normal deviation reference is unsupported")
    worker_timeout_s = float(runtime.get("worker_timeout_s", float("nan")))
    if not math.isfinite(worker_timeout_s) or not 15.0 < worker_timeout_s <= 60.0:
        raise ValueError("runtime.worker_timeout_s must be in (15, 60] seconds")
    write_raw_capture_previews = runtime.get(
        "write_raw_capture_previews_before_detection", True
    )
    if not isinstance(write_raw_capture_previews, bool):
        raise ValueError(
            "runtime.write_raw_capture_previews_before_detection must be boolean"
        )
    capture_hold_hz = float(runtime.get("capture_hold_hz", float("nan")))
    if not math.isfinite(capture_hold_hz) or not 5.0 <= capture_hold_hz <= 20.0:
        raise ValueError("runtime.capture_hold_hz must be in [5, 20] Hz")
    capture_velocity_guard_hz = float(
        runtime.get("capture_velocity_guard_hz", float("nan"))
    )
    if (
        not math.isfinite(capture_velocity_guard_hz)
        or not 0.5 <= capture_velocity_guard_hz <= capture_hold_hz
    ):
        raise ValueError(
            "runtime.capture_velocity_guard_hz must be in [0.5, capture_hold_hz] Hz"
        )
    capture_temperature_period_s = float(
        runtime.get("capture_temperature_period_s", float("nan"))
    )
    if (
        not math.isfinite(capture_temperature_period_s)
        or not 1.0 <= capture_temperature_period_s <= 10.0
    ):
        raise ValueError(
            "runtime.capture_temperature_period_s must be in [1, 10] seconds"
        )
    camera_attempts_raw = runtime.get("camera_attempts")
    camera_attempts = int(camera_attempts_raw) if camera_attempts_raw is not None else 0
    if camera_attempts_raw != camera_attempts or not 1 <= camera_attempts <= 3:
        raise ValueError("runtime.camera_attempts must be an integer in [1, 3]")
    camera_retry_delay_s = float(
        runtime.get("camera_retry_delay_s", float("nan"))
    )
    if not math.isfinite(camera_retry_delay_s) or not 0.0 <= camera_retry_delay_s <= 5.0:
        raise ValueError("runtime.camera_retry_delay_s must be in [0, 5] seconds")
    quality_override = record.get("capture_quality_override")
    if not isinstance(quality_override, dict):
        raise ValueError("capture_quality_override must be an object")
    if quality_override.get("scope") != GO2_CAPTURE_QUALITY_SCOPE:
        raise ValueError(
            "capture_quality_override.scope must remain local to Go2 visual alignment"
        )
    if quality_override.get("status") != "provisional_working_threshold":
        raise ValueError(
            "capture_quality_override must remain a provisional working threshold"
        )
    override_interval_ms = float(
        quality_override.get("maximum_frame_interval_ms", float("nan"))
    )
    if not math.isfinite(override_interval_ms) or not 300.0 < override_interval_ms <= 400.0:
        raise ValueError(
            "capture quality override must be in (300, 400] ms"
        )
    for text_key in ("reason", "revalidate_when"):
        if not str(quality_override.get(text_key, "")).strip():
            raise ValueError(f"capture_quality_override.{text_key} is required")
    isolated_spike = quality_override.get("isolated_frame_interval_spike")
    if isolated_spike is not None:
        if not isinstance(isolated_spike, dict):
            raise ValueError(
                "capture_quality_override.isolated_frame_interval_spike "
                "must be an object"
            )
        if isolated_spike.get("status") != "provisional_isolated_spike_exception":
            raise ValueError(
                "isolated frame interval policy must remain provisional"
            )
        if isolated_spike.get("enabled") is not True:
            raise ValueError("isolated frame interval policy must be explicitly enabled")
        isolated_max_ms = float(
            isolated_spike.get("maximum_single_frame_interval_ms", float("nan"))
        )
        isolated_p95_ms = float(
            isolated_spike.get("maximum_frame_interval_p95_ms", float("nan"))
        )
        isolated_min_depth = float(
            isolated_spike.get("minimum_valid_depth_ratio_fused", float("nan"))
        )
        if not (
            math.isfinite(isolated_max_ms)
            and override_interval_ms < isolated_max_ms <= 450.0
        ):
            raise ValueError(
                "isolated maximum frame interval must be above the base gate "
                "and at most 450ms"
            )
        if not (
            math.isfinite(isolated_p95_ms)
            and 0.0 < isolated_p95_ms <= override_interval_ms
        ):
            raise ValueError(
                "isolated frame interval P95 must be positive and no greater "
                "than the base gate"
            )
        if not (
            math.isfinite(isolated_min_depth)
            and 0.6 <= isolated_min_depth <= 1.0
        ):
            raise ValueError(
                "isolated frame interval minimum fused depth ratio must be "
                "within [0.6, 1.0]"
            )
        for text_key in ("reason", "revalidate_when"):
            if not str(isolated_spike.get(text_key, "")).strip():
                raise ValueError(
                    "capture_quality_override.isolated_frame_interval_spike."
                    f"{text_key} is required"
                )
    geometry_override = record.get("geometry_quality_override")
    if not isinstance(geometry_override, dict):
        raise ValueError("geometry_quality_override must be an object")
    if geometry_override.get("scope") not in {GO2_GEOMETRY_QUALITY_SCOPE, "go2_visual_alignment_go2_crouch_left_only"}:
        raise ValueError(
            "geometry_quality_override.scope must remain local to Go2 right alignment"
        )
    if geometry_override.get("status") != "provisional_working_threshold":
        raise ValueError(
            "geometry_quality_override must remain a provisional working threshold"
        )
    camera_tilt_limit = float(
        geometry_override.get("maximum_camera_tilt_from_down_deg", float("nan"))
    )
    scoped_tilt_maximum = 18.0 if runtime.get("simplified_full_flow", False) else 15.0
    if not math.isfinite(camera_tilt_limit) or not 10.0 <= camera_tilt_limit <= scoped_tilt_maximum:
        raise ValueError("local camera tilt threshold must be within [10, 15] deg")
    for text_key in ("reason", "revalidate_when"):
        if not str(geometry_override.get(text_key, "")).strip():
            raise ValueError(f"geometry_quality_override.{text_key} is required")
    payload = record.get("d455_payload")
    if not isinstance(payload, dict):
        raise ValueError("d455_payload must be an object")
    if payload.get("status") != "provisional_ab_only":
        raise ValueError("D455 payload model must remain provisional A/B-only")
    if payload.get("enabled_for_full_alignment") is not False:
        raise ValueError("D455 payload must remain disabled for full alignment")
    mass_kg = float(payload.get("mass_kg", float("nan")))
    ab_scale = float(payload.get("ab_scale", float("nan")))
    transition_s = float(payload.get("transition_s", float("nan")))
    hold_s = float(payload.get("hold_s", float("nan")))
    if not math.isfinite(mass_kg) or not 0.0 < mass_kg <= 0.2:
        raise ValueError("D455 payload mass must be within (0, 0.2] kg")
    if not math.isfinite(ab_scale) or not 0.0 < ab_scale <= 0.5:
        raise ValueError("D455 payload A/B scale must be within (0, 0.5]")
    if not math.isfinite(transition_s) or not 0.5 <= transition_s <= 3.0:
        raise ValueError("D455 payload transition must be within [0.5, 3] s")
    if not math.isfinite(hold_s) or not 1.0 <= hold_s <= 5.0:
        raise ValueError("D455 payload hold must be within [1, 5] s")
    center_camera = np.asarray(payload.get("center_of_mass_camera_m"), dtype=float)
    limits = np.asarray(payload.get("maximum_correction_nm"), dtype=float)
    if center_camera.shape != (3,) or not np.all(np.isfinite(center_camera)):
        raise ValueError("D455 payload camera-frame center must contain three values")
    if limits.shape != (6,) or not np.all(np.isfinite(limits)) or np.any(limits <= 0.0):
        raise ValueError("D455 payload torque limits must contain six positive values")
    if str(payload.get("attachment_link", "")) != "gripper":
        raise ValueError("D455 payload must remain attached to the gripper link")
    endpoint = record.get("observation_endpoint_convergence")
    if not isinstance(endpoint, dict):
        raise ValueError("observation_endpoint_convergence must be an object")
    endpoint_positive = (
        "success_joint_error_rad",
        "maximum_initial_joint_error_rad",
        "bias_step_rad",
        "maximum_bias_rad",
        "hold_seconds",
        "collision_step_rad",
        "minimum_joint_margin_deg",
    )
    for key in endpoint_positive:
        value = float(endpoint.get(key, float("nan")))
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(
                f"observation_endpoint_convergence.{key} must be positive and finite"
            )
    if float(endpoint["success_joint_error_rad"]) > 0.020:
        raise ValueError("observation endpoint success error cannot exceed 0.020rad")
    if not (
        float(endpoint["success_joint_error_rad"])
        < float(endpoint["maximum_initial_joint_error_rad"])
        <= 0.08
    ):
        raise ValueError("invalid observation endpoint joint-error limits")
    if not (
        float(endpoint["bias_step_rad"])
        <= float(endpoint["maximum_bias_rad"])
        <= 0.024
    ):
        raise ValueError("observation endpoint bias must remain within 0.024rad")
    attempts_raw = endpoint.get("maximum_attempts")
    attempts = int(attempts_raw) if attempts_raw is not None else 0
    if attempts_raw != attempts or not 1 <= attempts <= 6:
        raise ValueError("observation endpoint maximum_attempts must be in [1, 6]")
    if not 0.25 <= float(endpoint["hold_seconds"]) <= 1.0:
        raise ValueError("observation endpoint hold_seconds must be in [0.25, 1.0]")
    if float(endpoint["collision_step_rad"]) > 0.01:
        raise ValueError("observation endpoint collision step cannot exceed 0.01rad")
    if float(endpoint["minimum_joint_margin_deg"]) < 10.0:
        raise ValueError("observation endpoint joint margin cannot be below 10deg")
    alignment_endpoint = record.get("alignment_endpoint_convergence")
    if not isinstance(alignment_endpoint, dict):
        raise ValueError("alignment_endpoint_convergence must be an object")
    if alignment_endpoint.get("status") != "provisional_bounded_feedback_trim":
        raise ValueError("alignment endpoint convergence must remain provisional")
    for key in endpoint_positive:
        value = float(alignment_endpoint.get(key, float("nan")))
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(
                f"alignment_endpoint_convergence.{key} must be positive and finite"
            )
    if float(alignment_endpoint["success_joint_error_rad"]) > 0.012:
        raise ValueError("alignment endpoint success error cannot exceed 0.012rad")
    fallback_success_error = float(
        alignment_endpoint.get(
            "fallback_success_joint_error_rad", float("nan")
        )
    )
    if not (
        float(alignment_endpoint["success_joint_error_rad"])
        < fallback_success_error
        <= 0.020
        < float(alignment_endpoint["maximum_initial_joint_error_rad"])
        <= 0.05
    ):
        raise ValueError(
            "alignment endpoint errors must satisfy preferred < fallback "
            "<= 0.020 < initial <= 0.05rad"
        )
    if not (
        float(alignment_endpoint["bias_step_rad"])
        <= float(alignment_endpoint["maximum_bias_rad"])
        <= 0.024
    ):
        raise ValueError("alignment endpoint bias must remain within 0.024rad")
    alignment_attempts_raw = alignment_endpoint.get("maximum_attempts")
    alignment_attempts = (
        int(alignment_attempts_raw)
        if alignment_attempts_raw is not None
        else 0
    )
    if (
        alignment_attempts_raw != alignment_attempts
        or not 1 <= alignment_attempts <= 6
    ):
        raise ValueError("alignment endpoint maximum_attempts must be in [1, 6]")
    if not 0.25 <= float(alignment_endpoint["hold_seconds"]) <= 1.0:
        raise ValueError(
            "alignment endpoint hold_seconds must be in [0.25, 1.0]"
        )
    if float(alignment_endpoint["collision_step_rad"]) > 0.01:
        raise ValueError("alignment endpoint collision step cannot exceed 0.01rad")
    if float(alignment_endpoint["minimum_joint_margin_deg"]) < 10.0:
        raise ValueError("alignment endpoint joint margin cannot be below 10deg")
    residual = record.get("residual_correction")
    if not isinstance(residual, dict):
        raise ValueError("residual_correction must be an object")
    if residual.get("status") != "provisional_single_bounded_retry":
        raise ValueError("residual correction must remain a provisional retry")
    maximum_passes_raw = residual.get("maximum_passes")
    maximum_passes = int(maximum_passes_raw) if maximum_passes_raw is not None else 0
    if maximum_passes_raw != maximum_passes or maximum_passes != 1:
        raise ValueError("residual correction maximum_passes must remain exactly 1")
    maximum_residual_mm = float(
        residual.get("maximum_residual_error_mm", float("nan"))
    )
    if not (
        math.isfinite(maximum_residual_mm)
        and float(alignment["success_tangent_error_mm"])
        < maximum_residual_mm
        <= 12.0
    ):
        raise ValueError("residual correction range must end within (success, 12] mm")
    fault_recovery = record.get("fault_recovery")
    if not isinstance(fault_recovery, dict):
        raise ValueError("fault_recovery must be an object")
    if fault_recovery.get("status") != "provisional_low_speed_segmented_return":
        raise ValueError("fault recovery must remain low-speed and segmented")
    recovery_v_max = float(fault_recovery.get("v_max_rad_s", float("nan")))
    recovery_j6_v_max = float(
        fault_recovery.get("j6_v_max_rad_s", float("nan"))
    )
    recovery_joint_step = float(
        fault_recovery.get("maximum_joint_step_rad", float("nan"))
    )
    recovery_collision_step = float(
        fault_recovery.get("collision_step_rad", float("nan"))
    )
    recovery_support_timeout = float(
        fault_recovery.get("operator_support_timeout_s", float("nan"))
    )
    recovery_hold_hz = float(
        fault_recovery.get("operator_support_command_hz", float("nan"))
    )
    if not 0.0 < recovery_v_max <= 0.04:
        raise ValueError("fault recovery v_max_rad_s must be in (0, 0.04]")
    if not 0.0 < recovery_j6_v_max <= 0.04:
        raise ValueError("fault recovery j6_v_max_rad_s must be in (0, 0.04]")
    if not 0.0 < recovery_joint_step <= 0.04:
        raise ValueError("fault recovery maximum joint step must be in (0, 0.04]rad")
    if not 0.0 < recovery_collision_step <= 0.01:
        raise ValueError("fault recovery collision step must be in (0, 0.01]rad")
    if not 5.0 <= recovery_support_timeout <= 30.0:
        raise ValueError("fault recovery support timeout must be within [5, 30]s")
    if not 5.0 <= recovery_hold_hz <= 20.0:
        raise ValueError("fault recovery support command rate must be within [5, 20]Hz")
    operation = str(record.get("operation", "alignment_only"))
    if operation not in {
        "alignment_only",
        "safe_descent_round_trip",
        "adaptive_pregrasp_round_trip",
        "adaptive_secure_no_lift_round_trip",
        "adaptive_grasp_box_place_round_trip",
    }:
        raise ValueError("unsupported visual alignment operation")
    box_place = record.get("adaptive_grasp_box_place")
    adaptive_target_size = isinstance(box_place, dict) and box_place.get(
        "adaptive_target_size", False
    )
    forbidden = set(record.get("physical_scope", {}).get("forbidden_actions", []))
    required = set()
    if operation == "adaptive_grasp_box_place_round_trip":
        required.update(
            {
                "low_view_camera_recheck",
                "descent_below_grasp_height",
                "payload_above_40g",
                "unverified_box_route",
                "automatic_loaded_fault_recovery",
            }
        )
    else:
        required.update({"lift", "box_place", "orientation_change"})
    if operation in {
        "adaptive_secure_no_lift_round_trip",
        "adaptive_grasp_box_place_round_trip",
    }:
        required.update({"low_view_camera_recheck", "descent_below_grasp_height"})
    else:
        required.add("gripper_close")
        if operation == "alignment_only":
            required.add("descent")
        elif operation == "safe_descent_round_trip":
            required.add("descent_below_safe_clearance")
        else:
            required.add("descent_below_adaptive_pregrasp_clearance")
    if not required.issubset(forbidden):
        raise ValueError(
            "alignment commissioning physical scope is missing required prohibitions"
        )
    if operation == "safe_descent_round_trip":
        descent = record.get("safe_descent")
        if not isinstance(descent, dict):
            raise ValueError("safe_descent operation requires a safe_descent object")
        if descent.get("status") != "provisional_no_contact_round_trip":
            raise ValueError("safe_descent must remain provisional and no-contact")
        target_clearance = float(
            descent.get("target_normal_clearance_mm", float("nan"))
        )
        minimum_initial = float(
            descent.get("minimum_initial_normal_clearance_mm", float("nan"))
        )
        maximum_initial = float(
            descent.get("maximum_initial_normal_clearance_mm", float("nan"))
        )
        maximum_descent = float(
            descent.get("maximum_descent_distance_mm", float("nan"))
        )
        cartesian_step = float(
            descent.get("maximum_cartesian_step_mm", float("nan"))
        )
        joint_step = float(descent.get("maximum_joint_step_rad", float("nan")))
        joint_margin = float(descent.get("minimum_joint_margin_deg", float("nan")))
        collision_step = float(descent.get("collision_step_rad", float("nan")))
        clearance_error = float(
            descent.get("maximum_endpoint_clearance_error_mm", float("nan"))
        )
        progress_min = float(
            descent.get("minimum_descent_progress_ratio", float("nan"))
        )
        progress_max = float(
            descent.get("maximum_descent_progress_ratio", float("nan"))
        )
        v_max = float(descent.get("v_max_rad_s", float("nan")))
        j6_v_max = float(descent.get("j6_v_max_rad_s", float("nan")))
        hold_s = float(descent.get("hold_seconds", float("nan")))
        if not 80.0 <= target_clearance <= 120.0:
            raise ValueError("safe_descent target clearance must be within [80, 120]mm")
        if not target_clearance < minimum_initial < maximum_initial <= 300.0:
            raise ValueError("invalid safe_descent initial clearance range")
        if not 50.0 <= maximum_descent <= 160.0:
            raise ValueError("safe_descent distance cap must be within [50, 160]mm")
        if not 0.0 < cartesian_step <= 10.0:
            raise ValueError("safe_descent Cartesian step cannot exceed 10mm")
        if not 0.0 < joint_step <= 0.15:
            raise ValueError("safe_descent joint step cannot exceed 0.15rad")
        if joint_margin < 10.0:
            raise ValueError("safe_descent joint margin cannot be below 10deg")
        if not 0.0 < collision_step <= 0.01:
            raise ValueError("safe_descent collision step cannot exceed 0.01rad")
        if not 5.0 <= clearance_error <= 15.0:
            raise ValueError("safe_descent endpoint clearance error must be [5, 15]mm")
        if not 0.5 <= progress_min <= 0.9 < progress_max <= 1.5:
            raise ValueError("invalid safe_descent progress ratio limits")
        if not 0.0 < v_max <= 0.06 or not 0.0 < j6_v_max <= 0.06:
            raise ValueError("safe_descent speed limits cannot exceed 0.06rad/s")
        if not 0.5 <= hold_s <= 3.0:
            raise ValueError("safe_descent hold must be within [0.5, 3.0]s")
        for text_key in ("reason", "revalidate_when"):
            if not str(descent.get(text_key, "")).strip():
                raise ValueError(f"safe_descent.{text_key} is required")
    if operation in {
        "adaptive_pregrasp_round_trip",
        "adaptive_secure_no_lift_round_trip",
        "adaptive_grasp_box_place_round_trip",
    }:
        pregrasp = record.get("adaptive_pregrasp")
        if not isinstance(pregrasp, dict):
            raise ValueError(
                "adaptive_pregrasp operation requires an adaptive_pregrasp object"
            )
        if pregrasp.get("status") != "provisional_no_contact_adaptive_round_trip":
            raise ValueError("adaptive_pregrasp must remain provisional and no-contact")
        height_statistic = str(pregrasp.get("height_statistic", ""))
        minimum_height = float(
            pregrasp.get("minimum_target_height_mm", float("nan"))
        )
        maximum_height = float(
            pregrasp.get("maximum_target_height_mm", float("nan"))
        )
        top_clearance = float(
            pregrasp.get("clearance_above_detected_top_mm", float("nan"))
        )
        minimum_top_margin = float(
            pregrasp.get("minimum_theoretical_top_margin_mm", float("nan"))
        )
        minimum_initial = float(
            pregrasp.get("minimum_initial_normal_clearance_mm", float("nan"))
        )
        maximum_initial = float(
            pregrasp.get("maximum_initial_normal_clearance_mm", float("nan"))
        )
        maximum_descent = float(
            pregrasp.get("maximum_descent_distance_mm", float("nan"))
        )
        cartesian_step = float(
            pregrasp.get("maximum_cartesian_step_mm", float("nan"))
        )
        joint_step = float(
            pregrasp.get("maximum_joint_step_rad", float("nan"))
        )
        joint_margin = float(
            pregrasp.get("minimum_joint_margin_deg", float("nan"))
        )
        collision_step = float(
            pregrasp.get("collision_step_rad", float("nan"))
        )
        clearance_error = float(
            pregrasp.get("maximum_endpoint_clearance_error_mm", float("nan"))
        )
        progress_min = float(
            pregrasp.get("minimum_descent_progress_ratio", float("nan"))
        )
        progress_max = float(
            pregrasp.get("maximum_descent_progress_ratio", float("nan"))
        )
        v_max = float(pregrasp.get("v_max_rad_s", float("nan")))
        j6_v_max = float(pregrasp.get("j6_v_max_rad_s", float("nan")))
        hold_s = float(pregrasp.get("hold_seconds", float("nan")))
        if height_statistic != "p90":
            raise ValueError("adaptive_pregrasp height_statistic must be p90")
        if not 10.0 <= minimum_height < maximum_height <= 80.0:
            raise ValueError("invalid adaptive_pregrasp target height range")
        if not 15.0 <= minimum_top_margin <= top_clearance <= 40.0:
            raise ValueError("invalid adaptive_pregrasp top clearance")
        if not top_clearance < minimum_initial < maximum_initial <= 300.0:
            raise ValueError("invalid adaptive_pregrasp initial clearance range")
        maximum_descent_cap_mm = 220.0
        if operation == "adaptive_grasp_box_place_round_trip" and runtime.get(
            "simplified_full_flow"
        ):
            maximum_descent_cap_mm = 260.0 if adaptive_target_size else 230.0
        if not 100.0 <= maximum_descent <= maximum_descent_cap_mm:
            raise ValueError(
                "adaptive_pregrasp distance cap must be within "
                f"[100, {maximum_descent_cap_mm:g}]mm"
            )
        if not 0.0 < cartesian_step <= 10.0:
            raise ValueError("adaptive_pregrasp Cartesian step cannot exceed 10mm")
        if not 0.0 < joint_step <= 0.15:
            raise ValueError("adaptive_pregrasp joint step cannot exceed 0.15rad")
        if joint_margin < 10.0:
            raise ValueError("adaptive_pregrasp joint margin cannot be below 10deg")
        if not 0.0 < collision_step <= 0.01:
            raise ValueError("adaptive_pregrasp collision step cannot exceed 0.01rad")
        if not 1.0 <= clearance_error <= 5.0:
            raise ValueError(
                "adaptive_pregrasp endpoint clearance error must be within [1, 5]mm"
            )
        if not 0.8 <= progress_min <= 1.0 <= progress_max <= 1.2:
            raise ValueError("invalid adaptive_pregrasp progress ratio limits")
        if not 0.0 < v_max <= 0.06 or not 0.0 < j6_v_max <= 0.06:
            raise ValueError("adaptive_pregrasp speed limits cannot exceed 0.06rad/s")
        if not 0.5 <= hold_s <= 3.0:
            raise ValueError("adaptive_pregrasp hold must be within [0.5, 3.0]s")
        for text_key in ("reason", "revalidate_when"):
            if not str(pregrasp.get(text_key, "")).strip():
                raise ValueError(f"adaptive_pregrasp.{text_key} is required")
    if operation in {
        "adaptive_secure_no_lift_round_trip",
        "adaptive_grasp_box_place_round_trip",
    }:
        secure = record.get("adaptive_secure_no_lift")
        if not isinstance(secure, dict):
            raise ValueError(
                "adaptive_secure_no_lift operation requires its configuration object"
            )
        if secure.get("status") != "provisional_contact_no_lift_round_trip":
            raise ValueError("adaptive secure mode must remain provisional and no-lift")
        height_statistic = str(secure.get("height_statistic", ""))
        minimum_height = float(secure.get("minimum_target_height_mm", float("nan")))
        maximum_height = float(secure.get("maximum_target_height_mm", float("nan")))
        support_clearance = float(
            secure.get("target_support_plane_tcp_clearance_mm", float("nan"))
        )
        minimum_support_clearance = float(
            secure.get("minimum_support_plane_tcp_clearance_mm", float("nan"))
        )
        minimum_initial = float(
            secure.get("minimum_initial_top_clearance_mm", float("nan"))
        )
        maximum_initial = float(
            secure.get("maximum_initial_top_clearance_mm", float("nan"))
        )
        maximum_descent = float(
            secure.get("maximum_low_descent_distance_mm", float("nan"))
        )
        cartesian_step = float(
            secure.get("maximum_cartesian_step_mm", float("nan"))
        )
        joint_step = float(secure.get("maximum_joint_step_rad", float("nan")))
        joint_margin = float(secure.get("minimum_joint_margin_deg", float("nan")))
        collision_step = float(secure.get("collision_step_rad", float("nan")))
        clearance_error = float(
            secure.get("maximum_endpoint_clearance_error_mm", float("nan"))
        )
        progress_min = float(
            secure.get("minimum_descent_progress_ratio", float("nan"))
        )
        progress_max = float(
            secure.get("maximum_descent_progress_ratio", float("nan"))
        )
        v_max = float(secure.get("v_max_rad_s", float("nan")))
        j6_v_max = float(secure.get("j6_v_max_rad_s", float("nan")))
        hold_s = float(secure.get("hold_seconds", float("nan")))
        compensation_scale = float(
            secure.get("low_stage_compensation_scale", float("nan"))
        )
        pregrasp_compensation_scale = float(
            secure.get("pregrasp_descent_compensation_scale", float("nan"))
        )
        transition_s = float(
            secure.get("compensation_transition_s", float("nan"))
        )
        if height_statistic != "p90":
            raise ValueError("adaptive secure height_statistic must be p90")
        minimum_height_floor_mm = 40.0
        if operation == "adaptive_grasp_box_place_round_trip" and runtime.get(
            "simplified_full_flow"
        ):
            minimum_height_floor_mm = 15.0 if adaptive_target_size else 35.0
        if not minimum_height_floor_mm <= minimum_height < maximum_height <= 65.0:
            raise ValueError("invalid adaptive secure target height range")
        if not 6.0 <= minimum_support_clearance <= support_clearance <= 15.0:
            raise ValueError("invalid adaptive secure support-plane TCP clearance")
        if not 10.0 <= minimum_initial < maximum_initial <= 30.0:
            raise ValueError("invalid adaptive secure initial top-clearance range")
        if not 40.0 <= maximum_descent <= 80.0:
            raise ValueError("adaptive secure low descent cap must be within [40, 80]mm")
        if not 0.0 < cartesian_step <= 5.0:
            raise ValueError("adaptive secure Cartesian step cannot exceed 5mm")
        if not 0.0 < joint_step <= 0.10:
            raise ValueError("adaptive secure joint step cannot exceed 0.10rad")
        if joint_margin < 10.0:
            raise ValueError("adaptive secure joint margin cannot be below 10deg")
        if not 0.0 < collision_step <= 0.005:
            raise ValueError("adaptive secure collision step cannot exceed 0.005rad")
        clearance_error_upper = (
            15.0
            if operation == "adaptive_grasp_box_place_round_trip"
            else 2.5
        )
        if not 1.0 <= clearance_error <= clearance_error_upper:
            raise ValueError(
                "adaptive secure endpoint clearance error must be within "
                f"[1, {clearance_error_upper:.1f}]mm for operation={operation}"
            )
        if not 0.9 <= progress_min <= 1.0 <= progress_max <= 1.1:
            raise ValueError("invalid adaptive secure progress ratio limits")
        if not 0.0 < v_max <= 0.04 or not 0.0 < j6_v_max <= 0.04:
            raise ValueError("adaptive secure low-stage speed cannot exceed 0.04rad/s")
        if not 0.5 <= hold_s <= 3.0:
            raise ValueError("adaptive secure endpoint hold must be within [0.5, 3.0]s")
        if not 0.80 <= compensation_scale <= 1.0:
            raise ValueError(
                "adaptive secure low-stage compensation scale must be within [0.80, 1]"
            )
        if not 0.85 <= pregrasp_compensation_scale <= 1.0:
            raise ValueError(
                "adaptive secure pregrasp compensation scale must be within [0.85, 1]"
            )
        if not 0.25 <= transition_s <= 2.0:
            raise ValueError("adaptive secure compensation transition must be [0.25, 2]s")
        vision_handoff = secure.get("alignment_endpoint_vision_handoff")
        if not isinstance(vision_handoff, dict):
            raise ValueError(
                "adaptive_secure_no_lift.alignment_endpoint_vision_handoff is required"
            )
        if vision_handoff.get("status") != "provisional_final_vision_gate_only":
            raise ValueError("adaptive secure endpoint handoff must remain provisional")
        if vision_handoff.get("handoff_only_to_final_vision_gate") is not True:
            raise ValueError(
                "adaptive secure endpoint handoff must not directly authorize descent"
            )
        handoff_joint_error = float(
            vision_handoff.get("maximum_joint_error_rad", float("nan"))
        )
        handoff_tcp_error = float(
            vision_handoff.get("maximum_tcp_error_mm", float("nan"))
        )
        handoff_normal_error = float(
            vision_handoff.get("maximum_support_normal_error_mm", float("nan"))
        )
        if not 0.020 < handoff_joint_error <= 0.027:
            raise ValueError(
                "adaptive secure vision-handoff joint error must be in (0.020, 0.027]rad"
            )
        if not 0.0 < handoff_tcp_error <= 7.0:
            raise ValueError(
                "adaptive secure vision-handoff TCP error cannot exceed 7mm"
            )
        if not 0.0 < handoff_normal_error <= 5.0:
            raise ValueError(
                "adaptive secure vision-handoff support-normal error cannot exceed 5mm"
            )
        if not str(vision_handoff.get("reason", "")).strip():
            raise ValueError("adaptive secure endpoint handoff reason is required")
        for binding_key in ("adaptive_grasp_config", "empty_baseline"):
            binding = secure.get(binding_key)
            if not isinstance(binding, dict):
                raise ValueError(f"adaptive_secure_no_lift.{binding_key} is required")
            if not str(binding.get("path", "")).strip():
                raise ValueError(f"adaptive secure {binding_key} path is required")
            digest = str(binding.get("sha256", "")).lower()
            if not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise ValueError(f"adaptive secure {binding_key} SHA-256 is invalid")
        if not str(secure.get("hardware_identity_assumption", "")).strip():
            raise ValueError("adaptive secure hardware identity assumption is required")
        for text_key in ("reason", "revalidate_when"):
            if not str(secure.get(text_key, "")).strip():
                raise ValueError(f"adaptive_secure_no_lift.{text_key} is required")
    grasp_orientation = record.get("adaptive_grasp_orientation")
    if grasp_orientation is not None:
        if not isinstance(grasp_orientation, dict):
            raise ValueError("adaptive_grasp_orientation must be an object")
        if grasp_orientation.get("status") != "provisional_high_view_square_yaw":
            raise ValueError("adaptive grasp orientation must remain provisional")
        if grasp_orientation.get("enabled") is not True:
            raise ValueError("adaptive grasp orientation must be explicitly enabled")
        if not isinstance(grasp_orientation.get("full_flow_enabled"), bool):
            raise ValueError(
                "adaptive grasp orientation full_flow_enabled must be boolean"
            )
        hardware_binding = grasp_orientation.get(
            "dual_white_light_hardware_binding"
        )
        if hardware_binding is not None:
            if not isinstance(hardware_binding, dict):
                raise ValueError(
                    "dual white light hardware binding must be an object"
                )
            hardware_path = resolve_project_path(
                hardware_binding.get("path", "")
            )
            hardware_sha = str(
                hardware_binding.get("sha256", "")
            ).lower()
            if not hardware_path.is_file():
                raise FileNotFoundError(
                    f"dual white light hardware record does not exist: {hardware_path}"
                )
            if not re.fullmatch(r"[0-9a-f]{64}", hardware_sha):
                raise ValueError("dual white light hardware SHA-256 is invalid")
            if file_sha256(hardware_path) != hardware_sha:
                raise RuntimeError("dual white light hardware SHA-256 mismatch")
            evidence = grasp_orientation.get(
                "dual_white_light_static_validation_evidence"
            )
            if not isinstance(evidence, list) or len(evidence) < 3:
                raise ValueError(
                    "dual white light J6 commissioning requires three static "
                    "validation evidence records"
                )
            for index, item in enumerate(evidence, start=1):
                if not isinstance(item, dict):
                    raise ValueError(
                        f"dual white light evidence {index} must be an object"
                    )
                evidence_path = resolve_project_path(item.get("path", ""))
                evidence_sha = str(item.get("sha256", "")).lower()
                if not evidence_path.is_file():
                    raise FileNotFoundError(
                        f"dual white light evidence {index} does not exist: "
                        f"{evidence_path}"
                    )
                if not re.fullmatch(r"[0-9a-f]{64}", evidence_sha):
                    raise ValueError(
                        f"dual white light evidence {index} SHA-256 is invalid"
                    )
                if file_sha256(evidence_path) != evidence_sha:
                    raise RuntimeError(
                        f"dual white light evidence {index} SHA-256 mismatch"
                    )
        if not isinstance(
            grasp_orientation.get("j6_endpoint_trim_enabled", False), bool
        ):
            raise ValueError(
                "adaptive grasp orientation j6_endpoint_trim_enabled must be boolean"
            )
        numeric = {
            key: float(grasp_orientation.get(key, float("nan")))
            for key in (
                "symmetry_period_deg",
                "minimum_orientation_confidence_score",
                "maximum_orientation_p90_deviation_deg",
                "maximum_approach_tilt_from_support_down_deg",
                "maximum_rotation_deg",
                "maximum_orientation_step_deg",
                "maximum_joint_step_rad",
                "minimum_joint_margin_deg",
                "maximum_fk_position_error_mm",
                "maximum_fk_orientation_error_deg",
                "maximum_planned_tcp_position_drift_mm",
                "maximum_endpoint_joint_error_rad",
                "fallback_maximum_endpoint_joint_error_rad",
                "maximum_endpoint_tcp_position_drift_mm",
                "maximum_endpoint_orientation_error_deg",
                "collision_step_rad",
                "v_max_rad_s",
                "j6_v_max_rad_s",
                "hold_seconds",
                "unstable_retry_hold_seconds",
                "endpoint_evaluation_window_s",
                "maximum_endpoint_window_range_rad",
            )
        }
        if not all(math.isfinite(value) for value in numeric.values()):
            raise ValueError("adaptive grasp orientation values must be finite")
        if not math.isclose(numeric["symmetry_period_deg"], 90.0, abs_tol=1e-9):
            raise ValueError("adaptive grasp orientation symmetry must be 90deg")
        if not 0.75 <= numeric["minimum_orientation_confidence_score"] <= 1.0:
            raise ValueError("adaptive grasp orientation confidence must be [0.75, 1]")
        if not 0.0 < numeric["maximum_orientation_p90_deviation_deg"] <= 8.0:
            raise ValueError("adaptive grasp orientation p90 deviation cannot exceed 8deg")
        if not 0.0 < numeric["maximum_approach_tilt_from_support_down_deg"] <= scoped_tilt_maximum:
            raise ValueError("adaptive grasp approach tilt cannot exceed 15deg")
        if not 0.0 < numeric["maximum_rotation_deg"] <= 45.0:
            raise ValueError("adaptive square rotation cannot exceed 45deg")
        if not 0.5 <= numeric["maximum_orientation_step_deg"] <= 5.0:
            raise ValueError("adaptive orientation interpolation step must be [0.5, 5]deg")
        if not 0.0 < numeric["maximum_joint_step_rad"] <= 0.15:
            raise ValueError("adaptive orientation joint step cannot exceed 0.15rad")
        if numeric["minimum_joint_margin_deg"] < 10.0:
            raise ValueError("adaptive orientation joint margin cannot be below 10deg")
        if not 0.0 < numeric["maximum_fk_position_error_mm"] <= 1.0:
            raise ValueError("adaptive orientation FK position error cannot exceed 1mm")
        if not 0.0 < numeric["maximum_fk_orientation_error_deg"] <= 0.5:
            raise ValueError("adaptive orientation FK angle error cannot exceed 0.5deg")
        if not 0.0 < numeric["maximum_planned_tcp_position_drift_mm"] <= 1.0:
            raise ValueError("planned adaptive orientation TCP drift cannot exceed 1mm")
        if not 0.0 < numeric["maximum_endpoint_joint_error_rad"] <= 0.03:
            raise ValueError("adaptive orientation endpoint joint error cannot exceed 0.03rad")
        if not (
            numeric["maximum_endpoint_joint_error_rad"]
            <= numeric["fallback_maximum_endpoint_joint_error_rad"]
            <= 0.032
        ):
            raise ValueError(
                "adaptive orientation stable fallback joint error must be "
                "within [preferred, 0.032]rad"
            )
        if not 0.0 < numeric["maximum_endpoint_tcp_position_drift_mm"] <= 5.0:
            raise ValueError("adaptive orientation endpoint TCP drift cannot exceed 5mm")
        endpoint_orientation_limit = 4.0 if runtime.get("simplified_full_flow", False) else 3.0
        if not 0.0 < numeric["maximum_endpoint_orientation_error_deg"] <= endpoint_orientation_limit:
            raise ValueError("adaptive orientation endpoint angle error cannot exceed 3deg")
        if not 0.0 < numeric["collision_step_rad"] <= 0.005:
            raise ValueError("adaptive orientation collision step cannot exceed 0.005rad")
        if not 0.0 < numeric["v_max_rad_s"] <= 0.08:
            raise ValueError("adaptive orientation speed cannot exceed 0.08rad/s")
        if not 0.0 < numeric["j6_v_max_rad_s"] <= 0.10:
            raise ValueError("adaptive orientation J6 speed cannot exceed 0.10rad/s")
        if not 0.5 <= numeric["hold_seconds"] <= 2.0:
            raise ValueError("adaptive orientation hold must be within [0.5, 2]s")
        if not 0.3 <= numeric["unstable_retry_hold_seconds"] <= 1.0:
            raise ValueError(
                "adaptive orientation unstable retry hold must be within [0.3, 1]s"
            )
        if not (
            0.1
            <= numeric["endpoint_evaluation_window_s"]
            <= numeric["hold_seconds"]
        ):
            raise ValueError(
                "adaptive orientation endpoint evaluation window must be "
                "within [0.1s, hold_seconds]"
            )
        if (
            numeric["endpoint_evaluation_window_s"]
            > numeric["unstable_retry_hold_seconds"]
        ):
            raise ValueError(
                "adaptive orientation endpoint evaluation window cannot exceed "
                "the unstable retry hold"
            )
        if not 0.0 < numeric["maximum_endpoint_window_range_rad"] <= 0.01:
            raise ValueError(
                "adaptive orientation endpoint window range cannot exceed 0.01rad"
            )
        if grasp_orientation.get("j6_endpoint_trim_enabled") is True:
            trim_numeric = {
                key: float(grasp_orientation.get(key, float("nan")))
                for key in (
                    "j6_endpoint_trim_maximum_initial_error_rad",
                    "j6_endpoint_trim_maximum_other_joint_error_rad",
                    "j6_endpoint_trim_maximum_bias_rad",
                    "j6_endpoint_trim_maximum_initial_orientation_error_deg",
                    "j6_endpoint_trim_hold_seconds",
                )
            }
            if not all(math.isfinite(value) for value in trim_numeric.values()):
                raise ValueError("adaptive orientation J6 trim values must be finite")
            if not (
                numeric["fallback_maximum_endpoint_joint_error_rad"]
                < trim_numeric["j6_endpoint_trim_maximum_initial_error_rad"]
                <= 0.06
            ):
                raise ValueError(
                    "adaptive orientation J6 trim initial error must be within "
                    "(fallback, 0.06]rad"
                )
            if not (
                0.0
                < trim_numeric["j6_endpoint_trim_maximum_other_joint_error_rad"]
                <= 0.015
            ):
                raise ValueError(
                    "adaptive orientation J6 trim other-joint error cannot exceed 0.015rad"
                )
            if not (
                0.0
                < trim_numeric["j6_endpoint_trim_maximum_bias_rad"]
                <= numeric["maximum_endpoint_joint_error_rad"]
            ):
                raise ValueError(
                    "adaptive orientation J6 trim bias cannot exceed the preferred endpoint gate"
                )
            if not (
                numeric["maximum_endpoint_orientation_error_deg"]
                <= trim_numeric[
                    "j6_endpoint_trim_maximum_initial_orientation_error_deg"
                ]
                <= 5.0
            ):
                raise ValueError(
                    "adaptive orientation J6 trim initial tool error must be in [final, 5]deg"
                )
            if not 0.5 <= trim_numeric["j6_endpoint_trim_hold_seconds"] <= 2.0:
                raise ValueError(
                    "adaptive orientation J6 trim hold must be within [0.5, 2]s"
                )
        for text_key in ("reason", "revalidate_when"):
            if not str(grasp_orientation.get(text_key, "")).strip():
                raise ValueError(f"adaptive_grasp_orientation.{text_key} is required")
    if operation == "adaptive_grasp_box_place_round_trip":
        if not isinstance(box_place, dict):
            raise ValueError(
                "adaptive_grasp_box_place operation requires its configuration object"
            )
        if payload_mass_g is not None:
            box_place["maximum_test_mass_g"] = float(payload_mass_g)
        target_edge_mm = float(box_place.get("target_edge_mm", float("nan")))
        target_mass_g = float(box_place.get("maximum_test_mass_g", float("nan")))
        box_scale = float(
            box_place.get("box_route_compensation_scale", float("nan"))
        )
        transition_s = float(
            box_place.get("compensation_transition_s", float("nan"))
        )
        allowed_edges_mm = (40.0, 50.0) if runtime.get("simplified_full_flow") else (50.0,)
        if adaptive_target_size:
            if not 0.0 < target_edge_mm <= 50.0:
                raise ValueError("adaptive box-place target edge cap cannot exceed 50mm")
        elif target_edge_mm not in allowed_edges_mm:
            raise ValueError(f"box-place target edge must be one of {allowed_edges_mm} mm")
        if not math.isfinite(target_mass_g) or target_mass_g <= 0.0:
            raise ValueError("payload mass must be positive and finite")
        if not math.isclose(box_scale, 0.20, abs_tol=1e-9):
            raise ValueError("box route compensation scale must remain 0.20")
        if not 0.5 <= transition_s <= 2.0:
            raise ValueError("box route compensation transition must be within [0.5, 2]s")
        alignment_override = box_place.get(
            "alignment_working_threshold_override"
        )
        if not isinstance(alignment_override, dict):
            raise ValueError(
                "adaptive_grasp_box_place.alignment_working_threshold_override "
                "is required"
            )
        if (
            alignment_override.get("status")
            != "provisional_working_threshold"
        ):
            raise ValueError(
                "box-place alignment override must remain provisional"
            )
        if (
            alignment_override.get("scope")
            != "go2_adaptive_grasp_box_place_round_trip_only"
        ):
            raise ValueError(
                "box-place alignment override must remain local to the full flow"
            )
        normal_drift_override_mm = float(
            alignment_override.get(
                "maximum_final_normal_drift_mm", float("nan")
            )
        )
        base_normal_drift_mm = float(
            record["alignment"]["maximum_final_normal_drift_mm"]
        )
        if not (
            math.isfinite(normal_drift_override_mm)
            and base_normal_drift_mm
            <= normal_drift_override_mm
            <= 6.0
        ):
            raise ValueError(
                "box-place final normal drift override must be within "
                "[base threshold, 6.0]mm"
            )
        for text_key in ("reason", "revalidate_when"):
            if not str(alignment_override.get(text_key, "")).strip():
                raise ValueError(
                    "adaptive_grasp_box_place.alignment_working_threshold_override."
                    f"{text_key} is required"
                )
        for binding_key in (
            "box_plan",
            "box_collision_report",
            "empty_route_evidence",
        ):
            binding = box_place.get(binding_key)
            if not isinstance(binding, dict):
                raise ValueError(f"adaptive_grasp_box_place.{binding_key} is required")
            if not str(binding.get("path", "")).strip():
                raise ValueError(f"box placement {binding_key} path is required")
            digest = str(binding.get("sha256", "")).lower()
            if not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise ValueError(f"box placement {binding_key} SHA-256 is invalid")
        for text_key in ("loaded_fault_policy", "reason", "revalidate_when"):
            if not str(box_place.get(text_key, "")).strip():
                raise ValueError(f"adaptive_grasp_box_place.{text_key} is required")
    if runtime.get("simplified_full_flow") and "adaptive_secure_no_lift" in record:
        record["adaptive_secure_no_lift"].setdefault("secure_force_nm", 0.40)
        record["adaptive_secure_no_lift"].setdefault("descent_open_gap_mm", None)
    return config_path, record


def apply_local_j3_tilt_limit(mount_record, runtime):
    """Copy-on-write local correction allowance; leave bound files untouched."""
    if "j3_tilt_correction_limit_nm" not in runtime:
        return mount_record, None
    value = float(runtime["j3_tilt_correction_limit_nm"])
    if runtime.get("simplified_full_flow") is not True or value not in (.25, .32):
        raise ValueError("unapproved local J3 tilt limit")
    updated = json.loads(json.dumps(mount_record))
    limits = commissioning_vector(
        updated["diagnostic"]["correction_absolute_limits_nm"], 6,
        "tilt correction limits",
    ).tolist()
    if not math.isclose(limits[2], .20, abs_tol=1e-9):
        raise ValueError("local J3 override expects the original 0.20Nm limit")
    limits[2] = value
    updated["diagnostic"]["correction_absolute_limits_nm"] = limits
    evidence = dict(scope="dual_white_light_simplified_full_flow_only",
                    joint="J3", original_limit_nm=.20, applied_limit_nm=value,
                    global_mount_file_modified=False)
    return updated, evidence


def apply_local_j2_tilt_limit(mount_record, runtime):
    """Apply the configured J2 working allowance without editing bound mount files."""
    if "j2_tilt_correction_limit_nm" not in runtime:
        return mount_record, None
    updated = json.loads(json.dumps(mount_record))
    limits = updated["diagnostic"]["correction_absolute_limits_nm"]
    original = limits[1]
    limits[1] = float(runtime["j2_tilt_correction_limit_nm"])
    return updated, dict(scope="dual_white_light_simplified_full_flow_only",
                         joint="J2", original_limit_nm=original,
                         applied_limit_nm=limits[1], global_mount_file_modified=False)


def load_bound_deployment_source(plan: dict) -> tuple[Path, dict]:
    """Load the source config whose hash is embedded in the generated plan."""
    raw_path = plan.get("source_config")
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("deployment plan has no source_config binding")
    source_path = resolve_project_path(raw_path)
    if not source_path.is_file():
        raise FileNotFoundError(f"deployment source config does not exist: {source_path}")
    expected = str(plan.get("source_config_sha256", "")).lower()
    actual = file_sha256(source_path)
    if actual != expected:
        raise RuntimeError(
            f"deployment source config SHA-256 mismatch: expected={expected} actual={actual}"
        )
    record = load_deployment_config(source_path)
    return source_path, record


def load_bound_box_place_resources(
    box_config: dict,
    *,
    deployment_plan_path: Path,
    mount_path: Path,
    allow_identical_deployment_geometry: bool = False,
    allow_shared_box_from_left: bool = False,
) -> tuple[Path, Path, Path, dict, dict, dict, dict, dict | None]:
    """Verify the fixed-box route and its completed empty-route evidence."""
    resolved = {}
    for name in ("box_plan", "box_collision_report", "empty_route_evidence"):
        binding = box_config[name]
        path = resolve_project_path(binding["path"])
        if not path.is_file():
            raise FileNotFoundError(f"bound box artifact does not exist: {path}")
        expected = str(binding["sha256"]).lower()
        actual = file_sha256(path)
        if actual != expected:
            raise RuntimeError(
                f"bound {name} SHA-256 mismatch: expected={expected} actual={actual}"
            )
        resolved[name] = path

    box_plan, box_report, box_deployment_plan, box_mount_record = verify_box_artifacts(
        resolved["box_plan"], resolved["box_collision_report"]
    )
    validate_route_shape(box_plan["route"])
    if file_sha256(deployment_plan_path) != box_plan["bindings"][
        "deployment_plan_sha256"
    ]:
        active_deployment = json.loads(deployment_plan_path.read_text(encoding="utf-8"))
        identical = (allow_identical_deployment_geometry
                     and active_deployment.get("joint_path") == box_deployment_plan.get("joint_path")
                     and active_deployment.get("side") == box_deployment_plan.get("side"))
        shared_from_left = (
            allow_shared_box_from_left and active_deployment.get("side") == "left"
            and active_deployment["joint_path"][1]["q"] == box_deployment_plan["joint_path"][1]["q"]
        )
        if not (identical or shared_from_left):
            raise RuntimeError("visual deployment and fixed-box route use different plans")
        print("BOX_DEPLOYMENT_COMPATIBILITY =", "left side shares existing rear-ready and fixed box; live transfer separately planned" if shared_from_left else "identical checked joint geometry; separate plan hashes retained")
    if file_sha256(mount_path) != box_plan["bindings"]["mount_config_sha256"]:
        raise RuntimeError("visual deployment and fixed-box route use different mounts")
    if box_deployment_plan.get("side") != "right":
        raise ValueError("box route is not bound to the right-side Go2 deployment")
    if box_deployment_plan.get("joint_path", [{}])[-1].get("name") != "right_observe":
        raise ValueError("box route deployment does not terminate at right_observe")

    evidence = json.loads(
        resolved["empty_route_evidence"].read_text(encoding="utf-8")
    )
    if evidence.get("status") != "EMPTY_BOX_ROUTE_ROUND_TRIP_DONE":
        raise ValueError("empty fixed-box route has not completed physical validation")
    if evidence.get("plan_sha256") != file_sha256(resolved["box_plan"]):
        raise ValueError("empty-route evidence is not bound to the current box plan")
    if evidence.get("collision_report_sha256") != file_sha256(
        resolved["box_collision_report"]
    ):
        raise ValueError("empty-route evidence uses a different collision report")
    if not math.isclose(
        float(evidence.get("actual_payload_mass_g", float("nan"))),
        0.0,
        abs_tol=1e-9,
    ):
        raise ValueError("empty-route evidence was not collected with an empty gripper")

    target_mass_g = float(box_config["maximum_test_mass_g"])
    # The bound report remains immutable evidence for its original mass.
    # Point-mass gravity is linear in mass for this same route and TCP.
    model = box_report["payload_gravity_model"]
    ratio = target_mass_g / (1000.0 * float(model["mass_kg"]))
    fractions = [float(x) * ratio for x in model["maximum_design_payload_effort_fraction_per_joint"]]
    box_report = dict(box_report)
    box_report["configured_payload_estimate"] = {
        "mass_g": target_mass_g,
        "reference_mass_g": 1000.0 * float(model["mass_kg"]),
        "maximum_design_payload_torque_nm_per_joint": [float(x) * ratio for x in model["maximum_design_payload_torque_nm_per_joint"]],
        "maximum_design_payload_effort_fraction_per_joint": fractions,
        "within_original_design_margin": max(fractions) <= float(model["maximum_allowed_design_payload_effort_fraction"]),
        "scope": "same fixed-box route and TCP only; incremental payload estimate, not whole-arm or Go2 stability validation",
    }
    print("PAYLOAD_MASS_G =", target_mass_g)
    print("BOX_ROUTE_CONFIGURED_PAYLOAD_ESTIMATE =", json.dumps(box_report["configured_payload_estimate"], ensure_ascii=False))
    route_scale = float(box_config["box_route_compensation_scale"])
    plan_scale = float(box_plan["motion"]["tilt_compensation_scale"])
    if not math.isclose(route_scale, plan_scale, abs_tol=1e-9):
        raise ValueError("box config and commissioned route use different tilt scales")
    scoped_mount, route_override = mount_record_with_lower_route_scale(
        box_mount_record, route_scale
    )
    return (
        resolved["box_plan"],
        resolved["box_collision_report"],
        resolved["empty_route_evidence"],
        box_plan,
        box_report,
        evidence,
        scoped_mount,
        route_override,
    )


def loaded_fault_requires_operator_recovery(
    box_place_enabled: bool,
    payload_held: bool,
    box_route_in_progress: bool,
) -> bool:
    """Prevent an automatic drop or blind loaded recovery outside the box."""
    return bool(box_place_enabled and (payload_held or box_route_in_progress))


def make_run_id(raw: str | None) -> str:
    value = raw or datetime.now().strftime("alignment_%Y%m%d-%H%M%S")
    if not RUN_ID_PATTERN.fullmatch(value):
        raise ValueError("--run-id may contain letters, digits, dot, underscore and dash")
    return value


def bind_capture_path(capture: dict, path: Path) -> dict:
    value = dict(capture)
    value["path"] = path
    return value


def load_detector_config(path: str | Path) -> tuple[dict, Path]:
    """Unpack the detector loader's ``(config, path)`` public contract."""
    config, config_path = load_vision_config(path)
    if not isinstance(config, dict):
        raise TypeError("vision detector config must be a mapping")
    return config, Path(config_path)


def apply_local_capture_quality_policy(
    metadata: dict,
    quality_override: dict | None,
) -> dict:
    """Allow one bounded VM USB interval spike without hiding other faults."""
    original_pass = metadata.get("quality_pass") is True
    original_reasons = list(metadata.get("quality_reasons") or [])
    decision = {
        "status": "not_needed" if original_pass else "rejected",
        "original_quality_pass": original_pass,
        "original_quality_reasons": original_reasons,
    }
    metadata["local_quality_review"] = decision
    if original_pass or quality_override is None:
        return decision
    policy = quality_override.get("isolated_frame_interval_spike")
    if not isinstance(policy, dict) or policy.get("enabled") is not True:
        decision["reason"] = "isolated_spike_policy_not_enabled"
        return decision
    if len(original_reasons) != 1 or re.fullmatch(
        r"frame_interval_ms_max=[0-9]+(?:\.[0-9]+)? > [0-9]+(?:\.[0-9]+)?",
        str(original_reasons[0]),
    ) is None:
        decision["reason"] = "quality_failure_is_not_one_isolated_interval_spike"
        return decision
    observed_max_ms = float(metadata.get("frame_interval_ms_max", float("nan")))
    observed_p95_ms = float(metadata.get("frame_interval_ms_p95", float("nan")))
    observed_depth_ratio = float(
        metadata.get("valid_depth_ratio_fused", float("nan"))
    )
    limits = {
        "maximum_single_frame_interval_ms": float(
            policy["maximum_single_frame_interval_ms"]
        ),
        "maximum_frame_interval_p95_ms": float(
            policy["maximum_frame_interval_p95_ms"]
        ),
        "minimum_valid_depth_ratio_fused": float(
            policy["minimum_valid_depth_ratio_fused"]
        ),
    }
    observed = {
        "frame_interval_ms_max": observed_max_ms,
        "frame_interval_ms_p95": observed_p95_ms,
        "valid_depth_ratio_fused": observed_depth_ratio,
    }
    decision.update({"limits": limits, "observed": observed})
    finite = all(math.isfinite(value) for value in observed.values())
    accepted = bool(
        finite
        and observed_max_ms <= limits["maximum_single_frame_interval_ms"]
        and observed_p95_ms <= limits["maximum_frame_interval_p95_ms"]
        and observed_depth_ratio >= limits["minimum_valid_depth_ratio_fused"]
    )
    if not accepted:
        decision["reason"] = "isolated_spike_secondary_limits_failed"
        return decision
    decision["status"] = "accepted_isolated_frame_interval_spike"
    decision["reason"] = "bounded_vm_usb_spike_with_stable_p95_and_depth"
    metadata["quality_pass"] = True
    metadata["quality_reasons"] = []
    return decision


def capture_and_detect(
    loaded,
    vision_config,
    run_dir: Path,
    label: str,
    *,
    capture_quality_override: dict | None = None,
    write_raw_capture_previews: bool = True,
) -> dict:
    capture_cfg = loaded.record["capture"]
    configured_max_interval_ms = float(capture_cfg["maximum_frame_interval_ms"])
    applied_max_interval_ms = configured_max_interval_ms
    quality_gate_source = "wrist_servo_config"
    quality_gate_scope = "shared"
    quality_gate_status = "configured"
    if capture_quality_override is not None:
        applied_max_interval_ms = float(
            capture_quality_override["maximum_frame_interval_ms"]
        )
        quality_gate_source = "go2_visual_alignment_local_override"
        quality_gate_scope = str(capture_quality_override["scope"])
        quality_gate_status = str(capture_quality_override["status"])
    total_started = time.monotonic()
    capture_started = time.monotonic()
    capture = capture_aligned_rgbd(
        serial=loaded.record["camera_serial"],
        width=int(capture_cfg["width"]),
        height=int(capture_cfg["height"]),
        fps=int(capture_cfg["fps"]),
        warmup_frames=int(capture_cfg["warmup_frames"]),
        depth_frames=int(capture_cfg["depth_frames"]),
        timeout_ms=int(capture_cfg["timeout_ms"]),
        min_valid_depth_ratio=float(capture_cfg["minimum_valid_depth_ratio"]),
        max_frame_interval_ms=applied_max_interval_ms,
    )
    capture["metadata"]["quality_gate"] = {
        "source": quality_gate_source,
        "scope": quality_gate_scope,
        "status": quality_gate_status,
        "configured_maximum_frame_interval_ms": configured_max_interval_ms,
        "applied_maximum_frame_interval_ms": applied_max_interval_ms,
    }
    local_quality_review = apply_local_capture_quality_policy(
        capture["metadata"], capture_quality_override
    )
    if local_quality_review["status"] != "not_needed":
        print(
            "CAPTURE_QUALITY_LOCAL_REVIEW"
            f" label={label}"
            f" status={local_quality_review['status']}"
            f" reason={local_quality_review.get('reason', '')}"
        )
    capture_elapsed_s = time.monotonic() - capture_started
    capture_path = run_dir / f"{label}_capture.npz"
    detection_path = run_dir / f"{label}_detection.json"
    preview_path = run_dir / f"{label}_detection.png"
    save_started = time.monotonic()
    save_capture(
        capture,
        capture_path,
        write_preview=bool(write_raw_capture_previews),
    )
    save_elapsed_s = time.monotonic() - save_started
    detection_started = time.monotonic()
    detection = detect_capture(bind_capture_path(capture, capture_path), vision_config)
    if "candidate_search_roi_px" in detection:
        print(
            "VISION_FULL_FRAME_FALLBACK",
            f"label={label}",
            f"status={detection['status']}",
        )
    detection_elapsed_s = time.monotonic() - detection_started
    output_started = time.monotonic()
    save_result(detection, detection_path)
    save_preview(capture["rgb"], detection, preview_path)
    output_elapsed_s = time.monotonic() - output_started
    timing = {
        "capture_s": capture_elapsed_s,
        "capture_save_s": save_elapsed_s,
        "detection_s": detection_elapsed_s,
        "detection_output_s": output_elapsed_s,
        "total_s": time.monotonic() - total_started,
    }
    print(
        "VISION_STAGE_TIMING"
        f" label={label}"
        f" capture={timing['capture_s']:.3f}s"
        f" capture_save={timing['capture_save_s']:.3f}s"
        f" detection={timing['detection_s']:.3f}s"
        f" detection_output={timing['detection_output_s']:.3f}s"
        f" total={timing['total_s']:.3f}s"
    )
    return {
        "capture_metadata": capture["metadata"],
        "detection": detection,
        "timing_s": timing,
        "capture_path": str(capture_path.relative_to(PROJECT_ROOT)),
        "detection_path": str(detection_path.relative_to(PROJECT_ROOT)),
        "preview_path": str(preview_path.relative_to(PROJECT_ROOT)),
        "raw_capture_previews_written": bool(write_raw_capture_previews),
    }


def is_retriable_camera_timeout(exc: BaseException) -> bool:
    """Only retry a RealSense frame-arrival timeout after full pipeline cleanup."""
    message = str(exc).lower()
    return "frame didn't arrive within" in message or "frame did not arrive within" in message


def capture_and_detect_with_retry(
    loaded,
    vision_config,
    run_dir: Path,
    label: str,
    *,
    camera_attempts: int,
    retry_delay_s: float,
    capture_quality_override: dict | None = None,
    write_raw_capture_previews: bool = True,
) -> dict:
    """Retry one transient D455 frame timeout; never retry detection rejection."""
    for attempt in range(1, int(camera_attempts) + 1):
        print(f"CAMERA_CAPTURE_ATTEMPT label={label} attempt={attempt}/{camera_attempts}")
        try:
            result = capture_and_detect(
                loaded,
                vision_config,
                run_dir,
                label,
                capture_quality_override=capture_quality_override,
                write_raw_capture_previews=write_raw_capture_previews,
            )
            result["camera_attempt"] = attempt
            return result
        except Exception as exc:
            if attempt >= int(camera_attempts) or not is_retriable_camera_timeout(exc):
                raise
            print(
                "CAMERA_FRAME_TIMEOUT_RETRY"
                f" label={label} attempt={attempt}"
                f" delay_s={float(retry_delay_s):.3f} error={exc}"
            )
            time.sleep(float(retry_delay_s))
    raise AssertionError("unreachable camera retry state")


def capture_process_entry(
    wrist_config_path: str,
    vision_config_path: str,
    run_dir: str,
    label: str,
    result_path: str,
    camera_attempts: int,
    retry_delay_s: float,
    capture_quality_override: dict,
    write_raw_capture_previews: bool,
    search_full_frame_on_miss: bool = False,
) -> None:
    """Run RealSense and detection in a fresh interpreter process."""
    result_file = Path(result_path)
    try:
        loaded = load_wrist_servo_config(wrist_config_path)
        vision_config, _ = load_detector_config(vision_config_path)
        if search_full_frame_on_miss:
            vision_config["workspace_roi"]["search_full_frame_on_miss"] = True
        result = capture_and_detect_with_retry(
            loaded,
            vision_config,
            Path(run_dir),
            label,
            camera_attempts=int(camera_attempts),
            retry_delay_s=float(retry_delay_s),
            capture_quality_override=dict(capture_quality_override),
            write_raw_capture_previews=bool(write_raw_capture_previews),
        )
        write_json(result_file, {"ok": True, "result": result})
    except BaseException as exc:
        write_json(
            result_file,
            {
                "ok": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            },
        )


def terminate_spawn_worker(process, label: str, join_timeout_s: float = 5.0) -> None:
    """Terminate a spawned worker and verify that OS resources are released."""
    if process.is_alive():
        process.terminate()
    process.join(timeout=float(join_timeout_s))
    if process.is_alive() and hasattr(process, "kill"):
        process.kill()
        process.join(timeout=float(join_timeout_s))
    if process.is_alive():
        raise RuntimeError(f"{label}: spawned worker could not be terminated")
    print("SPAWN_WORKER_RELEASED =", label, "exitcode =", process.exitcode)


def load_spawn_worker_result(path: str | Path, label: str) -> object:
    result_path = Path(path)
    if not result_path.is_file():
        raise RuntimeError(f"{label}: spawned worker produced no result record")
    record = json.loads(result_path.read_text(encoding="utf-8"))
    if record.get("ok") is not True:
        raise RuntimeError(
            f"{label}: {record.get('error_type', 'WorkerError')}: "
            f"{record.get('error', 'unknown spawned-worker failure')}"
        )
    return record["result"]


def measured_position_from_commander(arm) -> list[float]:
    """Reuse the tilt commander's fresh feedback instead of reading serial twice."""
    commander = getattr(arm, "_position_commander", None)
    snapshot = getattr(commander, "last_snapshot", None)
    if isinstance(snapshot, dict):
        measured = snapshot.get("measured_q_rad")
        if (
            isinstance(measured, (list, tuple))
            and len(measured) >= 6
            and all(math.isfinite(float(value)) for value in measured[:6])
        ):
            return [float(value) for value in measured[:6]]
    return [float(value) for value in list(arm.get_pos())[:6]]


class ObservationEndpointConvergenceError(RuntimeError):
    """Endpoint convergence failed with a serializable diagnostic record."""

    def __init__(self, message: str, record: dict):
        super().__init__(message)
        self.record = record


def bounded_endpoint_bias(
    current_bias,
    desired_error,
    *,
    maximum_step_rad: float,
    maximum_bias_rad: float,
) -> list[float]:
    """Return a bounded six-joint command bias opposing measured error."""
    bias = np.asarray(current_bias, dtype=np.float64)
    error = np.asarray(desired_error, dtype=np.float64)
    if bias.shape != (6,) or error.shape != (6,):
        raise ValueError("endpoint bias and error must contain six values")
    if not np.isfinite(bias).all() or not np.isfinite(error).all():
        raise ValueError("endpoint bias and error must be finite")
    maximum_step_rad = float(maximum_step_rad)
    maximum_bias_rad = float(maximum_bias_rad)
    if not (
        math.isfinite(maximum_step_rad)
        and math.isfinite(maximum_bias_rad)
        and 0.0 < maximum_step_rad <= maximum_bias_rad
    ):
        raise ValueError("invalid endpoint bias bounds")
    requested = np.clip(-error, -maximum_step_rad, maximum_step_rad)
    return np.clip(
        bias + requested, -maximum_bias_rad, maximum_bias_rad
    ).tolist()


def endpoint_tracking_record(planned_q, measured_q, kinematics) -> dict:
    planned = np.asarray(planned_q, dtype=np.float64)
    measured = np.asarray(measured_q, dtype=np.float64)
    if planned.shape != (6,) or measured.shape != (6,):
        raise ValueError("endpoint joint vectors must contain six values")
    if not np.isfinite(planned).all() or not np.isfinite(measured).all():
        raise ValueError("endpoint joint vectors must be finite")
    planned_tcp = [float(value) for value in kinematics.fk(planned.tolist())]
    measured_tcp = [float(value) for value in kinematics.fk(measured.tolist())]
    error = measured - planned
    tcp_error_mm = 1000.0 * (
        np.asarray(measured_tcp[:3], dtype=np.float64)
        - np.asarray(planned_tcp[:3], dtype=np.float64)
    )
    return {
        "planned_q_rad": planned.tolist(),
        "measured_q_rad": measured.tolist(),
        "joint_error_rad": error.tolist(),
        "maximum_abs_joint_error_rad": float(np.max(np.abs(error))),
        "planned_tcp_pose_xyz_xyzw": planned_tcp,
        "measured_tcp_pose_xyz_xyzw": measured_tcp,
        "tcp_error_xyz_mm": tcp_error_mm.tolist(),
        "tcp_error_norm_mm": float(np.linalg.norm(tcp_error_mm)),
    }


def endpoint_vision_handoff_decision(
    tracking: dict,
    support_up_normal_base,
    config: dict,
    *,
    workspace_error: str | None = None,
) -> dict:
    """Decide whether endpoint residuals may proceed only to final vision.

    This is deliberately not a descent gate.  It only prevents additional
    joint-bias chasing when task-space residuals are already small enough for
    the mandatory D455 geometry recheck to make the next decision.
    """
    tcp_error = np.asarray(tracking["tcp_error_xyz_mm"], dtype=np.float64)
    support_up = np.asarray(support_up_normal_base, dtype=np.float64)
    if tcp_error.shape != (3,) or not np.isfinite(tcp_error).all():
        raise ValueError("endpoint TCP error must contain three finite values")
    if support_up.shape != (3,) or not np.isfinite(support_up).all():
        raise ValueError("support-up normal must contain three finite values")
    support_norm = float(np.linalg.norm(support_up))
    if support_norm <= 1e-9:
        raise ValueError("support-up normal cannot be zero")
    support_up = support_up / support_norm
    signed_normal_error_mm = float(np.dot(tcp_error, support_up))
    tangent_error = tcp_error - signed_normal_error_mm * support_up

    maximum_joint_error = float(config["maximum_joint_error_rad"])
    maximum_tcp_error = float(config["maximum_tcp_error_mm"])
    maximum_normal_error = float(config["maximum_support_normal_error_mm"])
    reasons = []
    if workspace_error is not None:
        reasons.append("workspace_out_of_range")
    measured_joint_error = float(tracking["maximum_abs_joint_error_rad"])
    if config.get("j6_tracking_diagnostic_only", False):
        measured_joint_error = max(abs(float(v)) for v in tracking["joint_error_rad"][:5])
    if measured_joint_error > maximum_joint_error:
        reasons.append("joint_error_too_large")
    if float(tracking["tcp_error_norm_mm"]) > maximum_tcp_error:
        reasons.append("tcp_error_too_large")
    if abs(signed_normal_error_mm) > maximum_normal_error:
        reasons.append("support_normal_error_too_large")
    return {
        "allowed": not reasons,
        "handoff_only_to_final_vision_gate": True,
        "authorizes_descent": False,
        "maximum_joint_error_rad": maximum_joint_error,
        "maximum_tcp_error_mm": maximum_tcp_error,
        "maximum_support_normal_error_mm": maximum_normal_error,
        "measured_joint_error_rad": measured_joint_error,
        "all_joint_error_rad_diagnostic": float(tracking["maximum_abs_joint_error_rad"]),
        "j6_tracking_diagnostic_only": config.get("j6_tracking_diagnostic_only", False),
        "measured_tcp_error_mm": float(tracking["tcp_error_norm_mm"]),
        "signed_support_normal_error_mm": signed_normal_error_mm,
        "support_tangent_error_norm_mm": float(np.linalg.norm(tangent_error)),
        "workspace_error": workspace_error,
        "reasons": reasons,
    }


def sample_endpoint_hold(arm, command_q, duration_s: float, label: str) -> list[float]:
    """Hold a command with normal guards and return median measured joints."""
    deadline = time.monotonic() + float(duration_s)
    next_tick = time.monotonic()
    samples = []
    while time.monotonic() < deadline:
        arm.command_position(command_q)
        position = measured_position_from_commander(arm)
        samples.append(position)
        fault = arm.guard(
            position,
            arm.get_vel(),
            arm.get_temp(),
            list(command_q),
            settling=False,
        )
        if fault:
            raise RuntimeError(f"{label}: {fault}")
        next_tick += arm.dt
        time.sleep(max(0.0, next_tick - time.monotonic()))
    if not samples:
        samples.append([float(value) for value in arm.get_pos()[:6]])
    return [
        statistics.median(row[index] for row in samples) for index in range(6)
    ]


def summarize_endpoint_tail(samples, evaluation_sample_count: int) -> dict:
    """Summarize only the stable tail of a bounded endpoint hold."""
    rows = np.asarray(samples, dtype=np.float64)
    if rows.ndim != 2 or rows.shape[0] < 1 or rows.shape[1] != 6:
        raise ValueError("endpoint samples must be a non-empty Nx6 array")
    if not np.isfinite(rows).all():
        raise ValueError("endpoint samples must be finite")
    evaluation_sample_count = int(evaluation_sample_count)
    if evaluation_sample_count < 1:
        raise ValueError("evaluation_sample_count must be positive")
    tail = rows[-min(rows.shape[0], evaluation_sample_count) :]
    window_range = np.ptp(tail, axis=0)
    return {
        "sample_count": int(rows.shape[0]),
        "evaluation_sample_count": int(tail.shape[0]),
        "first_q_rad": rows[0].tolist(),
        "last_q_rad": rows[-1].tolist(),
        "measured_q_rad": np.median(tail, axis=0).tolist(),
        "evaluation_window_range_rad": window_range.tolist(),
        "maximum_evaluation_window_range_rad": float(np.max(window_range)),
    }


def sample_endpoint_hold_tail(
    arm,
    command_q,
    duration_s: float,
    evaluation_window_s: float,
    label: str,
) -> dict:
    """Hold with normal guards and evaluate only the final stable window."""
    duration_s = float(duration_s)
    evaluation_window_s = float(evaluation_window_s)
    if not (
        math.isfinite(duration_s)
        and math.isfinite(evaluation_window_s)
        and duration_s > 0.0
        and 0.0 < evaluation_window_s <= duration_s
    ):
        raise ValueError("invalid endpoint hold/evaluation duration")
    deadline = time.monotonic() + duration_s
    next_tick = time.monotonic()
    samples = []
    while time.monotonic() < deadline:
        arm.command_position(command_q)
        position = measured_position_from_commander(arm)
        samples.append(position)
        fault = arm.guard(
            position,
            arm.get_vel(),
            arm.get_temp(),
            list(command_q),
            settling=False,
        )
        if fault:
            raise RuntimeError(f"{label}: {fault}")
        next_tick += arm.dt
        time.sleep(max(0.0, next_tick - time.monotonic()))
    if not samples:
        samples.append([float(value) for value in arm.get_pos()[:6]])
    evaluation_sample_count = max(
        1,
        int(math.ceil(evaluation_window_s / float(arm.dt))),
    )
    summary = summarize_endpoint_tail(samples, evaluation_sample_count)
    summary.update(
        {
            "hold_seconds": duration_s,
            "evaluation_window_s": evaluation_window_s,
        }
    )
    return summary


def prepare_continuous_alignment_path(
    arm, physical_path, *, collision_checker, tilt_model,
    support_up_normal_base, compensation_scale, torque_limits,
    collision_step_rad, minimum_joint_margin_deg, workspace, kinematics,
    preserve_physical_offsets=False, maximum_offset_rad=.05,
    clip_learned_offset=False, fit_offset_to_joint_margin=False,
):
    """Preflight both the command-continuous path and measured entry envelope."""
    trace = getattr(arm, "_position_commander", None)
    previous = getattr(trace, "last_command_q_rad", None)
    if previous is None:
        raise RuntimeError("continuous handoff requires the previous position command")
    learned_offset = None
    if preserve_physical_offsets:
        command_path, learned_offset = offset_command_path(
            previous, physical_path, maximum_offset_rad,
            clip_learned_offset=clip_learned_offset,
        )
        if fit_offset_to_joint_margin:
            physical = np.asarray(physical_path, dtype=float)
            lower, upper = np.asarray(JOINT_LIMITS_RAD, dtype=float).T
            margin = math.radians(minimum_joint_margin_deg)
            # Move one representable value inward so the margin check can
            # round-trip between radians and degrees at the boundary.
            lower = np.nextafter(lower + margin, np.inf)
            upper = np.nextafter(upper - margin, -np.inf)
            terminal_offset = np.clip(
                learned_offset, lower - physical.min(axis=0), upper - physical.max(axis=0)
            )
            if not np.array_equal(terminal_offset, learned_offset):
                progress = np.linspace(0.0, 1.0, len(physical))[:, None]
                offsets = (1.0 - progress) * learned_offset + progress * terminal_offset
                command_path = np.clip(physical + offsets, lower, upper).tolist()
                command_path[0] = list(previous)
    else:
        command_path = continuous_command_path(previous, physical_path)
    measured = measured_position_from_commander(arm)
    checked_path = [list(measured), *command_path]
    dense = densify_joint_path(checked_path, float(collision_step_rad))
    for q in dense:
        if joint_margin_deg(q) < minimum_joint_margin_deg:
            raise RuntimeError("continuous command handoff violates joint margin")
    for a, b in zip(command_path, command_path[1:]):
        if max_joint_delta(a, b) > arm.limits.max_joint_delta_rad:
            raise RuntimeError("continuous command handoff exceeds segment joint limit")
    collision = check_collision_path(collision_checker, checked_path, collision_step_rad)
    torque = validate_torque_envelope(
        dense,
        lambda q: float(compensation_scale)
        * differential_tilt_compensation_from_support_up(
            tilt_model, q, support_up_normal_base
        ),
        torque_limits,
    )
    # Workspace evidence is for physical planned/measured TCP, not the FK of
    # tracking-bias commands. Those commands already exceed the physical plan
    # by design. The physical route is checked by compute_alignment_plan and
    # endpoint validation; independently check the fresh measured entry here.
    validate_workspace_point(kinematics.fk(measured)[:3], workspace,
                             "continuous handoff measured TCP")
    return command_path, {
        "previous_command_q_rad": list(previous),
        "physical_planning_start_q_rad": list(physical_path[0]),
        "physical_target_q_rad": list(physical_path[-1]),
        "learned_command_offset_rad": learned_offset,
        "learned_command_offset_clipped": learned_offset is not None and any(
            abs(float(command) - float(physical)) > float(maximum_offset_rad)
            for command, physical in zip(previous, physical_path[0])
        ),
        "avoided_reset_rad": [float(a-b) for a,b in zip(physical_path[0], previous)],
        "command_path": command_path,
        "collision": collision,
        "torque": torque,
    }


def configure_alignment_downward_trace(trace, runtime, height_function, reference_height_mm):
    """Keep drift as telemetry in full flow; retain the center-only diagnostic."""
    limit = (None if runtime.get("simplified_full_flow", False)
             else float(runtime.get("maximum_live_alignment_downward_mm", 3.0)))
    trace.set_downward_guard(height_function, reference_height_mm, limit)
    return {"mode": "monitor_only" if limit is None else "diagnostic_abort",
            "reference_height_mm": reference_height_mm, "maximum_downward_mm": limit}


def prepare_continuous_alignment_path_while_holding(
    arm, physical_path, *, timeout_s, label="continuous_handoff_preflight", **kwargs
):
    """Run CPU-only path checks while the main thread keeps the last setpoint."""
    previous = getattr(arm._position_commander, "last_command_q_rad", None)
    if previous is None:
        raise RuntimeError("continuous handoff requires the previous position command")
    result, _ = run_worker_while_holding(
        arm, list(previous),
        lambda: prepare_continuous_alignment_path(arm, physical_path, **kwargs),
        timeout_s=timeout_s, label=label,
    )
    return result


def plan_flexible_endpoint_trim(
    arm, desired_q, measured_q, held_q, *, endpoint_config,
    kinematics, collision_checker, tilt_model, support_up_normal_base,
    compensation_scale, torque_limits, vision_handoff_config,
    observed_support_normal, check_body,
):
    """Fit one feedback correction into the existing high-view envelope."""
    desired = np.asarray(desired_q)
    measured = np.asarray(measured_q)
    held = np.asarray(held_q)
    maximum_offset = float(endpoint_config["maximum_initial_joint_error_rad"])
    collision_step = float(endpoint_config["collision_step_rad"])
    minimum_margin = float(endpoint_config["minimum_joint_margin_deg"])
    rejected = []
    for j2_scale in (1.0, 0.5):
        # J2 recovers height. J5 and J6 recover the wrist pose without
        # requiring all of the height correction to come from J2.
        delta = np.zeros(6)
        delta[[1, 4, 5]] = (desired - measured)[[1, 4, 5]]
        delta[1] *= j2_scale
        command = np.clip(held + delta, desired - maximum_offset, desired + maximum_offset)
        predicted = measured + (command - held)
        predicted_tracking = endpoint_tracking_record(desired_q, predicted.tolist(), kinematics)
        vision = endpoint_vision_handoff_decision(
            predicted_tracking, observed_support_normal, vision_handoff_config,
        )
        if not vision["allowed"]:
            rejected.append({"j2_scale": j2_scale, "reasons": vision["reasons"]})
            continue
        try:
            trim_path, command_check = prepare_continuous_alignment_path(
                arm, [measured_q, command.tolist()], collision_checker=collision_checker,
                tilt_model=tilt_model, support_up_normal_base=support_up_normal_base,
                compensation_scale=compensation_scale, torque_limits=torque_limits,
                collision_step_rad=collision_step, minimum_joint_margin_deg=minimum_margin,
                workspace=endpoint_config["validated_workspace"], kinematics=kinematics,
            )
            predicted_path = [measured_q, predicted.tolist()]
            predicted_dense = densify_joint_path(predicted_path, collision_step)
            if min(map(joint_margin_deg, predicted_dense)) < minimum_margin:
                raise RuntimeError("predicted flexible endpoint trim violates joint margin")
            predicted_collision = check_collision_path(
                collision_checker, predicted_path, collision_step,
            )
            predicted_torque = validate_torque_envelope(
                predicted_dense,
                lambda q: float(compensation_scale)
                * differential_tilt_compensation_from_support_up(
                    tilt_model, q, support_up_normal_base,
                ),
                torque_limits,
            )
            command_body = check_body(trim_path)
            predicted_body = check_body(predicted_path)
        except RuntimeError as exc:
            rejected.append({"j2_scale": j2_scale, "reasons": [str(exc)]})
            continue
        return trim_path, {
            "j2_scale": j2_scale,
            "delta_rad": (command - held).tolist(),
            "predicted_vision_handoff": vision,
            "command_preflight": command_check,
            "command_body_check": command_body,
            "predicted_body_check": predicted_body,
            "predicted_collision": predicted_collision,
            "predicted_torque": predicted_torque,
            "rejected_candidates": rejected,
        }
    return None, {"rejected_candidates": rejected}


def converge_observation_endpoint(
    arm,
    desired_q,
    *,
    endpoint_config: dict,
    kinematics,
    collision_checker,
    tilt_model,
    support_up_normal_base,
    compensation_scale: float,
    torque_limits,
    vision_handoff_config: dict | None = None,
    vision_handoff_support_up_normal_base=None,
    progress_callback=None,
    label_prefix: str = "observation_endpoint",
    continuous_command_handoff: bool = False,
    initial_command_q=None,
    flexible_endpoint_check_body=None,
    flexible_endpoint_j6_v_max_rad_s=None,
) -> dict:
    """Bounded feedback trim before D455 capture; all safety guards remain active."""
    desired = [float(value) for value in desired_q]
    success_error = float(endpoint_config["success_joint_error_rad"])
    fallback_success_error = endpoint_config.get(
        "fallback_success_joint_error_rad"
    )
    if fallback_success_error is not None:
        fallback_success_error = float(fallback_success_error)
    maximum_initial_error = float(
        endpoint_config["maximum_initial_joint_error_rad"]
    )
    bias_step = float(endpoint_config["bias_step_rad"])
    maximum_bias = float(endpoint_config["maximum_bias_rad"])
    maximum_attempts = int(endpoint_config["maximum_attempts"])
    hold_seconds = float(endpoint_config["hold_seconds"])
    collision_step = float(endpoint_config["collision_step_rad"])
    minimum_margin = float(endpoint_config["minimum_joint_margin_deg"])

    validate_workspace_point(
        kinematics.fk(desired)[:3], endpoint_config["validated_workspace"],
        "planned observation TCP",
    )
    record = {
        "status": "started",
        "label": str(label_prefix),
        "desired_q_rad": desired,
        "limits": {
            key: endpoint_config[key]
            for key in (
                "success_joint_error_rad",
                "maximum_initial_joint_error_rad",
                "bias_step_rad",
                "maximum_bias_rad",
                "maximum_attempts",
                "hold_seconds",
                "collision_step_rad",
                "minimum_joint_margin_deg",
            )
        },
        "attempts": [],
    }
    if fallback_success_error is not None:
        record["limits"]["fallback_success_joint_error_rad"] = (
            fallback_success_error
        )
    if vision_handoff_config is not None:
        if vision_handoff_support_up_normal_base is None:
            raise ValueError(
                "vision handoff requires the observed support-plane normal"
            )
        record["limits"]["vision_handoff"] = dict(vision_handoff_config)
    bias = [0.0] * 6
    command_q = list(desired if initial_command_q is None else initial_command_q)
    baseline_offset = commissioning_vector(command_q, 6, "initial endpoint command") - desired
    if initial_command_q is not None and not continuous_command_handoff:
        raise ValueError("mapped endpoint command requires continuous commissioning")
    # Subtracting the mapped endpoint can round a clipped 0.05 to 0.050000000000000044.
    if np.max(np.abs(baseline_offset)) > maximum_initial_error + 1e-12:
        raise ValueError("mapped endpoint baseline exceeds bounded correction range")
    record["baseline_command_offset_rad"] = baseline_offset.tolist()

    def publish_progress():
        if progress_callback is not None:
            progress_callback(record)

    for attempt in range(maximum_attempts + 1):
        if continuous_command_handoff:
            arm._position_commander.phase = f"{label_prefix}_hold_{attempt}"
        measured_q = sample_endpoint_hold(
            arm, command_q, hold_seconds, f"{label_prefix}_hold_{attempt}"
        )
        tracking = endpoint_tracking_record(desired, measured_q, kinematics)
        workspace_error = None
        try:
            validate_workspace_point(
                tracking["measured_tcp_pose_xyz_xyzw"][:3],
                endpoint_config["validated_workspace"],
                "measured observation TCP",
            )
        except RuntimeError as exc:
            workspace_error = str(exc)
        attempt_record = {
            "attempt": attempt,
            "command_bias_rad": list(bias),
            "command_q_rad": list(command_q),
            "tracking": tracking,
            "workspace_error": workspace_error,
        }
        record["attempts"].append(attempt_record)
        publish_progress()
        print(
            f"{label_prefix.upper()}_CHECK"
            f" attempt={attempt}"
            f" joint_error={tracking['maximum_abs_joint_error_rad']:.5f}rad"
            f" tcp_error={tracking['tcp_error_norm_mm']:.2f}mm"
            f" workspace={'OK' if workspace_error is None else 'OUT'}"
        )
        if (
            tracking["maximum_abs_joint_error_rad"] <= success_error
            and workspace_error is None
        ):
            record.update(
                {
                    "status": "passed",
                    "final_command_q_rad": list(command_q),
                    "final_median_q_rad": list(measured_q),
                    "final_tracking": tracking,
                }
            )
            publish_progress()
            return record
        if vision_handoff_config is not None:
            handoff = endpoint_vision_handoff_decision(
                tracking,
                vision_handoff_support_up_normal_base,
                vision_handoff_config,
                workspace_error=workspace_error,
            )
            attempt_record["vision_handoff"] = handoff
            print(
                f"{label_prefix.upper()}_VISION_HANDOFF"
                f" attempt={attempt}"
                f" allowed={handoff['allowed']}"
                f" joint={handoff['measured_joint_error_rad']:.5f}rad"
                f" tcp={handoff['measured_tcp_error_mm']:.2f}mm"
                f" normal={handoff['signed_support_normal_error_mm']:+.2f}mm"
                " authorizes_descent=False"
            )
            if handoff["allowed"]:
                record.update(
                    {
                        "status": "passed_to_final_vision_gate_only",
                        "authorizes_descent": False,
                        # Historical behavior freezes the measured pose. The
                        # continuity commissioning mode instead retains the last
                        # command, avoiding a new encoder-setpoint reset before
                        # the mandatory final visual geometry check.
                        "final_command_q_rad": list(
                            command_q if continuous_command_handoff else measured_q
                        ),
                        "hold_command_preserved": continuous_command_handoff,
                        "final_median_q_rad": list(measured_q),
                        "final_tracking": tracking,
                        "vision_handoff": handoff,
                    }
                )
                publish_progress()
                return record
        initial_error_for_gate = tracking["maximum_abs_joint_error_rad"]
        if endpoint_config.get("j6_tracking_diagnostic_only", False):
            initial_error_for_gate = max(abs(float(v)) for v in tracking["joint_error_rad"][:5])
            attempt_record["initial_error_gate_j1_to_j5_rad"] = initial_error_for_gate
        if initial_error_for_gate > maximum_initial_error:
            if attempt == 0 and attempt < maximum_attempts and flexible_endpoint_check_body is not None:
                (trim_path, trim), _ = run_worker_while_holding(
                    arm, command_q,
                    lambda: plan_flexible_endpoint_trim(
                        arm, desired, measured_q, command_q,
                        endpoint_config=endpoint_config, kinematics=kinematics,
                        collision_checker=collision_checker, tilt_model=tilt_model,
                        support_up_normal_base=support_up_normal_base,
                        compensation_scale=compensation_scale, torque_limits=torque_limits,
                        vision_handoff_config=vision_handoff_config,
                        observed_support_normal=vision_handoff_support_up_normal_base,
                        check_body=flexible_endpoint_check_body,
                    ),
                    timeout_s=10.0, label=f"{label_prefix}_flexible_trim_preflight",
                )
                attempt_record["flexible_endpoint_trim"] = trim
                publish_progress()
                if trim_path is None:
                    record["status"] = "rejected_flexible_endpoint_trim"
                    publish_progress()
                    raise ObservationEndpointConvergenceError(
                        "no checked flexible endpoint correction can reach the vision handoff range",
                        record,
                    )
                print(
                    "FLEXIBLE_ALIGNMENT_ENDPOINT_TRIM ="
                    f" j2_scale={trim['j2_scale']:.2f}"
                    f" delta_rad={trim['delta_rad']}"
                )
                arm._position_commander.phase = f"{label_prefix}_flexible_trim"
                previous_j6_v_max = arm.limits.j6_v_max_rad_s
                arm.limits.j6_v_max_rad_s = min(previous_j6_v_max, flexible_endpoint_j6_v_max_rad_s)
                try:
                    fault = arm.move_waypoints(trim_path, f"{label_prefix}_flexible_trim")
                finally:
                    arm.limits.j6_v_max_rad_s = previous_j6_v_max
                if fault:
                    record["status"] = "rejected_motion_guard"
                    publish_progress()
                    raise ObservationEndpointConvergenceError(str(fault), record)
                command_q = trim_path[-1]
                bias = (np.asarray(command_q) - np.asarray(desired) - baseline_offset).tolist()
                record["executed_flexible_trim_command_q_rad"] = command_q
                publish_progress()
                continue
            record["status"] = "rejected_initial_error"
            publish_progress()
            raise ObservationEndpointConvergenceError(
                "observation endpoint error exceeds bounded correction range",
                record,
            )
        if attempt >= maximum_attempts:
            if endpoint_config.get("handoff_after_one_trim", False):
                # This is NOT endpoint convergence and never authorizes descent.
                # Original initial-error bounds, live guards and mandatory final
                # vision remain. Retain the command rather than resetting it.
                record.update(status="pending_visual_verification",
                              authorizes_descent=False,
                              final_command_q_rad=list(command_q),
                              final_median_q_rad=list(measured_q),
                              final_tracking=tracking)
                publish_progress()
                return record
            if (
                fallback_success_error is not None
                and tracking["maximum_abs_joint_error_rad"]
                <= fallback_success_error
                and workspace_error is None
            ):
                record.update(
                    {
                        "status": "passed_fallback_working_threshold",
                        "final_command_q_rad": list(command_q),
                        "final_median_q_rad": list(measured_q),
                        "final_tracking": tracking,
                    }
                )
                publish_progress()
                return record
            if workspace_error is not None:
                record["status"] = "rejected_workspace_out_of_range"
                message = f"{label_prefix}: {workspace_error}"
            else:
                record["status"] = "rejected_joint_error_not_converged"
                message = (
                    f"{label_prefix}: joint error "
                    f"{tracking['maximum_abs_joint_error_rad']:.5f}rad "
                    "did not converge within the bounded attempts"
                )
            publish_progress()
            raise ObservationEndpointConvergenceError(message, record)

        next_bias = bounded_endpoint_bias(
            bias,
            tracking["joint_error_rad"],
            maximum_step_rad=bias_step,
            maximum_bias_rad=maximum_bias,
        )
        if np.allclose(next_bias, bias, atol=1e-12, rtol=0.0):
            record["status"] = "rejected_bias_saturated"
            publish_progress()
            raise ObservationEndpointConvergenceError(
                "observation endpoint command bias reached its hard cap",
                record,
            )
        next_command = [
            desired[index] + float(baseline_offset[index]) + next_bias[index]
            for index in range(6)
        ]
        if max(abs(a-b) for a,b in zip(next_command, desired)) > maximum_initial_error:
            record["status"] = "rejected_total_command_offset"
            publish_progress()
            raise ObservationEndpointConvergenceError(
                "learned offset plus endpoint trim exceeds bounded correction range", record
            )
        def build_trim_preflight():
            margin = joint_margin_deg(next_command)
            if margin < minimum_margin:
                record["status"] = "rejected_joint_margin"
                publish_progress()
                raise ObservationEndpointConvergenceError(
                    "observation endpoint trim has insufficient joint margin", record,
                )
            physical_trim = [measured_q, next_command]
            collision = check_collision_path(collision_checker, physical_trim, collision_step)
            dense = densify_joint_path(physical_trim, collision_step)
            torque = validate_torque_envelope(
                dense,
                lambda q: float(compensation_scale)
                * differential_tilt_compensation_from_support_up(
                    tilt_model, q, support_up_normal_base
                ),
                torque_limits,
            )
            preflight = {
                "start_measured_q_rad": list(measured_q),
                "joint_margin_deg": margin, "collision": collision, "torque": torque,
            }
            proof = None
            trim_path = physical_trim
            if continuous_command_handoff:
                trim_path, proof = prepare_continuous_alignment_path(
                    arm, physical_trim, collision_checker=collision_checker,
                    tilt_model=tilt_model, support_up_normal_base=support_up_normal_base,
                    compensation_scale=compensation_scale, torque_limits=torque_limits,
                    collision_step_rad=collision_step,
                    minimum_joint_margin_deg=minimum_margin,
                    workspace=endpoint_config["validated_workspace"], kinematics=kinematics,
                )
            return trim_path, preflight, proof

        if continuous_command_handoff:
            (trim_path, preflight, proof), _ = run_worker_while_holding(
                arm, command_q, build_trim_preflight, timeout_s=10.0,
                label=f"{label_prefix}_preflight_{attempt + 1}",
            )
        else:
            trim_path, preflight, proof = build_trim_preflight()
        attempt_record["next_command_preflight"] = preflight
        if proof is not None:
            attempt_record["continuous_command_handoff"] = proof
        publish_progress()
        if continuous_command_handoff:
            arm._position_commander.phase = f"{label_prefix}_trim_{attempt + 1}"
        fault = None if len(trim_path) < 2 else arm.move_waypoints(
            trim_path,
            f"{label_prefix}_trim_{attempt + 1}",
        )
        if fault:
            record["status"] = "rejected_motion_guard"
            publish_progress()
            raise ObservationEndpointConvergenceError(str(fault), record)
        bias = next_bias
        command_q = next_command

    raise AssertionError("unreachable endpoint convergence state")


def run_capture_process_while_holding(
    arm,
    q_hold,
    *,
    wrist_config_path: str | Path,
    vision_config_path: str | Path,
    run_dir: str | Path,
    capture_label: str,
    timeout_s: float,
    label: str,
    hold_hz: float,
    velocity_guard_hz: float,
    temperature_period_s: float,
    camera_attempts: int,
    camera_retry_delay_s: float,
    capture_quality_override: dict,
    write_raw_capture_previews: bool,
    search_full_frame_on_miss: bool = False,
) -> tuple[object, list[float]]:
    """Hold S1 at low serial load while RGB-D runs in a spawn process."""
    trace = getattr(arm, "_position_commander", None)
    if isinstance(trace, CommandTrace):
        trace.phase = label
    timeout_s = float(timeout_s)
    if not math.isfinite(timeout_s) or timeout_s <= 0.0:
        raise ValueError("capture process timeout must be positive and finite")
    hold_hz = float(hold_hz)
    velocity_guard_hz = float(velocity_guard_hz)
    temperature_period_s = float(temperature_period_s)
    if not math.isfinite(hold_hz) or hold_hz <= 0.0:
        raise ValueError("capture hold_hz must be positive and finite")
    if not math.isfinite(velocity_guard_hz) or velocity_guard_hz <= 0.0:
        raise ValueError("capture velocity_guard_hz must be positive and finite")
    if not math.isfinite(temperature_period_s) or temperature_period_s <= 0.0:
        raise ValueError("capture temperature_period_s must be positive and finite")
    command_period_s = 1.0 / hold_hz
    velocity_period_s = 1.0 / velocity_guard_hz

    run_dir = Path(run_dir)
    result_path = run_dir / f"{capture_label}_process_result.json"
    # Read slow-changing guards before RealSense starts using the VM USB stack.
    cached_velocity = list(arm.get_vel())
    cached_temperature = list(arm.get_temp())
    context = multiprocessing.get_context("spawn")
    process = context.Process(
        target=capture_process_entry,
        args=(
            str(wrist_config_path),
            str(vision_config_path),
            str(run_dir),
            str(capture_label),
            str(result_path),
            int(camera_attempts),
            float(camera_retry_delay_s),
            dict(capture_quality_override),
            bool(write_raw_capture_previews),
            bool(search_full_frame_on_miss),
        ),
        name=label,
        daemon=True,
    )
    process.start()
    print("VISION_PROCESS_STARTED =", label, "pid =", process.pid)
    print(
        "CAPTURE_HOLD_PROFILE ="
        f" command={hold_hz:.1f}Hz"
        f" velocity={velocity_guard_hz:.1f}Hz"
        f" temperature_period={temperature_period_s:.1f}s"
        f" camera_attempts={int(camera_attempts)}"
        f" raw_previews_before_detection={bool(write_raw_capture_previews)}"
    )
    started = time.monotonic()
    next_velocity_read = started + velocity_period_s
    next_temperature_read = started + temperature_period_s
    measured = []
    command_count = 0
    velocity_read_count = 1
    temperature_read_count = 1
    try:
        while process.is_alive():
            cycle = time.monotonic()
            arm.command_position(q_hold)
            command_count += 1
            position = measured_position_from_commander(arm)
            measured.append(position[:6])
            now = time.monotonic()
            if now >= next_velocity_read:
                cached_velocity = list(arm.get_vel())
                velocity_read_count += 1
                next_velocity_read = now + velocity_period_s
            if now >= next_temperature_read:
                cached_temperature = list(arm.get_temp())
                temperature_read_count += 1
                next_temperature_read = now + temperature_period_s
            fault = arm.guard(
                position,
                cached_velocity,
                cached_temperature,
                list(q_hold),
                settling=(now - started) < arm.limits.settle_seconds,
            )
            if fault:
                raise RuntimeError(f"{label}: {fault}")
            elapsed_s = now - started
            if elapsed_s > timeout_s:
                raise TimeoutError(
                    f"{label} exceeded {timeout_s:.3f}s; spawned worker will be "
                    "terminated before recovery"
                )
            time.sleep(max(0.0, command_period_s - (time.monotonic() - cycle)))
        process.join(timeout=0.0)
    except BaseException:
        terminate_spawn_worker(process, label)
        raise

    if process.exitcode not in (0, None):
        raise RuntimeError(f"{label}: spawned worker exitcode={process.exitcode}")
    result = load_spawn_worker_result(result_path, label)
    if not measured:
        measured.append(list(arm.get_pos())[:6])
    final_fault = arm.guard(
        measured[-1],
        list(arm.get_vel()),
        list(arm.get_temp()),
        list(q_hold),
        settling=False,
    )
    if final_fault:
        raise RuntimeError(f"{label}: post-capture {final_fault}")
    median_q = [
        statistics.median(row[index] for row in measured) for index in range(6)
    ]
    print(
        "VISION_PROCESS_DONE =",
        label,
        "elapsed_s =",
        round(time.monotonic() - started, 3),
    )
    print(
        "CAPTURE_HOLD_COUNTS ="
        f" commands={command_count}"
        f" velocity_reads={velocity_read_count + 1}"
        f" temperature_reads={temperature_read_count + 1}"
    )
    return result, median_q


def run_worker_while_holding(
    arm, q_hold, worker, *, timeout_s: float, label: str
) -> tuple[object, list[float]]:
    trace = getattr(arm, "_position_commander", None)
    if isinstance(trace, CommandTrace):
        trace.phase = label
    state = {"result": None, "error": None}

    def invoke():
        try:
            state["result"] = worker()
        except BaseException as exc:
            state["error"] = exc

    timeout_s = float(timeout_s)
    if not math.isfinite(timeout_s) or timeout_s <= 0.0:
        raise ValueError("worker timeout must be positive and finite")

    thread = threading.Thread(target=invoke, name=label, daemon=True)
    thread.start()
    started = time.monotonic()
    measured = []
    soft_timeout_exceeded = False
    while thread.is_alive():
        cycle = time.monotonic()
        arm.command_position(q_hold)
        position = list(arm.get_pos())
        measured.append(position[:6])
        fault = arm.guard(
            position,
            arm.get_vel(),
            arm.get_temp(),
            list(q_hold),
            settling=(time.monotonic() - started) < arm.limits.settle_seconds,
        )
        if fault:
            raise RuntimeError(f"{label}: {fault}")
        elapsed_s = time.monotonic() - started
        if elapsed_s > timeout_s and not soft_timeout_exceeded:
            soft_timeout_exceeded = True
            print(
                "WORKER_SOFT_TIMEOUT ="
                f" {label} exceeded {timeout_s:.3f}s;"
                " holding pose until the worker releases its resources"
            )
        time.sleep(max(0.0, arm.dt - (time.monotonic() - cycle)))
    thread.join(timeout=0.0)
    if state["error"] is not None:
        raise state["error"]
    elapsed_s = time.monotonic() - started
    if soft_timeout_exceeded:
        raise TimeoutError(
            f"{label} finished after {elapsed_s:.3f}s, exceeding {timeout_s:.3f}s; "
            "worker resources were released before recovery"
        )
    if not measured:
        measured.append(list(arm.get_pos())[:6])
    median_q = [
        statistics.median(row[index] for row in measured) for index in range(6)
    ]
    return state["result"], median_q


def _geom_only_contact_pair(pair) -> tuple[str, str]:
    """Strip diagnostic link suffixes from a reported collision pair."""
    return tuple(
        sorted(str(item).split(" (link=", 1)[0] for item in pair)
    )


def final_contact_is_explicitly_allowed(
    active,
    floor,
    allowed_final_contacts,
    *,
    is_final_endpoint: bool,
) -> bool:
    """Allow only a bound model contact at the exact final endpoint."""
    if floor or not active or not is_final_endpoint:
        return False
    allowed = {
        tuple(sorted(str(item) for item in pair))
        for pair in (allowed_final_contacts or [])
    }
    if not allowed:
        return False
    active_geom_pairs = {_geom_only_contact_pair(pair) for pair in active}
    return active_geom_pairs.issubset(allowed)


def check_collision_path(
    checker,
    joint_path,
    step_rad: float,
    *,
    allowed_final_contacts=None,
) -> dict:
    from check_cube_hover_path import collision_at, interpolate

    sample_count = 0
    excluded_count = 0
    allowed_final_contact_count = 0
    segment_count = max(0, len(joint_path) - 1)
    for segment, (q_from, q_to) in enumerate(zip(joint_path, joint_path[1:]), start=1):
        samples = list(interpolate(q_from, q_to, step_rad))
        for sample_index, (_, q) in enumerate(samples):
            sample_count += 1
            active, excluded, floor = collision_at(checker, q)
            excluded_count += len(excluded)
            if active or floor:
                is_final_endpoint = (
                    segment == segment_count
                    and sample_index == len(samples) - 1
                )
                if final_contact_is_explicitly_allowed(
                    active,
                    floor,
                    allowed_final_contacts,
                    is_final_endpoint=is_final_endpoint,
                ):
                    allowed_final_contact_count += 1
                    continue
                raise RuntimeError(
                    f"alignment collision at segment {segment}: "
                    f"active={sorted(active)} floor={sorted(floor)}"
                )
    return {
        "sample_count": sample_count,
        "excluded_contact_count": excluded_count,
        "allowed_final_contact_count": allowed_final_contact_count,
        "active_collision_count": 0,
        "floor_contact_count": 0,
    }


def append_executed_path(route, segment):
    """Join nonempty executed paths, recording their shared endpoint once."""
    first = 1 if route[-1] == segment[0] else 0
    route.extend(list(q) for q in segment[first:])


def nearest_recovery_path(current_q, outbound_path) -> list[list[float]]:
    current = np.asarray(current_q, dtype=float)
    path = [np.asarray(q, dtype=float) for q in outbound_path]
    index = min(range(len(path)), key=lambda item: float(np.linalg.norm(path[item] - current)))
    recovery = [current.tolist()]
    recovery.extend(q.tolist() for q in reversed(path[: index + 1]))
    return recovery


def build_segmented_recovery_path(
    current_q,
    waypoints,
    maximum_joint_step_rad: float,
) -> list[list[float]]:
    """Prepend fresh feedback, remove duplicates and densify a fault return."""
    current = np.asarray(current_q, dtype=float)
    if current.shape != (6,) or not np.all(np.isfinite(current)):
        raise ValueError("recovery current_q must contain six finite joints")
    maximum_joint_step_rad = float(maximum_joint_step_rad)
    if (
        not math.isfinite(maximum_joint_step_rad)
        or not 0.0 < maximum_joint_step_rad <= 0.04
    ):
        raise ValueError("recovery joint step must be in (0, 0.04]rad")

    compact = [current.tolist()]
    for raw in waypoints:
        point = np.asarray(raw, dtype=float)
        if point.shape != (6,) or not np.all(np.isfinite(point)):
            raise ValueError("recovery waypoint must contain six finite joints")
        if float(np.max(np.abs(point - np.asarray(compact[-1])))) > 1e-9:
            compact.append(point.tolist())
    if len(compact) == 1:
        return compact
    return [
        [float(value) for value in point]
        for point in densify_joint_path(compact, maximum_joint_step_rad)
    ]


class SegmentedRecoveryError(RuntimeError):
    """Fault recovery stopped, with its completed-step record retained."""

    def __init__(self, message: str, record: dict):
        super().__init__(message)
        self.record = record


def execute_segmented_recovery(
    arm,
    waypoints,
    *,
    label: str,
    collision_checker,
    collision_step_rad: float,
    maximum_joint_step_rad: float,
    v_max_rad_s: float,
    j6_v_max_rad_s: float,
    allowed_final_contacts=None,
    progress_callback=None,
    continuous_path: bool = False,
) -> dict:
    """Return over checked geometry; optional continuous timing avoids per-step stops."""
    start_q = measured_position_from_commander(arm)
    path = build_segmented_recovery_path(
        start_q, waypoints, maximum_joint_step_rad
    )
    record = {
        "status": "started",
        "label": str(label),
        "start_measured_q_rad": list(start_q),
        "maximum_joint_step_rad": float(maximum_joint_step_rad),
        "v_max_rad_s": float(v_max_rad_s),
        "j6_v_max_rad_s": float(j6_v_max_rad_s),
        "planned_step_count": max(0, len(path) - 1),
        "steps": [],
    }

    def publish():
        if progress_callback is not None:
            progress_callback(record)

    old_v_max = float(arm.limits.v_max_rad_s)
    old_j6_v_max = float(arm.limits.j6_v_max_rad_s)
    arm.limits.v_max_rad_s = float(v_max_rad_s) if continuous_path else min(old_v_max, float(v_max_rad_s))
    arm.limits.j6_v_max_rad_s = float(j6_v_max_rad_s) if continuous_path else min(old_j6_v_max, float(j6_v_max_rad_s))
    try:
        publish()
        if continuous_path:
            record["execution_mode"] = "continuous_checked_return"
            record["collision"] = check_collision_path(
                collision_checker, path, float(collision_step_rad),
                allowed_final_contacts=allowed_final_contacts,
            )
            publish()
            fault = arm.move_waypoints(path, label) if len(path) > 1 else None
            record["final_measured_q_rad"] = measured_position_from_commander(arm)
            record["status"] = "rejected_motion_guard" if fault else "completed"
            record["fault"] = fault
            publish()
            if fault:
                raise SegmentedRecoveryError(str(fault), record)
            return record
        for index, target_q in enumerate(path[1:], start=1):
            measured_q = measured_position_from_commander(arm)
            collision = check_collision_path(
                collision_checker,
                [measured_q, target_q],
                float(collision_step_rad),
                allowed_final_contacts=(
                    allowed_final_contacts
                    if index == len(path) - 1
                    else None
                ),
            )
            step_record = {
                "index": index,
                "start_measured_q_rad": list(measured_q),
                "target_q_rad": list(target_q),
                "maximum_command_delta_rad": max_joint_delta(
                    measured_q, target_q
                ),
                "collision": collision,
            }
            record["steps"].append(step_record)
            publish()
            fault = arm.move(
                measured_q,
                target_q,
                f"{label}_step_{index:03d}",
            )
            step_record["end_measured_q_rad"] = (
                measured_position_from_commander(arm)
            )
            step_record["fault"] = fault
            publish()
            if fault:
                record["status"] = "rejected_motion_guard"
                publish()
                raise SegmentedRecoveryError(str(fault), record)
        record["status"] = "completed"
        record["final_measured_q_rad"] = measured_position_from_commander(arm)
        publish()
        return record
    finally:
        arm.limits.v_max_rad_s = old_v_max
        arm.limits.j6_v_max_rad_s = old_j6_v_max


def hold_for_operator_support_before_disable(
    arm,
    *,
    timeout_s: float,
    command_hz: float,
    gripper=None,
    grip_gap_mm: float | None = None,
    grip_force: float | None = None,
    prompt: str = "AUTOMATIC_RETURN_FAILED: support the arm, then input s: ",
    non_interactive: bool = False,
) -> dict:
    """Keep the measured pose while the operator supports the arm before disable."""
    timeout_s = float(timeout_s)
    command_hz = float(command_hz)
    if not 5.0 <= timeout_s <= 30.0:
        raise ValueError("operator support timeout must be within [5, 30]s")
    if not 5.0 <= command_hz <= 20.0:
        raise ValueError("operator support command rate must be within [5, 20]Hz")
    if (gripper is None) != (grip_gap_mm is None):
        raise ValueError("gripper and grip_gap_mm must be provided together")

    hold_q = measured_position_from_commander(arm)
    response = {"value": None, "error": None}

    def read_confirmation():
        try:
            response["value"] = input(prompt).strip().lower()
        except BaseException as exc:
            response["error"] = repr(exc)

    reader = threading.Thread(
        target=read_confirmation,
        name="operator_support_confirmation",
        daemon=True,
    )
    if not non_interactive:
        reader.start()
    started = time.monotonic()
    period_s = 1.0 / command_hz
    guard_fault = None
    command_count = 0
    velocity = arm.get_vel()
    temperature = arm.get_temp()
    next_velocity_read = started + 0.5
    next_temperature_read = started + 2.0
    while (non_interactive or reader.is_alive()) and time.monotonic() - started < timeout_s:
        cycle = time.monotonic()
        arm.command_position(hold_q)
        if gripper is not None:
            gripper.command_mm(grip_gap_mm, force=grip_force)
        command_count += 1
        measured_q = measured_position_from_commander(arm)
        now = time.monotonic()
        if now >= next_velocity_read:
            velocity = arm.get_vel()
            next_velocity_read = now + 0.5
        if now >= next_temperature_read:
            temperature = arm.get_temp()
            next_temperature_read = now + 2.0
        guard_fault = arm.guard(
            measured_q,
            velocity,
            temperature,
            hold_q,
            settling=False,
        )
        if guard_fault:
            print("OPERATOR_SUPPORT_HOLD_WARNING =", guard_fault)
            break
        time.sleep(max(0.0, period_s - (time.monotonic() - cycle)))

    confirmed = response["value"] == "s"
    timed_out = (non_interactive or reader.is_alive()) and guard_fault is None
    print(
        "OPERATOR_SUPPORT_BEFORE_DISABLE =",
        "CONFIRMED" if confirmed else "NOT_CONFIRMED",
    )
    return {
        "hold_q_rad": list(hold_q),
        "timeout_s": timeout_s,
        "command_hz": command_hz,
        "command_count": command_count,
        "confirmed": confirmed,
        "timed_out": timed_out,
        "guard_fault": guard_fault,
        "input_error": response["error"],
        "gripper_hold_active": gripper is not None,
        "grip_gap_mm": float(grip_gap_mm) if grip_gap_mm is not None else None,
    }


def compute_observation(
    capture_result,
    q_observed,
    *,
    loaded,
    flange_kinematics,
    observation_safety=None,
) -> dict:
    detection = capture_result["detection"]
    if detection.get("status") == "NO_TARGET" and detection.get("candidates"):
        candidates = list(detection["candidates"])
        best = max(candidates, key=lambda item: int(item.get("area_px", 0)))
        reject_reasons = sorted(
            {
                str(reason)
                for candidate in candidates
                for reason in candidate.get("reject_reasons", [])
            }
        )
        core_depth_ratio = best.get("core_depth_valid_ratio")
        print(
            "TARGET_CANDIDATE_REJECTED ="
            f" component={best.get('component_id')}"
            f" area_px={best.get('area_px')}"
            f" core_depth_valid_ratio={core_depth_ratio}"
            f" reasons={reject_reasons}"
        )
        raise ValueError(
            "single-target candidate was found but rejected: "
            + ",".join(reject_reasons)
        )
    flange_pose = flange_kinematics.fk(q_observed)
    transform_base_camera = dynamic_base_camera(
        flange_pose, loaded.transform_flange_camera
    )
    observation = extract_single_surface_observation(
        detection,
        capture_result["capture_metadata"],
        transform_base_camera,
        loaded.record["camera_serial"],
        observation_safety or loaded.record["safety"],
    )
    return {
        "q_observed_rad": list(q_observed),
        "flange_pose_xyz_xyzw": flange_pose,
        "T_base_camera": transform_base_camera.tolist(),
        "observation": observation,
    }


def compute_alignment_plan(
    observation_record,
    *,
    planning_start_q_rad=None,
    loaded,
    alignment,
    tcp_kinematics,
    collision_checker,
    tilt_model,
    applied_support_up,
    side_scale,
    torque_limits,
    approach_orientation=None,
    force_correction: bool = False,
) -> dict:
    capture_q = np.asarray(observation_record["q_observed_rad"], dtype=float)
    planning_q = np.asarray(
        capture_q if planning_start_q_rad is None else planning_start_q_rad,
        dtype=float,
    )
    if capture_q.shape != (6,) or not np.all(np.isfinite(capture_q)):
        raise ValueError("observation capture joints must contain six finite values")
    if planning_q.shape != (6,) or not np.all(np.isfinite(planning_q)):
        raise ValueError("planning start joints must contain six finite values")
    observation = observation_record["observation"]
    tcp_before = tcp_kinematics.fk(planning_q.tolist())
    cartesian_path = build_tangent_tcp_path(
        tcp_before,
        observation["surface_point_base_m"],
        observation["support_up_normal_base"],
        maximum_initial_error_mm=alignment["maximum_initial_tangent_error_mm"],
        convergence_mm=float(alignment["success_tangent_error_mm"]),
        force_correction=force_correction,
        maximum_cartesian_step_mm=float(alignment["maximum_cartesian_step_mm"]),
        minimum_clearance_mm=float(loaded.record["safety"]["minimum_target_clearance_mm"]),
        maximum_clearance_mm=float(loaded.record["safety"]["maximum_target_clearance_mm"]),
        workspace=loaded.record["validated_workspace"],
    )
    if approach_orientation is not None:
        quaternion, maximum_step_deg = approach_orientation
        start_pose = np.asarray(tcp_before)
        end_position = np.asarray(cartesian_path["tcp_poses_xyz_xyzw"][-1][:3])
        segments = max(
            cartesian_path["segment_count"],
            math.ceil(quaternion_error_deg(start_pose[3:], quaternion) / maximum_step_deg),
        )
        poses = []
        for index in range(segments + 1):
            fraction = index / segments
            position = start_pose[:3] + fraction * (end_position - start_pose[:3])
            rotation = quaternion_slerp(start_pose[3:], quaternion, fraction)
            poses.append(np.r_[position, rotation].tolist())
        cartesian_path.update(
            tcp_poses_xyz_xyzw=poses, segment_count=segments, converged=False
        )
    result = {
        **observation_record,
        "observation_capture_q_rad": capture_q.tolist(),
        "planning_start_q_rad": planning_q.tolist(),
        "planning_start_rebased_after_support_normal": bool(
            planning_start_q_rad is not None
        ),
        "tcp_pose_before_xyz_xyzw": tcp_before,
        "cartesian_path": cartesian_path,
        "ik_path": None,
        "collision": None,
        "torque": None,
    }
    if cartesian_path["converged"]:
        result["alignment_joint_path"] = [planning_q.tolist()]
        return result

    ik_path = solve_continuous_ik_path(
        tcp_kinematics,
        planning_q.tolist(),
        cartesian_path["tcp_poses_xyz_xyzw"],
        maximum_joint_step_rad=float(alignment["maximum_joint_step_rad"]),
        minimum_joint_margin_deg=float(alignment["minimum_joint_margin_deg"]),
        maximum_fk_position_error_mm=float(alignment["maximum_fk_position_error_mm"]),
        maximum_fk_orientation_error_deg=float(alignment["maximum_fk_orientation_error_deg"]),
    )
    alignment_path = ik_path["joint_path"]
    collision = check_collision_path(
        collision_checker,
        alignment_path,
        float(alignment["collision_step_rad"]),
    )
    torque_samples = densify_joint_path(
        alignment_path, float(alignment["collision_step_rad"])
    )
    torque = validate_torque_envelope(
        torque_samples,
        lambda q: side_scale
        * differential_tilt_compensation_from_support_up(
            tilt_model, q, applied_support_up
        ),
        torque_limits,
    )
    result.update(
        {
            "ik_path": ik_path,
            "alignment_joint_path": alignment_path,
            "collision": collision,
            "torque": torque,
        }
    )
    return result


def compute_flexible_grasp_approach(
    observation_record, capture, *, alignment_options, flange_kinematics,
    observation_safety, orientation_config, pregrasp_config, secure_config,
    check_body,
):
    """Try alternative approach tilts with square-symmetric closing directions."""
    observation = observation_record["observation"]
    target = np.asarray(observation["surface_point_base_m"])
    normal = np.asarray(observation["support_up_normal_base"])
    normal = normal / np.linalg.norm(normal)
    outward = target - (target @ normal) * normal
    outward = outward / np.linalg.norm(outward)
    tangent = np.cross(normal, outward)
    edge = np.asarray(observation["target_edge_axis_base"])
    tcp = alignment_options["tcp_kinematics"]
    start_pose = tcp.fk(alignment_options["planning_start_q_rad"])
    maximum_lean_deg = float(
        orientation_config["maximum_approach_tilt_from_support_down_deg"]
    )
    candidates = []
    for lean_deg, heading_deg in ((6.0, 45.0), (12.0, -90.0)):
        if lean_deg > maximum_lean_deg:
            continue
        lean_rad = math.radians(lean_deg)
        heading_rad = math.radians(heading_deg)
        direction = math.cos(heading_rad) * outward + math.sin(heading_rad) * tangent
        approach = -math.cos(lean_rad) * normal + math.sin(lean_rad) * direction
        closing = edge - (edge @ approach) * approach
        closing /= np.linalg.norm(closing)
        reference_quat = rotation_matrix_to_quaternion(
            np.column_stack((approach, closing, np.cross(approach, closing)))
        )
        variants = square_grasp_orientation_candidates(
            [*start_pose[:3], *reference_quat],
            edge, normal,
            maximum_approach_tilt_from_support_down_deg=maximum_lean_deg,
        )
        variants.sort(key=lambda candidate: quaternion_error_deg(
            start_pose[3:], candidate["target_quaternion_xyzw"]
        ))
        candidates.extend((lean_deg, heading_deg, variant) for variant in variants)
    pregrasp, _ = resolve_adaptive_pregrasp_config(capture, pregrasp_config)
    secure, _ = resolve_adaptive_secure_no_lift_config(capture, secure_config)
    descent_options = {
        key: alignment_options[key]
        for key in (
            "alignment", "tcp_kinematics", "collision_checker",
            "tilt_model", "applied_support_up", "torque_limits",
        )
    }
    rejected = {}
    for lean_deg, heading_deg, candidate in candidates:
        quaternion = candidate["target_quaternion_xyzw"]
        try:
            plan = compute_alignment_plan(
                observation_record, **alignment_options,
                approach_orientation=(
                    quaternion, float(orientation_config["maximum_orientation_step_deg"])
                ),
            )
            path = plan["alignment_joint_path"]
            plan["alignment_body_check"] = check_body(path)
            endpoint = path[-1]
            camera = dynamic_base_camera(
                flange_kinematics.fk(endpoint),
                alignment_options["loaded"].transform_flange_camera,
            )
            camera_tilt = math.degrees(math.acos(float(np.clip(
                camera[:3, 2] @ (-normal), -1.0, 1.0
            ))))
            depth_mm = 1000.0 * float((target - camera[:3, 3]) @ camera[:3, 2])
            if (
                camera_tilt > float(observation_safety["maximum_camera_tilt_from_down_deg"])
                or not float(observation_safety["minimum_camera_target_depth_mm"])
                <= depth_mm <= float(observation_safety["maximum_camera_target_depth_mm"])
            ):
                raise RuntimeError("planned high-view endpoint outside existing camera geometry")
            descent_evidence = []
            for settings, scale_key in (
                (pregrasp, "pregrasp_descent_compensation_scale"),
                (secure, "low_stage_compensation_scale"),
            ):
                descent = compute_safe_descent_plan(
                    endpoint, observation, descent_config=settings,
                    side_scale=float(secure_config[scale_key]), **descent_options,
                )
                endpoint = descent["joint_path"][-1]
                descent_evidence.append({
                    "distance_mm": descent["descent_distance_mm"],
                    "minimum_joint_margin_deg": min(
                        joint_margin_deg(q) for q in descent["joint_path"]
                    ),
                })
            plan["flexible_approach"] = {
                "closing_direction": candidate["name"],
                "tool_lean_deg": candidate["approach_tilt_from_support_down_deg"],
                "lean_heading_deg": heading_deg,
                "camera_tilt_deg": camera_tilt,
                "camera_target_depth_mm": depth_mm,
                "descent_preview": descent_evidence,
            }
            return plan
        except (ValueError, RuntimeError) as exc:
            rejected[f"{lean_deg:g}deg/{candidate['name']}"] = str(exc)
    raise RuntimeError(f"no verified flexible approach: {rejected}")



def reuse_tracked_high_view_geometry(capture, q_observed, prior_capture, prior_observation,
                                    *, loaded, flange_kinematics):
    """Locate the same visible target using its last measured height and current plane."""
    import copy
    import cv2
    from demo_grasp.detect_science_target_rgbd import load_capture,estimate_square_orientation,_project_orientation_axis_to_pixels
    detection=capture["detection"]
    previous=(prior_capture.get("detection") or {}).get("selected")
    if (detection.get("status")!="NO_TARGET" or not previous
            or not previous.get("accepted") or not detection.get("plane",{}).get("quality_pass")):
        return False
    cfg,_=load_vision_config(loaded.vision_config_path)
    old_frame=load_capture(resolve_project_path(prior_capture["capture_path"]))
    frame=load_capture(resolve_project_path(capture["capture_path"]))
    x,y,w,h=map(int,previous["bbox_px"])
    old_lab=cv2.cvtColor(old_frame["rgb"],cv2.COLOR_RGB2LAB).astype(float)[:,:,1:]
    colors=old_lab[y+h//4:y+3*h//4,x+w//4:x+3*w//4].reshape(-1,2)
    center=np.median(colors,axis=0)
    radius=max(10.,1.5*float(np.percentile(np.linalg.norm(colors-center,axis=1),95)))
    lab=cv2.cvtColor(frame["rgb"],cv2.COLOR_RGB2LAB).astype(float)[:,:,1:]
    mask=(np.linalg.norm(lab-center,axis=2)<=radius).astype(np.uint8)
    count,labels,stats,_=cv2.connectedComponentsWithStats(mask,connectivity=8)
    T=dynamic_base_camera(flange_kinematics.fk(q_observed),loaded.transform_flange_camera)
    predicted=np.linalg.inv(T)@np.r_[prior_observation["surface_point_base_m"],1.]
    K=frame["K"]
    pixel=(K@predicted[:3]);pixel=pixel[:2]/pixel[2]
    plane=detection["plane"];normal=np.asarray(plane["normal_cam"],float)
    height=copy.deepcopy(previous["core_height_mm"])
    candidates=[]
    for label in range(1,count):
        bx,by,bw,bh,area=map(int,stats[label])
        component_cfg=cfg["component"]
        if not (bx<=pixel[0]<bx+bw and by<=pixel[1]<by+bh):
            continue
        # The legacy area cap measures depth pixels, not a completed RGB face.
        # Keep the existing RGB extent and orientation tests for the contour.
        if (area<component_cfg["min_area_px"]
                or min(bw,bh)<component_cfg["min_bbox_side_px"]
                or max(bw,bh)>component_cfg["max_bbox_side_px"]):
            continue
        yy,xx=np.nonzero(labels==label)
        rays=np.column_stack(((xx-K[0,2])/K[0,0],(yy-K[1,2])/K[1,1],np.ones(len(xx))))
        distance=(float(height["median"])/1000-float(plane["offset_m"]))/(rays@normal)
        points=rays*distance[:,None]
        orientation,reasons=estimate_square_orientation(points,normal,cfg["orientation"])
        if reasons:
            continue
        confidence=min(float(previous["confidence_score"]),float(orientation["confidence_score"]))
        if confidence<float(cfg["target"]["min_confidence_score"]):
            continue
        point=np.mean(points,axis=0)
        orientation["axis_endpoints_px"]=_project_orientation_axis_to_pixels(
            point,orientation["axis_cam"],min(orientation["rectangle_side_lengths_mm"])/1000,K)
        original=next((c for c in detection.get("candidates",[]) if
            c["bbox_px"][0]<=float(np.mean(xx))<c["bbox_px"][0]+c["bbox_px"][2]
            and c["bbox_px"][1]<=float(np.mean(yy))<c["bbox_px"][1]+c["bbox_px"][3]),{})
        target=copy.deepcopy(previous)
        target.update(bbox_px=[bx,by,bw,bh],area_px=original.get("area_px",0),contour_area_px=area,
            centroid_px=[float(K[0,0]*point[0]/point[2]+K[0,2]),float(K[1,1]*point[1]/point[2]+K[1,2])],
            surface_point_cam_m=point.tolist(),core_height_mm=height,orientation=orientation,
            confidence_score=confidence,reject_reasons=[],accepted=True,
            core_depth_region_corners_px=original.get("core_depth_region_corners_px"),
            core_pixels=original.get("core_pixels",0),
            core_depth_valid_ratio=original.get("core_depth_valid_ratio",0),
            geometry_reuse={"source":"same_task_prior_height_current_rgb_and_ground_plane",
                "prior_capture_path":str(prior_capture["capture_path"]),
                "current_capture_path":str(capture["capture_path"]),
                "current_depth_reject_reasons":original.get("reject_reasons",[]),
                "height_measurement_reused":True,"position_and_direction_recomputed":True,
                "predicted_pixel_xy":pixel.tolist(),"height_mm":height["median"]})
        candidates.append(target)
    if len(candidates)!=1:
        return False
    target=candidates[0]
    capture["geometry_reuse"]=target["geometry_reuse"]
    capture["detection"]={**detection,"status":"DETECTED_CAMERA_FRAME_ONLY",
        "depth_source":"prior_measured_target_height_current_rgb_ground_plane",
        "selected":target,"accepted_targets":[target],"accepted_candidate_count":1,
        "candidates":[target],"reasons":[],"geometry_reuse":target["geometry_reuse"]}
    from demo_grasp.detect_science_target_rgbd import save_preview,save_result
    current_path=resolve_project_path(capture["capture_path"])
    recovered_json=current_path.with_name(current_path.stem+"_tracked_geometry.json")
    recovered_preview=current_path.with_name(current_path.stem+"_tracked_geometry.png")
    capture["geometry_reuse"]["recovered_preview_path"]=str(recovered_preview)
    capture["geometry_reuse"]["recovered_detection_path"]=str(recovered_json)
    save_result(capture["detection"],recovered_json)
    save_preview(frame["rgb"],capture["detection"],recovered_preview)
    print("TRACKED_TARGET_GEOMETRY_REUSED =",target["geometry_reuse"])
    return True


def compute_final_check(
    capture_result,
    q_observed,
    *,
    loaded,
    alignment,
    flange_kinematics,
    tcp_kinematics,
    observation_safety=None,
    prior_capture=None,
    prior_observation=None,
) -> dict:
    if prior_capture is not None and prior_observation is not None:
        reuse_tracked_high_view_geometry(capture_result,q_observed,prior_capture,prior_observation,
            loaded=loaded,flange_kinematics=flange_kinematics)
    observation_record = compute_observation(
        capture_result,
        q_observed,
        loaded=loaded,
        flange_kinematics=flange_kinematics,
        observation_safety=observation_safety,
    )
    final_tcp = tcp_kinematics.fk(q_observed)
    observation = observation_record["observation"]
    check = build_tangent_tcp_path(
        final_tcp,
        observation["surface_point_base_m"],
        observation["support_up_normal_base"],
        maximum_initial_error_mm=alignment["maximum_initial_tangent_error_mm"],
        convergence_mm=float(alignment["success_tangent_error_mm"]),
        maximum_cartesian_step_mm=float(alignment["maximum_cartesian_step_mm"]),
        minimum_clearance_mm=float(loaded.record["safety"]["minimum_target_clearance_mm"]),
        maximum_clearance_mm=float(loaded.record["safety"]["maximum_target_clearance_mm"]),
        workspace=loaded.record["validated_workspace"],
    )
    return {
        **observation_record,
        "tcp_pose_xyz_xyzw": final_tcp,
        "check": check,
    }


def run_post_orientation_centering(
    arm, q_hold, *, capture, loaded, alignment, tcp_kinematics,
    flange_kinematics, collision_checker, tilt_model, commander, tilt_config,
    torque_limits, runtime, observation_safety, executed_alignment_path,
    record, save_progress,
):
    """Reuse high-view centering after yaw, preserving the final tool direction."""
    record.update(status="observing", reference_source="fresh_post_orientation_high_view")
    save_progress()
    capture_result, capture_q = capture("post_orientation", q_hold)
    checked, _ = run_worker_while_holding(
        arm, q_hold,
        lambda: compute_final_check(
            capture_result, capture_q, loaded=loaded, alignment=alignment,
            flange_kinematics=flange_kinematics, tcp_kinematics=tcp_kinematics,
            observation_safety=observation_safety),
        timeout_s=float(runtime["worker_timeout_s"]), label="post_orientation_observation")
    observation = checked["observation"]
    record.update(initial_capture=capture_result, initial_observation=observation,
                  initial_check=checked["check"])
    commander.set_support_up_normal(
        observation["support_up_normal_base"], source="validated_support_plane:post_orientation")
    guarded_hold(arm, q_hold, float(tilt_config["normal_transition_s"]) + .25,
                 "post_orientation_support_normal_hold")
    start_q = measured_position_from_commander(arm)
    support_up = blended_support_up_normal(
        commander.nominal_support_up_normal_base, observation["support_up_normal_base"],
        float(tilt_config["support_normal_blend"]))
    plan, _ = run_worker_while_holding(
        arm, q_hold,
        lambda: compute_alignment_plan(
            checked, planning_start_q_rad=start_q, loaded=loaded, alignment=alignment,
            tcp_kinematics=tcp_kinematics, collision_checker=collision_checker,
            tilt_model=tilt_model, applied_support_up=support_up,
            side_scale=commander.compensation_scale, torque_limits=torque_limits),
        timeout_s=float(runtime["worker_timeout_s"]), label="post_orientation_center_planning")
    record.update(planning=plan, status="planned")
    save_progress()
    print("POST_ORIENTATION_CENTER_INITIAL_ERROR_MM =",
          round(plan["cartesian_path"]["initial_tangent_error_norm_mm"], 3))
    if plan["cartesian_path"]["converged"]:
        # No correction motion: reuse the accepted image and the settled-pose check.
        record.update(status="passed", observation_reused=True,
                      final_capture=capture_result, final_capture_q_rad=capture_q,
                      final_q_rad=start_q, final_observation=observation,
                      final_check=plan["cartesian_path"],
                      final_normal_clearance_drift_mm=abs(
                          plan["cartesian_path"]["normal_clearance_mm"]
                          - checked["check"]["normal_clearance_mm"]),
                      final_command_q_rad=list(q_hold))
        save_progress()
        print("POST_ORIENTATION_CENTER_OBSERVATION_REUSED = True")
        print("POST_ORIENTATION_CENTER_FINAL_ERROR_MM =",
              round(plan["cartesian_path"]["initial_tangent_error_norm_mm"], 3))
        print("POST_ORIENTATION_CENTER_PASS = True")
        return list(q_hold), start_q, capture_result, observation
    path, handoff = prepare_continuous_alignment_path_while_holding(
        arm, plan["alignment_joint_path"], label="post_orientation_center_handoff",
        timeout_s=float(runtime["worker_timeout_s"]),
        collision_checker=collision_checker, tilt_model=tilt_model,
        support_up_normal_base=support_up, compensation_scale=commander.compensation_scale,
        torque_limits=torque_limits, collision_step_rad=float(alignment["collision_step_rad"]),
        minimum_joint_margin_deg=float(alignment["minimum_joint_margin_deg"]),
        workspace=loaded.record["validated_workspace"], kinematics=tcp_kinematics,
        preserve_physical_offsets=True,
        maximum_offset_rad=float(runtime.get("maximum_learned_position_bias_rad", .05)),
        clip_learned_offset=alignment.get("clip_learned_offset", False))
    record.update(command_handoff=handoff, status="moving")
    save_progress()
    # Retain the checked correction in both normal and fault return routes.
    executed_alignment_path.extend([list(q) for q in path[1:]])
    trace = getattr(arm, "_position_commander", None)
    if isinstance(trace, CommandTrace):
        trace.phase = "post_orientation_center_alignment"
    fault = arm.move_waypoints(path, "post_orientation_center_alignment")
    if fault:
        raise RuntimeError(fault)
    q_hold = list(path[-1])
    sample_endpoint_hold(arm, q_hold, float(alignment["hold_after_alignment_s"]),
                         "post_orientation_center_hold")
    # The existing final visual check decides, using a fresh high-view image.
    final_capture, final_q = capture("post_orientation_final", q_hold)
    final_record, _ = run_worker_while_holding(
        arm, q_hold,
        lambda: compute_final_check(
            final_capture, final_q, loaded=loaded, alignment=alignment,
            flange_kinematics=flange_kinematics, tcp_kinematics=tcp_kinematics,
            observation_safety=observation_safety),
        timeout_s=float(runtime["worker_timeout_s"]), label="post_orientation_center_final_check")
    check = final_record["check"]
    normal_drift = abs(check["normal_clearance_mm"] - plan["cartesian_path"]["normal_clearance_mm"])
    passed = bool(check["converged"] and center_normal_drift_allowed(normal_drift, alignment))
    record.update(status="passed" if passed else "rejected", observation_reused=False,
                  final_capture=final_capture, final_capture_q_rad=final_q,
                  final_q_rad=final_q, final_observation=final_record["observation"],
                  final_check=check, final_normal_clearance_drift_mm=normal_drift,
                  final_command_q_rad=q_hold)
    save_progress()
    print("POST_ORIENTATION_CENTER_FINAL_ERROR_MM =", round(check["initial_tangent_error_norm_mm"], 3))
    print("POST_ORIENTATION_CENTER_PASS =", passed)
    if not passed:
        raise RuntimeError("post-orientation center alignment failed existing final geometry check")
    return q_hold, final_q, final_capture, final_record["observation"]


def compute_grasp_orientation_plan(
    start_q_rad,
    observation,
    *,
    config: dict,
    tcp_kinematics,
    collision_checker,
    tilt_model,
    applied_support_up,
    compensation_scale: float,
    torque_limits,
    allow_alternate_closing_direction=False,
) -> dict:
    """Plan a square-symmetric wrist orientation at fixed TCP."""
    start_q = np.asarray(start_q_rad, dtype=np.float64)
    if start_q.shape != (6,) or not np.isfinite(start_q).all():
        raise ValueError("grasp-orientation start joints must contain six finite values")
    required_orientation_fields = (
        "target_edge_axis_base",
        "orientation_symmetry_period_deg",
        "orientation_confidence_score",
        "orientation_p90_deviation_deg",
    )
    missing_orientation_fields = [
        key for key in required_orientation_fields if key not in observation
    ]
    if missing_orientation_fields:
        raise RuntimeError(
            "final high-view detection has no validated square orientation: "
            + ",".join(missing_orientation_fields)
        )
    confidence = float(observation["orientation_confidence_score"])
    p90_deviation = float(observation["orientation_p90_deviation_deg"])
    if confidence < float(config["minimum_orientation_confidence_score"]):
        raise RuntimeError(
            f"orientation confidence {confidence:.3f} is below "
            f"{float(config['minimum_orientation_confidence_score']):.3f}"
        )
    if p90_deviation > float(config["maximum_orientation_p90_deviation_deg"]):
        raise RuntimeError(
            f"orientation p90 deviation {p90_deviation:.3f}deg exceeds "
            f"{float(config['maximum_orientation_p90_deviation_deg']):.3f}deg"
        )
    if abs(float(observation["orientation_symmetry_period_deg"]) - 90.0) > 1e-6:
        raise RuntimeError("adaptive square grasp requires 90 degree symmetry")

    start_tcp = [float(value) for value in tcp_kinematics.fk(start_q.tolist())]
    geometry_candidates = square_grasp_orientation_candidates(
        start_tcp,
        observation["target_edge_axis_base"],
        observation["support_up_normal_base"],
        maximum_approach_tilt_from_support_down_deg=float(
            config["maximum_approach_tilt_from_support_down_deg"]
        ),
    )
    preferred_rotation_limit = float(config["maximum_rotation_deg"]) + 1e-6
    alternate = None
    if allow_alternate_closing_direction:
        geometry_candidates.sort(
            key=lambda geometry: geometry["rotation_from_current_deg"] > preferred_rotation_limit
        )
        alternate = min(
            (geometry for geometry in geometry_candidates
             if geometry["rotation_from_current_deg"] > preferred_rotation_limit),
            key=lambda geometry: geometry["rotation_from_current_deg"],
            default=None,
        )
    candidates = []
    rejected = []
    for geometry in geometry_candidates:
        name = str(geometry["name"])
        rotation_deg = float(geometry["rotation_from_current_deg"])
        if rotation_deg > preferred_rotation_limit and (geometry is not alternate or candidates):
            rejected.append(
                {"name": name, "reason": "rotation_exceeds_limit", "rotation_deg": rotation_deg}
            )
            continue
        try:
            tcp_path = build_fixed_position_orientation_path(
                start_tcp,
                geometry["target_quaternion_xyzw"],
                maximum_orientation_step_deg=float(
                    config["maximum_orientation_step_deg"]
                ),
            )
            ik = solve_continuous_ik_path(
                tcp_kinematics,
                start_q.tolist(),
                tcp_path,
                maximum_joint_step_rad=float(config["maximum_joint_step_rad"]),
                minimum_joint_margin_deg=float(config["minimum_joint_margin_deg"]),
                maximum_fk_position_error_mm=float(
                    config["maximum_fk_position_error_mm"]
                ),
                maximum_fk_orientation_error_deg=float(
                    config["maximum_fk_orientation_error_deg"]
                ),
            )
            joint_path = ik["joint_path"]
            collision = check_collision_path(
                collision_checker,
                joint_path,
                float(config["collision_step_rad"]),
            )
            dense = densify_joint_path(
                joint_path, float(config["collision_step_rad"])
            )
            torque = validate_torque_envelope(
                dense,
                lambda q: float(compensation_scale)
                * differential_tilt_compensation_from_support_up(
                    tilt_model, q, applied_support_up
                ),
                torque_limits,
            )
            final_tcp = np.asarray(
                tcp_kinematics.fk(joint_path[-1]), dtype=np.float64
            )
            planned_position_drift_mm = 1000.0 * float(
                np.linalg.norm(final_tcp[:3] - np.asarray(start_tcp[:3]))
            )
            if planned_position_drift_mm > float(
                config["maximum_planned_tcp_position_drift_mm"]
            ):
                raise RuntimeError(
                    f"planned TCP drift {planned_position_drift_mm:.3f}mm exceeds limit"
                )
            joint_travel = np.sum(
                np.abs(np.diff(np.asarray(joint_path), axis=0)), axis=0
            )
            speed = np.full(6, float(config["v_max_rad_s"]), dtype=np.float64)
            speed[5] = float(config["j6_v_max_rad_s"])
            duration_score = float(np.max(joint_travel / speed))
            minimum_margin = min(
                joint_margin_deg(q) for q in joint_path
            )
            candidate = {
                **geometry,
                "alternate_closing_direction": geometry is alternate,
                "tcp_path_xyz_xyzw": tcp_path,
                "joint_path": joint_path,
                "ik": ik,
                "collision": collision,
                "torque": torque,
                "planned_tcp_position_drift_mm": planned_position_drift_mm,
                "joint_travel_rad": joint_travel.tolist(),
                "j6_travel_rad": float(joint_travel[5]),
                "duration_score_s": duration_score,
                "minimum_joint_margin_deg": minimum_margin,
                "selection_key": [
                    duration_score,
                    float(joint_travel[5]),
                    float(np.sum(joint_travel)),
                    -minimum_margin,
                ],
            }
            candidates.append(candidate)
        except Exception as exc:
            rejected.append(
                {
                    "name": name,
                    "rotation_deg": rotation_deg,
                    "reason": f"{type(exc).__name__}: {exc}",
                }
            )
    if not candidates:
        raise RuntimeError(
            "no safe square-grasp orientation candidate: "
            + json.dumps(rejected, ensure_ascii=False)
        )
    selected = min(candidates, key=lambda value: tuple(value["selection_key"]))
    return {
        "status": "planned",
        "start_q_rad": start_q.tolist(),
        "start_tcp_pose_xyz_xyzw": start_tcp,
        "orientation_confidence_score": confidence,
        "orientation_p90_deviation_deg": p90_deviation,
        "target_edge_axis_base": list(observation["target_edge_axis_base"]),
        "candidates": candidates,
        "rejected_candidates": rejected,
        "selected": selected,
    }


def evaluate_grasp_orientation_endpoint(
    planned_q,
    measured_q,
    *,
    start_tcp_pose,
    target_quaternion,
    config: dict,
    tcp_kinematics,
    endpoint_window_range_rad=None,
    j6_checked_by_tool_orientation=False,
) -> dict:
    """Check arm tracking and tool pose, avoiding duplicate J6 yaw acceptance."""
    tracking = endpoint_tracking_record(planned_q, measured_q, tcp_kinematics)
    measured_tcp = tracking["measured_tcp_pose_xyz_xyzw"]
    start_position = np.asarray(start_tcp_pose[:3], dtype=np.float64)
    measured_position = np.asarray(measured_tcp[:3], dtype=np.float64)
    position_drift_mm = 1000.0 * float(
        np.linalg.norm(measured_position - start_position)
    )
    orientation_error_deg = quaternion_error_deg(
        measured_tcp[3:], target_quaternion
    )
    preferred_joint_error_limit = float(
        config["maximum_endpoint_joint_error_rad"]
    )
    fallback_joint_error_limit = float(
        config.get(
            "fallback_maximum_endpoint_joint_error_rad",
            preferred_joint_error_limit,
        )
    )
    arm_joint_error = float(np.max(np.abs(tracking["joint_error_rad"][:5])))
    measured_joint_error = (arm_joint_error if j6_checked_by_tool_orientation
                            else float(tracking["maximum_abs_joint_error_rad"]))
    tcp_position_passed = position_drift_mm <= float(
        config["maximum_endpoint_tcp_position_drift_mm"]
    )
    tool_orientation_passed = orientation_error_deg <= float(
        config["maximum_endpoint_orientation_error_deg"]
    )
    window_range = None
    maximum_window_range = None
    endpoint_window_stable = False
    if endpoint_window_range_rad is not None:
        window_range = np.asarray(
            endpoint_window_range_rad, dtype=np.float64
        )
        if window_range.shape != (6,) or not np.isfinite(window_range).all():
            raise ValueError(
                "endpoint window range must contain six finite values"
            )
        if np.any(window_range < 0.0):
            raise ValueError("endpoint window ranges must be non-negative")
        maximum_window_range = float(np.max(window_range))
        endpoint_window_stable = maximum_window_range <= float(
            config["maximum_endpoint_window_range_rad"]
        )
    stable_task_space_fallback = bool(
        measured_joint_error > preferred_joint_error_limit
        and measured_joint_error <= fallback_joint_error_limit
        and tcp_position_passed
        and tool_orientation_passed
        and endpoint_window_stable
    )
    reasons = []
    if (
        measured_joint_error > preferred_joint_error_limit
        and not stable_task_space_fallback
    ):
        reasons.append("joint_tracking_error_too_large")
    if not tcp_position_passed:
        reasons.append("tcp_position_drift_too_large")
    if not tool_orientation_passed:
        reasons.append("tool_orientation_error_too_large")
    if endpoint_window_range_rad is not None and not endpoint_window_stable:
        reasons.append("endpoint_window_not_stable")
    if measured_joint_error <= preferred_joint_error_limit:
        joint_error_gate = "preferred"
        applied_joint_error_limit = preferred_joint_error_limit
    elif stable_task_space_fallback:
        joint_error_gate = "stable_task_space_fallback"
        applied_joint_error_limit = fallback_joint_error_limit
    else:
        joint_error_gate = "rejected"
        applied_joint_error_limit = preferred_joint_error_limit
    return {
        "passed": not reasons,
        "tracking": tracking,
        "tcp_position_drift_mm": position_drift_mm,
        "orientation_error_deg": orientation_error_deg,
        "endpoint_window_range_rad": (
            None if window_range is None else window_range.tolist()
        ),
        "maximum_endpoint_window_range_rad": maximum_window_range,
        "endpoint_window_stable": endpoint_window_stable,
        "preferred_joint_error_limit_rad": preferred_joint_error_limit,
        "fallback_joint_error_limit_rad": fallback_joint_error_limit,
        "applied_joint_error_limit_rad": applied_joint_error_limit,
        "joint_error_gate": joint_error_gate,
        "joint_error_scope": "J1-J5" if j6_checked_by_tool_orientation else "J1-J6",
        "evaluated_joint_error_rad": measured_joint_error,
        "reasons": reasons,
    }


def orientation_endpoint_can_recenter(endpoint, *, simplified_full_flow, orientation_only_requested):
    """Let the visual target check resolve drift after a stable wrist turn."""
    if not simplified_full_flow or orientation_only_requested:
        return False
    reasons = endpoint["reasons"]
    if reasons == ["tcp_position_drift_too_large"]:
        return True
    return (
        reasons == ["joint_tracking_error_too_large", "tcp_position_drift_too_large"]
        and endpoint["endpoint_window_stable"]
        and endpoint["evaluated_joint_error_rad"] <= endpoint["fallback_joint_error_limit_rad"]
    )


def plan_grasp_orientation_j6_endpoint_trim(
    planned_q,
    measured_q,
    endpoint: dict,
    config: dict,
    *,
    tcp_kinematics=None,
    target_quaternion=None,
    hold_command_q=None,
) -> dict:
    """Plan one bounded J6-only command-bias retry for a stable undershoot."""
    planned = np.asarray(planned_q, dtype=np.float64)
    measured = np.asarray(measured_q, dtype=np.float64)
    if planned.shape != (6,) or measured.shape != (6,):
        raise ValueError("orientation trim joint vectors must contain six values")
    if not np.isfinite(planned).all() or not np.isfinite(measured).all():
        raise ValueError("orientation trim joint vectors must be finite")
    errors = measured - planned
    j6_error = float(errors[5])
    other_error = float(np.max(np.abs(errors[:5])))
    reasons = set(endpoint.get("reasons", []))
    record = {
        "eligible": False,
        "reason": "not_evaluated",
        "desired_q_rad": planned.tolist(),
        "measured_q_rad": measured.tolist(),
        "joint_error_rad": errors.tolist(),
        "j6_error_rad": j6_error,
        "maximum_other_joint_error_rad": other_error,
    }
    if endpoint.get("passed"):
        record["reason"] = "endpoint_already_passed"
        return record
    if config.get("j6_endpoint_trim_enabled") is not True:
        record["reason"] = "trim_disabled"
        return record
    direction_only = (
        endpoint.get("joint_error_scope") == "J1-J5"
        and reasons == {"tool_orientation_error_too_large"}
    )
    if not direction_only and "joint_tracking_error_too_large" not in reasons:
        record["reason"] = "joint_tracking_error_not_present"
        return record
    allowed_reasons = {
        "joint_tracking_error_too_large",
        "tool_orientation_error_too_large",
    }
    if not reasons.issubset(allowed_reasons):
        record["reason"] = "non_j6_endpoint_gate_failed"
        return record
    if endpoint.get("endpoint_window_stable") is not True:
        record["reason"] = "endpoint_window_not_stable"
        return record
    if direction_only:
        maximum_bias = float(config["j6_endpoint_trim_maximum_bias_rad"])
        candidates = []
        for bias in (-maximum_bias, maximum_bias):
            predicted_q = measured.copy()
            predicted_q[5] += bias
            error_deg = quaternion_error_deg(
                tcp_kinematics.fk(predicted_q.tolist())[3:], target_quaternion
            )
            candidates.append((error_deg, bias, predicted_q))
        error_deg, bias, predicted_q = min(candidates, key=lambda candidate: candidate[0])
        record["predicted_tool_orientation_error_deg"] = error_deg
        if error_deg > float(config["maximum_endpoint_orientation_error_deg"]):
            record["reason"] = "bounded_j6_motion_cannot_reach_tool_direction"
            return record
        command = list(hold_command_q)
        command[5] += bias
        record.update(
            eligible=True,
            reason="stable_tool_direction_error",
            command_mode="held_setpoint_delta",
            command_q_rad=command,
            predicted_physical_q_rad=predicted_q.tolist(),
            applied_j6_bias_rad=bias,
            maximum_command_delta_rad=abs(bias),
        )
        return record
    if int(np.argmax(np.abs(errors))) != 5:
        record["reason"] = "j6_is_not_dominant_error"
        return record
    if other_error > float(config["j6_endpoint_trim_maximum_other_joint_error_rad"]):
        record["reason"] = "other_joint_error_too_large"
        return record
    if abs(j6_error) > float(config["j6_endpoint_trim_maximum_initial_error_rad"]):
        record["reason"] = "j6_error_outside_bounded_trim_range"
        return record
    if float(endpoint["tcp_position_drift_mm"]) > float(
        config["maximum_endpoint_tcp_position_drift_mm"]
    ):
        record["reason"] = "tcp_position_drift_too_large"
        return record
    if float(endpoint["orientation_error_deg"]) > float(
        config["j6_endpoint_trim_maximum_initial_orientation_error_deg"]
    ):
        record["reason"] = "tool_orientation_error_outside_trim_range"
        return record
    maximum_bias = float(config["j6_endpoint_trim_maximum_bias_rad"])
    requested_bias = -j6_error
    applied_bias = float(np.clip(requested_bias, -maximum_bias, maximum_bias))
    if math.isclose(applied_bias, 0.0, abs_tol=1e-12):
        record["reason"] = "zero_trim_bias"
        return record
    command = measured.copy()
    command[5] = planned[5] + applied_bias
    record.update(
        {
            "eligible": True,
            "reason": "stable_j6_dominant_undershoot",
            "requested_j6_bias_rad": requested_bias,
            "applied_j6_bias_rad": applied_bias,
            "command_q_rad": command.tolist(),
            "maximum_command_delta_rad": float(
                np.max(np.abs(command - measured))
            ),
        }
    )
    return record


def support_normal_clearance_mm(tcp_pose, surface_point, support_up_normal) -> float:
    tcp = np.asarray(tcp_pose, dtype=float)
    surface = np.asarray(surface_point, dtype=float)
    normal = np.asarray(support_up_normal, dtype=float)
    if tcp.shape != (7,) or not np.all(np.isfinite(tcp)):
        raise ValueError("TCP pose must contain seven finite values")
    if surface.shape != (3,) or not np.all(np.isfinite(surface)):
        raise ValueError("surface point must contain three finite values")
    if normal.shape != (3,) or not np.all(np.isfinite(normal)):
        raise ValueError("support normal must contain three finite values")
    norm = float(np.linalg.norm(normal))
    if norm <= 1e-9:
        raise ValueError("support normal must be non-zero")
    normal = normal / norm
    return 1000.0 * float(np.dot(tcp[:3] - surface, normal))


def apply_safe_descent_runtime_clearance_scope(
    wrist_record: dict,
    observation_safety: dict,
    descent_config: dict,
) -> tuple[dict, list[float]]:
    """Apply the derived descent envelope only to this in-memory invocation."""
    lower = float(descent_config["minimum_initial_normal_clearance_mm"])
    upper = float(descent_config["maximum_initial_normal_clearance_mm"])
    if not math.isfinite(lower) or not math.isfinite(upper) or lower >= upper:
        raise ValueError("invalid safe descent runtime clearance range")
    scoped_safety = dict(observation_safety)
    scoped_safety["minimum_target_clearance_mm"] = lower
    scoped_safety["maximum_target_clearance_mm"] = upper
    workspace = dict(wrist_record["validated_workspace"])
    workspace["normal_clearance_mm"] = [lower, upper]
    wrist_record["validated_workspace"] = workspace
    return scoped_safety, [lower, upper]


def resolve_adaptive_pregrasp_config(final_capture, pregrasp_config) -> tuple[dict, dict]:
    """Bind a no-contact pregrasp clearance to the final high-view target height."""
    detection = final_capture.get("detection")
    if not isinstance(detection, dict):
        raise ValueError("adaptive pregrasp requires a final detection record")
    selected = detection.get("selected")
    if not isinstance(selected, dict) or selected.get("accepted") is not True:
        raise ValueError("adaptive pregrasp requires one accepted selected target")
    statistic = str(pregrasp_config["height_statistic"])
    height_record = selected.get("core_height_mm")
    if not isinstance(height_record, dict) or statistic not in height_record:
        raise ValueError(
            f"adaptive pregrasp selected target has no core_height_mm.{statistic}"
        )
    target_height_mm = float(height_record[statistic])
    minimum_height = float(pregrasp_config["minimum_target_height_mm"])
    maximum_height = float(pregrasp_config["maximum_target_height_mm"])
    if not math.isfinite(target_height_mm):
        raise ValueError("adaptive pregrasp target height is not finite")
    if not minimum_height <= target_height_mm <= maximum_height:
        raise ValueError(
            "adaptive pregrasp target height "
            f"{target_height_mm:.3f}mm outside "
            f"[{minimum_height:.3f}, {maximum_height:.3f}]mm"
        )
    clearance_above_top_mm = float(
        pregrasp_config["clearance_above_detected_top_mm"]
    )
    minimum_top_margin_mm = float(
        pregrasp_config["minimum_theoretical_top_margin_mm"]
    )
    if clearance_above_top_mm < minimum_top_margin_mm:
        raise ValueError("adaptive pregrasp top margin is below its hard minimum")
    target_clearance_mm = clearance_above_top_mm
    predicted_support_plane_clearance_mm = (
        target_height_mm + clearance_above_top_mm
    )
    minimum_initial = float(
        pregrasp_config["minimum_initial_normal_clearance_mm"]
    )
    if target_clearance_mm >= minimum_initial:
        raise ValueError("adaptive pregrasp target is not below the high-view envelope")
    effective_config = dict(pregrasp_config)
    effective_config["target_normal_clearance_mm"] = target_clearance_mm
    handoff = {
        "status": "high_view_measurement_bound",
        "target_id": selected.get("target_id"),
        "height_statistic": statistic,
        "target_height_mm": target_height_mm,
        "clearance_above_detected_top_mm": clearance_above_top_mm,
        "minimum_theoretical_top_margin_mm": minimum_top_margin_mm,
        "target_normal_clearance_mm": target_clearance_mm,
        "target_clearance_reference": "selected_target_top_surface",
        "predicted_support_plane_clearance_mm": (
            predicted_support_plane_clearance_mm
        ),
        "low_view_camera_recheck_required": False,
        "low_view_camera_recheck_forbidden": True,
    }
    return effective_config, handoff


def load_bound_adaptive_grasp_resources(secure_config: dict):
    """Load the exact adaptive-grip config and empty baseline bound by SHA-256."""
    resolved = {}
    for key in ("adaptive_grasp_config", "empty_baseline"):
        binding = secure_config[key]
        path = resolve_project_path(binding["path"])
        if not path.is_file():
            raise FileNotFoundError(f"bound {key} does not exist: {path}")
        expected = str(binding["sha256"]).lower()
        actual = file_sha256(path)
        if actual != expected:
            raise RuntimeError(
                f"bound {key} SHA-256 mismatch: expected={expected} actual={actual}"
            )
        resolved[key] = path
    parameters = load_probe_parameters(resolved["adaptive_grasp_config"])
    if "secure_preload_command_mm" in secure_config:
        parameters = replace(
            parameters,
            secure_preload_command_mm=float(secure_config["secure_preload_command_mm"]),
        )
        parameters.validate()
    if "secure_force_nm" in secure_config:
        parameters = replace(parameters, secure_force_nm=float(secure_config["secure_force_nm"]))
        parameters.validate()
    baseline = load_empty_baseline(resolved["empty_baseline"])
    baseline.assert_compatible(parameters)
    return (
        resolved["adaptive_grasp_config"],
        resolved["empty_baseline"],
        parameters,
        baseline,
    )


def size_adaptive_probe_parameters(parameters, baseline, width_mm, minimum_gap_mm):
    """Keep the bound probe unless the observed width approaches its contact floor."""
    minimum_detectable_gap_mm = (
        parameters.target_gap_mm
        + baseline.tracking_excess_p99_mm
        + parameters.tracking_margin_over_empty_mm
    )
    if width_mm > minimum_detectable_gap_mm:
        return parameters
    return replace(
        parameters,
        target_gap_mm=max(minimum_gap_mm, width_mm - parameters.secure_preload_command_mm),
    )


def resolve_adaptive_secure_no_lift_config(
    final_capture,
    secure_config,
) -> tuple[dict, dict]:
    """Bind the low grasp endpoint to target height and the support plane."""
    detection = final_capture.get("detection")
    if not isinstance(detection, dict):
        raise ValueError("adaptive secure grasp requires a final detection record")
    selected = detection.get("selected")
    if not isinstance(selected, dict) or selected.get("accepted") is not True:
        raise ValueError("adaptive secure grasp requires one accepted selected target")
    statistic = str(secure_config["height_statistic"])
    height_record = selected.get("core_height_mm")
    if not isinstance(height_record, dict) or statistic not in height_record:
        raise ValueError(
            f"adaptive secure selected target has no core_height_mm.{statistic}"
        )
    target_height_mm = float(height_record[statistic])
    minimum_height = float(secure_config["minimum_target_height_mm"])
    maximum_height = float(secure_config["maximum_target_height_mm"])
    if not math.isfinite(target_height_mm):
        raise ValueError("adaptive secure target height is not finite")
    if not minimum_height <= target_height_mm <= maximum_height:
        raise ValueError(
            "adaptive secure target height "
            f"{target_height_mm:.3f}mm outside "
            f"[{minimum_height:.3f}, {maximum_height:.3f}]mm"
        )
    support_plane_clearance_mm = float(
        secure_config["target_support_plane_tcp_clearance_mm"]
    )
    minimum_support_clearance_mm = float(
        secure_config["minimum_support_plane_tcp_clearance_mm"]
    )
    if support_plane_clearance_mm < minimum_support_clearance_mm:
        raise ValueError("adaptive secure support-plane clearance is below minimum")
    target_top_clearance_mm = support_plane_clearance_mm - target_height_mm
    effective = dict(secure_config)
    effective.update(
        {
            "target_normal_clearance_mm": target_top_clearance_mm,
            "minimum_initial_normal_clearance_mm": float(
                secure_config["minimum_initial_top_clearance_mm"]
            ),
            "maximum_initial_normal_clearance_mm": float(
                secure_config["maximum_initial_top_clearance_mm"]
            ),
            "maximum_descent_distance_mm": float(
                secure_config["maximum_low_descent_distance_mm"]
            ),
        }
    )
    handoff = {
        "status": "pregrasp_to_contact_height_bound",
        "target_id": selected.get("target_id"),
        "height_statistic": statistic,
        "target_height_mm": target_height_mm,
        "target_support_plane_tcp_clearance_mm": support_plane_clearance_mm,
        "minimum_support_plane_tcp_clearance_mm": minimum_support_clearance_mm,
        "target_top_clearance_mm": target_top_clearance_mm,
        "target_clearance_reference": "selected_target_top_surface",
        "low_view_camera_recheck_required": False,
        "low_view_camera_recheck_forbidden": True,
        "lift_allowed": False,
    }
    return effective, handoff


def plan_direct_box_transfer(
    start_measured_q, start_command_q, box_plan, *, alignment, kinematics,
    collision_checker, tilt_model, applied_support_up, compensation_scale,
    torque_limits, deployment_source,
):
    """Connect the high grasp pose to the checked box approach without retracting."""
    from plan_go2_fixed_funnel_box_place import box_frame, relative_box_coordinates_mm
    from plan_go2_multiview_scan import geom_positions_mm, set_model_q

    route = box_plan["route"]
    entry_index = next(i for i, point in enumerate(route) if point["name"] == "box_transport_reference")
    bridge = densify_joint_path(
        [start_command_q, route[entry_index]["q"]],
        float(alignment["maximum_joint_step_rad"]),
    )
    command_path = [*bridge, *[point["q"] for point in route[entry_index + 1:]]]
    checked_path = [list(start_measured_q), *command_path]
    step = float(alignment["collision_step_rad"])
    dense = densify_joint_path(checked_path, step)
    minimum_margin = min(map(joint_margin_deg, dense))
    if minimum_margin < float(alignment["minimum_joint_margin_deg"]):
        raise RuntimeError("direct box transfer has insufficient joint margin")
    collision = check_collision_path(collision_checker, checked_path, step)
    torque = validate_torque_envelope(
        dense,
        lambda q: float(compensation_scale) * differential_tilt_compensation_from_support_up(
            tilt_model, q, applied_support_up,
        ),
        torque_limits,
    )
    body = deployment_source["safety"]["go2_body_envelope"]
    for q in densify_joint_path([start_measured_q, *bridge], step):
        set_model_q(collision_checker, q)
        for geom, xyz in geom_positions_mm(collision_checker, body["distal_geoms"]).items():
            if (abs(xyz[1]) < body["body_half_width_y_mm"]
                    and xyz[2] < body["minimum_distal_geom_center_z_inside_body_width_mm"]):
                raise RuntimeError(f"direct box transfer crosses the Go2 body envelope: {geom}")
    calibration = json.loads(resolve_project_path(box_plan["bindings"]["box_calibration"]).read_text())
    frame = box_frame(calibration)
    envelope = box_plan["box_envelope"]
    half_payload = float(envelope["payload_half_envelope_mm"])
    allowed_center = float(envelope["top_opening_half_width_mm"]) - half_payload - float(envelope["margin_mm"])
    outer_x, outer_y = np.asarray(calibration["box"]["outer_size_mm"][:2]) / 2.0
    for q in dense:
        rear, right, height = relative_box_coordinates_mm(kinematics.fk(q)[:3], frame)
        near_box = abs(rear) <= outer_x + half_payload and abs(right) <= outer_y + half_payload
        if (near_box and height < float(calibration["opening_hover"]["raise_mm"]) - 1.0
                and (abs(rear) > allowed_center or abs(right) > allowed_center)):
            raise RuntimeError("direct box transfer enters the box below its opening approach")
    return {
        "status": "planned",
        "command_path": command_path,
        "release_q_rad": list(route[-1]["q"]),
        "approach_entry": route[entry_index]["name"],
        "minimum_joint_margin_deg": minimum_margin,
        "collision": collision,
        "torque": torque,
        "go2_bridge_check": "passed",
        "box_approach_check": "passed",
    }


def compute_oriented_pregrasp_plan(
    q_start, observation, *, orientation_config, check_body, **descent_options,
):
    """Turn toward a square edge while descending to the pregrasp height."""
    if observation["orientation_confidence_score"] < orientation_config["minimum_orientation_confidence_score"]:
        raise RuntimeError("merged pregrasp orientation confidence is below the configured limit")
    if observation["orientation_p90_deviation_deg"] > orientation_config["maximum_orientation_p90_deviation_deg"]:
        raise RuntimeError("merged pregrasp orientation deviation exceeds the configured limit")
    if abs(observation["orientation_symmetry_period_deg"] - 90.0) > 1e-6:
        raise RuntimeError("merged pregrasp requires square target symmetry")
    pose = descent_options["tcp_kinematics"].fk(list(q_start))
    candidates = square_grasp_orientation_candidates(
        pose, observation["target_edge_axis_base"], observation["support_up_normal_base"],
        maximum_approach_tilt_from_support_down_deg=float(
            orientation_config["maximum_approach_tilt_from_support_down_deg"]
        ),
    )
    candidates.sort(key=lambda candidate: candidate["rotation_from_current_deg"])
    rejected = []
    for candidate in candidates[:2]:
        try:
            plan = compute_safe_descent_plan(
                q_start, observation, **descent_options,
                target_quaternion=candidate["target_quaternion_xyzw"],
                maximum_orientation_step_deg=float(orientation_config["maximum_orientation_step_deg"]),
            )
            plan["body_check"] = check_body(plan["joint_path"])
        except (RuntimeError, ValueError) as exc:
            rejected.append({"name": candidate["name"], "reason": str(exc)})
            continue
        plan["merged_grasp_orientation"] = candidate
        plan["rejected_orientation_candidates"] = rejected
        return plan
    raise RuntimeError(f"no checked combined orientation/pregrasp path: {rejected}")


def compute_safe_descent_plan(
    q_start,
    observation,
    *,
    descent_config,
    alignment,
    tcp_kinematics,
    collision_checker,
    tilt_model,
    applied_support_up,
    side_scale,
    torque_limits,
    target_quaternion=None,
    maximum_orientation_step_deg=5.0,
) -> dict:
    """Plan descent along the support normal, optionally turning during descent."""
    q_start = np.asarray(q_start, dtype=float)
    if q_start.shape != (6,) or not np.all(np.isfinite(q_start)):
        raise ValueError("safe descent start joints must contain six finite values")
    support_up = np.asarray(observation["support_up_normal_base"], dtype=float)
    support_up = support_up / float(np.linalg.norm(support_up))
    surface_point = np.asarray(observation["surface_point_base_m"], dtype=float)
    start_tcp = np.asarray(tcp_kinematics.fk(q_start.tolist()), dtype=float)
    initial_clearance_mm = support_normal_clearance_mm(
        start_tcp, surface_point, support_up
    )
    minimum_initial = float(
        descent_config["minimum_initial_normal_clearance_mm"]
    )
    maximum_initial = float(
        descent_config["maximum_initial_normal_clearance_mm"]
    )
    if (not descent_config.get("initial_clearance_range_advisory", False)
            and not minimum_initial <= initial_clearance_mm <= maximum_initial):
        raise RuntimeError(
            "safe descent initial clearance "
            f"{initial_clearance_mm:.3f}mm outside "
            f"[{minimum_initial:.3f}, {maximum_initial:.3f}]mm"
        )
    target_clearance_mm = float(descent_config["target_normal_clearance_mm"])
    descent_distance_mm = initial_clearance_mm - target_clearance_mm
    if descent_distance_mm <= 0.0:
        raise RuntimeError("safe descent target is not below the current TCP")
    if descent_distance_mm > float(descent_config["maximum_descent_distance_mm"]):
        raise RuntimeError(
            f"safe descent distance {descent_distance_mm:.3f}mm exceeds cap"
        )
    segment_count = max(
        1,
        int(
            math.ceil(
                descent_distance_mm
                / float(descent_config["maximum_cartesian_step_mm"])
            )
        ),
    )
    if target_quaternion is not None:
        segment_count = max(
            segment_count,
            math.ceil(quaternion_error_deg(start_tcp[3:], target_quaternion) / maximum_orientation_step_deg),
        )
    tcp_targets = []
    expected_clearances_mm = []
    for index in range(1, segment_count + 1):
        fraction = index / segment_count
        pose = start_tcp.copy()
        pose[:3] -= support_up * (descent_distance_mm / 1000.0) * fraction
        if target_quaternion is not None:
            pose[3:] = quaternion_slerp(start_tcp[3:], target_quaternion, fraction)
        tcp_targets.append(pose.tolist())
        expected_clearances_mm.append(
            support_normal_clearance_mm(pose, surface_point, support_up)
        )
    ik = solve_continuous_ik_path(
        tcp_kinematics,
        q_start.tolist(),
        # The IK helper treats pose zero as the already-reached start pose.
        [start_tcp.tolist(), *tcp_targets],
        maximum_joint_step_rad=float(descent_config["maximum_joint_step_rad"]),
        minimum_joint_margin_deg=float(descent_config["minimum_joint_margin_deg"]),
        maximum_fk_position_error_mm=float(alignment["maximum_fk_position_error_mm"]),
        maximum_fk_orientation_error_deg=float(
            alignment["maximum_fk_orientation_error_deg"]
        ),
    )
    joint_path = [list(q) for q in ik["joint_path"]]
    if not joint_path or max_joint_delta(q_start.tolist(), joint_path[0]) > 1e-9:
        joint_path.insert(0, q_start.tolist())
    collision = check_collision_path(
        collision_checker,
        joint_path,
        float(descent_config["collision_step_rad"]),
    )
    torque_samples = densify_joint_path(
        joint_path, float(descent_config["collision_step_rad"])
    )
    torque = validate_torque_envelope(
        torque_samples,
        lambda q: side_scale
        * differential_tilt_compensation_from_support_up(
            tilt_model, q, applied_support_up
        ),
        torque_limits,
    )
    return {
        "status": "planned_no_contact_round_trip",
        "start_q_rad": q_start.tolist(),
        "start_tcp_pose_xyz_xyzw": start_tcp.tolist(),
        "support_up_normal_base": support_up.tolist(),
        "surface_point_base_m": surface_point.tolist(),
        "initial_normal_clearance_mm": initial_clearance_mm,
        "initial_clearance_range_advisory": descent_config.get("initial_clearance_range_advisory", False),
        "target_normal_clearance_mm": target_clearance_mm,
        "descent_distance_mm": descent_distance_mm,
        "segment_count": segment_count,
        "tcp_targets_xyz_xyzw": tcp_targets,
        "expected_clearances_mm": expected_clearances_mm,
        "ik": ik,
        "joint_path": joint_path,
        "collision": collision,
        "torque": torque,
    }



def plan_pregrasp_endpoint_correction(desired_q, measured_q, held_q, *,
        descent_config, collision_checker, tilt_model, applied_support_up,
        compensation_scale, torque_limits, check_body):
    """Counter measured endpoint tracking error without changing the task goal."""
    desired = np.asarray(desired_q, dtype=float)
    measured = np.asarray(measured_q, dtype=float)
    held = np.asarray(held_q, dtype=float)
    correction = desired - measured
    target = held + correction
    command_path = densify_joint_path([held.tolist(), target.tolist()],
                                     float(descent_config["maximum_joint_step_rad"]))
    checked = [measured.tolist(), *command_path]
    dense = densify_joint_path(checked, float(descent_config["collision_step_rad"]))
    margin = min(map(joint_margin_deg, dense))
    if margin < float(descent_config["minimum_joint_margin_deg"]):
        raise RuntimeError("pregrasp correction violates existing joint margin")
    collision = check_collision_path(collision_checker, checked,
                                    float(descent_config["collision_step_rad"]))
    body = check_body(checked)
    torque = validate_torque_envelope(dense,
        lambda q: float(compensation_scale) * differential_tilt_compensation_from_support_up(
            tilt_model, q, applied_support_up), torque_limits)
    return command_path, {"status": "planned", "joint_correction_rad": correction.tolist(),
        "desired_q_rad": desired.tolist(), "measured_q_rad": measured.tolist(),
        "command_target_q_rad": target.tolist(), "minimum_joint_margin_deg": margin,
        "collision": collision, "body": body, "torque": torque}


def hold_until_low_descent_endpoint(
    runner, plan, *, descent_config, tcp_kinematics,
    command_gap_mm, force_nm, progress_callback,
):
    """Keep sending the planned endpoint while waiting for measured arrival."""
    sample = runner.hold(
        command_gap_mm, force_nm, float(descent_config["hold_seconds"]),
        "adaptive_secure_low_endpoint_open_hold",
    )
    waiting = False
    while True:
        measured_q = [float(value) for value in runner.arm.get_pos()[:6]]
        endpoint = evaluate_safe_descent_endpoint(
            plan, measured_q, descent_config=descent_config,
            tcp_kinematics=tcp_kinematics,
        )
        progress_callback(endpoint)
        if endpoint["passed"]:
            if waiting:
                print(
                    "LOW_ENDPOINT_RESUME ="
                    f" error={endpoint['clearance_error_mm']:.3f}mm"
                    f" progress={endpoint['progress_ratio']:.6f}"
                )
            return sample, measured_q, endpoint
        if not waiting:
            print(
                "LOW_ENDPOINT_WAIT ="
                f" error={endpoint['clearance_error_mm']:.3f}mm"
                f" progress={endpoint['progress_ratio']:.6f}"
            )
            waiting = True
        started = time.monotonic()
        sample = runner.tick(
            command_gap_mm, force_nm, "adaptive_secure_low_endpoint_wait",
        )
        time.sleep(max(0.0, 1.0 / runner.parameters.hz - (time.monotonic() - started)))


def evaluate_safe_descent_endpoint(
    plan,
    measured_q,
    *,
    descent_config,
    tcp_kinematics,
) -> dict:
    measured_tcp = tcp_kinematics.fk(measured_q)
    measured_clearance_mm = support_normal_clearance_mm(
        measured_tcp,
        plan["surface_point_base_m"],
        plan["support_up_normal_base"],
    )
    actual_descent_mm = (
        float(plan["initial_normal_clearance_mm"]) - measured_clearance_mm
    )
    planned_descent_mm = float(plan["descent_distance_mm"])
    progress_ratio = actual_descent_mm / planned_descent_mm
    clearance_error_mm = abs(
        measured_clearance_mm - float(plan["target_normal_clearance_mm"])
    )
    passed = bool(
        clearance_error_mm
        <= float(descent_config["maximum_endpoint_clearance_error_mm"])
        and float(descent_config["minimum_descent_progress_ratio"])
        <= progress_ratio
        <= float(descent_config["maximum_descent_progress_ratio"])
    )
    return {
        "passed": passed,
        "measured_q_rad": [float(value) for value in measured_q],
        "measured_tcp_pose_xyz_xyzw": [float(value) for value in measured_tcp],
        "measured_normal_clearance_mm": measured_clearance_mm,
        "actual_descent_distance_mm": actual_descent_mm,
        "planned_descent_distance_mm": planned_descent_mm,
        "progress_ratio": progress_ratio,
        "clearance_error_mm": clearance_error_mm,
    }


def center_normal_drift_allowed(normal_drift_mm: float, alignment: dict) -> bool:
    return bool(
        alignment.get("normal_drift_monitor_only", False)
        or normal_drift_mm <= float(alignment["maximum_final_normal_drift_mm"])
    )


def residual_correction_decision(
    final_check: dict,
    normal_drift_mm: float,
    *,
    alignment: dict,
    residual_config: dict,
) -> dict:
    """Decide whether to plan one residual correction."""
    residual_mm = float(final_check["initial_tangent_error_norm_mm"])
    success_mm = float(alignment["success_tangent_error_mm"])
    maximum_residual_mm = residual_config["maximum_residual_error_mm"]
    if maximum_residual_mm is not None:
        maximum_residual_mm = float(maximum_residual_mm)
    exceeds_retry_range = (
        maximum_residual_mm is not None and residual_mm > maximum_residual_mm
    )
    maximum_normal_drift_mm = float(alignment["maximum_final_normal_drift_mm"])
    drift_allowed = center_normal_drift_allowed(normal_drift_mm, alignment)
    allowed = bool(
        not final_check["converged"]
        and residual_mm > success_mm
        and not exceeds_retry_range
        and drift_allowed
    )
    if final_check["converged"]:
        reason = "already_converged"
    elif not drift_allowed:
        reason = "normal_drift_limit_reached"
    elif exceeds_retry_range:
        reason = "residual_above_bounded_retry_range"
    elif residual_mm <= success_mm:
        reason = "residual_within_success_threshold"
    elif maximum_residual_mm is None:
        reason = "single_retry_pending_path_planning"
    else:
        reason = "single_bounded_retry_allowed"
    return {
        "allowed": allowed,
        "reason": reason,
        "residual_error_mm": residual_mm,
        "success_error_mm": success_mm,
        "maximum_residual_error_mm": maximum_residual_mm,
        "normal_drift_mm": float(normal_drift_mm),
        "maximum_normal_drift_mm": maximum_normal_drift_mm,
        "normal_drift_monitor_only": alignment.get("normal_drift_monitor_only", False),
        "maximum_passes": int(residual_config["maximum_passes"]),
    }


def main(argv=None, *, arm_session=None) -> int:
    parser = argparse.ArgumentParser(
        description="Go2右侧：自动部署、D455单目标识别、支撑平面切向中心对准并返回"
    )
    parser.add_argument("--dev", default="/dev/ttyUSB0")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--run-id")
    parser.add_argument(
        "--orientation-only",
        action="store_true",
        help=(
            "stop after the high-view square-symmetric grasp-orientation "
            "round trip; do not descend, close the gripper, lift, or use the box"
        ),
    )
    parser.add_argument(
        "--commissioning-workspace-scan",
        help=(
            "offline workspace scan used to authorize exactly one staged "
            "alignment-only commissioning point"
        ),
    )
    parser.add_argument(
        "--commissioning-u-mm",
        type=float,
        help="requested support-plane u offset from the successful baseline",
    )
    parser.add_argument(
        "--commissioning-v-mm",
        type=float,
        help="requested support-plane v offset from the successful baseline",
    )
    parser.add_argument(
        "--commissioning-tolerance-mm",
        type=float,
        default=12.0,
        help="maximum planar placement error for the requested scan cell",
    )
    parser.add_argument(
        "--search-plan", nargs=2, metavar=("PLAN", "REPORT"),
        help="use a bound high-view search plan when the first view cannot hand off a target",
    )
    parser.add_argument(
        "--flexible-approach", action="store_true",
        help="try an alternate checked approach if the fixed-direction alignment cannot solve",
    )
    parser.add_argument(
        "--motion-speed-scale", type=float, default=1.0,
        help="scale J1-J5 transit, pregrasp and box-route speeds; retain low-contact and J6 speeds",
    )
    parser.add_argument(
        "--transit-speed-rad-s", type=float,
        help="absolute J1-J5 deployment, high-view and box transit speed; overrides the transit multiplier",
    )
    parser.add_argument(
        "--all-joint-speed-rad-s", type=float,
        help="absolute speed cap for J1-J6 in all arm motion stages, including contact and recovery",
    )
    parser.add_argument(
        "--descent-speed-rad-s", type=float, default=0.5,
        help="J1-J6 speed cap for pregrasp and low-contact descent only",
    )
    parser.add_argument(
        "--enable-tilt-compensation", action="store_true",
        help="restore the temporarily disabled extra tilt compensation and transition holds",
    )
    parser.add_argument("--deployment-acceleration-rad-s2", type=float, default=0.25,
                        help="gentler acceleration for lift, high turn and observation deployment")
    parser.add_argument("--descent-acceleration-rad-s2", type=float, default=0.25,
                        help="gentler acceleration for pregrasp and low-contact descent")
    parser.add_argument("--acceleration-rad-s2", type=float, default=None,
                        help="planned per-joint acceleration limit including starts/stops and path corners")
    parser.add_argument("--manual-confirmations", dest="non_interactive", action="store_false",
                        help="optional development mode requiring e/d confirmations")
    parser.add_argument("--non-interactive", action="store_true", default=True,
                        help="run without keyboard confirmations; integration faults remain held")
    parser.add_argument("--payload-mass-g", type=float, help="actual object mass in grams; overrides config maximum_test_mass_g")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)

    tilt_compensation_enabled = args.enable_tilt_compensation
    # Restore the original velocity-only timing unless acceleration shaping is
    # explicitly requested. No stage may silently re-enable the extra limiter.
    if args.acceleration_rad_s2 is None:
        args.deployment_acceleration_rad_s2 = None
        args.descent_acceleration_rad_s2 = None

    def ramp_tilt_scale(*ramp_args, **ramp_options):
        if tilt_compensation_enabled:
            return ramp_compensation_scale(*ramp_args, **ramp_options)
        return {"status": "tilt_compensation_disabled"}

    def hold_with_tilt_policy(arm, target, duration, label, **options):
        if not tilt_compensation_enabled and (
            "support_normal" in label or label == "search_view_normal_restore"
        ):
            return
        return guarded_hold(arm, target, duration, label, **options)

    config_path, config = load_alignment_config(args.config, payload_mass_g=args.payload_mass_g)
    motion_speed_scale = args.motion_speed_scale
    if not math.isfinite(motion_speed_scale) or motion_speed_scale <= 0:
        parser.error("--motion-speed-scale must be positive and finite")
    for section in ("motion", "adaptive_pregrasp", "adaptive_grasp_orientation"):
        if section in config:
            config[section]["v_max_rad_s"] *= motion_speed_scale
    transit_speed = args.transit_speed_rad_s
    if transit_speed is not None:
        if not math.isfinite(transit_speed) or transit_speed <= 0:
            parser.error("--transit-speed-rad-s must be positive and finite")
        config["motion"]["v_max_rad_s"] = transit_speed
        config["motion"]["maximum_measured_speed_rad_s"] = max(
            config["motion"]["maximum_measured_speed_rad_s"], 1.2 * transit_speed
        )
    all_joint_speed = args.all_joint_speed_rad_s
    if all_joint_speed is not None:
        if not math.isfinite(all_joint_speed) or all_joint_speed <= 0:
            parser.error("--all-joint-speed-rad-s must be positive and finite")
        for section in config.values():
            if isinstance(section, dict):
                for key in ("v_max_rad_s", "j6_v_max_rad_s"):
                    if key in section:
                        section[key] = all_joint_speed
        config["motion"]["maximum_measured_speed_rad_s"] = max(
            config["motion"]["maximum_measured_speed_rad_s"], 1.2 * all_joint_speed
        )
    descent_speed = args.descent_speed_rad_s
    if not math.isfinite(descent_speed) or descent_speed <= 0:
        parser.error("--descent-speed-rad-s must be positive and finite")
    for name in ("safe_descent", "adaptive_pregrasp", "adaptive_secure_no_lift"):
        if name in config:
            for key in ("v_max_rad_s", "j6_v_max_rad_s"):
                config[name][key] = min(config[name][key], descent_speed)
    fast_motion = motion_speed_scale > 1.0 or transit_speed is not None or all_joint_speed is not None
    plan_path = resolve_project_path(config["deployment_plan"])
    report_path = resolve_project_path(config["deployment_collision_report"])
    wrist_path = resolve_project_path(config["wrist_servo_config"])
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    deployment_source_path, deployment_source = load_bound_deployment_source(plan)
    mount_path = resolve_project_path(plan["mount_config"])
    mount_record = json.loads(mount_path.read_text(encoding="utf-8"))
    report = verify_bound_report(plan_path, report_path, mount_path)
    loaded = load_wrist_servo_config(wrist_path)
    if loaded.mount_config_path != mount_path:
        raise RuntimeError("deployment and wrist alignment use different mount records")
    waypoints = plan["joint_path"]
    grasp_side = plan.get("side", "right")
    observation_name = f"{grasp_side}_observe"
    print("GRASP_SIDE =", grasp_side)
    if [item["name"] for item in waypoints][-1] != observation_name:
        raise RuntimeError("deployment plan must terminate at right_observe")
    phases = planned_phases(waypoints[0]["q"], waypoints, observation_name)
    deployment_motion = plan["motion"]
    tilt_schedule = deployment_motion["tilt_compensation"]
    tilt_config = loaded.record["tilt_compensation"]
    alignment = config["alignment"]
    operation = str(config.get("operation", "alignment_only"))
    commissioning_workspace = None
    commissioning_values_given = (
        args.commissioning_u_mm is not None
        or args.commissioning_v_mm is not None
    )
    if args.commissioning_workspace_scan is None:
        if commissioning_values_given:
            raise ValueError(
                "commissioning u/v require --commissioning-workspace-scan"
            )
    else:
        if args.commissioning_u_mm is None or args.commissioning_v_mm is None:
            raise ValueError(
                "commissioning scan requires both --commissioning-u-mm and "
                "--commissioning-v-mm"
            )
        if operation != "alignment_only":
            raise ValueError(
                "workspace commissioning is restricted to alignment_only"
            )
        if args.orientation_only:
            raise ValueError(
                "workspace commissioning forbids grasp-orientation motion"
            )
        commissioning_workspace = load_workspace_commissioning_point(
            args.commissioning_workspace_scan,
            requested_u_mm=args.commissioning_u_mm,
            requested_v_mm=args.commissioning_v_mm,
            tolerance_mm=args.commissioning_tolerance_mm,
            active_config_path=config_path,
            active_config=config,
            plan_path=plan_path,
            wrist_path=wrist_path,
            loaded_workspace=loaded.record["validated_workspace"],
        )
        loaded.record["validated_workspace"] = dict(
            commissioning_workspace["runtime_workspace_override"]
        )
        alignment["maximum_initial_tangent_error_mm"] = float(
            commissioning_workspace["maximum_initial_tangent_error_mm"]
        )
    safe_descent_enabled = operation == "safe_descent_round_trip"
    adaptive_grasp_box_place_enabled = (
        operation == "adaptive_grasp_box_place_round_trip"
    )
    adaptive_secure_no_lift_enabled = (
        operation
        in {
            "adaptive_secure_no_lift_round_trip",
            "adaptive_grasp_box_place_round_trip",
        }
    )
    adaptive_pregrasp_enabled = operation in {
        "adaptive_pregrasp_round_trip",
        "adaptive_secure_no_lift_round_trip",
        "adaptive_grasp_box_place_round_trip",
    }
    descent_round_trip_enabled = safe_descent_enabled or adaptive_pregrasp_enabled
    safe_descent_config = (
        dict(config["safe_descent"]) if safe_descent_enabled else None
    )
    adaptive_pregrasp_config = (
        dict(config["adaptive_pregrasp"])
        if adaptive_pregrasp_enabled
        else None
    )
    adaptive_secure_config = (
        dict(config["adaptive_secure_no_lift"])
        if adaptive_secure_no_lift_enabled
        else None
    )
    grasp_orientation_config = (
        dict(config["adaptive_grasp_orientation"])
        if adaptive_secure_no_lift_enabled
        and isinstance(config.get("adaptive_grasp_orientation"), dict)
        else None
    )
    grasp_orientation_available = bool(
        grasp_orientation_config is not None
        and grasp_orientation_config.get("enabled") is True
    )
    orientation_only_requested = bool(args.orientation_only)
    orientation_only_required = config.get("orientation_only_required", False)
    if not isinstance(orientation_only_required, bool):
        raise ValueError("orientation_only_required must be boolean")
    if orientation_only_required and not orientation_only_requested:
        raise ValueError(
            "this commissioning config requires --orientation-only; "
            "descent and gripper operation are not authorized"
        )
    if orientation_only_requested and not grasp_orientation_available:
        raise ValueError(
            "--orientation-only requires enabled adaptive_grasp_orientation"
        )
    grasp_orientation_enabled = bool(
        grasp_orientation_available
        and (
            orientation_only_requested
            or grasp_orientation_config.get("full_flow_enabled") is True
        )
    )
    # The orientation-only commissioning branch cannot descend, grasp, carry a
    # payload, or enter the fixed-box route.  Do not force that branch to reuse
    # a box route bound to an older deployment-plan hash; full-flow runs still
    # load and verify every box artifact exactly as before.
    box_place_resources_enabled = bool(
        adaptive_grasp_box_place_enabled and not orientation_only_requested
    )
    alignment_endpoint_vision_handoff_config = (
        dict(adaptive_secure_config["alignment_endpoint_vision_handoff"])
        if adaptive_secure_no_lift_enabled
        else None
    )
    adaptive_grasp_config_path = None
    adaptive_baseline_path = None
    adaptive_parameters = None
    adaptive_baseline = None
    if adaptive_secure_no_lift_enabled:
        (
            adaptive_grasp_config_path,
            adaptive_baseline_path,
            adaptive_parameters,
            adaptive_baseline,
        ) = load_bound_adaptive_grasp_resources(adaptive_secure_config)
    box_place_config = (
        dict(config["adaptive_grasp_box_place"])
        if adaptive_grasp_box_place_enabled
        else None
    )
    if adaptive_grasp_box_place_enabled:
        alignment = dict(alignment)
        alignment["maximum_final_normal_drift_mm"] = float(
            box_place_config["alignment_working_threshold_override"][
                "maximum_final_normal_drift_mm"
            ]
        )
    box_plan_path = None
    box_report_path = None
    box_evidence_path = None
    box_plan = None
    box_report = None
    box_evidence = None
    box_route_scale_override = None
    adaptive_target_size = box_place_resources_enabled and box_place_config.get(
        "adaptive_target_size", False
    )
    use_planned_alignment_range = adaptive_target_size and not orientation_only_requested
    if args.flexible_approach and not use_planned_alignment_range:
        parser.error("--flexible-approach requires the full size-adaptive flow")
    if args.flexible_approach:
        print("FLEXIBLE_HIGH_VIEW_APPROACH = enabled")
    if use_planned_alignment_range:
        alignment["clip_learned_offset"] = True
        from plan_go2_multiview_scan import go2_envelope_check

        alignment["maximum_initial_tangent_error_mm"] = None
    search_views = []
    if args.search_plan:
        if not adaptive_target_size or orientation_only_requested:
            raise ValueError("high-view search requires the full size-adaptive flow")
        from run_go2_multiview_scan import verify_scan_artifacts

        search_plan_path, search_report_path = map(resolve_project_path, args.search_plan)
        search_plan, _ = verify_scan_artifacts(search_plan_path, search_report_path)
        if search_plan.get("grasp_search") is not True:
            raise ValueError("search plan must be generated with --grasp-search")
        for key, active_path in (
            ("flow_config", config_path),
            ("deployment_plan", plan_path),
            ("wrist_config", wrist_path),
            ("mount_config", mount_path),
        ):
            if resolve_project_path(search_plan[key]) != active_path:
                raise RuntimeError(f"high-view search uses a different {key}")
        if max_joint_delta(search_plan["hub"]["q_rad"], waypoints[-1]["q"]) > 1e-6:
            raise RuntimeError("high-view search must start at right_observe")
        search_views = search_plan["selected_views"][1:]
        print("HIGH_VIEW_SEARCH_VIEWS =", [view["name"] for view in search_views])
    if box_place_resources_enabled:
        box_target_edge_mm = float(box_place_config["target_edge_mm"])
        box_target_edge_label = f"{box_target_edge_mm:g}mm"
        if adaptive_target_size:
            box_target_edge_label = f"up to {box_target_edge_label}"
        (
            box_plan_path,
            box_report_path,
            box_evidence_path,
            box_plan,
            box_report,
            box_evidence,
            mount_record,
            box_route_scale_override,
        ) = load_bound_box_place_resources(
            box_place_config,
            deployment_plan_path=plan_path,
            mount_path=mount_path,
            allow_identical_deployment_geometry=config["runtime"].get("simplified_full_flow", False),
            allow_shared_box_from_left=(grasp_side == "left"),
        )
    active_descent_config = (
        safe_descent_config if safe_descent_enabled else adaptive_pregrasp_config
    )
    runtime = config["runtime"]
    mount_record, local_j3_limit = apply_local_j3_tilt_limit(mount_record, runtime)
    if local_j3_limit is not None:
        print("J3_TILT_CORRECTION_LIMIT_OVERRIDE =", local_j3_limit)
    mount_record, local_j2_limit = apply_local_j2_tilt_limit(mount_record, runtime)
    if local_j2_limit is not None:
        print("J2_TILT_CORRECTION_LIMIT_OVERRIDE =", local_j2_limit)
    simplified_full_flow = runtime.get("simplified_full_flow", False)
    alignment["normal_drift_monitor_only"] = bool(
        simplified_full_flow and adaptive_target_size and not orientation_only_requested
    )
    if simplified_full_flow:
        if (runtime.get("feedback_synchronized_alignment", False)
                or runtime.get("stop_after_center_alignment", False)
                or not adaptive_grasp_box_place_enabled):
            raise ValueError("simplified profile requires full box-place flow without clock/center-only")
        loaded.record["validated_workspace"]["advisory_bounds"] = True
        print("WORKSPACE_POLICY = historical bounds advisory; actual path checks retained")
    continuous_alignment_enabled = runtime.get("continuous_alignment_commands", False)
    preserve_position_bias = runtime.get("preserve_learned_position_bias", False)
    center_only_diagnostic = runtime.get("stop_after_center_alignment", False)
    if center_only_diagnostic:
        grasp_orientation_enabled = False
    worker_timeout_s = float(runtime["worker_timeout_s"])
    capture_hold_hz = float(runtime["capture_hold_hz"])
    capture_velocity_guard_hz = float(runtime["capture_velocity_guard_hz"])
    capture_temperature_period_s = float(
        runtime["capture_temperature_period_s"]
    )
    camera_attempts = int(runtime["camera_attempts"])
    camera_retry_delay_s = float(runtime["camera_retry_delay_s"])
    write_raw_capture_previews = bool(
        runtime.get("write_raw_capture_previews_before_detection", True)
    )
    capture_quality_override = dict(config["capture_quality_override"])
    geometry_quality_override = dict(config["geometry_quality_override"])
    observation_safety = dict(loaded.record["safety"])
    if adaptive_target_size:
        observation_safety["camera_target_depth_window_enabled"] = False
        print("CAMERA_TARGET_DEPTH_POLICY = detector_valid_depth_and_checked_path")
    descent_runtime_clearance_range = None
    if descent_round_trip_enabled:
        (
            observation_safety,
            descent_runtime_clearance_range,
        ) = apply_safe_descent_runtime_clearance_scope(
            loaded.record,
            observation_safety,
            active_descent_config,
        )
    global_camera_tilt_limit = float(
        observation_safety["maximum_camera_tilt_from_down_deg"]
    )
    local_camera_tilt_limit = float(
        geometry_quality_override["maximum_camera_tilt_from_down_deg"]
    )
    if local_camera_tilt_limit < global_camera_tilt_limit:
        raise ValueError("local camera tilt threshold cannot tighten below global value")
    observation_safety["maximum_camera_tilt_from_down_deg"] = (
        local_camera_tilt_limit
    )
    observation_endpoint_config = dict(
        config["observation_endpoint_convergence"]
    )
    observation_endpoint_config["validated_workspace"] = dict(
        loaded.record["validated_workspace"]
    )
    alignment_endpoint_config = dict(
        config["alignment_endpoint_convergence"]
    )
    alignment_endpoint_config["validated_workspace"] = dict(
        loaded.record["validated_workspace"]
    )
    if simplified_full_flow:
        for endpoint in (observation_endpoint_config, alignment_endpoint_config):
            endpoint["maximum_attempts"] = 1
            endpoint["handoff_after_one_trim"] = True
    if simplified_full_flow and adaptive_target_size:
        alignment_endpoint_config["j6_tracking_diagnostic_only"] = True
        alignment_endpoint_vision_handoff_config["j6_tracking_diagnostic_only"] = True
    residual_config = dict(config["residual_correction"])
    if use_planned_alignment_range:
        residual_config["maximum_residual_error_mm"] = None
    fault_recovery_config = dict(config["fault_recovery"])
    maximum_segment_delta_rad = float(
        deployment_source["safety"]["maximum_segment_delta_rad"]
    )
    if (
        not math.isfinite(maximum_segment_delta_rad)
        or not 0.0 < maximum_segment_delta_rad <= 0.9
    ):
        raise ValueError(
            "bound deployment maximum_segment_delta_rad must be in (0, 0.9]"
        )
    deployment_valid_only_if = str(
        deployment_source.get("valid_only_if", "")
    ).strip()
    wrist_valid_only_if = str(loaded.record.get("valid_only_if", "")).strip()
    if not deployment_valid_only_if or not wrist_valid_only_if:
        raise ValueError(
            "deployment and wrist configs must state non-empty valid_only_if conditions"
        )

    mode_name = "GO2_RIGHT_SINGLE_TARGET_VISUAL_ALIGNMENT"
    if commissioning_workspace is not None:
        mode_name = "GO2_RIGHT_WORKSPACE_POINT_ALIGNMENT_COMMISSIONING"
    elif center_only_diagnostic:
        mode_name = "GO2_RIGHT_VISUAL_CENTER_ALIGNMENT_DIAGNOSTIC"
    elif orientation_only_requested:
        mode_name = "GO2_RIGHT_VISUAL_ADAPTIVE_GRASP_ORIENTATION_ROUND_TRIP"
    elif safe_descent_enabled:
        mode_name = "GO2_RIGHT_VISUAL_ALIGNMENT_SAFE_DESCENT_ROUND_TRIP"
    elif adaptive_grasp_box_place_enabled:
        mode_name = "GO2_RIGHT_VISUAL_ADAPTIVE_GRASP_BOX_PLACE_ROUND_TRIP"
    elif adaptive_secure_no_lift_enabled:
        mode_name = "GO2_RIGHT_VISUAL_ADAPTIVE_SECURE_NO_LIFT_ROUND_TRIP"
    elif adaptive_pregrasp_enabled:
        mode_name = "GO2_RIGHT_VISUAL_ALIGNMENT_ADAPTIVE_PREGRASP_ROUND_TRIP"
    mode_name = mode_name.replace("GO2_RIGHT", f"GO2_{grasp_side.upper()}")
    print("MODE =", mode_name)
    if adaptive_grasp_box_place_enabled and adaptive_target_size:
        print("LOADED_TRANSPORT_MODE = direct_high_to_release_continuous")
    print("TILT_COMPENSATION_ENABLED =", tilt_compensation_enabled)
    print("DEPLOYMENT_ACCELERATION_LIMIT_RAD_S2 =", args.deployment_acceleration_rad_s2)
    print("DESCENT_ACCELERATION_LIMIT_RAD_S2 =", args.descent_acceleration_rad_s2)
    print("MOTION_TIMING_POLICY =", "original_velocity_profile" if args.acceleration_rad_s2 is None else "acceleration_limited")
    print("PLANNED_ACCELERATION_LIMIT_RAD_S2 =", args.acceleration_rad_s2)
    print("MOTION_SPEED_SCALE =", motion_speed_scale)
    print("TRANSIT_V_MAX_RAD_S =", config["motion"]["v_max_rad_s"])
    print("DESCENT_SPEED_CAP_RAD_S =", descent_speed)
    if all_joint_speed is not None:
        print("ALL_JOINT_SPEED_RAD_S =", all_joint_speed)
        print("EFFECTIVE_STAGE_SPEEDS =", {
            name: {key: section[key] for key in ("v_max_rad_s", "j6_v_max_rad_s") if key in section}
            for name, section in config.items()
            if isinstance(section, dict) and "v_max_rad_s" in section
        })
    print("MEASURED_SPEED_LIMIT_RAD_S =", config["motion"]["maximum_measured_speed_rad_s"])
    print("MOTION_TRACKING_POLICY = repeat_current_target_until_caught_up")
    print("MOTION_CLOCK =", "bounded_elapsed" if fast_motion else "fixed_tick")
    if center_only_diagnostic:
        print("CENTER_ONLY_DIAGNOSTIC = True; J6, descent and gripper commands are forbidden")
    print("CONFIG =", config_path)
    print("DEPLOYMENT_PLAN =", plan_path)
    print("DEPLOYMENT_PLAN_SHA256 =", file_sha256(plan_path))
    print("DEPLOYMENT_SOURCE_CONFIG =", deployment_source_path)
    print("DEPLOYMENT_SOURCE_CONFIG_VERIFIED = True")
    print("DEPLOYMENT_COLLISION_REPORT_VERIFIED = True")
    print("WRIST_CONFIG =", loaded.path)
    print("EYE_IN_HAND_CANDIDATE =", loaded.candidate_path)
    print("CAMERA_SERIAL =", loaded.record["camera_serial"])
    print(
        "VISION_RUNTIME ="
        f" worker_timeout={worker_timeout_s:.1f}s"
        " raw_previews_before_detection="
        f"{write_raw_capture_previews}"
    )
    print("SUPPORT_NORMAL_SOURCE = measured plane pitch+roll, blend=0.50")
    if use_planned_alignment_range:
        print("ALIGNMENT_DISTANCE_POLICY = checked_trajectory")
    else:
        print("ALIGNMENT_LIMIT_MM =", alignment["maximum_initial_tangent_error_mm"])
    print("ALIGNMENT_SUCCESS_MM =", alignment["success_tangent_error_mm"])
    if commissioning_workspace is not None:
        print(
            "WORKSPACE_COMMISSIONING_POINT_MM =",
            [
                commissioning_workspace["requested_u_mm"],
                commissioning_workspace["requested_v_mm"],
            ],
        )
        print(
            "WORKSPACE_COMMISSIONING_TOLERANCE_MM =",
            commissioning_workspace["tolerance_mm"],
        )
        print(
            "WORKSPACE_COMMISSIONING_SCAN_SHA256 =",
            commissioning_workspace["scan_sha256"],
        )
        print(
            "WORKSPACE_COMMISSIONING_RUNTIME_OVERRIDE =",
            commissioning_workspace["runtime_workspace_override"],
        )
        print(
            "WORKSPACE_COMMISSIONING_STATUS = "
            "offline_candidate_pending_alignment_only_physical_validation"
        )
    print(
        (
            "FINAL_NORMAL_DRIFT_REFERENCE_MM ="
            if alignment["normal_drift_monitor_only"]
            else "FINAL_NORMAL_DRIFT_LIMIT_MM ="
        ),
        alignment["maximum_final_normal_drift_mm"],
        (
            "scope=go2_adaptive_grasp_box_place_round_trip_only"
            if adaptive_grasp_box_place_enabled
            else "scope=base_alignment_config"
        ),
    )
    print("MAXIMUM_DEPLOYMENT_SEGMENT_DELTA_RAD =", maximum_segment_delta_rad)
    print(
        "OBSERVATION_ENDPOINT_CONVERGENCE ="
        f" success<={float(observation_endpoint_config['success_joint_error_rad']):.3f}rad"
        f" step<={float(observation_endpoint_config['bias_step_rad']):.3f}rad"
        f" bias<={float(observation_endpoint_config['maximum_bias_rad']):.3f}rad"
        f" attempts<={int(observation_endpoint_config['maximum_attempts'])}"
    )
    print(
        "ALIGNMENT_ENDPOINT_CONVERGENCE ="
        f" preferred<={float(alignment_endpoint_config['success_joint_error_rad']):.3f}rad"
        " fallback_after_all_attempts<="
        f"{float(alignment_endpoint_config['fallback_success_joint_error_rad']):.3f}rad"
        f" step<={float(alignment_endpoint_config['bias_step_rad']):.3f}rad"
        f" bias<={float(alignment_endpoint_config['maximum_bias_rad']):.3f}rad"
        f" attempts<={int(alignment_endpoint_config['maximum_attempts'])}"
    )
    success_mm = float(alignment["success_tangent_error_mm"])
    maximum_residual_mm = residual_config["maximum_residual_error_mm"]
    residual_policy = (
        f"plan_once_if_residual_exceeds={success_mm:.1f}mm"
        if maximum_residual_mm is None
        else f"range=({success_mm:.1f},{float(maximum_residual_mm):.1f}]mm"
    )
    print(
        "RESIDUAL_CORRECTION ="
        f" maximum_passes={int(residual_config['maximum_passes'])} {residual_policy}"
    )
    print(
        ("FAULT_RECOVERY = continuous checked path" if all_joint_speed is not None
         else "FAULT_RECOVERY = measured-state segmented")
        +
        f" step<={float(fault_recovery_config['maximum_joint_step_rad']):.3f}rad"
        f" speed<={float(fault_recovery_config['v_max_rad_s']):.3f}rad/s"
        f" support_wait={float(fault_recovery_config['operator_support_timeout_s']):.1f}s"
    )
    if grasp_orientation_enabled:
        print(
            "ADAPTIVE_GRASP_ORIENTATION ="
            " square_mod90"
            f" confidence>={float(grasp_orientation_config['minimum_orientation_confidence_score']):.2f}"
            f" p90<={float(grasp_orientation_config['maximum_orientation_p90_deviation_deg']):.1f}deg"
            f" {'preferred_rotation' if use_planned_alignment_range else 'rotation'}"
            f"<={float(grasp_orientation_config['maximum_rotation_deg']):.1f}deg"
            f" J6_speed<={float(grasp_orientation_config['j6_v_max_rad_s']):.2f}rad/s"
        )
    if commissioning_workspace is not None:
        print(
            "\nWORKSPACE COMMISSIONING: the requested scan cell is an offline "
            "candidate, not a validated grasp region."
        )
        print(
            "THIS RUN ONLY: zero deployment -> D455 detection -> verify the live "
            "target is inside the requested cell -> high-view center alignment -> "
            "reverse return."
        )
        print(
            "FORBIDDEN THIS RUN: J6 grasp-orientation change, descent, gripper "
            "close/open command, contact, lift, transport, or box placement."
        )
        print(
            "External Go2 body, fixed box, cables and soft supports remain "
            "operator-inspected obstacles because they are not fully modelled."
        )
    elif orientation_only_requested:
        print(
            "ORIENTATION_ONLY = True; descent, gripper, lift and box are forbidden"
        )
    if safe_descent_enabled:
        print(
            "SAFE_DESCENT ="
            f" target_clearance={float(safe_descent_config['target_normal_clearance_mm']):.1f}mm"
            f" distance_cap={float(safe_descent_config['maximum_descent_distance_mm']):.1f}mm"
            f" speed<={float(safe_descent_config['v_max_rad_s']):.3f}rad/s"
        )
        print(
            "SAFE_DESCENT_LOCAL_INITIAL_CLEARANCE_MM ="
            f" [{descent_runtime_clearance_range[0]:.1f},"
            f" {descent_runtime_clearance_range[1]:.1f}]"
            " scope=safe_descent_round_trip_only"
        )
        print(
            "FORBIDDEN = descent-below-safe-clearance, orientation-change,"
            " gripper-close, contact, lift, box-place"
        )
    elif adaptive_pregrasp_enabled:
        print(
            "ADAPTIVE_PREGRASP ="
            f" height={adaptive_pregrasp_config['height_statistic']}"
            f" top_clearance={float(adaptive_pregrasp_config['clearance_above_detected_top_mm']):.1f}mm"
            f" distance_cap={float(adaptive_pregrasp_config['maximum_descent_distance_mm']):.1f}mm"
            f" speed<={float(adaptive_pregrasp_config['v_max_rad_s']):.3f}rad/s"
        )
        print(
            "ADAPTIVE_PREGRASP_LOCAL_INITIAL_CLEARANCE_MM ="
            f" [{descent_runtime_clearance_range[0]:.1f},"
            f" {descent_runtime_clearance_range[1]:.1f}]"
            " scope=adaptive_pregrasp_round_trip_only"
        )
        print(
            "FORBIDDEN = low-view-camera-recheck,"
            + (
                " descent-below-grasp-height, payload-above-40g,"
                " unverified-box-route, automatic-loaded-fault-recovery"
                if adaptive_grasp_box_place_enabled
                else " descent-below-grasp-height, orientation-change, lift, box-place"
                if adaptive_secure_no_lift_enabled
                else " descent-below-adaptive-pregrasp-clearance, orientation-change,"
                " gripper-close, contact, lift, box-place"
            )
        )
        if adaptive_secure_no_lift_enabled:
            print(
                "ADAPTIVE_SECURE_NO_LIFT ="
                f" support_clearance={float(adaptive_secure_config['target_support_plane_tcp_clearance_mm']):.1f}mm"
                f" pregrasp_scale={float(adaptive_secure_config['pregrasp_descent_compensation_scale']):.2f}"
                f" low_scale={float(adaptive_secure_config['low_stage_compensation_scale']):.2f}"
                f" speed<={float(adaptive_secure_config['v_max_rad_s']):.3f}rad/s"
            )
            print(
                "ALIGNMENT_ENDPOINT_VISION_HANDOFF ="
                f" joint<={float(alignment_endpoint_vision_handoff_config['maximum_joint_error_rad']):.3f}rad"
                f" tcp<={float(alignment_endpoint_vision_handoff_config['maximum_tcp_error_mm']):.1f}mm"
                f" normal<={float(alignment_endpoint_vision_handoff_config['maximum_support_normal_error_mm']):.1f}mm"
                " final-vision-only"
            )
            print("ADAPTIVE_GRASP_CONFIG =", adaptive_grasp_config_path)
            print("ADAPTIVE_EMPTY_BASELINE =", adaptive_baseline_path)
            print(
                "ADAPTIVE_HARDWARE_IDENTITY_ASSUMPTION =",
                adaptive_secure_config["hardware_identity_assumption"],
            )
            if box_place_resources_enabled:
                print("BOX_PLAN =", box_plan_path)
                print("BOX_PLAN_SHA256 =", file_sha256(box_plan_path))
                print("BOX_COLLISION_REPORT =", box_report_path)
                print("BOX_COLLISION_REPORT_VERIFIED = True")
                print("BOX_EMPTY_ROUTE_EVIDENCE =", box_evidence_path)
                print("BOX_EMPTY_ROUTE_EVIDENCE_VERIFIED = True")
                print(
                    "BOX_TARGET ="
                    f" edge={box_target_edge_label}"
                    f" configured_mass={float(box_place_config['maximum_test_mass_g']):.1f}g"
                )
                print(
                    "BOX_ROUTE_TILT_SCALE =",
                    f"{float(box_place_config['box_route_compensation_scale']):.2f}",
                )
                print("BOX_ROUTE_SCALE_OVERRIDE =", box_route_scale_override)
    else:
        print("FORBIDDEN = descent, orientation-change, gripper-close, lift, box-place")
    print("UNMODELLED_EXTERNAL_OBSTACLES =", report["unmodelled_external_obstacles"])

    if not args.execute:
        print("OFFLINE_ONLY = True")
        print("ARM_SERIAL_ACCESS = False")
        print("CAMERA_ACCESS = False")
        print("RESULT = OFFLINE_PREFLIGHT_OK")
        return 0

    if center_only_diagnostic:
        print("\nCENTER ALIGNMENT DIAGNOSTIC: zero -> observation -> center alignment -> reverse return.")
        print("Go2 crouched with the battery fixed; one cube; clear route and continuous supervision.")
        print("FORBIDDEN THIS RUN: J6 orientation, descent, gripper commands, lift and box placement.")
    elif orientation_only_requested:
        print(
            "\nFIRST ORIENTATION COMMISSIONING: zero deployment -> high-view "
            "detection/center alignment -> square-symmetric grasp orientation -> "
            "reverse return."
        )
        print(
            "REQUIRED: exactly one square cube; Go2 crouched and stationary; "
            "soft support must not obstruct the route; continuous supervision."
        )
        print(
            "FORBIDDEN THIS RUN: descent, gripper close/open command, contact, "
            "lift, transport, or box placement."
        )
        print(
            "The D455 final high-view detection supplies the square edge axis. "
            "Only the selected bounded tool rotation is executed before the "
            "alignment and deployment paths are reversed."
        )
    elif adaptive_grasp_box_place_enabled:
        print(
            "\nLOADED BOX COMMISSIONING: zero deployment -> high-view "
            "detection/alignment -> adaptive secure grasp -> reverse-path lift -> "
            "verified fixed-box route -> partial insertion -> release -> empty return."
        )
        print(
            f"REQUIRED: exactly one cube with edge {box_target_edge_label} "
            f"with configured object mass {box_place_config['maximum_test_mass_g']:g}g; "
            "fixed funnel box; Go2 crouched and stationary; all routes clear; "
            "continuous operator supervision."
        )
        print(
            "LOADED FAULT POLICY: while the cube may still be held, automatic "
            "release and automatic recovery motion are forbidden; support/remove "
            "the payload when prompted, then the program disables."
        )
    elif adaptive_secure_no_lift_enabled:
        print(
            "\nFIRST CONTACT COMMISSIONING: zero deployment -> high-view detection "
            "and alignment -> 20mm pregrasp -> bounded low descent -> adaptive "
            "contact and preload -> release in place -> reverse return."
        )
        print(
            "REQUIRED: exactly one approximately 50mm cube; Go2 crouched and "
            "stationary; soft support must not obstruct the route; operator "
            "must supervise throughout."
        )
        print(
            "FORBIDDEN THIS RUN: lift, transport, box placement, orientation "
            "change, or descent below the calibrated grasp height."
        )
    elif descent_round_trip_enabled:
        print(
            "\n首次实机只验证：零位自动部署 -> 单目标识别 -> 高位中心对准 -> "
            "沿实测支撑面法向下降到安全净空 -> 原路返回。"
        )
    else:
        print("\n首次实机只验证：零位自动部署 -> 单目标识别 -> 高位中心对准 -> 原路返回。")
    print("DEPLOYMENT_VALID_ONLY_IF =", deployment_valid_only_if)
    print("WRIST_VALID_ONLY_IF =", wrist_valid_only_if)
    descent_clearance_description = (
        f"{float(safe_descent_config['target_normal_clearance_mm']):.1f}mm"
        if safe_descent_enabled
        else (
            f"{float(adaptive_pregrasp_config['clearance_above_detected_top_mm']):.1f}mm"
            " above detected target top"
            if adaptive_pregrasp_enabled
            else "not-applicable"
        )
    )
    if center_only_diagnostic:
        print("Final high-view geometry verifies center alignment only; no J6 orientation follows.")
    elif orientation_only_requested:
        print(
            "The final high-view target geometry is used only for center and "
            "square orientation alignment; no descent or gripper action follows."
        )
    elif adaptive_grasp_box_place_enabled:
        print(
            "The D455 low-view depth is not reused. High-view target geometry is "
            "frozen for encoder/FK descent. After verified adaptive preload, "
            "the checked descent is reversed to the high pose, then a continuous "
            "joint bridge joins the checked box approach while maintaining grip. "
            "Release occurs at the fixed box_release pose."
        )
    elif adaptive_secure_no_lift_enabled:
        print(
            "The D455 low-view depth is not reused. The accepted high-view target "
            "top and p90 height are frozen for encoder/FK descent. The gripper is "
            "opened before descent and any detected contact is released before "
            "the arm moves upward."
        )
    elif descent_round_trip_enabled:
        print(
            "软支撑不得阻挡路径；夹爪全程保持当前开口；本次最低仍保留"
            f"{descent_clearance_description}"
            "法向净空，不接触、不合爪、不提升。"
        )
    else:
        print("软支撑不得阻挡路径；夹爪全程保持当前开口，不下降、不接触目标。")
    if not args.non_interactive and input("确认上述条件后输入 e：").strip().lower() != "e":
        print("RESULT = CANCELLED_BEFORE_CONNECTION")
        return 2

    run_id = make_run_id(args.run_id)
    run_dir = DEFAULT_OUTPUT_ROOT / run_id
    if run_dir.exists():
        raise FileExistsError(f"run directory already exists: {run_dir}")
    log_path = run_dir / "run.json"
    log = {
        "schema_version": 1,
        "mode": operation,
        "grasp_side": grasp_side,
        "status": "started",
        "config": str(config_path.relative_to(PROJECT_ROOT)),
        "config_sha256": file_sha256(config_path),
        "camera_target_depth_window_enabled": observation_safety.get("camera_target_depth_window_enabled", True),
        "deployment_acceleration_rad_s2": args.deployment_acceleration_rad_s2,
        "descent_acceleration_rad_s2": args.descent_acceleration_rad_s2,
        "maximum_acceleration_rad_s2": args.acceleration_rad_s2,
        "motion_speed_scale": motion_speed_scale,
        "transit_speed_rad_s": transit_speed,
        "all_joint_speed_rad_s": all_joint_speed,
        "descent_speed_rad_s": descent_speed,
        "tilt_compensation_enabled": tilt_compensation_enabled,
        "loaded_transport_mode": (
            "direct_high_to_release_continuous"
            if adaptive_grasp_box_place_enabled and adaptive_target_size else "original"
        ),
        "motion_tracking_policy": "repeat_current_target_until_caught_up",
        "motion_clock": "bounded_elapsed" if fast_motion else "fixed_tick",
        "effective_motion": dict(config["motion"]),
        "plan": str(plan_path.relative_to(PROJECT_ROOT)),
        "plan_sha256": file_sha256(plan_path),
        "wrist_config_sha256": file_sha256(loaded.path),
        "candidate_sha256": file_sha256(loaded.candidate_path),
        "orientation_only_requested": orientation_only_requested,
        "center_only_diagnostic": center_only_diagnostic,
        "workspace_commissioning": commissioning_workspace,
    }
    if adaptive_secure_no_lift_enabled:
        log["adaptive_grasp_resources"] = {
            "config": str(adaptive_grasp_config_path.relative_to(PROJECT_ROOT)),
            "config_sha256": file_sha256(adaptive_grasp_config_path),
            "empty_baseline": str(adaptive_baseline_path.relative_to(PROJECT_ROOT)),
            "empty_baseline_sha256": file_sha256(adaptive_baseline_path),
            "hardware_identity_assumption": adaptive_secure_config[
                "hardware_identity_assumption"
            ],
        }
    if box_place_resources_enabled:
        log["box_place_resources"] = {
            "plan": str(box_plan_path.relative_to(PROJECT_ROOT)),
            "plan_sha256": file_sha256(box_plan_path),
            "collision_report": str(box_report_path.relative_to(PROJECT_ROOT)),
            "collision_report_sha256": file_sha256(box_report_path),
            "empty_route_evidence": str(box_evidence_path.relative_to(PROJECT_ROOT)),
            "empty_route_evidence_sha256": file_sha256(box_evidence_path),
            "maximum_test_mass_g": float(box_place_config["maximum_test_mass_g"]),
            "configured_payload_mass_g": float(box_place_config["maximum_test_mass_g"]),
            "target_edge_mm": box_target_edge_mm,
            "adaptive_target_size": adaptive_target_size,
            "route_scale_override": box_route_scale_override,
        }
    write_json(log_path, log)

    motion = config["motion"]
    limits = SafetyLimits(
        hz=float(motion["hz"]),
        v_max_rad_s=float(motion["v_max_rad_s"]),
        j6_v_max_rad_s=float(motion["j6_v_max_rad_s"]),
        motion_profile=str(motion["profile"]),
        max_acceleration_rad_s2=args.acceleration_rad_s2,
        max_track_err_rad=float(motion["maximum_track_error_rad"]),
        max_speed_rad_s=float(motion["maximum_measured_speed_rad_s"]),
        max_temp_c=float(motion["maximum_temperature_c"]),
        max_joint_delta_rad=maximum_segment_delta_rad,
        settle_seconds=float(motion["settle_seconds"]),
        elapsed_cycle_progress=fast_motion,
        pause_on_tracking_lag=True,
    )

    from S1_SDK.hardware.collision import CollisionChecker

    collision_checker = CollisionChecker("gripper")
    if collision_checker.model is None:
        collision_checker._load_model(gripper=True)
    if collision_checker.model is None or collision_checker.data is None:
        raise RuntimeError("MuJoCo collision model failed to load")

    tilt_model = UrdfGravityModel.from_file(locate_official_gripper_urdf())
    flange_kinematics = Kinematics(tcp=[0.0, 0.0, 0.0], verbose=False)
    tcp_kinematics = Kinematics(verbose=True)
    vision_config, vision_config_path = load_detector_config(
        loaded.vision_config_path
    )
    print("VISION_CONFIG =", vision_config_path)
    print(
        "CAPTURE_QUALITY_OVERRIDE ="
        f" scope={capture_quality_override['scope']}"
        " maximum_frame_interval_ms="
        f"{float(capture_quality_override['maximum_frame_interval_ms']):.1f}"
        f" status={capture_quality_override['status']}"
    )
    print(
        "GEOMETRY_QUALITY_OVERRIDE ="
        f" scope={geometry_quality_override['scope']}"
        " maximum_camera_tilt_from_down_deg="
        f"{local_camera_tilt_limit:.1f}"
        f" status={geometry_quality_override['status']}"
    )
    print("D455_PAYLOAD_COMPENSATION_FULL_ALIGNMENT = disabled")
    print("SUPPORT_NORMAL_DEVIATION_REFERENCE =", runtime.get(
        "support_normal_deviation_reference", "mount_record_pitch_only"
    ))
    vertical_scale = float(tilt_schedule["vertical_escape_scale"])
    high_turn_scale = float(tilt_schedule["high_turn_scale"])
    side_scale = float(tilt_schedule["side_deploy_scale"])
    pregrasp_descent_scale = (
        float(adaptive_secure_config["pregrasp_descent_compensation_scale"])
        if adaptive_secure_no_lift_enabled
        else side_scale
    )
    transition_s = float(tilt_schedule["scale_transition_s"])
    commander = commander_from_mount_record(
        tilt_model,
        mount_record,
        vertical_scale,
        maximum_support_tilt_deg=float(tilt_config["maximum_support_tilt_deg"]),
        maximum_support_normal_deviation_deg=float(
            tilt_config["maximum_support_normal_deviation_from_mount_deg"]
        ),
        support_normal_blend=float(tilt_config["support_normal_blend"]),
        normal_transition_s=float(tilt_config["normal_transition_s"]),
        deviation_reference_source=runtime.get(
            "support_normal_deviation_reference", "mount_record_pitch_only"
        ),
    )
    commander.tilt_compensation_enabled = tilt_compensation_enabled
    if not tilt_compensation_enabled:
        commander.normal_transition_s = 0.0
        vertical_scale = high_turn_scale = side_scale = pregrasp_descent_scale = 0.0
        if adaptive_secure_config is not None:
            adaptive_secure_config["pregrasp_descent_compensation_scale"] = 0.0
            adaptive_secure_config["low_stage_compensation_scale"] = 0.0
        if box_place_config is not None:
            box_place_config["box_route_compensation_scale"] = 0.0
    print("SUPPORT_NORMAL_NOMINAL_DEVIATION_POLICY = diagnostic_only")
    print("SUPPORT_NORMAL_DEVIATION_REFERENCE_BASE =",
          commander.deviation_reference_support_up_normal_base.tolist())
    if local_j3_limit is not None:
        log["local_j3_tilt_correction_limit"] = local_j3_limit
        write_json(log_path, log)
    if local_j2_limit is not None:
        log["local_j2_tilt_correction_limit"] = local_j2_limit
        write_json(log_path, log)

    control_trace = None
    arm = None
    enabled = False
    deployed = False
    alignment_path = None
    executed_alignment_path = []
    alignment_motion_started = False
    search_path = []
    executed_descent_path = []
    descent_motion_started = False
    executed_low_descent_path = []
    low_descent_motion_started = False
    pregrasp_compensation_scale_active = False
    low_compensation_scale_active = False
    adaptive_gripper = None
    adaptive_gripper_may_be_closed = False
    adaptive_secure_outcome = None
    payload_held = False
    payload_grip_gap_mm = None
    payload_grip_force_nm = None
    box_route_in_progress = False
    box_release_verified = False
    result = "ABORTED"
    try:
        arm = (arm_session.acquire(limits) if arm_session is not None else
               Arm(dev=args.dev, end_effector="gripper", limits=limits, check_collision=False))
        if runtime.get("record_control_trace", False):
            trace_path = run_dir / "position_command_trace.jsonl"
            control_trace = CommandTrace(commander, trace_path)
            arm.set_position_commander(control_trace)
            log["control_trace"] = {
                "path": str(trace_path), "nominal_sample_hz": 20.0,
                "feedback_source": "existing SDK snapshot; freshness not independently verified",
                "measurement_timing": "snapshot sampled before issuing the current command",
            }
            print("CONTROL_TRACE =", trace_path)
        else:
            arm.set_position_commander(commander)
        if adaptive_secure_no_lift_enabled:
            adaptive_gripper = Gripper(arm)
        start_q, temperature, readiness = wait_for_valid_feedback(arm, limits.max_temp_c)
        print("STARTUP_FEEDBACK_READY =", readiness["ready"])
        print("START_Q =", [round(value, 6) for value in start_q])
        print("TEMPERATURE_C =", [round(value, 1) for value in temperature])
        violations = start_window_violations(start_q, plan["start_safe_windows_rad"])
        rear_ready = [float(value) for value in waypoints[1]["q"]]
        start_delta = max_joint_delta(start_q, rear_ready)
        live_ok = not violations and start_delta <= limits.max_joint_delta_rad
        print("START_SAFE_WINDOW_OK =", not violations)
        for violation in violations:
            print("START_WINDOW_VIOLATION =", violation)
        print("START_TO_REAR_READY_DELTA_RAD =", round(start_delta, 6))
        print("LIVE_PRECHECK_OK =", live_ok)
        if not live_ok:
            result = "LIVE_PRECHECK_REJECTED"
            return 2
        arm.preflight(
            [(item["name"], item["q"]) for item in waypoints[1:]],
            start_q,
            collision_report_verified=True,
        )
        if box_place_resources_enabled:
            box_route = box_plan["route"]
            box_rear_ready = [float(value) for value in box_route[0]["q"]]
            if max_joint_delta(rear_ready, box_rear_ready) > 1e-9:
                raise RuntimeError(
                    "visual deployment and box route use different rear_ready poses"
                )
            arm.preflight(
                [(item["name"], item["q"]) for item in box_route[1:]],
                box_rear_ready,
                collision_report_verified=True,
            )
            print("BOX_ROUTE_LIVE_PREFLIGHT_OK = True")
        if not args.non_interactive and input("确认当前所选侧部署、目标上方高位对准及返回路径净空，输入 d：").strip().lower() != "d":
            result = "CANCELLED_BEFORE_ENABLE"
            return 2

        phases = planned_phases(start_q, waypoints, observation_name)
        if arm_session is None:
            arm.enable()
        enabled = True
        print("ENABLED_WITH_TILT_COMPENSATION scale =", f"{vertical_scale:.2f}")
        hold_with_tilt_policy(arm, start_q, 0.5, "initial_hold")
        for name, points in phases:
            if name == "high_turn" and not math.isclose(
                vertical_scale, high_turn_scale, abs_tol=1e-9
            ):
                print(
                    "TILT_SCALE_TRANSITION =",
                    f"{vertical_scale:.2f}->{high_turn_scale:.2f}",
                )
                ramp_tilt_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=vertical_scale,
                    end_scale=high_turn_scale,
                    duration_s=transition_s,
                    label="rear_ready_high_turn_scale_up",
                )
            if name == "side_deploy":
                print(
                    "TILT_SCALE_TRANSITION =",
                    f"{high_turn_scale:.2f}->{side_scale:.2f}",
                )
                ramp_tilt_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=high_turn_scale,
                    end_scale=side_scale,
                    duration_s=transition_s,
                    label="right_ready_scale_up",
                )
            print("DEPLOY_PHASE =", name)
            if control_trace is not None:
                control_trace.phase = name
            normal_acceleration = arm.limits.max_acceleration_rad_s2
            arm.limits.max_acceleration_rad_s2 = (
                min(normal_acceleration,args.deployment_acceleration_rad_s2)
                if normal_acceleration is not None else None)
            print("DEPLOYMENT_PHASE_ACCELERATION_RAD_S2 =", name,
                  arm.limits.max_acceleration_rad_s2)
            try:
                fault = arm.move_waypoints(points, name)
            finally:
                arm.limits.max_acceleration_rad_s2 = normal_acceleration
            if fault:
                raise RuntimeError(fault)
            print("到达:", name)
        deployed = True
        q_observe = list(phases[-1][1][-1])
        if motion_speed_scale <= 1.0:
            hold_with_tilt_policy(arm, q_observe, 1.0, "observation_hold")

        def save_observation_endpoint_progress(record):
            log["observation_endpoint_convergence"] = record
            write_json(log_path, log)

        try:
            observation_endpoint = converge_observation_endpoint(
                arm,
                q_observe,
                endpoint_config=observation_endpoint_config,
                kinematics=tcp_kinematics,
                collision_checker=collision_checker,
                tilt_model=tilt_model,
                support_up_normal_base=commander.nominal_support_up_normal_base,
                compensation_scale=side_scale,
                torque_limits=mount_record["diagnostic"][
                    "correction_absolute_limits_nm"
                ],
                progress_callback=save_observation_endpoint_progress,
            )
        except ObservationEndpointConvergenceError as exc:
            log["observation_endpoint_convergence"] = exc.record
            write_json(log_path, log)
            raise
        log["observation_endpoint_convergence"] = observation_endpoint
        observation_command_q = list(
            observation_endpoint["final_command_q_rad"]
        )
        write_json(log_path, log)
        print("OBSERVATION_ENDPOINT_CONVERGED = True")
        print(
            "OBSERVATION_ENDPOINT_COMMAND_BIAS_RAD =",
            [
                round(command - desired, 6)
                for command, desired in zip(observation_command_q, q_observe)
            ],
        )
        print("OBSERVATION_POSE_REACHED = True")

        def capture_observation_view(q_hold, capture_label):
            return run_capture_process_while_holding(
                arm,
                q_hold,
                wrist_config_path=loaded.path,
                vision_config_path=vision_config_path,
                run_dir=run_dir,
                capture_label=capture_label,
                timeout_s=worker_timeout_s,
                label=f"{capture_label}_capture_detection",
                hold_hz=capture_hold_hz,
                velocity_guard_hz=capture_velocity_guard_hz,
                temperature_period_s=capture_temperature_period_s,
                camera_attempts=camera_attempts,
                camera_retry_delay_s=camera_retry_delay_s,
                capture_quality_override=capture_quality_override,
                write_raw_capture_previews=write_raw_capture_previews,
                search_full_frame_on_miss=adaptive_target_size,
            )
        def observe_view(capture, measured, q_hold, *, allow_geometry_rejection=False):
            def transform_observation():
                try:
                    record = compute_observation(
                        capture, measured, loaded=loaded,
                        flange_kinematics=flange_kinematics,
                        observation_safety=observation_safety,
                    )
                except (ValueError, RuntimeError) as exc:
                    if not allow_geometry_rejection:
                        raise
                    return None, str(exc)
                return record, None

            result, _ = run_worker_while_holding(
                arm, q_hold, transform_observation,
                timeout_s=worker_timeout_s,
                label="initial_observation_transform",
            )
            return result

        def view_alignment_distance(record, measured):
            observed = record["observation"]
            tcp = np.asarray(tcp_kinematics.fk(measured)[:3])
            delta = np.asarray(observed["surface_point_base_m"]) - tcp
            normal = np.asarray(observed["support_up_normal_base"])
            return 1000.0 * float(np.linalg.norm(delta - (delta @ normal) * normal))

        def check_alignment_body(path):
            body = go2_envelope_check(
                collision_checker,
                densify_joint_path(path, float(alignment["collision_step_rad"])),
                deployment_source,
            )
            if not body["pass"]:
                raise RuntimeError(
                    "Go2 envelope rejects high-view alignment: "
                    + str(body["violations"][0])
                )
            return body

        def prepare_view_alignment(view_record, q_hold, capture, *, allow_search=False):
            view_observation = view_record["observation"]
            update = commander.set_support_up_normal(
                view_observation["support_up_normal_base"],
                source="validated_support_plane:go2_visual_alignment",
            )
            if control_trace is not None:
                control_trace.phase = "support_normal_update_hold"
            normal_hold_s = float(tilt_config["normal_transition_s"]) + 0.25
            hold_with_tilt_policy(arm, q_hold, normal_hold_s, "support_normal_transition")
            start_q = (
                sample_endpoint_hold(
                    arm, q_hold, float(observation_endpoint_config["hold_seconds"]),
                    "post_support_normal_rebase_hold",
                )
                if tilt_compensation_enabled else measured_position_from_commander(arm)
            )
            tracking = endpoint_tracking_record(q_hold, start_q, tcp_kinematics)
            rebase = {
                "status": "planning_start_rebound_to_measured_state",
                "tracking": tracking,
            }
            log["post_support_normal_rebase"] = rebase
            write_json(log_path, log)
            applied_up = blended_support_up_normal(
                commander.nominal_support_up_normal_base,
                view_observation["support_up_normal_base"],
                float(tilt_config["support_normal_blend"]),
            )

            def plan_view():
                options = dict(
                    planning_start_q_rad=start_q, loaded=loaded,
                    alignment=alignment, tcp_kinematics=tcp_kinematics,
                    collision_checker=collision_checker, tilt_model=tilt_model,
                    applied_support_up=applied_up, side_scale=side_scale,
                    torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                )
                try:
                    try:
                        planned = compute_alignment_plan(view_record, **options)
                    except RuntimeError as exc:
                        if not (
                            args.flexible_approach
                            and str(exc).startswith((
                                "no safe continuous IK solution",
                                "tilt compensation torque cap",
                            ))
                        ):
                            raise
                        planned = compute_flexible_grasp_approach(
                            view_record, capture, alignment_options=options,
                            flange_kinematics=flange_kinematics,
                            observation_safety=observation_safety,
                            orientation_config=grasp_orientation_config,
                            pregrasp_config=adaptive_pregrasp_config,
                            secure_config=adaptive_secure_config,
                            check_body=check_alignment_body,
                        )
                        planned["flexible_approach"]["straight_path_rejection"] = str(exc)
                    if (
                        use_planned_alignment_range
                        and not planned["cartesian_path"]["converged"]
                        and "alignment_body_check" not in planned
                    ):
                        planned["alignment_body_check"] = check_alignment_body(
                            planned["alignment_joint_path"]
                        )
                except (ValueError, RuntimeError) as exc:
                    if not allow_search:
                        raise
                    return None, str(exc)
                return planned, None

            (planned, rejection), _ = run_worker_while_holding(
                arm, q_hold, plan_view, timeout_s=worker_timeout_s, label="alignment_planning",
            )
            if rejection is not None:
                commander.set_support_up_normal(
                    commander.nominal_support_up_normal_base,
                    source="mount_record_pitch_only:search_view_rejected",
                )
                hold_with_tilt_policy(arm, q_hold, normal_hold_s, "search_view_normal_restore")
                return None, rejection
            planned["support_normal_update"] = update
            planned["post_support_normal_rebase"] = rebase
            return (planned, start_q, applied_up), None

        initial_capture, measured_q = capture_observation_view(
            observation_command_q, "initial"
        )
        observation_record = None
        prepared_alignment = None
        capture_reference_q = q_observe
        if search_views:
            status = initial_capture["detection"]["status"]
            known_target = status == "DETECTED_CAMERA_FRAME_ONLY"
            first_geometry_rejection = None
            first_planning_rejection = None
            if known_target:
                observation_record, first_geometry_rejection = observe_view(
                    initial_capture, measured_q, observation_command_q,
                    allow_geometry_rejection=True,
                )
            first_distance_mm = (
                view_alignment_distance(observation_record, measured_q)
                if observation_record is not None else None
            )
            if observation_record is not None:
                prepared_alignment, first_planning_rejection = prepare_view_alignment(
                    observation_record, observation_command_q, initial_capture, allow_search=True
                )
            search_needed = status == "NO_TARGET" or (
                known_target and prepared_alignment is None
            )
            if search_needed:
                if first_planning_rejection is not None:
                    print("HIGH_VIEW_ALIGNMENT_REJECTED = initial", first_planning_rejection)
                search_log = {
                    "status": "searching",
                    "plan": str(search_plan_path),
                    "plan_sha256": file_sha256(search_plan_path),
                    "first_capture": initial_capture,
                    "first_geometry_rejection": first_geometry_rejection,
                    "first_planning_rejection": first_planning_rejection,
                    "first_initial_alignment_distance_mm": first_distance_mm,
                    "first_target_base_m": (
                        observation_record["observation"]["surface_point_base_m"]
                        if observation_record is not None else None
                    ),
                    "observations": [],
                }
                log["high_view_search"] = search_log
                hub_command = list(observation_command_q)
                ordered_views = (
                    sorted(
                        search_views,
                        key=lambda view: view_alignment_distance(observation_record, view["q_rad"]),
                    )
                    if observation_record is not None else search_views
                )
                for index, view in enumerate(ordered_views, start=1):
                    path = [list(q) for q in view["path_from_hub_q_rad"]]
                    if max_joint_delta(path[0], q_observe) > 1e-6:
                        raise RuntimeError(f"search view does not start at right_observe: {view['name']}")
                    if max_joint_delta(hub_command, path[0]) > 1e-9:
                        path.insert(0, hub_command)
                    check_collision_path(
                        collision_checker, path, float(alignment["collision_step_rad"])
                    )
                    search_path = path
                    view_label = f"search_view_{index:02d}"
                    if control_trace is not None:
                        control_trace.phase = view_label + "_outbound"
                    print("HIGH_VIEW_SEARCH_OUTBOUND =", view["name"])
                    fault = arm.move_waypoints(search_path, view_label)
                    if fault:
                        raise RuntimeError(fault)
                    candidate, candidate_q = capture_observation_view(search_path[-1], view_label)
                    entry = {
                        "name": view["name"],
                        "capture": candidate,
                        "measured_q_rad": candidate_q,
                    }
                    search_log["observations"].append(entry)
                    if candidate["detection"]["status"] == "DETECTED_CAMERA_FRAME_ONLY":
                        candidate_record, geometry_rejection = observe_view(
                            candidate, candidate_q, search_path[-1],
                            allow_geometry_rejection=True,
                        )
                        if geometry_rejection is not None:
                            entry["geometry_rejection"] = geometry_rejection
                    else:
                        candidate_record = None
                    if candidate_record is not None:
                        entry["target_base_m"] = candidate_record["observation"]["surface_point_base_m"]
                        entry["initial_alignment_distance_mm"] = view_alignment_distance(
                            candidate_record, candidate_q
                        )
                        prepared_alignment, planning_rejection = prepare_view_alignment(
                            candidate_record, search_path[-1], candidate, allow_search=True
                        )
                        if planning_rejection is not None:
                            entry["planning_rejection"] = planning_rejection
                            print("HIGH_VIEW_ALIGNMENT_REJECTED =", view["name"], planning_rejection)
                        if prepared_alignment is not None:
                            initial_capture, measured_q = candidate, candidate_q
                            observation_record = candidate_record
                            observation_command_q = list(search_path[-1])
                            capture_reference_q = observation_command_q
                            search_log.update(status="target_acquired", selected_view=view["name"])
                            write_json(log_path, log)
                            print("HIGH_VIEW_SEARCH_TARGET_ACQUIRED =", view["name"])
                            break
                    write_json(log_path, log)
                    if control_trace is not None:
                        control_trace.phase = view_label + "_return"
                    fault = arm.move_waypoints(list(reversed(search_path)), view_label + "_return")
                    if fault:
                        raise RuntimeError(fault)
                    search_path = []
                else:
                    search_log["status"] = "no_grasp_handoff_at_current_stance"
                    write_json(log_path, log)
                    raise RuntimeError("high-view search exhausted without a grasp handoff at this Go2 stance")

        initial_capture_tracking = endpoint_tracking_record(
            capture_reference_q, measured_q, tcp_kinematics
        )
        log["initial_capture_tracking"] = initial_capture_tracking
        write_json(log_path, log)
        print(
            "INITIAL_CAPTURE_TRACKING ="
            f" joint_error={initial_capture_tracking['maximum_abs_joint_error_rad']:.5f}rad"
            f" tcp_error={initial_capture_tracking['tcp_error_norm_mm']:.2f}mm"
            " measured_tcp_mm=",
            [
                round(1000.0 * value, 3)
                for value in initial_capture_tracking[
                    "measured_tcp_pose_xyz_xyzw"
                ][:3]
            ],
        )
        if observation_record is None:
            observation_record, _ = observe_view(
                initial_capture, measured_q, observation_command_q
            )
        observation = observation_record["observation"]
        if commissioning_workspace is not None:
            live_commissioning = validate_workspace_commissioning_observation(
                observation,
                commissioning_workspace,
            )
            commissioning_workspace["live_observation"] = live_commissioning
            log["workspace_commissioning"] = commissioning_workspace
            write_json(log_path, log)
            print(
                "WORKSPACE_COMMISSIONING_LIVE_MATCH ="
                f" u={live_commissioning['observed_u_mm']:.1f}mm"
                f" v={live_commissioning['observed_v_mm']:.1f}mm"
                f" normal={live_commissioning['support_normal_offset_mm']:.1f}mm"
                f" cell_error={live_commissioning['requested_cell_error_mm']:.1f}mm"
                " result=PASS"
            )
        if prepared_alignment is None:
            prepared_alignment, _ = prepare_view_alignment(
                observation_record, observation_command_q, initial_capture
            )
        planning_record, post_support_q, applied_support_up = prepared_alignment
        support_update = planning_record["support_normal_update"]
        post_support_tracking = planning_record["post_support_normal_rebase"]["tracking"]
        print(
            "POST_SUPPORT_NORMAL_REBASE ="
            f" joint_error={post_support_tracking['maximum_abs_joint_error_rad']:.5f}rad"
            f" tcp_error={post_support_tracking['tcp_error_norm_mm']:.2f}mm"
            " planning_start=measured"
        )
        cartesian_path = planning_record["cartesian_path"]
        print(
            "INITIAL_TANGENT_ERROR_MM =",
            [round(value, 3) for value in cartesian_path["initial_tangent_error_base_xyz_mm"]],
            "NORM =",
            round(cartesian_path["initial_tangent_error_norm_mm"], 3),
        )
        print("SUPPORT_UP_NORMAL_BASE =", [round(value, 6) for value in observation["support_up_normal_base"]])
        print("NORMAL_CLEARANCE_MM =", round(cartesian_path["normal_clearance_mm"], 3))
        print("SUPPORT_NORMAL_UPDATE =", support_update)

        planning_record["initial_capture"] = initial_capture
        flexible_approach = planning_record.get("flexible_approach")
        if flexible_approach is not None:
            print("FLEXIBLE_HIGH_VIEW_APPROACH_SELECTED =", flexible_approach)
        if "alignment_body_check" in planning_record:
            print("HIGH_VIEW_ALIGNMENT_BODY_CHECKED = True")
        log["planning"] = planning_record
        write_json(log_path, log)
        if not cartesian_path["converged"]:
            alignment_path = planning_record["alignment_joint_path"]
            collision = planning_record["collision"]
            torque = planning_record["torque"]
            print("ALIGNMENT_CARTESIAN_SEGMENTS =", cartesian_path["segment_count"])
            print("ALIGNMENT_COLLISION_OK = True samples =", collision["sample_count"])
            print("ALIGNMENT_TORQUE_ENVELOPE_OK = True max_fraction =", round(torque["maximum_limit_fraction"], 3))
            if continuous_alignment_enabled:
                alignment_path, handoff_proof = prepare_continuous_alignment_path_while_holding(
                    arm, alignment_path, collision_checker=collision_checker,
                    label="initial_alignment_handoff_preflight", timeout_s=worker_timeout_s,
                    tilt_model=tilt_model, support_up_normal_base=applied_support_up,
                    compensation_scale=side_scale,
                    torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                    collision_step_rad=float(alignment["collision_step_rad"]),
                    minimum_joint_margin_deg=float(alignment["minimum_joint_margin_deg"]),
                    workspace=loaded.record["validated_workspace"], kinematics=tcp_kinematics,
                    preserve_physical_offsets=preserve_position_bias,
                    maximum_offset_rad=float(runtime.get("maximum_learned_position_bias_rad", .05)),
                    clip_learned_offset=use_planned_alignment_range,
                )
                if "alignment_body_check" in planning_record:
                    body, _ = run_worker_while_holding(
                        arm, observation_command_q,
                        lambda: check_alignment_body(alignment_path),
                        timeout_s=worker_timeout_s, label="alignment_handoff_body_check",
                    )
                    handoff_proof["go2_body_check"] = body
                log["alignment_command_handoff"] = handoff_proof
                write_json(log_path, log)
                control_trace.phase = "support_tangent_center_alignment"
                print("CONTINUOUS_COMMAND_HANDOFF = initial_alignment preflight=PASS")
                if preserve_position_bias:
                    live_normal = np.asarray(observation["support_up_normal_base"], dtype=float)
                    live_height = lambda q: 1000.0 * float(
                        np.dot(np.asarray(tcp_kinematics.fk(q)[:3]), live_normal)
                    )
                    reference_height = live_height(planning_record["planning_start_q_rad"])
                    drift_trace = configure_alignment_downward_trace(
                        control_trace, runtime, live_height, reference_height)
                    log["live_alignment_normal_guard"] = {
                        **drift_trace, "support_up_normal_base": live_normal.tolist(),
                    }
                    print("LEARNED_COMMAND_OFFSET_RAD =", handoff_proof["learned_command_offset_rad"])
                    print("LIVE_ALIGNMENT_DOWNWARD_MODE =", drift_trace["mode"])
                    if drift_trace["maximum_downward_mm"] is not None:
                        print("LIVE_ALIGNMENT_DOWNWARD_LIMIT_MM =", drift_trace["maximum_downward_mm"])
            executed_alignment_path = [list(q) for q in alignment_path]
            alignment_motion_started = True
            previous_alignment_j6_v_max = arm.limits.j6_v_max_rad_s
            if use_planned_alignment_range and grasp_orientation_config is not None:
                arm.limits.j6_v_max_rad_s = min(
                    previous_alignment_j6_v_max,
                    float(grasp_orientation_config["j6_v_max_rad_s"]),
                )
                log["alignment_j6_v_max_rad_s"] = arm.limits.j6_v_max_rad_s
                print("ALIGNMENT_J6_V_MAX_RAD_S =", arm.limits.j6_v_max_rad_s)
            try:
                if runtime.get("feedback_synchronized_alignment", False):
                    report = log.setdefault("feedback_alignment", {})
                    print("FEEDBACK_SHARED_CLOCK = enabled soft=0.002rad stop=0.004rad")
                    fault = move_feedback_synchronized(
                        arm, alignment_path, planning_record["alignment_joint_path"],
                        "support_tangent_center_alignment", report,
                    )
                else:
                    fault = arm.move_waypoints(alignment_path, "support_tangent_center_alignment")
            finally:
                arm.limits.j6_v_max_rad_s = previous_alignment_j6_v_max
            if fault:
                raise RuntimeError(fault)

            def save_alignment_endpoint_progress(record):
                log["alignment_endpoint_convergence_pass_1"] = record
                trim_q = record.get("executed_flexible_trim_command_q_rad")
                if trim_q is not None and trim_q != executed_alignment_path[-1]:
                    executed_alignment_path.append(list(trim_q))
                write_json(log_path, log)

            try:
                alignment_endpoint = converge_observation_endpoint(
                    arm,
                    (planning_record["alignment_joint_path"][-1]
                     if preserve_position_bias else alignment_path[-1]),
                    endpoint_config=alignment_endpoint_config,
                    kinematics=tcp_kinematics,
                    collision_checker=collision_checker,
                    tilt_model=tilt_model,
                    support_up_normal_base=applied_support_up,
                    compensation_scale=side_scale,
                    torque_limits=mount_record["diagnostic"][
                        "correction_absolute_limits_nm"
                    ],
                    vision_handoff_config=(
                        alignment_endpoint_vision_handoff_config
                    ),
                    vision_handoff_support_up_normal_base=observation[
                        "support_up_normal_base"
                    ],
                    progress_callback=save_alignment_endpoint_progress,
                    label_prefix="alignment_endpoint_pass_1",
                    continuous_command_handoff=continuous_alignment_enabled,
                    initial_command_q=alignment_path[-1] if preserve_position_bias else None,
                    flexible_endpoint_check_body=(
                        check_alignment_body if flexible_approach is not None else None
                    ),
                    flexible_endpoint_j6_v_max_rad_s=(
                        float(grasp_orientation_config["j6_v_max_rad_s"])
                        if flexible_approach is not None else None
                    ),
                )
            except ObservationEndpointConvergenceError as exc:
                log["alignment_endpoint_convergence_pass_1"] = exc.record
                write_json(log_path, log)
                raise
            log["alignment_endpoint_convergence_pass_1"] = alignment_endpoint
            q_aligned = list(alignment_endpoint["final_command_q_rad"])
            if not np.allclose(
                q_aligned, executed_alignment_path[-1], atol=1e-12, rtol=0.0
            ):
                endpoint_return_collision = check_collision_path(
                    collision_checker,
                    [q_aligned, executed_alignment_path[-1]],
                    float(alignment_endpoint_config["collision_step_rad"]),
                )
                log["alignment_endpoint_return_collision_pass_1"] = (
                    endpoint_return_collision
                )
                executed_alignment_path.append(q_aligned)
            write_json(log_path, log)
            if alignment_endpoint["status"] in {
                "pending_visual_verification",
                "passed_to_final_vision_gate_only",
            }:
                print("ALIGNMENT_ENDPOINT_PENDING_VISUAL_VERIFICATION pass=1")
            else:
                print("ALIGNMENT_ENDPOINT_CONVERGED pass=1")
        else:
            q_aligned = list(
                observation_command_q if continuous_alignment_enabled else post_support_q
            )
            alignment_path = [list(q_aligned)]
            executed_alignment_path = [list(q_aligned)]
            print("ALREADY_ALIGNED = True")

        final_capture, final_measured_q = run_capture_process_while_holding(
            arm,
            q_aligned,
            wrist_config_path=loaded.path,
            vision_config_path=vision_config_path,
            run_dir=run_dir,
            capture_label="final",
            timeout_s=worker_timeout_s,
            label="final_capture_detection",
            hold_hz=capture_hold_hz,
            velocity_guard_hz=capture_velocity_guard_hz,
            temperature_period_s=capture_temperature_period_s,
            camera_attempts=camera_attempts,
            camera_retry_delay_s=camera_retry_delay_s,
            capture_quality_override=capture_quality_override,
            write_raw_capture_previews=write_raw_capture_previews,
            search_full_frame_on_miss=adaptive_target_size,
        )
        log.update({
            "planning": planning_record,
            "final_capture": final_capture,
            "final_q_rad": final_measured_q,
            "final_geometry_check_status": "pending",
        })
        write_json(log_path, log)
        final_record, _ = run_worker_while_holding(
            arm,
            q_aligned,
            lambda: compute_final_check(
                final_capture,
                final_measured_q,
                loaded=loaded,
                alignment=alignment,
                flange_kinematics=flange_kinematics,
                tcp_kinematics=tcp_kinematics,
                observation_safety=observation_safety,
                prior_capture=initial_capture if adaptive_target_size else None,
                prior_observation=planning_record["observation"] if adaptive_target_size else None,
            ),
            timeout_s=worker_timeout_s,
            label="final_alignment_check",
        )
        final_observation = final_record["observation"]
        final_check = final_record["check"]
        normal_drift_mm = abs(
            final_check["normal_clearance_mm"] - cartesian_path["normal_clearance_mm"]
        )
        alignment_pass = bool(
            final_check["converged"]
            and center_normal_drift_allowed(normal_drift_mm, alignment)
        )
        print("FINAL_TANGENT_ERROR_NORM_MM =", round(final_check["initial_tangent_error_norm_mm"], 3))
        print("FINAL_NORMAL_CLEARANCE_DRIFT_MM =", round(normal_drift_mm, 3))
        print("CENTER_ALIGNMENT_PASS =", alignment_pass)
        log.update({
            "planning": planning_record,
            "final_capture": final_capture,
            "final_q_rad": final_measured_q,
            "final_observation": final_observation,
            "final_check": final_check,
            "final_normal_clearance_drift_mm": normal_drift_mm,
            "center_alignment_pass": alignment_pass,
            "final_geometry_check_status": "passed" if alignment_pass else "rejected",
        })
        write_json(log_path, log)

        residual_decision = residual_correction_decision(
            final_check,
            normal_drift_mm,
            alignment=alignment,
            residual_config=residual_config,
        )
        log["residual_correction"] = {
            "status": "not_needed" if alignment_pass else "evaluated",
            "decision": residual_decision,
        }
        write_json(log_path, log)
        if not alignment_pass and residual_decision["allowed"]:
            print(
                "RESIDUAL_CORRECTION_TRIGGERED ="
                f" residual={residual_decision['residual_error_mm']:.3f}mm"
                f" {residual_policy}"
                " pass=2/2"
            )
            residual_update = commander.set_support_up_normal(
                final_observation["support_up_normal_base"],
                source="validated_support_plane:go2_visual_alignment_residual",
            )
            hold_with_tilt_policy(
                arm,
                q_aligned,
                float(tilt_config["normal_transition_s"]) + 0.25,
                "residual_support_normal_transition",
            )
            residual_start_q = (
                sample_endpoint_hold(
                    arm, q_aligned, float(alignment_endpoint_config["hold_seconds"]),
                    "residual_post_support_rebase_hold",
                )
                if tilt_compensation_enabled else measured_position_from_commander(arm)
            )
            residual_rebase = endpoint_tracking_record(
                q_aligned,
                residual_start_q,
                tcp_kinematics,
            )
            residual_applied_support_up = blended_support_up_normal(
                commander.nominal_support_up_normal_base,
                final_observation["support_up_normal_base"],
                float(tilt_config["support_normal_blend"]),
            )
            residual_planning, _ = run_worker_while_holding(
                arm,
                q_aligned,
                lambda: compute_alignment_plan(
                    final_record,
                    planning_start_q_rad=residual_start_q,
                    force_correction=True,
                    loaded=loaded,
                    alignment=alignment,
                    tcp_kinematics=tcp_kinematics,
                    collision_checker=collision_checker,
                    tilt_model=tilt_model,
                    applied_support_up=residual_applied_support_up,
                    side_scale=side_scale,
                    torque_limits=mount_record["diagnostic"][
                        "correction_absolute_limits_nm"
                    ],
                ),
                timeout_s=worker_timeout_s,
                label="residual_alignment_planning",
            )
            residual_path = residual_planning["alignment_joint_path"]
            residual_record = {
                "status": "planned",
                "decision": residual_decision,
                "correction_requested_by_final_vision": True,
                "support_normal_update": residual_update,
                "post_support_normal_rebase": residual_rebase,
                "planning": residual_planning,
            }
            log["residual_correction"] = residual_record
            write_json(log_path, log)
            if residual_planning["cartesian_path"]["converged"]:
                residual_record["status"] = "already_converged_before_motion"
                write_json(log_path, log)
                print("RESIDUAL_ALIGNMENT_MOTION_SKIPPED = already converged; proceeding to final vision")
            else:
                print(
                    "RESIDUAL_ALIGNMENT_CARTESIAN_SEGMENTS =",
                    residual_planning["cartesian_path"]["segment_count"],
                )
                if continuous_alignment_enabled:
                    residual_path, handoff_proof = prepare_continuous_alignment_path_while_holding(
                        arm, residual_path, collision_checker=collision_checker,
                        label="residual_alignment_handoff_preflight", timeout_s=worker_timeout_s,
                        tilt_model=tilt_model, support_up_normal_base=residual_applied_support_up,
                        compensation_scale=side_scale,
                        torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                        collision_step_rad=float(alignment["collision_step_rad"]),
                        minimum_joint_margin_deg=float(alignment["minimum_joint_margin_deg"]),
                        workspace=loaded.record["validated_workspace"], kinematics=tcp_kinematics,
                        preserve_physical_offsets=preserve_position_bias,
                        maximum_offset_rad=float(runtime.get("maximum_learned_position_bias_rad", .05)),
                        clip_learned_offset=use_planned_alignment_range,
                    )
                    residual_record["continuous_command_handoff"] = handoff_proof
                    write_json(log_path, log)
                    control_trace.phase = "support_tangent_residual_alignment"
                if use_planned_alignment_range:
                    body, _ = run_worker_while_holding(
                        arm, q_aligned,
                        lambda: check_alignment_body(residual_path),
                        timeout_s=worker_timeout_s, label="residual_alignment_body_check",
                    )
                    residual_record["alignment_body_check"] = body
                    write_json(log_path, log)
                alignment_motion_started = True
                if runtime.get("feedback_synchronized_alignment", False):
                    report = residual_record.setdefault("feedback_alignment", {})
                    fault = move_feedback_synchronized(
                        arm, residual_path, residual_planning["alignment_joint_path"],
                        "support_tangent_residual_alignment", report,
                    )
                else:
                    fault = arm.move_waypoints(
                        residual_path,
                        "support_tangent_residual_alignment",
                    )
                if fault:
                    raise RuntimeError(fault)
                executed_alignment_path.extend(
                    [list(q) for q in residual_path[1:]]
                )

                def save_residual_endpoint_progress(record):
                    residual_record["endpoint_convergence"] = record
                    log["residual_correction"] = residual_record
                    write_json(log_path, log)

                try:
                    residual_endpoint = converge_observation_endpoint(
                        arm,
                        (residual_planning["alignment_joint_path"][-1]
                         if preserve_position_bias else residual_path[-1]),
                        endpoint_config=alignment_endpoint_config,
                        kinematics=tcp_kinematics,
                        collision_checker=collision_checker,
                        tilt_model=tilt_model,
                        support_up_normal_base=residual_applied_support_up,
                        compensation_scale=side_scale,
                        torque_limits=mount_record["diagnostic"][
                            "correction_absolute_limits_nm"
                        ],
                        vision_handoff_config=(
                            alignment_endpoint_vision_handoff_config
                        ),
                        vision_handoff_support_up_normal_base=final_observation[
                            "support_up_normal_base"
                        ],
                        progress_callback=save_residual_endpoint_progress,
                        label_prefix="alignment_endpoint_pass_2",
                        continuous_command_handoff=continuous_alignment_enabled,
                        initial_command_q=residual_path[-1] if preserve_position_bias else None,
                    )
                except ObservationEndpointConvergenceError as exc:
                    residual_record["endpoint_convergence"] = exc.record
                    log["residual_correction"] = residual_record
                    write_json(log_path, log)
                    raise
                residual_record["endpoint_convergence"] = residual_endpoint
                q_aligned = list(residual_endpoint["final_command_q_rad"])
                if not np.allclose(
                    q_aligned, executed_alignment_path[-1], atol=1e-12, rtol=0.0
                ):
                    residual_return_collision = check_collision_path(
                        collision_checker,
                        [q_aligned, executed_alignment_path[-1]],
                        float(alignment_endpoint_config["collision_step_rad"]),
                    )
                    residual_record["endpoint_return_collision"] = (
                        residual_return_collision
                    )
                    executed_alignment_path.append(q_aligned)
            residual_capture, residual_measured_q = (
                run_capture_process_while_holding(
                    arm,
                    q_aligned,
                    wrist_config_path=loaded.path,
                    vision_config_path=vision_config_path,
                    run_dir=run_dir,
                    capture_label="residual_final",
                    timeout_s=worker_timeout_s,
                    label="residual_final_capture_detection",
                    hold_hz=capture_hold_hz,
                    velocity_guard_hz=capture_velocity_guard_hz,
                    temperature_period_s=capture_temperature_period_s,
                    camera_attempts=camera_attempts,
                    camera_retry_delay_s=camera_retry_delay_s,
                    capture_quality_override=capture_quality_override,
                    write_raw_capture_previews=write_raw_capture_previews,
                    search_full_frame_on_miss=adaptive_target_size,
                )
            )
            residual_record.update({
                "status": "captured",
                "capture": residual_capture,
                "measured_q_rad": residual_measured_q,
                "geometry_check_status": "pending",
            })
            log["residual_correction"] = residual_record
            write_json(log_path, log)
            residual_final_record, _ = run_worker_while_holding(
                arm,
                q_aligned,
                lambda: compute_final_check(
                    residual_capture,
                    residual_measured_q,
                    loaded=loaded,
                    alignment=alignment,
                    flange_kinematics=flange_kinematics,
                    tcp_kinematics=tcp_kinematics,
                    observation_safety=observation_safety,
                    prior_capture=final_capture if adaptive_target_size else None,
                    prior_observation=final_observation if adaptive_target_size else None,
                ),
                timeout_s=worker_timeout_s,
                label="residual_final_alignment_check",
            )
            final_capture = residual_capture
            final_measured_q = residual_measured_q
            final_record = residual_final_record
            final_observation = final_record["observation"]
            final_check = final_record["check"]
            normal_drift_mm = abs(
                final_check["normal_clearance_mm"]
                - cartesian_path["normal_clearance_mm"]
            )
            alignment_pass = bool(
                final_check["converged"]
                and center_normal_drift_allowed(normal_drift_mm, alignment)
            )
            residual_record.update({
                "status": "passed" if alignment_pass else "rejected",
                "final_observation": final_observation,
                "final_check": final_check,
                "final_normal_clearance_drift_mm": normal_drift_mm,
                "center_alignment_pass": alignment_pass,
                "geometry_check_status": (
                    "passed" if alignment_pass else "rejected"
                ),
            })
            log.update({
                "residual_correction": residual_record,
                "final_capture": final_capture,
                "final_q_rad": final_measured_q,
                "final_observation": final_observation,
                "final_check": final_check,
                "final_normal_clearance_drift_mm": normal_drift_mm,
                "center_alignment_pass": alignment_pass,
                "final_geometry_check_status": (
                    "passed" if alignment_pass else "rejected"
                ),
            })
            print(
                "RESIDUAL_FINAL_TANGENT_ERROR_NORM_MM =",
                round(final_check["initial_tangent_error_norm_mm"], 3),
            )
            print(
                "RESIDUAL_FINAL_NORMAL_CLEARANCE_DRIFT_MM =",
                round(normal_drift_mm, 3),
            )
            print("CENTER_ALIGNMENT_PASS_AFTER_RESIDUAL =", alignment_pass)
            write_json(log_path, log)
        if not alignment_pass:
            raise RuntimeError(
                "final center-alignment gate failed: "
                f"residual={float(final_check['initial_tangent_error_norm_mm']):.3f}mm "
                f"normal_drift={float(normal_drift_mm):.3f}mm "
                f"initial_decision={residual_decision['reason']}"
            )

        merge_orientation_pregrasp = bool(
            simplified_full_flow and adaptive_target_size and grasp_orientation_enabled
            and not orientation_only_requested
        )
        if merge_orientation_pregrasp:
            print("ORIENTATION_PREGRASP_MODE = combined_motion_without_post_rotation_capture")
        if grasp_orientation_enabled and not merge_orientation_pregrasp:
            orientation_support_up = blended_support_up_normal(
                commander.nominal_support_up_normal_base,
                final_observation["support_up_normal_base"],
                float(tilt_config["support_normal_blend"]),
            )
            orientation_plan, _ = run_worker_while_holding(
                arm,
                q_aligned,
                lambda: compute_grasp_orientation_plan(
                    final_measured_q,
                    final_observation,
                    config=grasp_orientation_config,
                    tcp_kinematics=tcp_kinematics,
                    collision_checker=collision_checker,
                    tilt_model=tilt_model,
                    applied_support_up=orientation_support_up,
                    compensation_scale=side_scale,
                    torque_limits=mount_record["diagnostic"][
                        "correction_absolute_limits_nm"
                    ],
                    allow_alternate_closing_direction=use_planned_alignment_range,
                ),
                timeout_s=worker_timeout_s,
                label="adaptive_grasp_orientation_planning",
            )
            log["adaptive_grasp_orientation"] = orientation_plan
            selected_orientation = orientation_plan["selected"]
            orientation_path = [
                [float(value) for value in row]
                for row in selected_orientation["joint_path"]
            ]
            # Keep physical targets separate from motor setpoints. The learned
            # offset must survive center alignment -> wrist rotation -> hold.
            orientation_physical_target_q = list(orientation_path[-1])
            orientation_command_offset = np.zeros(6)
            if preserve_position_bias:
                orientation_path, orientation_handoff = prepare_continuous_alignment_path_while_holding(
                    arm, orientation_path, collision_checker=collision_checker,
                    label="orientation_command_handoff_preflight", timeout_s=worker_timeout_s,
                    tilt_model=tilt_model, support_up_normal_base=orientation_support_up,
                    compensation_scale=side_scale,
                    torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                    collision_step_rad=float(grasp_orientation_config["collision_step_rad"]),
                    minimum_joint_margin_deg=float(grasp_orientation_config["minimum_joint_margin_deg"]),
                    workspace=loaded.record["validated_workspace"], kinematics=tcp_kinematics,
                    preserve_physical_offsets=True,
                    maximum_offset_rad=float(runtime.get("maximum_learned_position_bias_rad", .05)),
                    clip_learned_offset=use_planned_alignment_range,
                    fit_offset_to_joint_margin=use_planned_alignment_range,
                )
                orientation_command_offset = (
                    np.asarray(orientation_path[-1]) - orientation_physical_target_q
                )
                orientation_handoff["terminal_command_offset_rad"] = (
                    orientation_command_offset.tolist()
                )
                orientation_plan["continuous_command_handoff"] = orientation_handoff
                offset_was_reduced = orientation_handoff["learned_command_offset_clipped"] or not np.allclose(
                    orientation_command_offset, orientation_handoff["learned_command_offset_rad"]
                )
                print(
                    "GRASP_ORIENTATION_COMMAND_HANDOFF =",
                    "bounded_offset" if offset_was_reduced else "mapped",
                )
            write_json(log_path, log)
            print(
                "GRASP_ORIENTATION_SELECTED ="
                f" {selected_orientation['name']}"
                f" rotation={float(selected_orientation['rotation_from_current_deg']):.2f}deg"
                f" alternate_closing_direction={selected_orientation['alternate_closing_direction']}"
                f" j6_travel={float(selected_orientation['j6_travel_rad']):.3f}rad"
                f" duration_score={float(selected_orientation['duration_score_s']):.2f}s"
            )
            print(
                "GRASP_ORIENTATION_PREFLIGHT ="
                f" collision_samples={selected_orientation['collision']['sample_count']}"
                f" torque_fraction={float(selected_orientation['torque']['maximum_limit_fraction']):.3f}"
                f" planned_tcp_drift={float(selected_orientation['planned_tcp_position_drift_mm']):.3f}mm"
            )
            old_orientation_v_max = float(arm.limits.v_max_rad_s)
            old_orientation_j6_v_max = float(arm.limits.j6_v_max_rad_s)
            arm.limits.v_max_rad_s = min(
                old_orientation_v_max,
                float(grasp_orientation_config["v_max_rad_s"]),
            )
            arm.limits.j6_v_max_rad_s = min(
                old_orientation_j6_v_max,
                float(grasp_orientation_config["j6_v_max_rad_s"]),
            )
            try:
                alignment_motion_started = True
                if control_trace is not None:
                    control_trace.phase = "adaptive_square_grasp_orientation"
                fault = arm.move_waypoints(
                    orientation_path,
                    "adaptive_square_grasp_orientation",
                )
                if fault:
                    raise RuntimeError(fault)
                orientation_command_q = list(orientation_path[-1])
                orientation_hold_command_q = list(orientation_command_q)
                orientation_executed_path = [list(q) for q in orientation_path]
                orientation_endpoint_holds = []
                for hold_attempt in range(2):
                    hold_duration_s = float(
                        grasp_orientation_config[
                            "hold_seconds"
                            if hold_attempt == 0
                            else "unstable_retry_hold_seconds"
                        ]
                    )
                    orientation_endpoint_hold = sample_endpoint_hold_tail(
                        arm,
                        orientation_command_q,
                        hold_duration_s,
                        float(
                            grasp_orientation_config[
                                "endpoint_evaluation_window_s"
                            ]
                        ),
                        (
                            "adaptive_grasp_orientation_endpoint"
                            f"_attempt_{hold_attempt + 1}"
                        ),
                    )
                    orientation_endpoint_holds.append(
                        orientation_endpoint_hold
                    )
                    print(
                        "GRASP_ORIENTATION_ENDPOINT_HOLD ="
                        f" attempt={hold_attempt + 1}/2"
                        f" samples={int(orientation_endpoint_hold['sample_count'])}"
                        f" tail_samples={int(orientation_endpoint_hold['evaluation_sample_count'])}"
                        f" tail_window={float(orientation_endpoint_hold['evaluation_window_s']):.2f}s"
                        f" max_range={float(orientation_endpoint_hold['maximum_evaluation_window_range_rad']):.6f}rad"
                    )
                    if float(
                        orientation_endpoint_hold[
                            "maximum_evaluation_window_range_rad"
                        ]
                    ) <= float(
                        grasp_orientation_config[
                            "maximum_endpoint_window_range_rad"
                        ]
                    ):
                        break
                    if hold_attempt == 0:
                        print(
                            "GRASP_ORIENTATION_ENDPOINT_RETRY ="
                            " unstable tail; one bounded extra hold"
                            f" duration={float(grasp_orientation_config['unstable_retry_hold_seconds']):.2f}s"
                        )
                orientation_measured_q = orientation_endpoint_hold[
                    "measured_q_rad"
                ]
                orientation_plan["endpoint_hold_attempts"] = (
                    orientation_endpoint_holds
                )
                orientation_plan["endpoint_hold"] = orientation_endpoint_hold
                orientation_endpoint = evaluate_grasp_orientation_endpoint(
                    orientation_physical_target_q,
                    orientation_measured_q,
                    start_tcp_pose=orientation_plan["start_tcp_pose_xyz_xyzw"],
                    target_quaternion=selected_orientation[
                        "target_quaternion_xyzw"
                    ],
                    config=grasp_orientation_config,
                    tcp_kinematics=tcp_kinematics,
                    endpoint_window_range_rad=orientation_endpoint_hold[
                        "evaluation_window_range_rad"
                    ],
                    j6_checked_by_tool_orientation=(simplified_full_flow and not orientation_only_requested),
                )
                validate_workspace_point(
                    orientation_endpoint["tracking"][
                        "measured_tcp_pose_xyz_xyzw"
                    ][:3],
                    loaded.record["validated_workspace"],
                    "adaptive grasp orientation TCP",
                )
                orientation_trim = plan_grasp_orientation_j6_endpoint_trim(
                    orientation_physical_target_q,
                    orientation_measured_q,
                    orientation_endpoint,
                    grasp_orientation_config,
                    tcp_kinematics=tcp_kinematics,
                    target_quaternion=selected_orientation["target_quaternion_xyzw"],
                    hold_command_q=orientation_hold_command_q,
                )
                orientation_plan["endpoint_before_j6_trim"] = orientation_endpoint
                orientation_plan["j6_endpoint_trim"] = orientation_trim
                if orientation_trim["eligible"]:
                    trim_command_q = [
                        float(value) for value in orientation_trim["command_q_rad"]
                    ]
                    trim_from_held_setpoint = (
                        orientation_trim.get("command_mode") == "held_setpoint_delta"
                    )
                    if preserve_position_bias and not trim_from_held_setpoint:
                        orientation_trim["physical_trim_command_q_rad"] = list(trim_command_q)
                        trim_command_q = (np.asarray(trim_command_q) + orientation_command_offset).tolist()
                        orientation_trim["mapped_motor_command_q_rad"] = list(trim_command_q)
                    trim_motion_start = (
                        list(orientation_hold_command_q)
                        if preserve_position_bias or trim_from_held_setpoint
                        else list(orientation_measured_q)
                    )
                    trim_preflight_path = (
                        [orientation_measured_q, trim_motion_start, trim_command_q]
                        if preserve_position_bias or trim_from_held_setpoint
                        else [orientation_measured_q, trim_command_q]
                    )
                    if trim_from_held_setpoint:
                        trim_preflight_path.insert(0, orientation_trim["predicted_physical_q_rad"])
                    maximum_trim_delta = float(
                        orientation_trim["maximum_command_delta_rad"]
                    )
                    if maximum_trim_delta > float(
                        grasp_orientation_config["maximum_joint_step_rad"]
                    ):
                        orientation_trim["status"] = "rejected_command_delta"
                        write_json(log_path, log)
                        raise RuntimeError(
                            "adaptive grasp orientation J6 trim command delta "
                            f"{maximum_trim_delta:.5f}rad exceeds the bounded step"
                        )
                    trim_margin = joint_margin_deg(trim_command_q)
                    if trim_margin < float(
                        grasp_orientation_config["minimum_joint_margin_deg"]
                    ):
                        orientation_trim["status"] = "rejected_joint_margin"
                        write_json(log_path, log)
                        raise RuntimeError(
                            "adaptive grasp orientation J6 trim has insufficient joint margin"
                        )
                    validate_workspace_point(
                        tcp_kinematics.fk(trim_command_q)[:3],
                        loaded.record["validated_workspace"],
                        "adaptive grasp orientation J6 trim command TCP",
                    )
                    trim_collision = check_collision_path(
                        collision_checker,
                        trim_preflight_path,
                        float(grasp_orientation_config["collision_step_rad"]),
                    )
                    trim_dense = densify_joint_path(
                        trim_preflight_path,
                        float(grasp_orientation_config["collision_step_rad"]),
                    )
                    trim_torque = validate_torque_envelope(
                        trim_dense,
                        lambda q: float(side_scale)
                        * differential_tilt_compensation_from_support_up(
                            tilt_model, q, orientation_support_up
                        ),
                        mount_record["diagnostic"][
                            "correction_absolute_limits_nm"
                        ],
                    )
                    orientation_trim.update(
                        {
                            "status": "preflight_passed",
                            "joint_margin_deg": trim_margin,
                            "collision": trim_collision,
                            "torque": trim_torque,
                        }
                    )
                    write_json(log_path, log)
                    print(
                        "GRASP_ORIENTATION_J6_TRIM ="
                        f" error={float(orientation_trim['j6_error_rad']):+.5f}rad"
                        f" bias={float(orientation_trim['applied_j6_bias_rad']):+.5f}rad"
                        f" command_delta={maximum_trim_delta:.5f}rad"
                        " attempts=1"
                    )
                    fault = arm.move_waypoints(
                        [trim_motion_start, trim_command_q],
                        "adaptive_square_grasp_orientation_j6_trim",
                    )
                    if fault:
                        orientation_trim["status"] = "rejected_motion_guard"
                        write_json(log_path, log)
                        raise RuntimeError(fault)
                    trim_hold = sample_endpoint_hold_tail(
                        arm,
                        trim_command_q,
                        float(
                            grasp_orientation_config[
                                "j6_endpoint_trim_hold_seconds"
                            ]
                        ),
                        float(
                            grasp_orientation_config[
                                "endpoint_evaluation_window_s"
                            ]
                        ),
                        "adaptive_grasp_orientation_j6_trim_endpoint",
                    )
                    orientation_endpoint_holds.append(trim_hold)
                    orientation_measured_q = trim_hold["measured_q_rad"]
                    orientation_endpoint = evaluate_grasp_orientation_endpoint(
                        orientation_physical_target_q,
                        orientation_measured_q,
                        start_tcp_pose=orientation_plan[
                            "start_tcp_pose_xyz_xyzw"
                        ],
                        target_quaternion=selected_orientation[
                            "target_quaternion_xyzw"
                        ],
                        config=grasp_orientation_config,
                        tcp_kinematics=tcp_kinematics,
                        endpoint_window_range_rad=trim_hold[
                            "evaluation_window_range_rad"
                        ],
                        j6_checked_by_tool_orientation=(simplified_full_flow and not orientation_only_requested),
                    )
                    validate_workspace_point(
                        orientation_endpoint["tracking"][
                            "measured_tcp_pose_xyz_xyzw"
                        ][:3],
                        loaded.record["validated_workspace"],
                        "adaptive grasp orientation J6-trimmed TCP",
                    )
                    orientation_hold_command_q = list(trim_command_q)
                    orientation_executed_path.append(list(trim_command_q))
                    orientation_trim.update(
                        {
                            "status": (
                                "completed"
                                if orientation_endpoint["passed"]
                                else "rejected_after_trim"
                            ),
                            "hold": trim_hold,
                            "endpoint": orientation_endpoint,
                        }
                    )
                    print(
                        "GRASP_ORIENTATION_J6_TRIM_ENDPOINT ="
                        f" joint_error_all6={float(orientation_endpoint['tracking']['maximum_abs_joint_error_rad']):.5f}rad"
                        f" checked_joint_error={float(orientation_endpoint['evaluated_joint_error_rad']):.5f}rad"
                        f" joint_scope={orientation_endpoint['joint_error_scope']}"
                        f" tcp_drift={float(orientation_endpoint['tcp_position_drift_mm']):.2f}mm"
                        f" orientation_error={float(orientation_endpoint['orientation_error_deg']):.2f}deg"
                        f" result={'PASS' if orientation_endpoint['passed'] else 'REJECT'}"
                    )
                orientation_plan["endpoint_hold_attempts"] = (
                    orientation_endpoint_holds
                )
                orientation_plan["endpoint_hold"] = orientation_endpoint_holds[-1]
                orientation_plan["endpoint"] = orientation_endpoint
                center_handoff = orientation_endpoint_can_recenter(
                    orientation_endpoint, simplified_full_flow=simplified_full_flow,
                    orientation_only_requested=orientation_only_requested)
                orientation_plan["center_verification_required"] = center_handoff
                orientation_plan["status"] = (
                    "completed" if orientation_endpoint["passed"]
                    else "pending_center_verification" if center_handoff else "rejected"
                )
                log["adaptive_grasp_orientation"] = orientation_plan
                write_json(log_path, log)
                print(
                    "GRASP_ORIENTATION_ENDPOINT ="
                    f" joint_error_all6={float(orientation_endpoint['tracking']['maximum_abs_joint_error_rad']):.5f}rad"
                        f" checked_joint_error={float(orientation_endpoint['evaluated_joint_error_rad']):.5f}rad"
                        f" joint_scope={orientation_endpoint['joint_error_scope']}"
                    f" tcp_drift={float(orientation_endpoint['tcp_position_drift_mm']):.2f}mm"
                    f" orientation_error={float(orientation_endpoint['orientation_error_deg']):.2f}deg"
                    f" joint_gate={orientation_endpoint['joint_error_gate']}"
                    f" applied_limit={float(orientation_endpoint['applied_joint_error_limit_rad']):.3f}rad"
                    f" result={'PASS' if orientation_endpoint['passed'] else 'CENTER_RECHECK' if center_handoff else 'REJECT'}"
                )
                if center_handoff:
                    print("GRASP_ORIENTATION_POSITION_DRIFT = pending target-center verification before descent")
                if not orientation_endpoint["passed"] and not center_handoff:
                    raise RuntimeError(
                        "adaptive grasp orientation endpoint failed: "
                        + ",".join(orientation_endpoint["reasons"])
                    )
                append_executed_path(executed_alignment_path, orientation_executed_path)
                q_aligned = orientation_hold_command_q
                final_measured_q = orientation_measured_q
            finally:
                arm.limits.v_max_rad_s = old_orientation_v_max
                arm.limits.j6_v_max_rad_s = old_orientation_j6_v_max

        if simplified_full_flow and grasp_orientation_enabled and not orientation_only_requested and not merge_orientation_pregrasp:
            post_orientation_record = {}
            log["post_orientation_centering"] = post_orientation_record

            def save_post_orientation_progress():
                write_json(log_path, log)

            def capture_post_orientation(label, hold_q):
                return run_capture_process_while_holding(
                    arm, hold_q, wrist_config_path=loaded.path,
                    vision_config_path=vision_config_path, run_dir=run_dir,
                    capture_label=label, timeout_s=worker_timeout_s,
                    label=f"{label}_capture_detection", hold_hz=capture_hold_hz,
                    velocity_guard_hz=capture_velocity_guard_hz,
                    temperature_period_s=capture_temperature_period_s,
                    camera_attempts=camera_attempts, camera_retry_delay_s=camera_retry_delay_s,
                    capture_quality_override=capture_quality_override,
                    write_raw_capture_previews=write_raw_capture_previews,
                    search_full_frame_on_miss=adaptive_target_size)

            q_aligned, final_measured_q, final_capture, final_observation = run_post_orientation_centering(
                arm, q_aligned, capture=capture_post_orientation, loaded=loaded,
                alignment=alignment, tcp_kinematics=tcp_kinematics,
                flange_kinematics=flange_kinematics, collision_checker=collision_checker,
                tilt_model=tilt_model, commander=commander, tilt_config=tilt_config,
                torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                runtime=runtime, observation_safety=observation_safety,
                executed_alignment_path=executed_alignment_path,
                record=post_orientation_record, save_progress=save_post_orientation_progress)
            if orientation_plan["center_verification_required"]:
                orientation_plan.update(status="completed_after_center_verification",
                                        center_verification_required=False,
                                        center_verification_passed=True)
            log.update(final_capture=final_capture, final_q_rad=final_measured_q,
                       final_capture_q_rad=post_orientation_record["final_capture_q_rad"],
                       final_observation=final_observation,
                       final_check=post_orientation_record["final_check"],
                       final_normal_clearance_drift_mm=post_orientation_record["final_normal_clearance_drift_mm"],
                       center_alignment_pass=True, final_geometry_check_status="passed")
            write_json(log_path, log)

        if descent_round_trip_enabled and not orientation_only_requested:
            descent_log_key = (
                "adaptive_pregrasp" if adaptive_pregrasp_enabled else "safe_descent"
            )
            descent_print_prefix = (
                "ADAPTIVE_PREGRASP" if adaptive_pregrasp_enabled else "SAFE_DESCENT"
            )
            descent_motion_label = (
                "support_normal_adaptive_pregrasp"
                if adaptive_pregrasp_enabled
                else "support_normal_safe_descent"
            )
            if adaptive_pregrasp_enabled:
                active_descent_config, visual_handoff = (
                    resolve_adaptive_pregrasp_config(
                        final_capture, adaptive_pregrasp_config
                    )
                )
                if adaptive_target_size:
                    active_descent_config["initial_clearance_range_advisory"] = True
                active_descent_config["maximum_endpoint_clearance_error_mm"] = 10.0
                visual_handoff["maximum_endpoint_clearance_error_mm"] = 10.0
                log["visual_handoff"] = visual_handoff
                write_json(log_path, log)
                print(
                    "VISUAL_HANDOFF ="
                    f" height_{visual_handoff['height_statistic']}="
                    f"{visual_handoff['target_height_mm']:.2f}mm"
                    f" top_clearance={visual_handoff['clearance_above_detected_top_mm']:.2f}mm"
                    f" target_clearance={visual_handoff['target_normal_clearance_mm']:.2f}mm"
                    " target_reference=selected_target_top_surface"
                    f" predicted_support_clearance={visual_handoff['predicted_support_plane_clearance_mm']:.2f}mm"
                    " low_view_camera_recheck=False"
                )
            descent_planner = compute_oriented_pregrasp_plan if merge_orientation_pregrasp else compute_safe_descent_plan
            merged_options = (
                {"orientation_config": grasp_orientation_config, "check_body": check_alignment_body}
                if merge_orientation_pregrasp else {}
            )
            descent_planning, _ = run_worker_while_holding(
                arm,
                q_aligned,
                lambda: descent_planner(
                    final_measured_q,
                    final_observation,
                    descent_config=active_descent_config,
                    alignment=alignment,
                    tcp_kinematics=tcp_kinematics,
                    collision_checker=collision_checker,
                    tilt_model=tilt_model,
                    applied_support_up=blended_support_up_normal(
                        commander.nominal_support_up_normal_base,
                        final_observation["support_up_normal_base"],
                        float(tilt_config["support_normal_blend"]),
                    ),
                    side_scale=pregrasp_descent_scale,
                    torque_limits=mount_record["diagnostic"][
                        "correction_absolute_limits_nm"
                    ],
                    **merged_options,
                ),
                timeout_s=worker_timeout_s,
                label=f"{descent_log_key}_planning",
            )
            if merge_orientation_pregrasp:
                log["adaptive_grasp_orientation"] = {
                    "status": "merged_with_pregrasp",
                    "selected": descent_planning["merged_grasp_orientation"],
                    "post_orientation_capture": False,
                }
                print("MERGED_ORIENTATION_PREGRASP_SELECTED =", descent_planning["merged_grasp_orientation"])
            log[descent_log_key] = {
                "status": "planned",
                "planning": descent_planning,
                "compensation_scale": pregrasp_descent_scale,
            }
            write_json(log_path, log)
            print(
                f"{descent_print_prefix}_PLAN ="
                f" initial={descent_planning['initial_normal_clearance_mm']:.2f}mm"
                f" target={descent_planning['target_normal_clearance_mm']:.2f}mm"
                f" distance={descent_planning['descent_distance_mm']:.2f}mm"
                f" segments={descent_planning['segment_count']}"
            )
            print(
                f"{descent_print_prefix}_COLLISION_OK = True samples =",
                descent_planning["collision"]["sample_count"],
            )
            print(
                f"{descent_print_prefix}_TORQUE_ENVELOPE_OK = True max_fraction =",
                round(
                    descent_planning["torque"]["maximum_limit_fraction"], 3
                ),
            )
            if adaptive_secure_no_lift_enabled and not math.isclose(
                commander.compensation_scale,
                pregrasp_descent_scale,
                abs_tol=1e-9,
            ):
                pregrasp_compensation_scale_active = True
                ramp_tilt_scale(
                    arm,
                    commander,
                    q_aligned,
                    start_scale=commander.compensation_scale,
                    end_scale=pregrasp_descent_scale,
                    duration_s=float(
                        adaptive_secure_config["compensation_transition_s"]
                    ),
                    label="adaptive_secure_pregrasp_scale_down",
                )
                print(
                    "PREGRASP_TILT_SCALE_TRANSITION =",
                    f"{side_scale:.2f}->{pregrasp_descent_scale:.2f}",
                )
            executed_descent_path = [
                list(q) for q in descent_planning["joint_path"]
            ]
            descent_motion_started = True
            old_acceleration = arm.limits.max_acceleration_rad_s2
            arm.limits.max_acceleration_rad_s2 = (
                min(old_acceleration,args.descent_acceleration_rad_s2)
                if old_acceleration is not None else None)
            log[descent_log_key]["acceleration_rad_s2"] = arm.limits.max_acceleration_rad_s2
            old_v_max = float(arm.limits.v_max_rad_s)
            old_j6_v_max = float(arm.limits.j6_v_max_rad_s)
            arm.limits.v_max_rad_s = min(
                old_v_max, float(active_descent_config["v_max_rad_s"])
            )
            arm.limits.j6_v_max_rad_s = min(
                old_j6_v_max, float(active_descent_config["j6_v_max_rad_s"])
            )
            try:
                descent_grip_cmd = None
                descent_grip_force = 0.3
                if adaptive_secure_no_lift_enabled:
                    assert adaptive_gripper is not None
                    assert adaptive_parameters is not None
                    pregrasp_open_runner = BenchRunner(
                        arm,
                        adaptive_gripper,
                        final_measured_q,
                        adaptive_parameters,
                    )
                    probe_record = None
                    if adaptive_target_size:
                        width_mm = min(
                            final_capture["detection"]["selected"]["orientation"][
                                "rectangle_side_lengths_mm"
                            ]
                        )
                        probe_parameters = size_adaptive_probe_parameters(
                            adaptive_parameters, adaptive_baseline, width_mm,
                            adaptive_gripper.min_gap_mm,
                        )
                        probe_source = "bound_empty_baseline"
                        if probe_parameters is not adaptive_parameters:
                            # The target is below this high pose. Measure the empty
                            # gripper at the same gap used for contact on this run.
                            adaptive_gripper_may_be_closed = True
                            pregrasp_open_runner.parameters = probe_parameters
                            empty_samples = pregrasp_open_runner.probe_until_settled()
                            adaptive_baseline = EmptyProbeBaseline.from_samples(
                                empty_samples, probe_parameters
                            )
                            adaptive_parameters = probe_parameters
                            probe_source = "empty_probe_at_high_pose"
                        probe_record = {
                            "observed_width_mm": width_mm,
                            "target_gap_mm": adaptive_parameters.target_gap_mm,
                            "baseline_source": probe_source,
                            "baseline": adaptive_baseline.to_record(),
                        }
                        print(
                            "ADAPTIVE_PROBE",
                            f"width={width_mm:.2f}mm",
                            f"target_gap={adaptive_parameters.target_gap_mm:.2f}mm",
                            f"baseline={probe_source}",
                        )
                    descent_open_gap_mm = (adaptive_gripper.max_gap_mm
                        if adaptive_secure_config.get("descent_open_gap_mm") is None
                        else float(adaptive_secure_config["descent_open_gap_mm"]))
                    opened = pregrasp_open_runner.hold(
                        descent_open_gap_mm,
                        adaptive_parameters.secure_force_nm,
                        adaptive_parameters.open_hold_s,
                        "pregrasp_open_before_descent",
                    )
                    open_shortfall_mm = (
                        descent_open_gap_mm - opened.actual_gap_mm
                    )
                    if open_shortfall_mm > adaptive_parameters.empty_max_final_excess_mm:
                        raise RuntimeError(
                            "gripper did not open to the bounded pregrasp region: "
                            f"actual={opened.actual_gap_mm:.2f}mm"
                        )
                    adaptive_gripper_may_be_closed = False
                    log["adaptive_secure_no_lift"] = {
                        "status": "gripper_open_before_pregrasp_descent",
                        "pregrasp_open_actual_gap_mm": opened.actual_gap_mm,
                        "descent_open_command_gap_mm": descent_open_gap_mm,
                        "pregrasp_open_records": pregrasp_open_runner.records,
                    }
                    if probe_record is not None:
                        log["adaptive_secure_no_lift"]["adaptive_probe"] = probe_record
                    write_json(log_path, log)
                    descent_grip_cmd = adaptive_gripper.mm_to_fb(
                        descent_open_gap_mm
                    )
                    descent_grip_force = adaptive_parameters.secure_force_nm
                fault = arm.move_waypoints(
                    executed_descent_path,
                    descent_motion_label,
                    grip_cmd=descent_grip_cmd,
                    grip_force=descent_grip_force,
                )
                if fault:
                    raise RuntimeError(fault)
                descent_end_q = sample_endpoint_hold(
                    arm,
                    executed_descent_path[-1],
                    float(active_descent_config["hold_seconds"]),
                    f"{descent_log_key}_endpoint_hold",
                )
                descent_endpoint = evaluate_safe_descent_endpoint(
                    descent_planning,
                    descent_end_q,
                    descent_config=active_descent_config,
                    tcp_kinematics=tcp_kinematics,
                )
                if (adaptive_target_size and adaptive_pregrasp_enabled and
                        descent_endpoint["clearance_error_mm"] > 10.0):
                    initial_endpoint = descent_endpoint
                    correction_path, correction_record = plan_pregrasp_endpoint_correction(
                        descent_planning["joint_path"][-1], descent_end_q,
                        executed_descent_path[-1], descent_config=active_descent_config,
                        collision_checker=collision_checker, tilt_model=tilt_model,
                        applied_support_up=descent_planning["support_up_normal_base"],
                        compensation_scale=commander.compensation_scale,
                        torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                        check_body=check_alignment_body,
                    )
                    correction_record["before"] = initial_endpoint
                    correction_record["v_max_rad_s"] = arm.limits.v_max_rad_s
                    correction_record["j6_v_max_rad_s"] = arm.limits.j6_v_max_rad_s
                    log[descent_log_key]["endpoint_correction"] = correction_record
                    write_json(log_path, log)
                    print("PREGRASP_ENDPOINT_CORRECTION ="
                          f" error={initial_endpoint['clearance_error_mm']:.2f}mm"
                          f" speed={arm.limits.v_max_rad_s:.2f}rad/s")
                    # Record every commanded correction point before moving so
                    # fault recovery and subsequent lift reverse this same route.
                    append_executed_path(executed_descent_path, correction_path)
                    fault = arm.move_waypoints(correction_path, "pregrasp_endpoint_correction",
                        grip_cmd=descent_grip_cmd, grip_force=descent_grip_force)
                    if fault:
                        raise RuntimeError(fault)
                    descent_end_q = sample_endpoint_hold(arm, correction_path[-1],
                        float(active_descent_config["hold_seconds"]),
                        "pregrasp_corrected_endpoint_hold")
                    descent_endpoint = evaluate_safe_descent_endpoint(
                        descent_planning, descent_end_q,
                        descent_config=active_descent_config, tcp_kinematics=tcp_kinematics)
                    correction_record.update(status="completed", after=descent_endpoint)
                    write_json(log_path, log)
                log[descent_log_key].update(
                    {
                        "status": (
                            "endpoint_passed"
                            if descent_endpoint["passed"]
                            else "endpoint_rejected"
                        ),
                        "endpoint": descent_endpoint,
                    }
                )
                write_json(log_path, log)
                print(
                    f"{descent_print_prefix}_ENDPOINT ="
                    f" clearance={descent_endpoint['measured_normal_clearance_mm']:.2f}mm"
                    f" progress={descent_endpoint['progress_ratio']:.3f}"
                    f" error={descent_endpoint['clearance_error_mm']:.2f}mm"
                    f" result={'PASS' if descent_endpoint['passed'] else 'REJECT'}"
                )
                if not descent_endpoint["passed"]:
                    raise RuntimeError(
                        f"{descent_log_key} endpoint verification failed"
                    )
                if merge_orientation_pregrasp:
                    target_rotation = descent_planning["merged_grasp_orientation"]["target_quaternion_xyzw"]
                    actual_rotation = tcp_kinematics.fk(descent_end_q)[3:]
                    tool_error = quaternion_error_deg(actual_rotation, target_rotation)
                    log[descent_log_key]["tool_orientation_error_deg"] = tool_error
                    direction_passed = tool_error <= float(grasp_orientation_config["maximum_endpoint_orientation_error_deg"])
                    log["adaptive_grasp_orientation"].update(
                        status="completed_with_pregrasp" if direction_passed else "rejected_pregrasp_tool_direction",
                        tool_orientation_error_deg=tool_error,
                    )
                    write_json(log_path, log)
                    print("MERGED_PREGRASP_TOOL_ERROR_DEG =", round(tool_error, 3))
                    if not direction_passed:
                        raise RuntimeError("combined pregrasp tool direction exceeds the existing orientation tolerance")
                if adaptive_secure_no_lift_enabled:
                    assert adaptive_secure_config is not None
                    assert adaptive_parameters is not None
                    assert adaptive_baseline is not None
                    assert adaptive_gripper is not None
                    low_descent_config, low_handoff = (
                        resolve_adaptive_secure_no_lift_config(
                            final_capture,
                            adaptive_secure_config,
                        )
                    )
                    pregrasp_tolerance = float(active_descent_config["maximum_endpoint_clearance_error_mm"])
                    pregrasp_clearance = float(active_descent_config["target_normal_clearance_mm"])
                    low_descent_config["minimum_initial_normal_clearance_mm"] = pregrasp_clearance-pregrasp_tolerance
                    low_descent_config["maximum_initial_normal_clearance_mm"] = pregrasp_clearance+pregrasp_tolerance
                    low_handoff["accepted_initial_top_clearance_mm"] = [
                        pregrasp_clearance-pregrasp_tolerance,pregrasp_clearance+pregrasp_tolerance]
                    low_scale = float(
                        adaptive_secure_config["low_stage_compensation_scale"]
                    )
                    low_planning, _ = run_worker_while_holding(
                        arm,
                        descent_end_q,
                        lambda: compute_safe_descent_plan(
                            descent_end_q,
                            final_observation,
                            descent_config=low_descent_config,
                            alignment=alignment,
                            tcp_kinematics=tcp_kinematics,
                            collision_checker=collision_checker,
                            tilt_model=tilt_model,
                            applied_support_up=blended_support_up_normal(
                                commander.nominal_support_up_normal_base,
                                final_observation["support_up_normal_base"],
                                float(tilt_config["support_normal_blend"]),
                            ),
                            side_scale=low_scale,
                            torque_limits=mount_record["diagnostic"][
                                "correction_absolute_limits_nm"
                            ],
                        ),
                        timeout_s=worker_timeout_s,
                        label="adaptive_secure_low_descent_planning",
                    )
                    log["adaptive_secure_no_lift"].update(
                        {
                            "status": "low_descent_planned",
                            "visual_handoff": low_handoff,
                            "low_descent_planning": low_planning,
                        }
                    )
                    write_json(log_path, log)
                    print(
                        "ADAPTIVE_SECURE_LOW_PLAN ="
                        f" initial_top={low_planning['initial_normal_clearance_mm']:.2f}mm"
                        f" target_top={low_planning['target_normal_clearance_mm']:.2f}mm"
                        f" target_support={low_handoff['target_support_plane_tcp_clearance_mm']:.2f}mm"
                        f" distance={low_planning['descent_distance_mm']:.2f}mm"
                        f" segments={low_planning['segment_count']}"
                    )
                    print(
                        "ADAPTIVE_SECURE_LOW_COLLISION_OK = True samples =",
                        low_planning["collision"]["sample_count"],
                    )
                    print(
                        "ADAPTIVE_SECURE_LOW_TORQUE_ENVELOPE_OK = True max_fraction =",
                        round(low_planning["torque"]["maximum_limit_fraction"], 3),
                    )
                    executed_low_descent_path = [
                        list(q) for q in low_planning["joint_path"]
                    ]
                    low_compensation_scale_active = True
                    ramp_tilt_scale(
                        arm,
                        commander,
                        descent_end_q,
                        start_scale=commander.compensation_scale,
                        end_scale=low_scale,
                        duration_s=float(
                            adaptive_secure_config["compensation_transition_s"]
                        ),
                        label="adaptive_secure_low_scale_down",
                    )
                    print(
                        "LOW_STAGE_TILT_SCALE_TRANSITION =",
                        f"{pregrasp_descent_scale:.2f}->{low_scale:.2f}",
                    )
                    pregrasp_acceleration = arm.limits.max_acceleration_rad_s2
                    pregrasp_v_max = float(arm.limits.v_max_rad_s)
                    pregrasp_j6_v_max = float(arm.limits.j6_v_max_rad_s)
                    arm.limits.v_max_rad_s = min(
                        pregrasp_v_max,
                        float(low_descent_config["v_max_rad_s"]),
                    )
                    arm.limits.j6_v_max_rad_s = min(
                        pregrasp_j6_v_max,
                        float(low_descent_config["j6_v_max_rad_s"]),
                    )
                    try:
                        low_descent_motion_started = True
                        fault = arm.move_waypoints(
                            executed_low_descent_path,
                            "adaptive_secure_low_descent",
                            grip_cmd=adaptive_gripper.mm_to_fb(
                                descent_open_gap_mm
                            ),
                            grip_force=adaptive_parameters.secure_force_nm,
                        )
                        if fault:
                            raise RuntimeError(fault)
                        low_endpoint_runner = BenchRunner(
                            arm,
                            adaptive_gripper,
                            executed_low_descent_path[-1],
                            adaptive_parameters,
                        )
                        def record_low_endpoint(endpoint):
                            log["adaptive_secure_no_lift"].update(
                                low_endpoint=endpoint,
                                low_endpoint_records=low_endpoint_runner.records,
                                status="low_endpoint_passed" if endpoint["passed"] else "waiting_for_low_endpoint",
                            )

                        low_endpoint_sample, low_end_q, low_endpoint = hold_until_low_descent_endpoint(
                            low_endpoint_runner, low_planning,
                            descent_config=low_descent_config, tcp_kinematics=tcp_kinematics,
                            command_gap_mm=descent_open_gap_mm,
                            force_nm=adaptive_parameters.secure_force_nm,
                            progress_callback=record_low_endpoint,
                        )
                        log["adaptive_secure_no_lift"].update(
                            {
                                "status": (
                                    "low_endpoint_passed"
                                    if low_endpoint["passed"]
                                    else "low_endpoint_rejected"
                                ),
                                "low_endpoint": low_endpoint,
                                "low_endpoint_open_gap_mm": (
                                    low_endpoint_sample.actual_gap_mm
                                ),
                                "low_endpoint_records": low_endpoint_runner.records,
                            }
                        )
                        write_json(log_path, log)
                        print(
                            "ADAPTIVE_SECURE_LOW_ENDPOINT ="
                            f" top_clearance={low_endpoint['measured_normal_clearance_mm']:.2f}mm"
                            f" support_clearance="
                            f"{low_endpoint['measured_normal_clearance_mm'] + low_handoff['target_height_mm']:.2f}mm"
                            f" progress={low_endpoint['progress_ratio']:.3f}"
                            f" error={low_endpoint['clearance_error_mm']:.2f}mm"
                            f" result={'PASS' if low_endpoint['passed'] else 'REJECT'}"
                        )
                        adaptive_runner = BenchRunner(
                            arm,
                            adaptive_gripper,
                            low_end_q,
                            adaptive_parameters,
                        )
                        adaptive_gripper_may_be_closed = True
                        try:
                            acquisition = run_adaptive_acquisition(
                                adaptive_runner,
                                adaptive_parameters,
                                adaptive_baseline,
                                secure=True,
                                minimum_secure_gap_mm=(
                                    adaptive_gripper.min_gap_mm if adaptive_target_size else None
                                ),
                            )
                        finally:
                            log["adaptive_secure_no_lift"][
                                "adaptive_grip_records"
                            ] = adaptive_runner.records
                            log["adaptive_secure_no_lift"][
                                "maximum_joint_hold_error_rad"
                            ] = adaptive_runner.max_hold_error_rad
                            write_json(log_path, log)
                        if not acquisition["detected"]:
                            adaptive_secure_outcome = "contact_miss"
                        elif not acquisition["secure_valid"]:
                            adaptive_secure_outcome = "secure_lost"
                        else:
                            adaptive_secure_outcome = "holding_verified"
                        log["adaptive_secure_no_lift"].update(
                            {
                                "status": adaptive_secure_outcome,
                                "acquisition": acquisition,
                                "lift_executed": False,
                            }
                        )
                        write_json(log_path, log)
                        print(
                            "ADAPTIVE_SECURE_NO_LIFT_RESULT =",
                            adaptive_secure_outcome,
                        )
                        print("LIFT_EXECUTED = False")
                        if (
                            adaptive_grasp_box_place_enabled
                            and adaptive_secure_outcome == "holding_verified"
                        ):
                            payload_held = True
                            payload_grip_gap_mm = float(acquisition["secure_gap_mm"])
                            payload_grip_force_nm = float(
                                adaptive_parameters.secure_force_nm
                            )
                            log["adaptive_secure_no_lift"].update(
                                {
                                    "released_before_return": False,
                                    "loaded_transport_authorized": True,
                                    "payload_grip_gap_mm": payload_grip_gap_mm,
                                    "payload_grip_force_nm": payload_grip_force_nm,
                                }
                            )
                            write_json(log_path, log)
                            print(
                                "LOADED_TRANSPORT_AUTHORIZED = True"
                                f" gap={payload_grip_gap_mm:.2f}mm"
                                f" force={payload_grip_force_nm:.2f}Nm"
                            )
                        else:
                            release_runner = BenchRunner(
                                arm,
                                adaptive_gripper,
                                low_end_q,
                                adaptive_parameters,
                            )
                            released = release_runner.hold(
                                adaptive_parameters.start_gap_mm,
                                adaptive_parameters.secure_force_nm,
                                adaptive_parameters.open_hold_s,
                                "adaptive_secure_release_in_place",
                            )
                            release_shortfall_mm = (
                                adaptive_parameters.start_gap_mm
                                - released.actual_gap_mm
                            )
                            if (
                                release_shortfall_mm
                                > adaptive_parameters.empty_max_final_excess_mm
                            ):
                                raise RuntimeError(
                                    "gripper release was not verified before return: "
                                    f"actual={released.actual_gap_mm:.2f}mm"
                                )
                            adaptive_gripper_may_be_closed = False
                            log["adaptive_secure_no_lift"].update(
                                {
                                    "released_gap_mm": released.actual_gap_mm,
                                    "release_records": release_runner.records,
                                    "released_before_return": True,
                                }
                            )
                            write_json(log_path, log)
                            print(
                                "GRIPPER_RELEASED_BEFORE_RETURN = True gap=",
                                round(released.actual_gap_mm, 2),
                            )

                        low_return_path = [list(low_end_q)] + list(
                            reversed(executed_low_descent_path)
                        )
                        if max_joint_delta(
                            low_return_path[-1], descent_end_q
                        ) > 1e-9:
                            low_return_path.append(list(descent_end_q))
                        low_return_collision = check_collision_path(
                            collision_checker,
                            low_return_path,
                            float(low_descent_config["collision_step_rad"]),
                        )
                        log["adaptive_secure_no_lift"]["low_return_collision"] = (
                            low_return_collision
                        )
                        write_json(log_path, log)
                        arm.limits.max_acceleration_rad_s2 = old_acceleration
                        if all_joint_speed is not None:
                            arm.limits.v_max_rad_s = all_joint_speed
                            arm.limits.j6_v_max_rad_s = all_joint_speed
                        elif payload_held and motion_speed_scale > 1.0:
                            arm.limits.v_max_rad_s = min(
                                pregrasp_v_max,
                                float(low_descent_config["v_max_rad_s"]) * motion_speed_scale,
                            )
                        log["adaptive_secure_no_lift"]["lift_v_max_rad_s"] = arm.limits.v_max_rad_s
                        log["adaptive_secure_no_lift"]["lift_j6_v_max_rad_s"] = arm.limits.j6_v_max_rad_s
                        if control_trace is not None:
                            control_trace.phase = "adaptive_secure_low_lift"
                        fault = arm.move_waypoints(
                            low_return_path,
                            "adaptive_secure_low_descent_return",
                            grip_cmd=adaptive_gripper.mm_to_fb(
                                payload_grip_gap_mm
                                if payload_held
                                else adaptive_parameters.start_gap_mm
                            ),
                            grip_force=(
                                payload_grip_force_nm
                                if payload_held
                                else adaptive_parameters.secure_force_nm
                            ),
                        )
                        if fault:
                            raise RuntimeError(fault)
                        if payload_held:
                            log["adaptive_secure_no_lift"]["lift_executed"] = True
                            log["adaptive_secure_no_lift"]["lift_path"] = (
                                "reverse_checked_low_descent"
                            )
                            lift_grip_feedback = {
                                "actual_gap_mm": adaptive_gripper.read_gap_mm(),
                                "gripper_tau_nm": float(arm.get_tau()[6]),
                            }
                            log["adaptive_secure_no_lift"]["lift_grip_feedback"] = (
                                lift_grip_feedback
                            )
                            write_json(log_path, log)
                            print(
                                "LIFT_PATH_COMPLETED = True",
                                f"gap={lift_grip_feedback['actual_gap_mm']:.2f}mm",
                                f"tau={lift_grip_feedback['gripper_tau_nm']:.3f}Nm",
                            )
                        low_descent_motion_started = False
                    finally:
                        arm.limits.max_acceleration_rad_s2 = pregrasp_acceleration
                        arm.limits.v_max_rad_s = pregrasp_v_max
                        arm.limits.j6_v_max_rad_s = pregrasp_j6_v_max
                    ramp_tilt_scale(
                        arm,
                        commander,
                        descent_end_q,
                        start_scale=commander.compensation_scale,
                        end_scale=pregrasp_descent_scale,
                        duration_s=float(
                            adaptive_secure_config["compensation_transition_s"]
                        ),
                        label="adaptive_secure_low_scale_restore",
                        gripper=adaptive_gripper if payload_held else None,
                        grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                        grip_force=payload_grip_force_nm if payload_held else None,
                    )
                    low_compensation_scale_active = False
                    print(
                        "LOW_STAGE_TILT_SCALE_TRANSITION =",
                        f"{low_scale:.2f}->{pregrasp_descent_scale:.2f}",
                    )
                descent_return_path = [list(descent_end_q)] + list(
                    reversed(executed_descent_path)
                )
                if max_joint_delta(descent_return_path[-1], q_aligned) > 1e-9:
                    descent_return_path.append(list(q_aligned))
                descent_return_collision = check_collision_path(
                    collision_checker,
                    descent_return_path,
                    float(active_descent_config["collision_step_rad"]),
                )
                log[descent_log_key]["return_collision"] = (
                    descent_return_collision
                )
                write_json(log_path, log)
                if payload_held:
                    descent_grip_cmd = adaptive_gripper.mm_to_fb(
                        payload_grip_gap_mm
                    )
                    descent_grip_force = payload_grip_force_nm
                arm.limits.max_acceleration_rad_s2 = old_acceleration
                if all_joint_speed is not None:
                    arm.limits.v_max_rad_s = all_joint_speed
                    arm.limits.j6_v_max_rad_s = all_joint_speed
                log[descent_log_key]["return_v_max_rad_s"] = arm.limits.v_max_rad_s
                log[descent_log_key]["return_j6_v_max_rad_s"] = arm.limits.j6_v_max_rad_s
                fault = arm.move_waypoints(
                    descent_return_path,
                    f"{descent_motion_label}_return",
                    grip_cmd=descent_grip_cmd,
                    grip_force=descent_grip_force,
                )
                if fault:
                    raise RuntimeError(fault)
                if motion_speed_scale <= 1.0 or not pregrasp_compensation_scale_active:
                    hold_with_tilt_policy(
                        arm,
                        q_aligned,
                        float(active_descent_config["hold_seconds"]),
                        f"{descent_log_key}_return_hold",
                        gripper=adaptive_gripper if payload_held else None,
                        grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                        grip_force=payload_grip_force_nm if payload_held else None,
                    )
                log[descent_log_key]["status"] = "round_trip_completed"
                write_json(log_path, log)
                descent_motion_started = False
                print(f"{descent_print_prefix}_ROUND_TRIP_DONE = True")
                if pregrasp_compensation_scale_active:
                    ramp_tilt_scale(
                        arm,
                        commander,
                        q_aligned,
                        start_scale=commander.compensation_scale,
                        end_scale=side_scale,
                        duration_s=float(
                            adaptive_secure_config["compensation_transition_s"]
                        ),
                        label="adaptive_secure_pregrasp_scale_restore",
                        gripper=adaptive_gripper if payload_held else None,
                        grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                        grip_force=payload_grip_force_nm if payload_held else None,
                    )
                    pregrasp_compensation_scale_active = False
                    print(
                        "PREGRASP_TILT_SCALE_TRANSITION =",
                        f"{pregrasp_descent_scale:.2f}->{side_scale:.2f}",
                    )
            finally:
                arm.limits.max_acceleration_rad_s2 = old_acceleration
                arm.limits.v_max_rad_s = old_v_max
                arm.limits.j6_v_max_rad_s = old_j6_v_max

        if control_trace is not None:
            control_trace.clear_downward_guard()

        if adaptive_grasp_box_place_enabled and adaptive_target_size and payload_held:
            direct_plan, _ = run_worker_while_holding(
                arm, q_aligned,
                lambda: plan_direct_box_transfer(
                    measured_position_from_commander(arm), q_aligned, box_plan,
                    alignment=alignment, kinematics=tcp_kinematics,
                    collision_checker=collision_checker, tilt_model=tilt_model,
                    applied_support_up=commander.last_snapshot["support_up_normal_base"],
                    compensation_scale=commander.compensation_scale,
                    torque_limits=mount_record["diagnostic"]["correction_absolute_limits_nm"],
                    deployment_source=deployment_source,
                ),
                timeout_s=worker_timeout_s, label="direct_box_transfer_planning",
            )
            log["direct_box_transfer"] = direct_plan
            box_route_in_progress = True
            write_json(log_path, log)
            if control_trace is not None:
                control_trace.phase = "direct_high_to_box_release"
            print("BOX_ROUTE_PHASE = direct_high_to_release_continuous")
            fault = arm.move_waypoints(
                direct_plan["command_path"], "direct_high_to_box_release",
                grip_cmd=adaptive_gripper.mm_to_fb(payload_grip_gap_mm),
                grip_force=payload_grip_force_nm,
            )
            if fault:
                raise RuntimeError(fault)
            release_q = direct_plan["release_q_rad"]
            release_runner = BenchRunner(arm, adaptive_gripper, release_q, adaptive_parameters)
            released = release_runner.hold(
                adaptive_parameters.start_gap_mm, adaptive_parameters.secure_force_nm,
                adaptive_parameters.open_hold_s, "verified_box_release",
            )
            if adaptive_parameters.start_gap_mm - released.actual_gap_mm > adaptive_parameters.empty_max_final_excess_mm:
                raise RuntimeError("gripper release was not verified at the box")
            payload_held = False
            adaptive_gripper_may_be_closed = False
            box_release_verified = True
            log["adaptive_grasp_box_place"] = {
                "status": "gripper_open_verified",
                "placement_confirmed": None,
                "release_gap_mm": released.actual_gap_mm,
                "release_records": release_runner.records,
                "route": "direct_high_to_box_release",
            }
            direct_plan["status"] = "released_at_box"
            write_json(log_path, log)
            print("BOX_RELEASE_POSE_REACHED = True")
            empty_return = [list(point["q"]) for point in reversed(box_plan["route"])]
            empty_collision = check_collision_path(
                collision_checker, empty_return, float(alignment["collision_step_rad"]),
            )
            log["direct_box_empty_return_collision"] = empty_collision
            if control_trace is not None:
                control_trace.phase = "direct_box_empty_return"
            fault = arm.move_waypoints(
                empty_return, "direct_box_empty_return",
                grip_cmd=adaptive_gripper.mm_to_fb(adaptive_parameters.start_gap_mm),
                grip_force=adaptive_parameters.secure_force_nm,
            )
            if fault:
                raise RuntimeError(fault)
            ramp_tilt_scale(
                arm, commander, empty_return[-1],
                start_scale=commander.compensation_scale, end_scale=vertical_scale,
                duration_s=transition_s, label="direct_box_vertical_scale_restore",
                gripper=adaptive_gripper, grip_gap_mm=adaptive_parameters.start_gap_mm,
                grip_force=adaptive_parameters.secure_force_nm,
            )
            fault = arm.move_waypoints(
                list(reversed(phases[0][1])), "direct_box_return_to_start",
                grip_cmd=adaptive_gripper.mm_to_fb(adaptive_parameters.start_gap_mm),
                grip_force=adaptive_parameters.secure_force_nm,
            )
            if fault:
                raise RuntimeError(fault)
            box_route_in_progress = False
            deployed = False
            direct_plan["status"] = "released_and_empty_return_done"
            log["adaptive_grasp_box_place"]["status"] = "gripper_open_verified_and_return_at_start"
            result = "VISUAL_ADAPTIVE_GRASP_BOX_MOTION_DONE_PLACEMENT_UNVERIFIED"
            return 0

        if len(executed_alignment_path) > 1:
            alignment_return_path = list(reversed(executed_alignment_path))
            alignment_return_collision = check_collision_path(
                collision_checker,
                alignment_return_path,
                float(alignment["collision_step_rad"]),
            )
            log["alignment_return_collision"] = alignment_return_collision
            previous_j6_v_max = arm.limits.j6_v_max_rad_s
            if payload_held and simplified_full_flow and adaptive_target_size:
                arm.limits.j6_v_max_rad_s = min(
                    previous_j6_v_max,
                    float(grasp_orientation_config["j6_v_max_rad_s"]),
                )
                print("LOADED_ALIGNMENT_RETURN_J6_V_MAX_RAD_S =", arm.limits.j6_v_max_rad_s)
            try:
                log["alignment_return_j6_v_max_rad_s"] = arm.limits.j6_v_max_rad_s
                write_json(log_path, log)
                if control_trace is not None:
                    control_trace.phase = "alignment_return"
                fault = arm.move_waypoints(
                    alignment_return_path,
                    "alignment_return",
                    grip_cmd=(
                        adaptive_gripper.mm_to_fb(payload_grip_gap_mm)
                        if payload_held
                        else None
                    ),
                    grip_force=payload_grip_force_nm if payload_held else 0.3,
                )
            finally:
                arm.limits.j6_v_max_rad_s = previous_j6_v_max
            if fault:
                raise RuntimeError(fault)
        q_observe = list(phases[-1][1][-1])
        restore = commander.set_support_up_normal(
            commander.nominal_support_up_normal_base,
            source="mount_record_pitch_only:alignment_return",
        )
        hold_with_tilt_policy(
            arm,
            observation_command_q,
            float(tilt_config["normal_transition_s"]) + 0.25,
            "support_normal_restore",
            gripper=adaptive_gripper if payload_held else None,
            grip_gap_mm=payload_grip_gap_mm if payload_held else None,
            grip_force=payload_grip_force_nm if payload_held else None,
        )
        print("SUPPORT_NORMAL_RESTORED =", restore)
        alignment_motion_started = False
        if search_path:
            if control_trace is not None:
                control_trace.phase = "high_view_search_return"
            fault = arm.move_waypoints(
                list(reversed(search_path)),
                "high_view_search_return",
                grip_cmd=adaptive_gripper.mm_to_fb(payload_grip_gap_mm) if payload_held else None,
                grip_force=payload_grip_force_nm if payload_held else 0.3,
            )
            if fault:
                raise RuntimeError(fault)
            search_path = []

        endpoint_return_start = [float(value) for value in arm.get_pos()[:6]]
        endpoint_return_collision = check_collision_path(
            collision_checker,
            [endpoint_return_start, q_observe],
            float(observation_endpoint_config["collision_step_rad"]),
        )
        log["observation_endpoint_return"] = {
            "start_q_rad": endpoint_return_start,
            "target_q_rad": q_observe,
            "collision": endpoint_return_collision,
        }
        fault = arm.move_waypoints(
            [endpoint_return_start, q_observe],
            "observation_endpoint_trim_return",
            grip_cmd=(
                adaptive_gripper.mm_to_fb(payload_grip_gap_mm)
                if payload_held
                else None
            ),
            grip_force=payload_grip_force_nm if payload_held else 0.3,
        )
        if fault:
            raise RuntimeError(fault)
        hold_with_tilt_policy(
            arm,
            q_observe,
            0.5,
            "observation_endpoint_return_hold",
            gripper=adaptive_gripper if payload_held else None,
            grip_gap_mm=payload_grip_gap_mm if payload_held else None,
            grip_force=payload_grip_force_nm if payload_held else None,
        )

        for name, points in reversed(phases):
            if (
                name == "vertical_escape"
                and adaptive_grasp_box_place_enabled
                and payload_held
            ):
                box_route_in_progress = True
                box_route = box_plan["route"]
                box_route_q = [
                    [float(value) for value in item["q"]] for item in box_route
                ]
                box_scale = float(box_place_config["box_route_compensation_scale"])
                box_transition_s = float(
                    box_place_config["compensation_transition_s"]
                )
                print(
                    "BOX_TILT_SCALE_TRANSITION =",
                    f"{vertical_scale:.2f}->{box_scale:.2f}",
                )
                ramp_tilt_scale(
                    arm,
                    commander,
                    box_route_q[0],
                    start_scale=vertical_scale,
                    end_scale=box_scale,
                    duration_s=box_transition_s,
                    label="box_route_scale_down",
                    gripper=adaptive_gripper,
                    grip_gap_mm=payload_grip_gap_mm,
                    grip_force=payload_grip_force_nm,
                )
                previous_v_max = float(arm.limits.v_max_rad_s)
                previous_j6_v_max = float(arm.limits.j6_v_max_rad_s)
                arm.limits.v_max_rad_s = min(
                    previous_v_max,
                    (all_joint_speed if all_joint_speed is not None
                     else transit_speed if transit_speed is not None
                     else float(box_plan["motion"]["v_max_rad_s"]) * motion_speed_scale),
                )
                arm.limits.j6_v_max_rad_s = min(
                    previous_j6_v_max,
                    (all_joint_speed if all_joint_speed is not None
                     else float(box_plan["motion"]["j6_v_max_rad_s"])),
                )
                try:
                    print("BOX_ROUTE_PHASE = rear_ready_to_box_release_loaded")
                    fault = arm.move_waypoints(
                        box_route_q,
                        "loaded_box_route_forward",
                        grip_cmd=adaptive_gripper.mm_to_fb(payload_grip_gap_mm),
                        grip_force=payload_grip_force_nm,
                    )
                    if fault:
                        raise RuntimeError(fault)
                    pre_release_grip_feedback = {
                        "actual_gap_mm": adaptive_gripper.read_gap_mm(),
                        "gripper_tau_nm": float(arm.get_tau()[6]),
                    }
                    log["adaptive_grasp_box_place"] = {
                        "status": "box_release_pose_reached",
                        "pre_release_grip_feedback": pre_release_grip_feedback,
                        "placement_confirmed": None,
                    }
                    print(
                        "BOX_RELEASE_POSE_REACHED = True",
                        f"gap={pre_release_grip_feedback['actual_gap_mm']:.2f}mm",
                        f"tau={pre_release_grip_feedback['gripper_tau_nm']:.3f}Nm",
                    )
                    release_runner = BenchRunner(
                        arm,
                        adaptive_gripper,
                        box_route_q[-1],
                        adaptive_parameters,
                    )
                    released = release_runner.hold(
                        adaptive_parameters.start_gap_mm,
                        adaptive_parameters.secure_force_nm,
                        adaptive_parameters.open_hold_s,
                        "verified_box_release",
                    )
                    release_shortfall_mm = (
                        adaptive_parameters.start_gap_mm - released.actual_gap_mm
                    )
                    if (
                        release_shortfall_mm
                        > adaptive_parameters.empty_max_final_excess_mm
                    ):
                        raise RuntimeError(
                            "box release was not verified: "
                            f"actual={released.actual_gap_mm:.2f}mm"
                        )
                    payload_held = False
                    adaptive_gripper_may_be_closed = False
                    box_release_verified = True
                    log["adaptive_grasp_box_place"].update(
                        {
                            "status": "box_gripper_open_verified",
                            "release_gap_mm": released.actual_gap_mm,
                            "release_records": release_runner.records,
                            "route_scale": box_scale,
                        }
                    )
                    write_json(log_path, log)
                    print(
                        "BOX_GRIPPER_OPEN_VERIFIED = True gap=",
                        round(released.actual_gap_mm, 2),
                    )
                    print("BOX_ROUTE_PHASE = box_release_to_rear_ready_empty")
                    fault = arm.move_waypoints(
                        list(reversed(box_route_q)),
                        "empty_box_route_return",
                        grip_cmd=adaptive_gripper.mm_to_fb(
                            adaptive_parameters.start_gap_mm
                        ),
                        grip_force=adaptive_parameters.secure_force_nm,
                    )
                    if fault:
                        raise RuntimeError(fault)
                finally:
                    arm.limits.v_max_rad_s = previous_v_max
                    arm.limits.j6_v_max_rad_s = previous_j6_v_max
                print(
                    "BOX_TILT_SCALE_TRANSITION =",
                    f"{box_scale:.2f}->{vertical_scale:.2f}",
                )
                ramp_tilt_scale(
                    arm,
                    commander,
                    box_route_q[0],
                    start_scale=box_scale,
                    end_scale=vertical_scale,
                    duration_s=box_transition_s,
                    label="box_route_scale_restore",
                    gripper=adaptive_gripper,
                    grip_gap_mm=adaptive_parameters.start_gap_mm,
                    grip_force=adaptive_parameters.secure_force_nm,
                )
                box_route_in_progress = False
                log["adaptive_grasp_box_place"]["status"] = (
                    "gripper_open_verified_and_return_at_rear_ready"
                )
                write_json(log_path, log)
            return_name = f"{name}_return"
            print("RETURN_PHASE =", return_name)
            fault = arm.move_waypoints(
                list(reversed(points)),
                return_name,
                grip_cmd=(
                    adaptive_gripper.mm_to_fb(payload_grip_gap_mm)
                    if payload_held
                    else adaptive_gripper.mm_to_fb(adaptive_parameters.start_gap_mm)
                    if adaptive_grasp_box_place_enabled
                    and not orientation_only_requested
                    else None
                ),
                grip_force=(
                    payload_grip_force_nm
                    if payload_held
                    else adaptive_parameters.secure_force_nm
                    if adaptive_grasp_box_place_enabled
                    and not orientation_only_requested
                    else 0.3
                ),
            )
            if fault:
                raise RuntimeError(fault)
            print("到达:", return_name)
            if name == "side_deploy":
                print(
                    "TILT_SCALE_TRANSITION =",
                    f"{side_scale:.2f}->{high_turn_scale:.2f}",
                )
                ramp_tilt_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=side_scale,
                    end_scale=high_turn_scale,
                    duration_s=transition_s,
                    label="right_ready_scale_down",
                    gripper=adaptive_gripper if payload_held else None,
                    grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                    grip_force=payload_grip_force_nm if payload_held else None,
                )
            elif name == "high_turn" and not math.isclose(
                high_turn_scale, vertical_scale, abs_tol=1e-9
            ):
                print(
                    "TILT_SCALE_TRANSITION =",
                    f"{high_turn_scale:.2f}->{vertical_scale:.2f}",
                )
                ramp_tilt_scale(
                    arm,
                    commander,
                    points[0],
                    start_scale=high_turn_scale,
                    end_scale=vertical_scale,
                    duration_s=transition_s,
                    label="rear_ready_vertical_scale_restore",
                    gripper=adaptive_gripper if payload_held else None,
                    grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                    grip_force=payload_grip_force_nm if payload_held else None,
                )
        deployed = False
        return_code = 0
        if center_only_diagnostic:
            result = "VISUAL_CENTER_ALIGNMENT_DIAGNOSTIC_ROUND_TRIP_DONE"
        elif orientation_only_requested:
            result = "VISUAL_ADAPTIVE_GRASP_ORIENTATION_ROUND_TRIP_DONE"
        elif adaptive_grasp_box_place_enabled:
            if adaptive_secure_outcome == "holding_verified":
                if not box_release_verified:
                    raise RuntimeError(
                        "loaded run ended without verified gripper opening at the box"
                    )
                result = "VISUAL_ADAPTIVE_GRASP_BOX_MOTION_DONE_PLACEMENT_UNVERIFIED"
            elif adaptive_secure_outcome == "contact_miss":
                result = "VISUAL_ADAPTIVE_CONTACT_MISS_SAFE_RETURN"
                return_code = 3
            elif adaptive_secure_outcome == "secure_lost":
                result = "VISUAL_ADAPTIVE_SECURE_LOST_SAFE_RETURN"
                return_code = 3
            else:
                raise RuntimeError(
                    "adaptive box mode ended without a terminal acquisition state"
                )
        elif adaptive_secure_no_lift_enabled:
            if adaptive_secure_outcome == "holding_verified":
                result = "VISUAL_ADAPTIVE_SECURE_NO_LIFT_ROUND_TRIP_DONE"
            elif adaptive_secure_outcome == "contact_miss":
                result = "VISUAL_ADAPTIVE_CONTACT_MISS_SAFE_RETURN"
                return_code = 3
            elif adaptive_secure_outcome == "secure_lost":
                result = "VISUAL_ADAPTIVE_SECURE_LOST_SAFE_RETURN"
                return_code = 3
            else:
                raise RuntimeError(
                    "adaptive secure mode ended without a terminal acquisition state"
                )
        elif adaptive_pregrasp_enabled:
            result = "VISUAL_ALIGN_ADAPTIVE_PREGRASP_ROUND_TRIP_DONE"
        elif safe_descent_enabled:
            result = "VISUAL_ALIGN_SAFE_DESCENT_ROUND_TRIP_DONE"
        else:
            result = "VISUAL_CENTER_ALIGNMENT_ROUND_TRIP_DONE"
        return return_code
    except Exception as exc:
        result = f"ABORTED: {type(exc).__name__}: {exc}"
        if control_trace is not None:
            control_trace.phase = "fault_recovery"
            control_trace.clear_downward_guard()
        print(result)
        if arm_session is not None and enabled and not deployed:
            arm_session.mark_fault(result)
        if arm is not None and enabled and deployed:
            if loaded_fault_requires_operator_recovery(
                adaptive_grasp_box_place_enabled,
                payload_held,
                box_route_in_progress,
            ):
                print(
                    "LOADED_FAULT_POLICY = STOP_IN_PLACE; NO_AUTOMATIC_RELEASE; "
                    "NO_AUTOMATIC_RECOVERY_MOTION"
                )
                log["loaded_fault"] = {
                    "payload_may_be_held": bool(payload_held),
                    "box_route_in_progress": bool(box_route_in_progress),
                    "box_release_verified": bool(box_release_verified),
                    "automatic_release_executed": False,
                    "automatic_recovery_motion_executed": False,
                }
                if arm_session is not None:
                    arm_session.mark_fault(result)
                    write_json(log_path, log)
                    return 1
                try:
                    support_record = hold_for_operator_support_before_disable(
                        arm,
                        non_interactive=args.non_interactive,
                        timeout_s=float(
                            fault_recovery_config["operator_support_timeout_s"]
                        ),
                        command_hz=float(
                            fault_recovery_config["operator_support_command_hz"]
                        ),
                        gripper=adaptive_gripper if payload_held else None,
                        grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                        grip_force=payload_grip_force_nm if payload_held else None,
                        prompt=(
                            "LOADED_FAULT: support the arm and manually secure/remove "
                            "the payload if reachable, then input s: "
                        ),
                    )
                    log["loaded_fault"]["operator_support_before_disable"] = (
                        support_record
                    )
                except Exception as support_exc:
                    print("LOADED_OPERATOR_SUPPORT_WARNING =", repr(support_exc))
                    log["loaded_fault"]["operator_support_hold_error"] = (
                        f"{type(support_exc).__name__}: {support_exc}"
                    )
                write_json(log_path, log)
                return 1
            try:
                def save_fault_recovery_progress(stage, record):
                    log.setdefault("fault_safe_return", {})[stage] = record
                    write_json(log_path, log)

                if adaptive_gripper_may_be_closed:
                    if adaptive_gripper is None or adaptive_parameters is None:
                        raise RuntimeError(
                            "cannot prove gripper release before fault recovery"
                        )
                    release_q = [float(value) for value in arm.get_pos()[:6]]
                    emergency_release = BenchRunner(
                        arm,
                        adaptive_gripper,
                        release_q,
                        adaptive_parameters,
                    )
                    released = emergency_release.hold(
                        adaptive_parameters.start_gap_mm,
                        adaptive_parameters.secure_force_nm,
                        adaptive_parameters.open_hold_s,
                        "fault_release_before_motion",
                    )
                    release_shortfall_mm = (
                        adaptive_parameters.start_gap_mm - released.actual_gap_mm
                    )
                    if (
                        release_shortfall_mm
                        > adaptive_parameters.empty_max_final_excess_mm
                    ):
                        raise RuntimeError(
                            "fault recovery cannot verify target release: "
                            f"actual={released.actual_gap_mm:.2f}mm"
                        )
                    adaptive_gripper_may_be_closed = False
                    log.setdefault("fault_safe_return", {})[
                        "gripper_release_before_motion"
                    ] = {
                        "actual_gap_mm": released.actual_gap_mm,
                        "records": emergency_release.records,
                    }
                    write_json(log_path, log)
                    print(
                        "FAULT_GRIPPER_RELEASED_BEFORE_MOTION = True gap=",
                        round(released.actual_gap_mm, 2),
                    )

                if low_descent_motion_started and executed_low_descent_path:
                    low_recovery = nearest_recovery_path(
                        arm.get_pos()[:6], executed_low_descent_path
                    )
                    low_recovery_collision = check_collision_path(
                        collision_checker,
                        low_recovery,
                        float(adaptive_secure_config["collision_step_rad"]),
                    )
                    log["fault_low_descent_recovery_collision"] = (
                        low_recovery_collision
                    )
                    write_json(log_path, log)
                    print("RECOVERY_PHASE = low_grasp_to_pregrasp")
                    execute_segmented_recovery(
                        arm,
                        low_recovery[1:],
                        continuous_path=(all_joint_speed is not None),
                        label="low_grasp_recovery",
                        collision_checker=collision_checker,
                        collision_step_rad=float(
                            fault_recovery_config["collision_step_rad"]
                        ),
                        maximum_joint_step_rad=float(
                            fault_recovery_config["maximum_joint_step_rad"]
                        ),
                        v_max_rad_s=float(
                            fault_recovery_config["v_max_rad_s"]
                        ),
                        j6_v_max_rad_s=float(
                            fault_recovery_config["j6_v_max_rad_s"]
                        ),
                        progress_callback=lambda record: save_fault_recovery_progress(
                            "low_grasp_to_pregrasp", record
                        ),
                    )
                    low_descent_motion_started = False

                if low_compensation_scale_active:
                    recovery_hold_q = [float(value) for value in arm.get_pos()[:6]]
                    ramp_tilt_scale(
                        arm,
                        commander,
                        recovery_hold_q,
                        start_scale=commander.compensation_scale,
                        end_scale=pregrasp_descent_scale,
                        duration_s=float(
                            adaptive_secure_config["compensation_transition_s"]
                        ),
                        label="fault_adaptive_secure_scale_restore",
                    )
                    low_compensation_scale_active = False

                if descent_motion_started and executed_descent_path:
                    descent_recovery = nearest_recovery_path(
                        arm.get_pos()[:6], executed_descent_path
                    )
                    descent_recovery_collision = check_collision_path(
                        collision_checker,
                        descent_recovery,
                        float(active_descent_config["collision_step_rad"]),
                    )
                    log["fault_descent_recovery_collision"] = (
                        descent_recovery_collision
                    )
                    write_json(log_path, log)
                    print("RECOVERY_PHASE = descent_to_alignment")
                    execute_segmented_recovery(
                        arm,
                        descent_recovery[1:],
                        continuous_path=(all_joint_speed is not None),
                        label="descent_recovery",
                        collision_checker=collision_checker,
                        collision_step_rad=float(
                            fault_recovery_config["collision_step_rad"]
                        ),
                        maximum_joint_step_rad=float(
                            fault_recovery_config["maximum_joint_step_rad"]
                        ),
                        v_max_rad_s=float(
                            fault_recovery_config["v_max_rad_s"]
                        ),
                        j6_v_max_rad_s=float(
                            fault_recovery_config["j6_v_max_rad_s"]
                        ),
                        progress_callback=lambda record: save_fault_recovery_progress(
                            "descent_to_alignment", record
                        ),
                    )
                    descent_motion_started = False

                if pregrasp_compensation_scale_active:
                    recovery_hold_q = [float(value) for value in arm.get_pos()[:6]]
                    ramp_tilt_scale(
                        arm,
                        commander,
                        recovery_hold_q,
                        start_scale=commander.compensation_scale,
                        end_scale=side_scale,
                        duration_s=float(
                            adaptive_secure_config["compensation_transition_s"]
                        ),
                        label="fault_adaptive_pregrasp_scale_restore",
                    )
                    pregrasp_compensation_scale_active = False

                if alignment_motion_started and executed_alignment_path:
                    recovery = nearest_recovery_path(
                        arm.get_pos()[:6], executed_alignment_path
                    )
                    recovery_collision = check_collision_path(
                        collision_checker,
                        recovery,
                        float(alignment["collision_step_rad"]),
                    )
                    log["fault_alignment_recovery_collision"] = (
                        recovery_collision
                    )
                    write_json(log_path, log)
                    print("RECOVERY_PHASE = alignment_to_observation")
                    execute_segmented_recovery(
                        arm,
                        recovery[1:],
                        continuous_path=(all_joint_speed is not None),
                        label="alignment_recovery",
                        collision_checker=collision_checker,
                        collision_step_rad=float(
                            fault_recovery_config["collision_step_rad"]
                        ),
                        maximum_joint_step_rad=float(
                            fault_recovery_config["maximum_joint_step_rad"]
                        ),
                        v_max_rad_s=float(
                            fault_recovery_config["v_max_rad_s"]
                        ),
                        j6_v_max_rad_s=float(
                            fault_recovery_config["j6_v_max_rad_s"]
                        ),
                        progress_callback=lambda record: save_fault_recovery_progress(
                            "alignment_to_observation", record
                        ),
                    )
                q_observe = list(phases[-1][1][-1])
                commander.set_support_up_normal(
                    commander.nominal_support_up_normal_base,
                    source="mount_record_pitch_only:fault_return",
                )
                normal_restore_q = measured_position_from_commander(arm)
                hold_with_tilt_policy(
                    arm,
                    normal_restore_q,
                    float(tilt_config["normal_transition_s"]) + 0.25,
                    "fault_normal_restore",
                )
                if search_path:
                    recovery = nearest_recovery_path(normal_restore_q, search_path)
                    execute_segmented_recovery(
                        arm, recovery[1:], continuous_path=(all_joint_speed is not None),
                        label="high_view_search_fault_return",
                        collision_checker=collision_checker,
                        collision_step_rad=float(fault_recovery_config["collision_step_rad"]),
                        maximum_joint_step_rad=float(fault_recovery_config["maximum_joint_step_rad"]),
                        v_max_rad_s=float(fault_recovery_config["v_max_rad_s"]),
                        j6_v_max_rad_s=float(fault_recovery_config["j6_v_max_rad_s"]),
                        progress_callback=lambda record: save_fault_recovery_progress(
                            "high_view_search_return", record
                        ),
                    )
                endpoint_fault_start = [
                    float(value) for value in arm.get_pos()[:6]
                ]
                endpoint_fault_collision = check_collision_path(
                    collision_checker,
                    [endpoint_fault_start, q_observe],
                    float(observation_endpoint_config["collision_step_rad"]),
                )
                log["fault_observation_endpoint_return"] = {
                    "start_q_rad": endpoint_fault_start,
                    "target_q_rad": q_observe,
                    "collision": endpoint_fault_collision,
                }
                execute_segmented_recovery(
                    arm,
                    [q_observe],
                    continuous_path=(all_joint_speed is not None),
                    label="fault_observation_endpoint_trim_return",
                    collision_checker=collision_checker,
                    collision_step_rad=float(
                        fault_recovery_config["collision_step_rad"]
                    ),
                    maximum_joint_step_rad=float(
                        fault_recovery_config["maximum_joint_step_rad"]
                    ),
                    v_max_rad_s=float(fault_recovery_config["v_max_rad_s"]),
                    j6_v_max_rad_s=float(
                        fault_recovery_config["j6_v_max_rad_s"]
                    ),
                    progress_callback=lambda record: save_fault_recovery_progress(
                        "observation_endpoint", record
                    ),
                )
                for name, points in reversed(phases):
                    execute_segmented_recovery(
                        arm,
                        list(reversed(points)),
                        continuous_path=(all_joint_speed is not None),
                        label=f"fault_{name}_return",
                        collision_checker=collision_checker,
                        collision_step_rad=float(
                            fault_recovery_config["collision_step_rad"]
                        ),
                        maximum_joint_step_rad=float(
                            fault_recovery_config["maximum_joint_step_rad"]
                        ),
                        v_max_rad_s=float(
                            fault_recovery_config["v_max_rad_s"]
                        ),
                        j6_v_max_rad_s=float(
                            fault_recovery_config["j6_v_max_rad_s"]
                        ),
                        allowed_final_contacts=(
                            deployment_source["safety"][
                                "allowed_start_model_contacts"
                            ]
                            if name == "vertical_escape"
                            else None
                        ),
                        progress_callback=lambda record, stage=name: save_fault_recovery_progress(
                            f"{stage}_return", record
                        ),
                    )
                    if name == "side_deploy":
                        ramp_tilt_scale(
                            arm,
                            commander,
                            points[0],
                            start_scale=side_scale,
                            end_scale=high_turn_scale,
                            duration_s=transition_s,
                            label="fault_right_ready_scale_down",
                        )
                    elif name == "high_turn" and not math.isclose(
                        high_turn_scale, vertical_scale, abs_tol=1e-9
                    ):
                        ramp_tilt_scale(
                            arm,
                            commander,
                            points[0],
                            start_scale=high_turn_scale,
                            end_scale=vertical_scale,
                            duration_s=transition_s,
                            label="fault_rear_ready_vertical_scale_restore",
                        )
                print("SAFE_RETURN_AFTER_REJECT = True")
                deployed = False
            except Exception as recovery_exc:
                print("SAFE_RETURN_WARNING =", repr(recovery_exc))
                if isinstance(recovery_exc, SegmentedRecoveryError):
                    log.setdefault("fault_safe_return", {})[
                        "failed_segment"
                    ] = recovery_exc.record
                log.setdefault("fault_safe_return", {})["status"] = (
                    f"failed: {type(recovery_exc).__name__}: {recovery_exc}"
                )
                if arm_session is not None:
                    arm_session.mark_fault(result)
                    write_json(log_path, log)
                    return 1
                try:
                    support_record = hold_for_operator_support_before_disable(
                        arm,
                        non_interactive=args.non_interactive,
                        timeout_s=float(
                            fault_recovery_config["operator_support_timeout_s"]
                        ),
                        command_hz=float(
                            fault_recovery_config["operator_support_command_hz"]
                        ),
                    )
                    log["fault_safe_return"][
                        "operator_support_before_disable"
                    ] = support_record
                except Exception as support_exc:
                    print("OPERATOR_SUPPORT_HOLD_WARNING =", repr(support_exc))
                    log["fault_safe_return"]["operator_support_hold_error"] = (
                        f"{type(support_exc).__name__}: {support_exc}"
                    )
                write_json(log_path, log)
        return 1
    finally:
        if arm is not None:
            if arm_session is not None:
                arm_session.finish_task(
                    at_zero=not deployed, result=result, log_path=str(log_path),
                    gripper=adaptive_gripper if payload_held else None,
                    grip_gap_mm=payload_grip_gap_mm if payload_held else None,
                    grip_force=payload_grip_force_nm if payload_held else None,
                )
            else:
                try:
                    arm.disable()
                except Exception as exc:
                    print("DISABLE_WARNING =", repr(exc))
        if control_trace is not None:
            log["control_trace"]["row_count"] = control_trace.row_count
            log["control_trace"]["command_count"] = control_trace.command_count
            try:
                control_trace.close()
            except Exception as exc:
                log["control_trace"]["close_error"] = repr(exc)
        log["status"] = result
        write_json(log_path, log)
        if arm_session is None:
            print("DISABLED：电机应为常红；继续托稳直到机械臂落在软支撑上。")
        else:
            print("INTEGRATION_STATE =", arm_session.snapshot()["state"])
        print("LOG_SAVED =", log_path)
        print("RESULT =", result)


if __name__ == "__main__":
    raise SystemExit(main())
