# -*- coding: utf-8 -*-
"""机械臂运动控制 —— 官方 S1_SDK 运动层，带安全闸的 50Hz 关节斜坡。

实现照搬 industrial-agent/scripts/s1_l4_hover_official.py 的 guard/move（已实机验证）。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★安全阈值分两类，后续开发者请分清（本项目前身吃过“把可调值误当死线”的亏）★

【可调工作阈值】—— 为适配新工况【就应该】调整，调它们是正常操作，不是破坏安全：
    v_max_rad_s, max_track_err_rad, max_speed_rad_s, max_temp_c,
    max_joint_delta_rad, settle_seconds
  例：本项目前身速度闸误触发，把 v_max_rad_s 0.20→0.12 即解决，闸本身没动也不该动。
  这些全是 SafetyLimits 的字段，构造时可覆盖，默认值来自 l4 实机调定。

【保命结构】—— 是流程骨架，可调其阈值但【不要删除该检查本身】：
    · finally 里的 disable()（异常/中止/正常都失能）
    · 通电前验证碰撞证据：SDK实时检查，或与当前计划哈希绑定的离线全路径报告
    · 段间关节增量 Δq 上限（防大跳变）
    · guard 的速度去抖（连续 3 拍超限才判违例，避免静摩擦粘滑单拍尖峰误杀）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
from __future__ import annotations

import math
import statistics
import time
from collections import deque
from dataclasses import dataclass

from .kinematics import READY_Q


MOTION_PROFILES = ("linear", "s_curve")
S_CURVE_BLEND_FRACTION = 0.20
J6_INDEX = 5


def motion_profile_peak_factor(profile: str) -> float:
    """Return max normalized speed for the selected position profile."""
    if profile == "linear":
        return 1.0
    if profile == "s_curve":
        return 1.0 / (1.0 - S_CURVE_BLEND_FRACTION)
    raise ValueError(
        f"motion_profile must be one of {MOTION_PROFILES}, got {profile!r}"
    )


def motion_profile_progress(u: float, profile: str) -> float:
    """Map normalized time to normalized position without overshoot."""
    u = min(1.0, max(0.0, float(u)))
    if profile == "linear":
        return u
    if profile != "s_curve":
        raise ValueError(
            f"motion_profile must be one of {MOTION_PROFILES}, got {profile!r}"
        )

    blend = S_CURVE_BLEND_FRACTION
    peak = motion_profile_peak_factor(profile)
    if u < blend:
        return peak * 0.5 * (
            u - blend / math.pi * math.sin(math.pi * u / blend)
        )
    if u <= 1.0 - blend:
        return peak * (u - 0.5 * blend)

    tail = u - (1.0 - blend)
    return peak * (
        1.0 - 1.5 * blend
        + 0.5 * (
            tail
            + blend / math.pi * math.sin(math.pi * tail / blend)
        )
    )


def motion_duration_s(
    delta_rad: float,
    v_max_rad_s: float,
    profile: str,
    minimum_s: float = 0.8,
) -> float:
    """Choose duration so the profile peak speed never exceeds v_max."""
    if not math.isfinite(v_max_rad_s) or v_max_rad_s <= 0.0:
        raise ValueError("v_max_rad_s must be positive")
    if not math.isfinite(minimum_s) or minimum_s < 0.0:
        raise ValueError("minimum_s cannot be negative")
    if not math.isfinite(delta_rad):
        raise ValueError("delta_rad must be finite")
    peak = motion_profile_peak_factor(profile)
    return max(float(minimum_s), abs(float(delta_rad)) * peak / v_max_rad_s)


def _validated_joint_path(waypoints):
    points = []
    for index, raw_q in enumerate(waypoints):
        q = [float(value) for value in raw_q]
        if len(q) != 6 or not all(math.isfinite(value) for value in q):
            raise ValueError(
                f"joint path waypoint {index} must contain 6 finite values"
            )
        points.append(q)
    if len(points) < 2:
        raise ValueError("joint path requires at least two waypoints")

    segment_lengths = [
        max(abs(a - b) for a, b in zip(q_from, q_to))
        for q_from, q_to in zip(points, points[1:])
    ]
    if any(length <= 0.0 for length in segment_lengths):
        raise ValueError("joint path cannot contain duplicate adjacent waypoints")
    return points, segment_lengths, sum(segment_lengths)


def joint_path_total_delta(waypoints) -> float:
    """Return the sum of per-segment max-joint deltas for a checked path."""
    _, _, total_delta = _validated_joint_path(waypoints)
    return total_delta


def _joint_path_axis_equivalent_delta_prepared(
    points,
    segment_lengths,
    total_delta: float,
    joint_index: int,
) -> float:
    """Return the worst-case axis delta under global path progress.

    The checked path is parameterized by the sum of each segment's maximum
    joint delta.  Multiplying the largest local axis/path slope by the total
    path length gives the equivalent delta needed to cap that axis everywhere
    on the synchronized path.
    """
    if joint_index < 0 or joint_index >= 6:
        raise ValueError("joint_index must be in [0, 5]")
    maximum_axis_path_slope = max(
        abs(q_to[joint_index] - q_from[joint_index]) / segment_length
        for q_from, q_to, segment_length in zip(
            points, points[1:], segment_lengths
        )
    )
    return total_delta * maximum_axis_path_slope


def _joint_path_motion_duration_prepared(
    points,
    segment_lengths,
    total_delta: float,
    v_max_rad_s: float,
    j6_v_max_rad_s: float,
    profile: str,
    minimum_s: float = 0.8,
) -> float:
    global_duration = motion_duration_s(
        total_delta,
        v_max_rad_s,
        profile,
        minimum_s,
    )
    j6_equivalent_delta = _joint_path_axis_equivalent_delta_prepared(
        points,
        segment_lengths,
        total_delta,
        J6_INDEX,
    )
    j6_duration = motion_duration_s(
        j6_equivalent_delta,
        j6_v_max_rad_s,
        profile,
        minimum_s=0.0,
    )
    return max(global_duration, j6_duration)


def joint_path_motion_duration_s(
    waypoints,
    v_max_rad_s: float,
    j6_v_max_rad_s: float,
    profile: str,
    minimum_s: float = 0.8,
) -> float:
    """Choose synchronized path duration with an independent J6 speed cap."""
    points, segment_lengths, total_delta = _validated_joint_path(waypoints)
    return _joint_path_motion_duration_prepared(
        points,
        segment_lengths,
        total_delta,
        v_max_rad_s,
        j6_v_max_rad_s,
        profile,
        minimum_s,
    )



def acceleration_limited_path_duration(points, segment_lengths, duration_s, profile,
                                      acceleration_rad_s2, dt):
    """Time-scale the original path, including sampled corner accelerations.

    No joint waypoint or Cartesian geometry changes. Limits describe planned
    command samples; actual motor acceleration is still hardware feedback.
    """
    import numpy as np
    if acceleration_rad_s2 is None:
        return duration_s
    limit = float(acceleration_rad_s2)
    if not math.isfinite(limit) or limit <= 0:
        raise ValueError("maximum acceleration must be positive and finite")
    cumulative = np.r_[0.0, np.cumsum(segment_lengths)]
    duration = float(duration_s)
    values = np.asarray(points, dtype=float)
    while True:
        times = np.linspace(0.0,duration,int(math.ceil(duration/dt))+1)
        intervals = np.diff(times)
        progress = np.asarray([motion_profile_progress(t/duration,profile) for t in times])
        distance = progress*cumulative[-1]
        targets = np.column_stack([np.interp(distance,cumulative,values[:,axis]) for axis in range(6)])
        velocities = np.diff(targets,axis=0)/intervals[:,None]
        velocity_times = (times[:-1]+times[1:])/2
        velocities = np.vstack([np.zeros(6),velocities,np.zeros(6)])
        velocity_times = np.r_[0.0,velocity_times,duration]
        maximum = float(np.max(np.abs(np.diff(velocities,axis=0)/np.diff(velocity_times)[:,None])))
        if maximum <= limit:
            return duration
        duration *= max(1.02, math.sqrt(maximum/limit)*1.01)


def _joint_path_target_prepared(
    points,
    segment_lengths,
    total_delta: float,
    progress: float,
):
    progress = min(1.0, max(0.0, float(progress)))
    if progress <= 0.0:
        return list(points[0])
    if progress >= 1.0:
        return list(points[-1])

    remaining = progress * total_delta
    for q_from, q_to, length in zip(
        points, points[1:], segment_lengths
    ):
        if remaining <= length:
            local = remaining / length
            return [
                start + local * (end - start)
                for start, end in zip(q_from, q_to)
            ]
        remaining -= length
    return list(points[-1])


def joint_path_target(waypoints, progress: float) -> list[float]:
    """Interpolate a checked piecewise-linear joint path by global progress."""
    points, segment_lengths, total_delta = _validated_joint_path(waypoints)
    return _joint_path_target_prepared(
        points, segment_lengths, total_delta, progress
    )


@dataclass
class SafetyLimits:
    """可调工作阈值（默认值 = l4 实机调定值）。见模块 docstring 的分类说明。"""
    hz: float = 50.0
    v_max_rad_s: float = 0.12          # 巡航速度目标（斜坡用）。前身从 0.20 下调至此解决速度闸误触发。
    j6_v_max_rad_s: float = 0.10       # J6（夹爪旋转）独立规划峰值上限；整条同步路径会按它延长。
    motion_profile: str = "linear"     # linear保持旧行为；s_curve为限峰值的余弦加减速。
    max_acceleration_rad_s2: float | None = None  # planned per-axis command acceleration
    max_track_err_rad: float = 0.08    # 相对插值目标的跟踪误差上限（settling 期放宽 2×）
    max_speed_rad_s: float = 0.5       # 关节速度上限（连续 3 拍超限才判违例）
    max_temp_c: float = 55.0
    max_joint_delta_rad: float = 1.5   # 段间关节增量上限（预检用）
    settle_seconds: float = 0.5        # 起步 settling 窗口，期内放宽跟踪误差、不计速度
    elapsed_cycle_progress: bool = False
    pause_on_tracking_lag: bool = False


class Arm:
    """S1 机械臂运动控制。构造→(预检)→enable→move/hold→disable。

    仅依赖 S1_SDK；不 import 相机/串口代码（自包含关键）。
    """

    def __init__(self, dev: str = "/dev/s1-arm", end_effector: str = "gripper",
                 arm_version: str = "V2", limits: SafetyLimits | None = None,
                 check_collision: bool = True):
        from S1_SDK import S1_arm, control_mode
        self.limits = limits or SafetyLimits()
        motion_profile_peak_factor(self.limits.motion_profile)
        if not math.isfinite(self.limits.hz) or self.limits.hz <= 0.0:
            raise ValueError("hz must be positive and finite")
        if (
            not math.isfinite(self.limits.j6_v_max_rad_s)
            or self.limits.j6_v_max_rad_s <= 0.0
        ):
            raise ValueError("j6_v_max_rad_s must be positive and finite")
        self.dt = 1.0 / self.limits.hz
        self.collision_enabled = bool(check_collision)
        self._arm = S1_arm(mode=control_mode.only_real, dev=dev,
                           end_effector=end_effector,
                           check_collision=self.collision_enabled,
                           arm_version=arm_version)
        self._speed_strikes = 0
        self._speed_strike_samples = []
        self._guard_position_samples = deque(maxlen=5)
        self._position_commander = None

    # ---- 底层透传 ----
    def get_pos(self):
        return list(self._arm.get_pos())

    def get_vel(self):
        return list(self._arm.get_vel())

    def get_tau(self):
        return list(self._arm.get_tau())

    def get_temp(self):
        return list(self._arm.get_temp())

    def gravity(self):
        """Run one official SDK gravity-compensation control cycle."""
        return self._arm.gravity()

    def set_position_commander(self, commander):
        """Install an explicit platform-specific position command strategy.

        A caller must opt in.  This avoids silently applying Go2 tilt
        compensation to historical level-bench programs or applying it twice
        in diagnostics that already command compensated motor torques.
        """
        if commander is not None and not callable(commander):
            raise TypeError("position commander must be callable or None")
        self._position_commander = commander

    def command_position(self, target_q):
        """Command six joints through the configured position strategy."""
        target = [float(value) for value in target_q]
        if len(target) != 6 or not all(math.isfinite(value) for value in target):
            raise ValueError("position target must contain six finite joints")
        commander = getattr(self, "_position_commander", None)
        if commander is None:
            return self._arm.joint_control_mit(target)
        return commander(self, target)

    def enable(self):
        self._arm.enable()

    def disable(self):
        self._arm.disable()

    def close(self):
        self._arm.close()

    def check_collision(self, q) -> bool:
        if not self.collision_enabled or self._arm.collision_checker is None:
            raise RuntimeError(
                "实时碰撞检查未启用；必须先验证与当前规划匹配的离线碰撞报告"
            )
        return bool(self._arm.check_collision(list(q)))

    def read_joint_median(self, n: int = 10, warmup_s: float = 1.0) -> list[float]:
        """稳态读关节角（7 维，含夹爪 index 6）。"""
        t_end = time.monotonic() + warmup_s
        while time.monotonic() < t_end:
            self._arm.get_pos()
            time.sleep(0.02)
        reads = []
        for _ in range(n):
            reads.append(list(self._arm.get_pos()))
            time.sleep(0.02)
        return [statistics.median(r[i] for r in reads) for i in range(7)]

    # ---- 安全闸（保命结构：速度去抖不可删）----
    def guard(self, meas, vel, temp, target6, settling: bool, *, check_tracking: bool = True):
        """返回中止原因字符串，或 None（通过）。照搬 l4 guard。"""
        L = self.limits
        meas6 = [float(meas[i]) for i in range(6)]
        vel6 = [float(vel[i]) for i in range(6)]
        err = [meas6[i] - target6[i] for i in range(6)]

        # Diagnostics only: retain a short measured-position window so a raw
        # SDK velocity excursion can later be compared with actual joint
        # displacement. This does not participate in the safety decision.
        if not hasattr(self, "_guard_position_samples"):
            self._guard_position_samples = deque(maxlen=5)
        if not hasattr(self, "_speed_strike_samples"):
            self._speed_strike_samples = []
        now = time.monotonic()
        self._guard_position_samples.append((now, meas6))

        lim = L.max_track_err_rad * (2.0 if settling else 1.0)
        if check_tracking and max(abs(e) for e in err) > lim:
            return f"track_err>{lim:.3f}: {['%+.4f' % e for e in err]}"
        peak_index = max(range(6), key=lambda index: abs(vel6[index]))
        peak_speed = abs(vel6[peak_index])
        if not settling and peak_speed > L.max_speed_rad_s:
            self._speed_strikes += 1
            self._speed_strike_samples.append(
                {
                    "joint": peak_index + 1,
                    "peak": vel6[peak_index],
                    "vel": vel6,
                }
            )
            self._speed_strike_samples = self._speed_strike_samples[-3:]
            if self._speed_strikes >= 3:   # 去抖：连续 3 拍才判违例（静摩擦粘滑会有单拍尖峰）
                frames = "; ".join(
                    "J{joint}={peak:+.3f} vel=[{vel}]".format(
                        joint=sample["joint"],
                        peak=sample["peak"],
                        vel=",".join(f"{value:+.3f}" for value in sample["vel"]),
                    )
                    for sample in self._speed_strike_samples
                )
                position_summary = "pos_window=unavailable"
                if len(self._guard_position_samples) >= 2:
                    first_t, first_q = self._guard_position_samples[0]
                    last_t, last_q = self._guard_position_samples[-1]
                    window_s = last_t - first_t
                    if window_s > 1e-6:
                        position_velocity = [
                            (last_q[index] - first_q[index]) / window_s
                            for index in range(6)
                        ]
                        position_summary = (
                            f"pos_window_ms={window_s * 1000.0:.1f} "
                            "pos_vel=["
                            + ",".join(
                                f"{value:+.3f}" for value in position_velocity
                            )
                            + "]"
                        )
                return (
                    f"speed>{L.max_speed_rad_s} x{self._speed_strikes}: "
                    f"sdk_frames=[{frames}]; {position_summary}; "
                    f"track_err_max={max(abs(value) for value in err):.4f}"
                )
        else:
            self._speed_strikes = 0
            self._speed_strike_samples = []
        if max(temp) > L.max_temp_c:
            return f"temp>{L.max_temp_c}C: {temp}"
        return None

    def preflight(self, waypoints, start_q,
                  collision_report_verified: bool = False) -> None:
        """通电前预检：碰撞证据 + 段间 Δq 上限。

        默认仍调用 SDK 的实时碰撞检查。只有上层已经验证离线碰撞报告与
        当前规划的哈希完全一致时，才可显式传入
        ``collision_report_verified=True``，避免在实时串口会话中运行 MuJoCo。
        """
        prev = list(start_q)[:6]
        for name, q in waypoints:
            if collision_report_verified:
                collision_state = "外部报告已验证"
            else:
                if self.check_collision(q):
                    raise RuntimeError(f"路点 {name} 自碰撞检查不通过")
                collision_state = "实时检查通过"
            delta = max(abs(a - b) for a, b in zip(prev, q))
            if delta > self.limits.max_joint_delta_rad:
                raise RuntimeError(f"段->{name} 关节增量 {delta:.3f} 超限 {self.limits.max_joint_delta_rad}")
            print(
                f"路点 {name}: 段增量={delta:.3f} "
                f"碰撞={collision_state}"
            )
            prev = q

    def _motion_feedback(self, target, label, settling, was_waiting):
        measured = list(self._arm.get_pos())
        velocity = list(self._arm.get_vel())
        temperature = list(self._arm.get_temp())
        error = max(abs(float(measured[i]) - target[i]) for i in range(6))
        limit = self.limits.max_track_err_rad * (2.0 if settling else 1.0)
        waiting = self.limits.pause_on_tracking_lag and error > limit
        bad = self.guard(
            measured, velocity, temperature, target,
            settling=settling and not waiting,
            check_tracking=not self.limits.pause_on_tracking_lag,
        )
        if not bad and waiting != was_waiting:
            print(
                f"MOTION_TRACKING_{'WAIT' if waiting else 'RESUME'}"
                f" label={label} error={error:.5f}rad threshold={limit:.5f}rad"
            )
        return bad, waiting

    def move(self, q_from, q_to, label: str, grip_cmd=None, grip_force: float = 0.3):
        """50Hz 斜坡插值 q_from→q_to，每拍过 guard。grip_cmd 非空则同拍下发夹爪。
        返回中止原因或 None。照搬 l4 move（含可选夹爪交替下发）。"""
        L = self.limits
        delta = max(abs(a - b) for a, b in zip(q_from, q_to))
        ramp = max(
            motion_duration_s(
                delta,
                L.v_max_rad_s,
                L.motion_profile,
            ),
            motion_duration_s(
                abs(q_to[J6_INDEX] - q_from[J6_INDEX]),
                L.j6_v_max_rad_s,
                L.motion_profile,
                minimum_s=0.0,
            ),
        )
        if delta > 1e-12 and L.max_acceleration_rad_s2 is not None:
            accel_points, accel_lengths, _ = _validated_joint_path([q_from,q_to])
            ramp = acceleration_limited_path_duration(accel_points,accel_lengths,ramp,
                L.motion_profile,L.max_acceleration_rad_s2,self.dt)
        trajectory_time = 0.0
        waiting = False
        while True:
            cycle_started = time.monotonic()
            u = min(1.0, trajectory_time / ramp)
            a = motion_profile_progress(u, L.motion_profile)
            target = [q_from[i] + a * (q_to[i] - q_from[i]) for i in range(6)]
            self.command_position(target)
            if grip_cmd is not None:
                self._arm.control_gripper(grip_cmd, grip_force)
            bad, waiting = self._motion_feedback(
                target, label, trajectory_time < L.settle_seconds, waiting,
            )
            if bad:
                return f"{label}: {bad}"
            if u >= 1.0 and not waiting:
                return None
            cycle_elapsed = time.monotonic() - cycle_started
            time.sleep(max(0.0, self.dt - cycle_elapsed))
            # Account for routine serial overhead, while bounding a delayed
            # cycle to two trajectory ticks as in the reference controller.
            advance = (
                min(time.monotonic() - cycle_started, 2.0 * self.dt)
                if L.elapsed_cycle_progress else self.dt
            )
            if not waiting:
                trajectory_time = min(ramp, trajectory_time + advance)

    def move_waypoints(
        self,
        waypoints,
        label: str,
        grip_cmd=None,
        grip_force: float = 0.3,
    ):
        """Continuously traverse checked waypoints with one global profile.

        The path remains the same piecewise-linear joint path used by the
        offline checker. Only the first and final waypoint have zero profile
        speed; intermediate safety waypoints are crossed without restarting
        the S-curve.
        """
        points, segment_lengths, total_delta = _validated_joint_path(waypoints)
        L = self.limits
        ramp = _joint_path_motion_duration_prepared(
            points,
            segment_lengths,
            total_delta,
            L.v_max_rad_s,
            L.j6_v_max_rad_s,
            L.motion_profile,
        )
        ramp = acceleration_limited_path_duration(points,segment_lengths,ramp,
            L.motion_profile,L.max_acceleration_rad_s2,self.dt)
        trajectory_time = 0.0
        waiting = False
        while True:
            cycle_started = time.monotonic()
            u = min(1.0, trajectory_time / ramp)
            progress = motion_profile_progress(u, L.motion_profile)
            target = _joint_path_target_prepared(
                points, segment_lengths, total_delta, progress
            )
            self.command_position(target)
            if grip_cmd is not None:
                self._arm.control_gripper(grip_cmd, grip_force)
            bad, waiting = self._motion_feedback(
                target, label, trajectory_time < L.settle_seconds, waiting,
            )
            if bad:
                return f"{label}: {bad}"
            if u >= 1.0 and not waiting:
                return None
            cycle_elapsed = time.monotonic() - cycle_started
            time.sleep(max(0.0, self.dt - cycle_elapsed))
            # Account for routine serial overhead, while bounding a delayed
            # cycle to two trajectory ticks as in the reference controller.
            advance = (
                min(time.monotonic() - cycle_started, 2.0 * self.dt)
                if L.elapsed_cycle_progress else self.dt
            )
            if not waiting:
                trajectory_time = min(ramp, trajectory_time + advance)
