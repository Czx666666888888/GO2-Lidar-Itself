# 机械臂最终融合交付（2026-11-17）

默认全自动，无e/d/s人工确认。抓取与倾倒为独立任务，共用一个串口所有者和零位保持服务。重启服务才能加载本版代码；不要同时启动左右两个服务。

## 任务时序（导航端必须按此调度）

1. 启动机械臂服务：读取当前位置、回零、持续零位保持。
2. Go2探索导航，到采样位置停止并采用原趴下/支撑构型，发送grasp。
3. 等待抓取动作完成并回ZERO_HOLD，再恢复导航；继续探索、抓取、收集。每次抓取完成不会触发倾倒。
4. 全部导航探索及物块收集完成后，Go2返回卸载区。确认到位、停止并恢复示教时的机身支撑构型，物料将倒向Go2后侧，后侧应对准卸载区地面。
5. 导航端此时发送一次dump，执行夹把手、翻倒、停留、复位至80%处松爪、张爪走剩余短段、退出回零保持。
6. 等dump完成且回ZERO_HOLD后才能让Go2继续移动或结束任务。

机械臂没有Go2定位或任务完成信息，无法自行判断“全部探索完成”或“已到卸载区”。该条件由上层导航/任务状态机决定，dump请求即上层开始卸料的指令，不能与每次grasp完成绑定。无需人按确认键。

## 安装及启动

使用Python3.10兼容环境，安装CMake/g++/make，再安装：

```bash
python -m pip install -r requirements-integration.txt
python -m pip install -e ./vendor/S1_SDK_V2-official
```

SDK随包提供源码和原平台文件；跨x86_64/aarch64需要重建SDK并安装目标平台RealSense依赖。environment/pip-freeze-S1.txt仅记录原环境。

从解压后的s1-arm-control根目录运行。原虚拟机Python为/home/ljw/miniforge3/envs/S1/bin/python。

右侧常驻服务：

```bash
OPENBLAS_NUM_THREADS=1 python -uB scripts/run_arm_integration.py --dev /dev/ttyUSB0 --execute
```

左侧服务：

```bash
OPENBLAS_NUM_THREADS=1 python -uB scripts/run_go2_left_grasp.py --dev /dev/ttyUSB0 --execute
```

左右入口共用同一个倾倒计划。不要添加--manual-confirmations。需要配置物块重量时追加--payload-mass-g 实际克数；不传仍使用所选抓取配置中的40g值，这不是硬编码的承载上限。重量是本次服务的统一配置，不是自动称重，不会自动提高夹紧力或电机力矩。

看到INTEGRATION_READY=ZERO_HOLD后，可用命令行或Python请求：

```bash
python scripts/arm_task_client.py status
python scripts/arm_task_client.py grasp
# 只有任务全部完成且返回卸载区后才执行这一条：
python scripts/arm_task_client.py dump
```

Python：将scripts目录加入导入路径，然后：

```python
from arm_task_client import request
# 每个采样点：由导航端先完成停车和支撑状态切换
reply = request('grasp')
# reply['accepted']只表示入队。轮询status等待任务结束后再导航。
# 全部探索、收集完成 -> 导航返回卸载区 -> 停车并恢复原支撑构型
reply = request('dump')
```

Unix socket为/tmp/s1-arm-integration.sock，一行JSON请求响应，例如{"command":"dump"}。

status中busy=true时不重复提交。state为GRASPING/DUMPING时navigation_allowed=false。busy=false后应同时检查state、last_task、last_exit_code、last_result、last_log。成功回零为ZERO_HOLD、last_exit_code=0；last_task为grasp或dump。navigation_allowed只表示机械臂空闲回零，不代表Go2自身稳定性已满足。

失败为FAULT_HOLD或FAULT_IO，不自动恢复导航。卸料中途失败会保持当前位置，若已夹住把手则保持夹紧，不自动松开或强行回零。命令不排队重复执行。Ctrl+C/SIGTERM等活动任务结束后退出，不是立即急停；退出会失能。保持零位依赖服务存活和供电。

## 当前动作参数

- 抓取常规运动、回零、抬升、搬运：1.5rad/s；下降和预抓取微调：0.75rad/s。
- 下降夹爪全开，跟随标定max_gap_mm，当前102.2mm；到低位后原接触探测从65mm起点闭合。
- 接触探测0.20Nm，夹紧及载物保持0.40Nm，相对预紧指令12mm。力矩参数不是实测指尖夹持力。
- 预抓取高度误差<=10mm通过，>10mm沿原机制修正；高位最终视觉对准5mm标准保留。
- 倾倒接近/退出/回零1.5rad/s，翻倒1.0rad/s，复位1.5rad/s，卸料停留2s。restore_release_fraction=0.8按逆序关节路径累计长度定义，不是盒子角度或经过时间百分比。
- 配置config/go2_hinged_box_dump.json包含最新实机示教路径。相邻重复点仅在回放时合并，原始示教记录保留。
- 额外倾斜补偿和新增的加速度时间缩放默认关闭；SDK原生重力补偿保留。抓取J6映射补偿边界浮点误判已修复。

## 标定及机械状态

D455序列号231622302209，原夹爪、金属支架双白灯、原S1/Go2安装和趴下支撑构型。所有关节以弧度表示。转轴盒及把手位置、转轴方向、机身姿态改变后，旧示教路径不能直接代表新位置。若安装转轴/把手改变了盒口位置，需核对原投放位标定。随包标定和绑定计划保留原字节与SHA256，旧/home/ljw/桌面/s1-arm-control前缀映射到解压根目录。

原固定放盒路径的载荷模型参考300g，配置重量会线性换算该路径的载荷增量并记录日志，超出旧设计余量不按固定重量拒绝。该估计不覆盖新翻盒路径和满盒载荷，不是整机稳定性或额定载荷证明。没有把物块重量当成盒子加全部物料的总重量。

已有侧翻现象，当前包不含Go2整机重心/支撑多边形控制。优先采样点仍是右侧S1基座X≈0、Y≈310mm附近；左侧镜像仅作测试参考，不能当作已验证安全区。+X朝后、+Y朝右。不能把IK通过或手扶完成视为稳定承载通过。

## 运行证据与结果含义

最新dump_20261117-010027-864700日志显示倾倒/复位/回零动作完成。DUMP_MOTION_DONE_UNLOAD_UNVERIFIED的unload_confirmed仍为null，程序没有盒内判空传感器；不宣称自动确认卸空。

抓取结果VISUAL_ADAPTIVE_GRASP_BOX_MOTION_DONE_PLACEMENT_UNVERIFIED表示动作完成，未通过相机确认盒内落物。全自动确认的是控制流程，不替代实际投放/卸空判定。

本包不自动启动录像，相机按原抓取方式采样；不需要S1_RGBD_RECORD_SOCKET环境变量。

## 离线验证

```bash
python -B scripts/verify_handoff.py
python -B scripts/verify_handoff.py --tests
```

离线验证不打开相机和串口。VALIDATION.json记录模块和结果，SHA256SUMS为逐文件校验。包含SDK、标定、运行计划、回放测试所需数据、最新卸料示教及运行日志，未包含全部历史日志、SSH密钥、.git和缓存。示教工具仅用于后续结构变化后的重新记录，正常融合不运行示教脚本。
